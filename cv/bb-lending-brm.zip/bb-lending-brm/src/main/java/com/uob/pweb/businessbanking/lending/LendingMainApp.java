package com.uob.pweb.businessbanking.lending;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.dsl.Files;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.uob.pweb.businessbanking.lending.configuration.LookupConfiguration;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.common.framework.CommonConfig;
import com.uob.pweb.common.framework.myinfo.MyInfoConfig;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;
import com.uob.pweb.component.JsonMapper;
import com.uob.pweb.component.JwtBuilder;
import com.uob.pweb.component.KeyManagementBuilder;
import com.uob.pweb.component.KeyManagementBuilder.KeyManagementConfig.PrivateKey;
import com.uob.pweb.component.ObjectMapperBuilder;
import com.uob.pweb.component.RestTemplateBuilder;
import com.uob.pweb.component.brm.BrmBuilder;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@PropertySource(
    value = {"classpath:default.properties", "file://${external-config-path}"})
@Import({CommonConfig.class, MyInfoConfig.class, MyInfoValidation.class})
@ComponentScan({"com.uob.pweb.common.framework.integrations.logging",
    "com.uob.pweb.businessbanking.lending", "com.uob.pweb.common.framework.myinfo"})
@IntegrationComponentScan({"com.uob.pweb.common.framework.integrations.logging",
    "com.uob.pweb.businessbanking.lending", "com.uob.pweb.common.framework.myinfo"})
@Slf4j
public class LendingMainApp extends SpringBootServletInitializer
    implements RestTemplateBuilder, ObjectMapperBuilder, BrmBuilder, JwtBuilder,
    KeyManagementBuilder {

  public static void main(String[] args) {
    SpringApplication.run(LendingMainApp.class, args);
  }

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(LendingMainApp.class);
  }

  @Bean
  public JsonMapper jsonMapper(@Value("classpath:json/brm-0.13.json") Resource brmJson,
      @Value("classpath:json/bb-1.0.0.json") Resource bbJson) throws IOException {

    Map<String, String> mapperMap = new HashMap<String, String>();
    mapperMap.put("brm-0.13.json",
        new BufferedReader(new InputStreamReader(brmJson.getInputStream())).lines()
            .collect(Collectors.joining(System.lineSeparator())));
    mapperMap.put("bb-1.0.0.json",
        new BufferedReader(new InputStreamReader(bbJson.getInputStream())).lines()
            .collect(Collectors.joining(System.lineSeparator())));

    return new JsonMapper(
        new ObjectMapperBuilder() {}.objectMapper(new ObjectMapperConfig()), mapperMap);
  }

  @Bean
  public IntegrationFlow fileRefreshFlow(
      @Value("${config.file.path}") String configFilePath,
      @Value("${config.file.interval:1}") long interval,
      @Value("${config.file.name:lending.json}") String lending,
      ObjectMapper objectMapper, SpecificationService specificationService) {
    return IntegrationFlows.from(Files.inboundAdapter(new File(configFilePath))
        .autoCreateDirectory(true)
        .regexFilter("(corppass-mapping.properties|" + lending + ")")
        .watchEvents(FileReadingMessageSource.WatchEventType.CREATE,
            FileReadingMessageSource.WatchEventType.MODIFY)
        .useWatchService(true)
        .scanEachPoll(true)
        .preventDuplicates(false),
        e -> e.poller(Pollers.fixedDelay(interval, TimeUnit.MINUTES)
            .maxMessagesPerPoll(Integer.MAX_VALUE)))
        .<File, Resource>transform(p -> new FileSystemResource(p))
        .<Resource>handle((p, h) -> {
          try {
            log.info("Lending App: refreshing file {}", p.getFilename());

            if (p.getFilename()
                .equalsIgnoreCase(lending)) {
              specificationService.initiate(p, objectMapper);
            } else {
              LookupConfiguration.initiate(p);
            }

            log.info("Lending App: File {} is refreshed", p.getFilename());

          } catch (Exception ioEx) {
            log.error("Error refreshing json specs {}", ioEx);
          }
          return null;
        })
        .get();
  }

  @Bean
  public HttpSessionEventPublisher httpSessionEventPublisher() {
    return new HttpSessionEventPublisher();
  }

  @Bean
  public CookieSerializer cookieSerializer() {
    DefaultCookieSerializer serializer = new DefaultCookieSerializer();
    serializer.setCookieName("JSESSIONID");
    return serializer;
  }

  @Bean
  public RestTemplateConfig restTemplateConfig() {
    return new RestTemplateConfig();
  }

  @Bean
  public KeyManagementConfig keyManagementConfig(
      @Value("${jwt.trustore.path:}") String storepath,
      @Value("${jwt.trustore.pass:}") String storepass,
      @Value("${jwt.trustore.key1:}") String key1,
      @Value("${jwt.trustore.key2:}") String key2,
      @Value("${jwt.trustore.pwd:}") String pwd) {
    KeyManagementConfig.PrivateKey privateKey = new KeyManagementConfig.PrivateKey();
    privateKey.setAlias("bbbrm");
    privateKey.setPath(storepath);
    privateKey.setStorepass(storepass);

    PrivateKey.File file = new PrivateKey.File();
    file.setKey1(key1);
    file.setKey2(key2);
    file.setPwd(pwd);

    privateKey.setFile(file);

    KeyManagementConfig keyManagementConfig = new KeyManagementConfig();
    keyManagementConfig.setPrivateKey(privateKey);

    return keyManagementConfig;
  }

  @Bean
  public JwtConfig jwtConfig(KeyManagement keyManagement) {
    JwtConfig jwtConfig = new JwtConfig();
    jwtConfig.setSubject("{\"id\":\"16b552caa631f54419dc8ce4938c17fd\"}");
    jwtConfig.setIss("https://PWEB.com.sg");
    jwtConfig.setPrivateKey(keyManagement.getPrivateKey());

    return jwtConfig;
  }

  @Bean
  public BrmConfig brmConfig(Jwt jwt, RestTemplate restTemplate) {
    BrmConfig brmConfig = new BrmConfig();
    brmConfig.setJwt(jwt);
    brmConfig.setRestTemplate(restTemplate);

    return brmConfig;
  }

  @Override
  public ObjectMapper objectMapper() {
    ObjectMapperConfig objectMapperConfig = new ObjectMapperConfig();
    objectMapperConfig.setPropertyNamingStrategy(PropertyNamingStrategy.UPPER_CAMEL_CASE);
    return this.objectMapper(objectMapperConfig);
  }
}

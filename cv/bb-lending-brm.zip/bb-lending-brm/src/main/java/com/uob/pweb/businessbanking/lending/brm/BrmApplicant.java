package com.uob.pweb.businessbanking.lending.brm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.jayway.jsonpath.JsonPath;
import com.uob.pweb.businessbanking.lending.component.Applicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.Noa;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.OnlineFormAddress;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.component.brm.BrmDate;
import com.uob.pweb.component.brm.IdType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@Slf4j
public class BrmApplicant implements Applicant {

  @JsonProperty("ApplicationId")
  private String applicationId;

  @JsonProperty("ApplicantId")
  private String applicantId;

  @JsonProperty("ApplicationReferenceNumber")
  private String applicationReferenceNumber;

  @JsonProperty("PrincipalDetails")
  private PrincipalDetails principalDetails;

  public String findApplicantId() {
    return applicantId;
  }

  
  
  private List<Map<String,Object>> findIncomeDetails(LendingApplicant lendingApplicant){
	    List<Noa> noa = lendingApplicant.getNoaHistory();
	    List<Map<String,Object>> noaList = new ArrayList<>();
	   if(Objects.nonNull(noa) && noa.size()>0) {
	      for(Noa noaAddrs : noa) {
		    Map<String, Object> noahistory = new HashMap<>();
		   	noahistory.put("yearlyAssessableIncomeInSGD",noaAddrs.getAmount());
		    noahistory.put("EmploymentIncome",noaAddrs.getEmployment());
		    noahistory.put("Category",noaAddrs.getCategory());
		    noahistory.put("TaxClearenceIndicator","Y".equalsIgnoreCase(noaAddrs.getTaxClearance()) ? true : false);
		    noahistory.put("TradeIncome",noaAddrs.getTrade());
		    noahistory.put("YearOfAssessment",noaAddrs.getYearOfAssessment());
		    noahistory.put("RentalIncome",noaAddrs.getRent());
		    noahistory.put("Currency","SGD");
		    noaList.add(noahistory); 
	    }
	   }
	    return noaList;
  }
  
  
 private Map<String,String>findRegisteredAddress(OnlineFormAddress addrs){
	  Map<String, String> regstAddrs = new LinkedHashMap<>();
	  regstAddrs.put("AddressFormat",SpecificationService.brmMapping().getHouseTypes().getOrDefault(addrs.getPropertyType(),Strings.EMPTY));
	  regstAddrs.put("Street", addrs.getStreet());
	  regstAddrs.put("Block", addrs.getBlock());
	  regstAddrs.put("buildingName", addrs.getBuilding());
	  regstAddrs.put("StoreyNo", addrs.getFloor());
	  regstAddrs.put("UnitNo", addrs.getUnitNo());
	  regstAddrs.put("Country", addrs.getCountry());
	  regstAddrs.put("PostalCode", addrs.getPostalCode());
	  regstAddrs.put("AddressLine1", addrs.getLine1());
	  regstAddrs.put("AddressLine2", addrs.getLine2());
	  regstAddrs.put("AddressLine3", addrs.getLine3());
	  regstAddrs.put("AddressLine4", addrs.getLine4());
	  return regstAddrs;
  }
  
   public BrmApplicant update(LendingApplicant lendingApplicant) {
    log.info("****update lending applicant {}********",lendingApplicant);
	Map<String, Object> personalDetails = JsonPath.parse(principalDetails.getPersonalDetails()).json();
    personalDetails.put("ContactNo", lendingApplicant.getBasicInfo().getMobileNumber());
    personalDetails.put("Name", lendingApplicant.getBasicInfo().getPrincipalName());
    personalDetails.put("MaritalStatus", lendingApplicant.getPersonalInfo().getMaritalStatus());
    personalDetails.put("Gender", lendingApplicant.getPersonalInfo().getGender());
    personalDetails.put("DateOfBirth", BrmDate.getBrmDate(lendingApplicant.getPersonalInfo().getDateOfBirth()));
    personalDetails.put("CountryOfBirth", lendingApplicant.getPersonalInfo().getCountryOfBirth());
    personalDetails.put("CountryOfCitizenship", StringUtils.isBlank(lendingApplicant.getPersonalInfo().getNationality())? "SG" :lendingApplicant.getPersonalInfo().getNationality());
    personalDetails.put("IdType", IdType.getIndividualType(lendingApplicant.getBasicInfo().getLegalId()));
    personalDetails.put("Email", lendingApplicant.getBasicInfo().getEmailAddress());
    personalDetails.put("Alias", lendingApplicant.getBasicInfo().getAlternateNames().getAlias());
    personalDetails.put("HanYuPinYinName", lendingApplicant.getBasicInfo().getAlternateNames().getHanYuPinYinName());
    personalDetails.put("HanYuPinYinAliasName", lendingApplicant.getBasicInfo().getAlternateNames().getHanYuPinYinAliasName());
    personalDetails.put("MarriedName", lendingApplicant.getBasicInfo().getAlternateNames().getMarriedName());
    personalDetails.put("IncomeDetails",findIncomeDetails(lendingApplicant));
    personalDetails.put("PersonalRegisteredAddress",findRegisteredAddress(lendingApplicant.getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null)));
    
    return this;
  }

  @Data
  @AllArgsConstructor
  public static class PrincipalDetails {
    @JsonProperty("PersonalDetails")
    private Object personalDetails;
  }

}

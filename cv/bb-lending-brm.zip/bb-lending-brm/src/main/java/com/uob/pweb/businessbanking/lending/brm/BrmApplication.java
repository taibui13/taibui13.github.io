package com.uob.pweb.businessbanking.lending.brm;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.uob.pweb.component.EntityPersonResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.util.Strings;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.uob.pweb.businessbanking.lending.brm.BrmApplicant.PrincipalDetails;
import com.uob.pweb.businessbanking.lending.component.ApplicationForm;
import com.uob.pweb.businessbanking.lending.form.AdditionalAppointment;
import com.uob.pweb.businessbanking.lending.form.Business;
import com.uob.pweb.businessbanking.lending.form.Business.Address;
import com.uob.pweb.businessbanking.lending.form.Business.Appointment;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.OnlineFormAddress;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.component.JsonMapper;
import com.uob.pweb.component.ObjectMapperUtil;
import com.uob.pweb.component.brm.IdType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder.Default;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONArray;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class BrmApplication implements ApplicationForm, Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -5824536896265226302L;
  @JsonProperty("ApplicationId")
  private String applicationId;
  @JsonProperty("ProductCode")
  private String productCode;
  @JsonProperty("SourceType")
  private String sourceType;
  @JsonProperty("ApplicationStatus")
  private String applicationStatus;
  @JsonProperty("TrackingCode")
  private String trackingCode;
  @JsonProperty("CompanyDetails")
  private Object companyDetails;
  @JsonProperty("SupplementaryInfo")
  @Default private List<SupplementaryInfo> supplementaryInfo = new ArrayList<SupplementaryInfo>();
  @JsonProperty("PrincipalList")
  public List<Object> principalList;
  @JsonProperty("ApplicationReferenceNumber")
  private String applicationReferenceNumber;
  @JsonProperty("ExpiryDate")
  private String expiryDate;
  @JsonProperty("InitiateDate")
  private String initiateDate;

  @JsonIgnore
  private String createdDate;

  @JsonIgnore
  private String applicantId;

  public String findApplicationId() {
    return applicationId;
  }

  public List<SupplementaryInfo> getAppoitmentList(LendingApplicationForm lendingApplicationForm) throws JsonProcessingException{
	  List<SupplementaryInfo> bbApmtList = new ArrayList<>();
	  ObjectMapper objMapper = ObjectMapperUtil.getObjectMapper();
	  int count = 1;
	  for(Appointment appointment : lendingApplicationForm.getEntity().getAppointments()) {
		  bbApmtList.add(SupplementaryInfo.builder().name("Appoitments"+count++)   
			      .contents(Arrays.asList(objMapper.writeValueAsString(appointment))).build());
	  }
	  return bbApmtList;
  }
  
  public List<Appointment> SetAppointmentList(LendingApplicationForm lendingApplicationForm, String apmtStr) throws JsonParseException, JsonMappingException, IOException {
	  ObjectMapper objMapper = ObjectMapperUtil.getObjectMapper();
	  List<Appointment> apmtList  = objMapper.readValue(apmtStr, new TypeReference<List<Appointment>>(){});
      return apmtList;
  }
  
  public String getProductCodeFromSource(String sourceType) {
	  String pcode = ""; 
	  if(Objects.nonNull(sourceType)) {
	    String[] code = Stream.of(sourceType).filter(p -> p.contains("=")).findAny().get().split("=");
	    pcode = code[1];
	  }
	  return pcode; 
  }
   
  
  // for application form
  
  public List<SupplementaryInfo>setSupInfo(LendingApplicationForm lendingApplicationForm) throws Exception{
	  List<SupplementaryInfo>supplementaryInfoList = new ArrayList<>();

	  supplementaryInfoList.add(SupplementaryInfo.builder().name("residentialStatus")   
              .contents(Arrays.asList(lendingApplicationForm.findCurrentApplicant().getBasicInfo().getResidentialStatus())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("trackingCode")   
              .contents(Arrays.asList(lendingApplicationForm.getSourceType())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("buildingName")   
			  .contents(Arrays.asList((lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null)).getBuilding())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("entityType")   
              .contents(Arrays.asList(lendingApplicationForm.getEntity().getBasicProfile().getEntityType())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("companyType")   
              .contents(Arrays.asList(lendingApplicationForm.getEntity().getBasicProfile().getCompanyType())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("businessConstitution")   
              .contents(Arrays.asList(lendingApplicationForm.getEntity().getBasicProfile().getBusinessConstitution())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("CountryOfBirth")   
              .contents(Arrays.asList(lendingApplicationForm.findCurrentApplicant().getPersonalInfo().getCountryOfBirth())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("DateOfBirth")   
              .contents(Arrays.asList(lendingApplicationForm.findCurrentApplicant().getPersonalInfo().getDateOfBirth())).build());
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("propertyType")   
              .contents(Arrays.asList((lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null)).getPropertyType())).build());
	  supplementaryInfoList.addAll(getAppoitmentList(lendingApplicationForm));
	  supplementaryInfoList.add(SupplementaryInfo.builder().name("MainApplicantName")
               .contents(Arrays.asList(lendingApplicationForm.findCurrentApplicantPrincipalName())).build());
      return supplementaryInfoList;
  }
  
  

  public ApplicationForm create(LendingApplicationForm lendingApplicationForm,
      JsonMapper jsonMapper, Object businessInfo){

    // map base
    BrmApplication brmApplication =
        jsonMapper.map("brm-0.13.json", businessInfo, BrmApplication.class);
    
    try {             
    		brmApplication.setSupplementaryInfo(setSupInfo(lendingApplicationForm));                        		   
    	} catch (Exception e) {
			e.printStackTrace();
		}
    
 // map values

    brmApplication.setProductCode(lendingApplicationForm.getProduct()
        .getBrm());
    brmApplication.setTrackingCode(lendingApplicationForm.getSourceType());
    
    Map<String, Object> businessDetails = JsonPath.parse(brmApplication.getCompanyDetails()).read("$.BusinessDetails");
    String coi = (String)businessDetails.get("CountryOfIncorporation");
    
    if(StringUtils.isBlank((String)businessDetails.get("CountryOfIncorporation"))){
        businessDetails.put("CountryOfIncorporation","SG");
     } else {
    	 businessDetails.put("CountryOfIncorporation",businessDetails.get("CountryOfIncorporation"));
     }
    
    // update email address
    Map<String, Object> basicDetails = JsonPath.parse(brmApplication.getCompanyDetails())
        .read("$.BasicDetails");
       
    basicDetails.put("Email", lendingApplicationForm.findEmailAddress());
    
    OnlineFormAddress ofa = lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null);
	List<Map<String,Object>> personalDetails = JsonPath.parse(brmApplication.getPrincipalList()) .read("$..PersonalDetails[?(@.IsMainApplicant == true)]");
		 for(Map<String,Object> PersonalDetails : personalDetails) {
			    @SuppressWarnings("unchecked")
				Map<String, Object>pra = (Map<String,Object>)PersonalDetails.get("PersonalRegisteredAddress");
			    pra.put("AddressFormat",SpecificationService.brmMapping().getHouseTypes().getOrDefault(ofa.getPropertyType(),Strings.EMPTY));
			   }
   
    
    @SuppressWarnings("unchecked")
    Map<String, Object> mainApplicant =
        ((List<Map<String, Object>>) JsonPath.parse(brmApplication.getPrincipalList())
            .read("$..PersonalDetails[?(@.IsMainApplicant == true)]")).iterator()
                .next();
    
     mainApplicant.put("Email", lendingApplicationForm.findEmailAddress());
    
    // update share holders
    JSONArray capitalAmountArray = JsonPath.parse(brmApplication.getCompanyDetails())
        .read(
            "$.EntityDetails.BusinessCapitalDetails[?(@.BusinessType == 'Ordinary Capital' && @.SharedAllottedAmount)].SharedAllottedAmount");

    if (!capitalAmountArray.isEmpty()) {
      final String capitalAmount = capitalAmountArray.iterator().next()
          .toString();

      // get share holders
      List<Map<String, Object>> applicantList =
          JsonPath.parse(brmApplication.getPrincipalList())
              .read("$..PersonalDetails");

      Map<String, List<Map<String, Object>>> applicantsMap = new HashMap<>();
      for (Map<String, Object> applicant : applicantList) {
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> positions =
            (List<Map<String, Object>>) applicant.get("Positions");
        for (Map<String, Object> position : positions) {
          if ("S".equals(position.get("PositionType"))) {

            BigDecimal sharePercentage = new BigDecimal(applicant.get("Allocation")
                .toString()).multiply(new BigDecimal("100"))
                    .divide(new BigDecimal(capitalAmount));
            sharePercentage.setScale(2, RoundingMode.HALF_EVEN);

            applicant.put("ShareholderPercentage", sharePercentage);

            position.put("ShareholdingPercentage", sharePercentage.toPlainString() + "%");
            position.put("EffectiveShareholding", sharePercentage);
          }
        }

        if (applicantsMap.get((String) applicant.get("IdNo")) == null) {
            List appsList = new ArrayList();
            appsList.add(applicant);
            applicantsMap.put((String) applicant.get("IdNo"), appsList);
        } else {
            applicantsMap.get((String) applicant.get("IdNo")).add(applicant);
        }
      }

      List<Map<String, Object>> newApplicantsList = new ArrayList<>();
      for (List<Map<String, Object>> applicants : applicantsMap.values()) {
          if (applicants.size() > 1) {
              List<Map<String, Object>> newPositions = new ArrayList<>();
              for (Map<String, Object> app : applicants) {
                  List<Map<String, Object>> positions = (List<Map<String, Object>>) app.get("Positions");
                  newPositions.addAll(positions);
                  positions.forEach(pos -> {
                      if ("S".equals(pos.get("PositionType"))) {
                          newApplicantsList.add(app);
                      }
                  });
              }
              newApplicantsList.get(newApplicantsList.size() - 1).put("Positions", newPositions);
          } else {
              newApplicantsList.add(applicants.get(0));
          }
      }

      Map<String, Object> map = new HashMap<>();
      brmApplication.getPrincipalList().clear();
      newApplicantsList.forEach(app -> {
          if ((boolean) app.get("IsMainApplicant")) {
              map.put("PersonalDetails", app);
              brmApplication.getPrincipalList().add(map);
          }
      });
      newApplicantsList.remove(((Map<String, Object>)brmApplication.getPrincipalList().get(0)).get("PersonalDetails"));
      for(Map<String, Object> app : newApplicantsList) {
          Map<String, Object> map2 = new HashMap<>();
          map2.put("PersonalDetails", app);
          brmApplication.getPrincipalList().add(map2);
      };
    }

    // Filling Category and ShareType for Main Applicant
    String mainAppCategory = (String) ((Map<String, Object>) ((Map<String, Object>) brmApplication.getPrincipalList().get(0)).get("PersonalDetails")).get("Category");
    String mainShareTypeCategory = (String) ((Map<String, Object>) ((Map<String, Object>) brmApplication.getPrincipalList().get(0)).get("PersonalDetails")).get("ShareType");
    if (StringUtils.isBlank(mainAppCategory) || NumberUtils.isParsable(mainAppCategory)) {
        String catInAppointment = NumberUtils.isParsable(mainAppCategory)
            ? mainAppCategory
            : (String) ((List<Map<String,Object>>) ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) ((EntityPersonResponse) businessInfo).getEntityPerson())).get("entity")).get("appointments")).get(0).get("category");
        SpecificationService.brmMapping().getShareholderCategories().forEach((k, v) -> {
            if (v.equals(catInAppointment)) {
                ((Map<String, Object>) ((Map<String, Object>) brmApplication.getPrincipalList().get(0)).get("PersonalDetails")).put("Category", k);
            }
        });
    }
    if (!StringUtils.isBlank(mainShareTypeCategory) && NumberUtils.isParsable(mainShareTypeCategory)) {
        SpecificationService.brmMapping().getShareTypes().forEach((k, v) -> {
            if (v.equals(mainShareTypeCategory)) {
                ((Map<String, Object>) ((Map<String, Object>) brmApplication.getPrincipalList().get(0)).get("PersonalDetails")).put("ShareType", k);
            }
        });
    }

      // Resize positions array for each applicant
      List<Object> newPrincipalsList = new ArrayList<>();
      for (Object princTemp : brmApplication.getPrincipalList()) {
          Map<String, Object> principal = (Map<String, Object>) princTemp;
          List<LinkedHashMap> appPositions = new ArrayList<>();
          ((List<LinkedHashMap>) ((Map<String, Object>)principal.get("PersonalDetails")).get("Positions")).stream().forEach(pos -> {
              if (!appPositions.contains(pos)) {
                  appPositions.add(pos);
              }
          });
          ((Map<String, Object>)principal.get("PersonalDetails")).put("Positions", appPositions);
          newPrincipalsList.add(principal);
      };
      brmApplication.setPrincipalList(newPrincipalsList);

      List<Map<String, Object>> companyAddressList =
          JsonPath.parse(brmApplication.getCompanyDetails()).read("$.BusinessDetails.CompanyAddressList");
      if (companyAddressList != null && companyAddressList.size() == 1) {
          companyAddressList.get(0).put("IsSameAsRegisteredAddress", true);
      }

      return brmApplication;
  }

  @SuppressWarnings("unchecked")
  public ApplicationForm update(LendingApplicationForm lendingApplicationForm,
      JsonMapper jsonMapper) {

    // set id
    this.setApplicationId(lendingApplicationForm.getId());
    this.setTrackingCode(lendingApplicationForm.getSourceType()); 
    this.setSourceType("PWEB - MyInfo");
    
    List<Map<String, Object>> companyAddressList =
        JsonPath.parse(this.getCompanyDetails()).read("$.BusinessDetails.CompanyAddressList");

    // map mailing address
    for (Address address : lendingApplicationForm.getEntity()
        .getAddresses()) {
      if ("M".equals(address.getType())) {
        companyAddressList.add(mapMailingAddress(address, false));
      }
    }

    // map same as registered address
//    if (companyAddressList.size() == 1) {
//      for (Address address : lendingApplicationForm.getEntity()
//          .getAddresses()) {
//        if ("R".equals(address.getType())) {
//          companyAddressList.add(mapMailingAddress(address, true));
//        }
//      }
//    }

    if (companyAddressList.size() == 1) {
        companyAddressList.get(0).put("IsSameAsRegisteredAddress", true);
    } else if (companyAddressList.size() == 2) {
        companyAddressList.get(0).put("IsSameAsRegisteredAddress", false);
        companyAddressList.get(1).put("IsSameAsRegisteredAddress", false);
    }

    // map marital status
    Map<String, Object> mainApplicant =
        ((List<Map<String, Object>>) JsonPath.parse(this.getPrincipalList())
            .read("$..PersonalDetails[?(@.IsMainApplicant == true)]")).iterator() .next();
    mainApplicant.put("MaritalStatus", lendingApplicationForm.findCurrentApplicant().getPersonalInfo().getMaritalStatus());
       
    // map to tax clerence
     List<Map<String,Object>> personalDetails = JsonPath.parse(this.getPrincipalList()) .read("$..PersonalDetails[?(@.IsMainApplicant == true)]");
	 for(Map<String,Object> PersonalDetails : personalDetails) {
	    List<Map<String, Object>> incDetails = (List<Map<String, Object>>)PersonalDetails.get("IncomeDetails");
	     if(Objects.nonNull(incDetails))
	    	 	for(Map<String, Object> incObj : incDetails) {
	    		if(incObj.get("TaxClearenceIndicator").equals("Y")) 
	    		 incObj.put("TaxClearenceIndicator", true);
	    		 else incObj.put("TaxClearenceIndicator", false);
	       }
	 }
    
    
    // update appointment list
    List<Map<String, Object>> partnerApplicantList =JsonPath.parse(this.getPrincipalList()).read("$..PersonalDetails[?(@.IsMainApplicant == false)]");
    List<Map<String, Object>> newPartnerApplicantList = new ArrayList<Map<String, Object>>();
     // add guarantor
    for (Map<String, Object> partnerApplication : partnerApplicantList) {
        boolean found = false;
      for (AdditionalAppointment additionalAppointment : lendingApplicationForm.getAdditionalAppointment()) {
        if (additionalAppointment.getLegalId().equals(partnerApplication.get("IdNo"))) {
          found = true;
          partnerApplication.put("ContactNo", additionalAppointment.getMobileNumber());
          partnerApplication.put("Email", additionalAppointment.getEmailAddress());
           break;
        }
      }

      if (!found) {
        List<Map<String, Object>> positions =
            (List<Map<String, Object>>) ((Map<String, Object>) partnerApplication)
                .get("Positions");

        for (Map<String, Object> position : positions) {
          if ("G".equals(position.get("PositionType"))) {
            positions.remove(position);
            break;
          }
        }
      }
    }

    for (AdditionalAppointment additionalAppointment : lendingApplicationForm.getAdditionalAppointment()) {
          boolean partnerFound = false;
       
       for (Map<String, Object> partnerApplication : partnerApplicantList) {
        if (partnerApplication.get("IdNo").equals(additionalAppointment.getLegalId())) {
            partnerFound = true;
            break;
        }
      }
      
      if (!partnerFound) {
        Map<String, Object> newPartner = new HashMap<>();
        newPartner.put("IsMainApplicant", false);
        newPartner.put("IdNo", additionalAppointment.getLegalId());
        newPartner.put("Name", additionalAppointment.getName());
        newPartner.put("Type", "Individual");
        newPartner.put("IdType", IdType.getIndividualType(additionalAppointment.getLegalId()));
        newPartner.put("ContactNo", additionalAppointment.getMobileNumber());
        newPartner.put("Email", additionalAppointment.getEmailAddress());
        Map<String, Object> position = new HashMap<>();
        position.put("PositionType", "G");
        List<Map<String, Object>> positionList = new ArrayList<>();
        positionList.add(position);
        newPartner.put("Positions", positionList);
        Map<String, Object> newPersonalDetails = new HashMap<>();
        newPersonalDetails.put("PersonalDetails", newPartner);
        newPartnerApplicantList.add(newPersonalDetails);
      }
    }

    // add new guarantor
    this.getPrincipalList().addAll(newPartnerApplicantList);
    return this;
  }

  public Map<String, Object> mapMailingAddress(Business.Address businessAddress,
      boolean IsSameAsRegisteredAddress) {

    Map<String, Object> mailingAddress = new LinkedHashMap<>();

    mailingAddress.put("AddressType", businessAddress.getType());
    mailingAddress.put("AddressFormat",
        "SG".equals(businessAddress.getCountry()) ? null : "F");
    mailingAddress.put("buildingName", businessAddress.getBuilding());
    mailingAddress.put("Block", businessAddress.getBlock());
    mailingAddress.put("StreetName", businessAddress.getStreet());
    mailingAddress.put("Floor", businessAddress.getFloor());
    mailingAddress.put("UnitNo", businessAddress.getUnitNo());
    mailingAddress.put("PostalCode", businessAddress.getPostalCode());
    mailingAddress.put("IsSameAsRegisteredAddress", IsSameAsRegisteredAddress);
    mailingAddress.put("AddressLine1", businessAddress.getLine1());
    mailingAddress.put("AddressLine2", businessAddress.getLine2());
    mailingAddress.put("AddressLine3", businessAddress.getLine3());
    mailingAddress.put("AddressLine4", businessAddress.getLine4());
    mailingAddress.put("City", businessAddress.getCity());
    mailingAddress.put("Country", businessAddress.getCountry());

    return mailingAddress;
  }

  // for lending application form
  @SuppressWarnings("unchecked")
  public LendingApplicationForm to(JsonMapper jsonMapper,
      SpecificationService specificationService) {

    
	List<SupplementaryInfo> supplementaryInfoList  = this.getSupplementaryInfo();
	// map to tax clearance
	List<Map<String,Object>> personalDetails = JsonPath.parse(this.getPrincipalList()) .read("$..PersonalDetails[?(@.IsMainApplicant == true)]");
	 for(Map<String,Object> PersonalDetails : personalDetails) {
	    List<Map<String, Object>> incDetails = (List<Map<String, Object>>)PersonalDetails.get("IncomeDetails");
	    	  if(Objects.nonNull(incDetails))
	    	  for(Map<String, Object> incObj : incDetails) {
	    		if((Boolean)incObj.get("TaxClearenceIndicator") == true) incObj.put("TaxClearenceIndicator", "Y");
	    	   	 else incObj.put("TaxClearenceIndicator", "N");
	              }
	      }
	  // rearrange person main applicant must be at 0
	Object principalList = JsonPath.parse(this.getPrincipalList()) .read("$..PersonalDetails[?(@.IsMainApplicant == true)]");
    if (principalList != null && ((List<Map<String, Object>>) principalList).iterator().hasNext())
         {
       
      Map<String, Object> mainApplicant = ((List<Map<String, Object>>) principalList).iterator().next();
        for (int i = 0; i < this.principalList.size(); i++) {
         
    	  Map<String, Object> lendingApplicant = (Map<String, Object>) this.principalList.get(i);
    
        if (((Map<String, Object>) lendingApplicant.get("PersonalDetails")).get("IdNo").equals(mainApplicant.get("IdNo"))) {
          
          Map<String, Object> firstApplicant = (Map<String, Object>) this.principalList.get(0);
          this.principalList.set(0, lendingApplicant);
          this.principalList.set(i, firstApplicant);

          break;
        }
      }
    }
 
    LendingApplicationForm lendingApplicationForm = jsonMapper.map("bb-1.0.0.json", this, LendingApplicationForm.class);

    lendingApplicationForm.getEntity().getShareholders().stream().forEach(sh -> {
        if (!NumberUtils.isParsable(sh.getCategory()))
            sh.setCategory(specificationService.getLendingConfig().getBrmMapping().getShareholderCategories().get(sh.getCategory()));
        if (!NumberUtils.isParsable(sh.getShareType()))
            sh.setShareType(specificationService.getLendingConfig().getBrmMapping().getShareTypes().get(sh.getShareType()));
    });
    lendingApplicationForm.findCurrentApplicant().getBasicInfo().setMobileNumber(lendingApplicationForm.getMobileNum()); 
    lendingApplicationForm.setInitiateDate(this.getInitiateDate());
    lendingApplicationForm.setExpiryDate(this.getExpiryDate());
    lendingApplicationForm.setReferenceNumber(this.getApplicationReferenceNumber());

    // Set capitals to list of one element only
    if (lendingApplicationForm.getEntity().getCapitals() != null
        && !lendingApplicationForm.getEntity().getCapitals().isEmpty()) {
        Business.Capital mergedCapital =  lendingApplicationForm.getEntity().getCapitals().get(0);
        lendingApplicationForm.getEntity().getCapitals().stream().forEach(capital -> {
            if (mergedCapital.getIssuedCapitalAmount() == null
                && capital.getIssuedCapitalAmount() != null) {
                mergedCapital.setIssuedCapitalAmount(capital.getIssuedCapitalAmount());
            }
            if (mergedCapital.getPaidUpCapitalAmount() == null
                && capital.getPaidUpCapitalAmount() != null) {
                mergedCapital.setPaidUpCapitalAmount(capital.getPaidUpCapitalAmount());
            }
        });
        lendingApplicationForm.getEntity().setCapitals(Collections.singletonList(mergedCapital));
    }
    
    // map to pweb value for tax clearance
     for(int i=0;i<supplementaryInfoList.size();i++) {
      	 Map<String, Object> info = (Map<String, Object>) supplementaryInfoList.get(i);
    	try {
      	  String name = (String) info.get("Name");
    	  List<String> contents = (List<String>) info.get("Contents");
          if(name.equalsIgnoreCase("residentialStatus"))
        	  	lendingApplicationForm.findCurrentApplicant().getBasicInfo().setResidentialStatus(contents.get(0));
		   else if (name.equalsIgnoreCase("entityType"))
			   lendingApplicationForm.getEntity().getBasicProfile().setEntityType(contents.get(0));
		   else if (name.equalsIgnoreCase("trackingCode"))
			   lendingApplicationForm.setSourceType(contents.get(0));
		   else if (name.equalsIgnoreCase("companyType"))
			   lendingApplicationForm.getEntity().getBasicProfile().setCompanyType(contents.get(0));
		   else if (name.equalsIgnoreCase("businessConstitution"))
			   lendingApplicationForm.getEntity().getBasicProfile().setBusinessConstitution(contents.get(0));
		   else if (name.equalsIgnoreCase("buildingName"))
			   lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null).setBuilding(contents.get(0));
		   else if (name.equalsIgnoreCase("CountryOfBirth"))
			   lendingApplicationForm.findCurrentApplicant().getPersonalInfo().setCountryOfBirth(contents.get(0));
		   else if (name.equalsIgnoreCase("DateOfBirth"))
			   lendingApplicationForm.findCurrentApplicant().getPersonalInfo().setDateOfBirth(contents.get(0));
		   else if (name.equalsIgnoreCase("propertyType"))
			   lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null).setPropertyType(contents.get(0));
		   else if (name.equalsIgnoreCase("Appoitments"))
              lendingApplicationForm.getEntity().setAppointments(SetAppointmentList(lendingApplicationForm, contents.get(0)));
		   else if (name.contains("Appoitments")) {
              List<Appointment> appts = lendingApplicationForm.getEntity().getAppointments().stream().filter(a ->
                  a.getPersonReference() != null
                      ? contents.get(0).contains(a.getPersonReference().getIdno())
                      : contents.get(0).contains(a.getEntityReference().getUen())
              ).collect(Collectors.toList());
              if (!appts.isEmpty()) {
                  int length = "PositionCode:".length();
                  int startInd = contents.get(0).indexOf("PositionCode") + length;
                  String positionCode = contents.get(0).substring(startInd, startInd + 5);
                  appts.get(0).setPositionCode(
                      positionCode.split(",")[0].replaceAll("[^\\d]", "")
                  );
                  length = "Category:".length();
                  startInd = contents.get(0).indexOf("Category") + length;
                  positionCode = contents.get(0).substring(startInd, startInd + 5);
                  appts.get(0).setCategory(
                      positionCode.split(",")[0].replaceAll("[^\\d]", "")
                  );
              }
          } else if (name.equalsIgnoreCase("MainApplicantName")) {
		      lendingApplicationForm.setMainApplicantName(contents.get(0));
          }
    	  } catch(Exception ex) {
    		  log.error("Error {} occured while processing supplementaryInfoList",ex);
    	  }
     }

     // Format appointment dates
     if (!lendingApplicationForm.getEntity().getAppointments().isEmpty()) {
         DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy h:mm:ss a");
         for (Business.Appointment appt : lendingApplicationForm.getEntity().getAppointments()) {
             if (!StringUtils.isBlank(appt.getAppointmentDate())) {
                 LocalDate date = LocalDate.parse(appt.getAppointmentDate(), DATE_FORMAT);
                 appt.setAppointmentDate(
                     String.valueOf(date.getYear())
                     + String.valueOf(date.getMonthValue())
                     + String.valueOf(date.getDayOfMonth())
                 );
             }
         };
     }

     lendingApplicationForm.setApplicationAdditionalAppointments(specificationService);

   return Authentication.save(Authentication.current()
        .toBuilder()
        .lendingApplicationForm(lendingApplicationForm.toBuilder()
            .id(applicationId)
            .referenceNumber(applicationReferenceNumber)
            .product(specificationService.getProductByCode(getProductCodeFromSource(lendingApplicationForm.getSourceType())))
            .build())
        .build())
        .getLendingApplicationForm();
  }

  // for applicant
  @SuppressWarnings("unchecked")
  public BrmApplicant from(String legalId) throws RuntimeException {
    return BrmApplicant.builder()
        .applicationId(applicationId)
        .applicantId(applicantId)
        .principalDetails(new PrincipalDetails(
            ((List<Map<String, Object>>) JsonPath.parse(principalList)
                .read("$..PersonalDetails[?(@.IsMainApplicant == false && @.IdNo == '"
                    + legalId + "')]")).iterator()
                        .next()))
        .build();
  }
}
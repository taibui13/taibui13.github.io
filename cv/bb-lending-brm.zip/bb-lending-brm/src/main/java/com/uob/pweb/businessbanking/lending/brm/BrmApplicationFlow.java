package com.uob.pweb.businessbanking.lending.brm;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.jayway.jsonpath.JsonPath;
import com.uob.pweb.businessbanking.lending.component.ApplicationForm;
import com.uob.pweb.businessbanking.lending.form.Business;
import com.uob.pweb.businessbanking.lending.form.Business.BasicProfile;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm.ApplicationResponse;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.component.JsonMapper;
import com.uob.pweb.component.brm.BrmResponse;

@Configuration
public class BrmApplicationFlow implements BrmApplicationService {

  @Bean
  public IntegrationFlow getApplicationDraft(JsonMapper jsonMapper,
      SpecificationService specificationService, RestTemplate restTemplate,
      @Value("${outbound.application.list:}") String outbound) {
    return with -> with.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-get application draft")
        .enrichHeaders(outboundHeader -> outboundHeader.headerFunction("brm", message -> {
          return UriComponentsBuilder.fromHttpUrl(outbound)
              .queryParam("CompanyUenNo", message.getHeaders()
                  .get("companyUenNo"))
              .queryParam("ProductCode", message.getHeaders()
                  .get("productCode"))
              .queryParam("Status", message.getHeaders()
                  .get("status"))
              .queryParam("IDNo", message.getHeaders()
                  .get("idNo"))
              .encode()
              .build()
              .toUriString();
        }, true))
        .gateway("brmGet.input")
        .gateway(checkResponse -> checkResponse
            .filter(BrmResponse.class,
              brmResponse -> brmResponse.isSuccess(),
                orElse -> orElse.discardFlow(then -> then.log(Level.INFO, this.getClass()
                    .getName(), m -> "[filter]-Existing application or Product Code not found")
                    .handle((p, h) -> LendingApplicationForm.builder()
                        .build())))
            .<BrmResponse>handle(
                (brmResponse, headers) -> brmResponse.findDraftApplicationForm())
            .<BrmApplication, LendingApplicationForm>transform((brmApplication) -> {
              return LendingApplicationForm.builder()
                  .id(brmApplication.getApplicationId())
                  .expiryDate(brmApplication.getExpiryDate())
                  .status(brmApplication.getApplicationStatus())
                  .product(specificationService.getProductByBrm(brmApplication.getProductCode()))
                  .referenceNumber(brmApplication.getApplicationReferenceNumber())
                  .entity(Business.builder()
                      .basicProfile(BasicProfile.builder()
                          .entityName(JsonPath.parse(brmApplication.getCompanyDetails())
                              .read("$.RegisteredBusinessName"))
                          .build())
                      .build())
                  .createdDate(brmApplication.getCreatedDate())
                  .build();
            }));
  }

  @Bean
  public IntegrationFlow getApplication(JsonMapper jsonMapper,
      SpecificationService specificationService, RestTemplate restTemplate,
      @Value("${outbound.application.get:}") String outbound) {
    return with -> with.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-get application")
        .enrichHeaders(outboundHeader -> outboundHeader.headerFunction("brm", message -> {
          return UriComponentsBuilder.fromHttpUrl(outbound)
              .queryParam("ApplicationId", message.getHeaders()
                  .get("applicationId"))
              .queryParam("ApplicantId", message.getHeaders()
                  .get("applicantId"))
              .encode()
              .build()
              .toUriString();
        }, true))
        .gateway("brmGet.input")
        .gateway(checkResponse -> checkResponse
            .filter(BrmResponse.class, p -> p.isSuccess(),
                orElse -> orElse.discardFlow(then -> then.handle((p, h) -> {
                  throw new RuntimeException();
                })))
            .<BrmResponse>handle(
                (brmResponse, h) -> brmResponse.findApplicationForm()))
        .<BrmApplication>handle((brmApplication, headers) -> {
          brmApplication.setApplicantId((String) headers.get("applicantId"));
          return brmApplication;
        })
        .wireTap(saveBrmApplicationForm())
        .<BrmApplication, LendingApplicationForm>transform(
            (brmApplication) -> brmApplication.to(jsonMapper, specificationService));
        
  }

  @Bean
  public IntegrationFlow createApplication(RestTemplate restTemplate, JsonMapper jsonMapper,
      @Value("${outbound.application.create:}") String outbound) {
    return f -> 
      f.log(Level.INFO, this.getClass().getName(), m -> "[start]-application create")
        .<LendingApplicationForm, ApplicationForm>transform(p -> 
            BrmApplication.builder().build().create(p, jsonMapper, Authentication.current().getBusinessInfo()))
        .wireTap(saveBrmApplicationForm())
        .enrichHeaders(h -> h.header("brm", outbound, true))
        .gateway(createOrUpdate());
  }

  @Bean
  public IntegrationFlow updateApplication(RestTemplate restTemplate,
      JsonMapper jsonMapper, @Value("${outbound.application.update:}") String outbound) {
    return with -> with.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-application update")
        .<LendingApplicationForm, ApplicationForm>transform(
            lendingApplicationForm -> Authentication.current()
                .getApplicationForm()
                .update(lendingApplicationForm, jsonMapper))
        .enrichHeaders(outboundHeader -> outboundHeader.header("brm", outbound, true))
        .gateway(createOrUpdate());
  }

  @Bean
  public IntegrationFlow updateApplicant(RestTemplate restTemplate,
      @Value("${outbound.applicant.update:}") String outbound) {
    return with -> with.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-applicant update Applicant")
        .<LendingApplicant>handle((lendingApplicant, headers) -> Authentication.current()
            .getApplicationForm()
            .from(lendingApplicant.findLegalId())
            .update(lendingApplicant))
        .enrichHeaders(outboundHeader -> outboundHeader.header("brm", outbound, true))
        .gateway(createOrUpdateApplicant());
  }

  @Bean
  public IntegrationFlow submitApplication(RestTemplate restTemplate,
      @Value("${outbound.application.submit:}") String outbound) {
    return with -> with.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-application submit")
        .<LendingApplicationForm, Map<String, Object>>transform(
            lendingApplicationForm -> Stream.of(Authentication.current()
                .getApplicationForm()
                .findApplicationId())
                .collect(Collectors.toMap(key -> "ApplicationId", value -> value))
      		)
        .<Map<String, Object>>handle((map, headers) -> {
          SimpleDateFormat brmFormat =
              new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
          brmFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
          map.put("ApplicationSubmissionDate", brmFormat.format(new Date()));
          return map;
        })
        .enrichHeaders(outboundHeader -> outboundHeader.header("brm", outbound, true))
        .gateway(submit())
        .<BrmResponse>handle((p,h) -> MessageBuilder.withPayload(ApplicationResponse.builder()
                .referenceNumber(p.findReferenceNumber())
                .build())
                .setHeader(HttpHeaders.STATUS_CODE, HttpStatus.OK)
                .build())
        .wireTap(Authentication.invalidate());
  }

  @Bean
  public IntegrationFlow submitApplicant(RestTemplate restTemplate,
      @Value("${outbound.applicant.submit:}") String outbound) {
    return with -> with.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-applicant submit")
       	.<LendingApplicant>handle((lendingApplicant, headers) -> {
          return Stream.of(Authentication.current()
              .getApplicationForm()
              .from(lendingApplicant.findLegalId())
              .findApplicantId())
        	  .collect(Collectors.toMap(key -> "ApplicantId", value -> value));
       	})
       .<Map<String, Object>>handle((map, headers) -> {
            SimpleDateFormat brmFormat =
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            brmFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            map.put("ApplicationId", Authentication.current()
                    .getApplicationForm()
                    .findApplicationId());
            map.put("ConsentDate", brmFormat.format(new Date()));
            return map;
          })
        
        .enrichHeaders(outboundHeader -> outboundHeader.header("brm", outbound, true))
        .gateway(submit())
        .<BrmResponse>handle((p,h) -> MessageBuilder.withPayload(ApplicationResponse.builder()
                    .referenceNumber(p.findReferenceNumber())
                    .build())
                    .setHeader(HttpHeaders.STATUS_CODE, HttpStatus.OK)
                    .build())
        
        .wireTap(Authentication.invalidate());
  }

}

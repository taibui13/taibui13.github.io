package com.uob.pweb.businessbanking.lending.brm;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BrmApplicationRequest {

  @JsonProperty("Application")
  private Object application;

}

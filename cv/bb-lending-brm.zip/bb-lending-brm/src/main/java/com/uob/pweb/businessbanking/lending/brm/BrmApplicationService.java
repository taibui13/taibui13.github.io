package com.uob.pweb.businessbanking.lending.brm;

import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.handler.LoggingHandler.Level;
import com.uob.pweb.businessbanking.lending.component.Application;
import com.uob.pweb.businessbanking.lending.component.ApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.component.brm.BrmApplicationRequest;
import com.uob.pweb.component.brm.BrmResponse;

public interface BrmApplicationService {

  default public IntegrationFlow createOrUpdate() {
    return start -> start
        .log(Level.INFO, this.getClass().getName(), m -> "[start]-outbound create or update")
        .enrich(e -> e.requestSubFlow(sf -> sf
            .<Application, BrmApplicationRequest>transform(p -> BrmApplicationRequest.builder().application(p).build())
            .gateway("brmPost.input")
            .gateway(f -> f.filter(BrmResponse.class, p -> p.isSuccess(),
                orElse -> orElse.discardFlow(then -> then.handle((p, h) -> {
                  throw new RuntimeException();
                })))))
            .propertyExpression("applicationReferenceNumber", "payload.findReferenceNumber()")
            .propertyExpression("applicationId", "payload.findApplicationId()")
            .propertyExpression("initiateDate", "payload.findInitiateDate()")
            .propertyExpression("expiryDate", "payload.findExpiryDate()"))
            .<BrmApplication, LendingApplicationForm>transform(p -> 
            Authentication.current().getLendingApplicationForm().toBuilder()
              .id(p.getApplicationId())
              .expiryDate(p.getExpiryDate())
              .initiateDate(p.getInitiateDate())
              .referenceNumber(p.getApplicationReferenceNumber())
              .build());
  }
  
  default public IntegrationFlow createOrUpdateApplicant() {
	    
	  return start -> start.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-outbound create or update")
        .enrich(enrich -> enrich.requestSubFlow(to -> to
            .<Application, BrmApplicationRequest>transform(
                application -> BrmApplicationRequest.builder()
                    .application(application)
                    .build())
            .gateway("brmPost.input")
            .gateway(f -> f.filter(BrmResponse.class, p -> p.isSuccess(),
                orElse -> orElse.discardFlow(then -> then.handle((p, h) -> {
                  throw new RuntimeException();
                })))))
         	 .propertyExpression("applicationReferenceNumber",
                "payload.findReferenceNumber()"))
              .<BrmApplicant, LendingApplicationForm>transform(
                brmApplicant -> Authentication.current()
                    .getLendingApplicationForm()
                    .toBuilder()
                    .referenceNumber(brmApplicant.getApplicationReferenceNumber())
                    .build());
  }
  
  
  default public IntegrationFlow submit() {
    return start -> start.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-outbound submit")
        .gateway("brmPost.input")
       
        .gateway(checkResponse -> checkResponse.filter(BrmResponse.class,
            p -> p.isSuccess(),
            orElse -> orElse.discardFlow(then -> then.handle((p, h) -> {
              throw new RuntimeException();
            }))));
  }

  default public IntegrationFlow saveBrmApplicationForm() {
    return save -> save.<ApplicationForm>handle((applicationForm,
        headers) -> Authentication.save(Authentication.current()
            .toBuilder()
            .applicationForm(applicationForm)
            .build()));
  }

}

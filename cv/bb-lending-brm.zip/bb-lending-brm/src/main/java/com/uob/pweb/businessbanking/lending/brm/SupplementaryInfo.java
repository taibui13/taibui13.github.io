package com.uob.pweb.businessbanking.lending.brm;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SupplementaryInfo implements Serializable {

	 private static final long serialVersionUID = 1L;
	  
	 @JsonProperty("Name")
	 private String name;
	 @JsonProperty("Contents")
	 private List<String> contents;	
	
}

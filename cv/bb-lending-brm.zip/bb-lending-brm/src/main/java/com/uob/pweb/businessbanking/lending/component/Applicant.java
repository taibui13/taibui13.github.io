package com.uob.pweb.businessbanking.lending.component;

import com.uob.pweb.businessbanking.lending.brm.BrmApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;

public interface Applicant extends Application {

  public BrmApplicant update(LendingApplicant lendingApplicant);

  public String findApplicantId();
}

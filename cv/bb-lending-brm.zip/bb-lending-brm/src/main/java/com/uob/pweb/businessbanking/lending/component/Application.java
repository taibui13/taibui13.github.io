package com.uob.pweb.businessbanking.lending.component;

public interface Application {

}

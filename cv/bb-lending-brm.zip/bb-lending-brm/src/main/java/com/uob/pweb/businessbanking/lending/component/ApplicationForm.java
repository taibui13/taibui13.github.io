package com.uob.pweb.businessbanking.lending.component;

import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.component.JsonMapper;

public interface ApplicationForm extends Application {

  public ApplicationForm create(LendingApplicationForm lendingApplicationForm,
      JsonMapper jsonMapper, Object businessInfo);

  public ApplicationForm update(LendingApplicationForm lendingApplicationForm,
      JsonMapper jsonMapper);

  public LendingApplicationForm to(JsonMapper jsonMapper,
      SpecificationService specificationService);

  public String findApplicationId();

  public Applicant from(String legalId) throws RuntimeException;

}

package com.uob.pweb.businessbanking.lending.configuration;

import org.springframework.context.annotation.Profile;

@Profile({"!local", "!sit"})
public class Configuration {

  static {
    System.loadLibrary("libscm.so");
  }

}

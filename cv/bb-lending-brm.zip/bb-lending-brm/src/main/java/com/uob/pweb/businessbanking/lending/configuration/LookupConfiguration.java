package com.uob.pweb.businessbanking.lending.configuration;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.logging.log4j.util.Strings;
import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
import org.springframework.boot.env.OriginTrackedMapPropertySource;
import org.springframework.boot.env.PropertiesPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * this class is to load file based on file modification event - properties : PLCE/ MyInfo mapping
 */

@Slf4j
public class LookupConfiguration {

  private static Map<String, Object> corppassMap =
      new HashMap<String, Object>();

  public static void initiate(Resource propertiesResource) throws IOException {
    PropertiesPropertySourceLoader propertyLoader =
        new PropertiesPropertySourceLoader();
    List<PropertySource<?>> resources =
        propertyLoader.load("resource", propertiesResource);
    AtomicReference<Map<String, Object>> atomicReference =
        new AtomicReference<Map<String, Object>>();
    ConfigurationPropertySources.from(resources.get(0)).forEach(p -> {
      OriginTrackedMapPropertySource resource =
          (OriginTrackedMapPropertySource) p.getUnderlyingSource();
      atomicReference.set(resource.getSource());
    });
    if (atomicReference.get() != null) {
      log.info("initiate Business Banking properties file successful");
      corppassMap = atomicReference.get();
    } else {
      log.error("ignore changes because sth is wrong in properties data file");
    }
  }

  public static String getCorpPassProperty(String code, String defaultValue) {
    return corppassMap.containsKey(code) ? corppassMap.get(code).toString()
        : defaultValue;
  }

  public static String getCorpPassPropertyDefault(String code) {
    return corppassMap.containsKey(code) ? corppassMap.get(code).toString()
        : Strings.EMPTY;
  }

  public static String getEducationType(String code) {
    return getCorpPassPropertyDefault("education.type." + code);
  }

  public static String getMaritalStatus(String code) {
    return getCorpPassPropertyDefault("marital.status.type." + code);
  }

  public static String getHouseType(String code) {
    return getCorpPassPropertyDefault("house.type." + code);
  }

}

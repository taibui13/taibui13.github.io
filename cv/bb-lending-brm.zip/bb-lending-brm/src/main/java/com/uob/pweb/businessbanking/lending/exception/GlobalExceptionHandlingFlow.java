package com.uob.pweb.businessbanking.lending.exception;

import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;
import org.springframework.security.core.context.SecurityContextHolder;

import com.uob.pweb.common.framework.exception.ApiRuntimeException;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class GlobalExceptionHandlingFlow {

  @Bean
  public IntegrationFlow globalErrorFlow() {
    return f -> f.<RuntimeException, Message<?>>transform(payload -> {
      
      if (payload.getCause() instanceof ApiRuntimeException) {
        ApiRuntimeException apiRuntimeException = (ApiRuntimeException) payload.getCause();
        log.error("Handled api exception - http status {} | error message : ",
            apiRuntimeException.getHttpStatus(), payload.getCause());

        if (!HttpStatus.BAD_REQUEST.equals(apiRuntimeException.getHttpStatus())) {
          log.info("clearing session");
         //SecurityContextHolder.clearContext(); -- Handled exception. inform customer and customer journey continues
        }

        return MessageBuilder.withPayload(apiRuntimeException.getErrorResponse())
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, apiRuntimeException.getHttpStatus())
            .build();
      }

      if (payload.getCause() instanceof MessagingException) {
        if (((MessagingException) payload).getRootCause() instanceof ApiRuntimeException) {
          ApiRuntimeException apiRuntimeException = (ApiRuntimeException) ((MessagingException) payload).getRootCause();
          log.error("Handled api exception - http status {} | error message : ",
              apiRuntimeException.getHttpStatus(), apiRuntimeException);

          if (!HttpStatus.BAD_REQUEST.equals(apiRuntimeException.getHttpStatus())) {
            log.info("clearing session");
            SecurityContextHolder.clearContext(); //<-- actually this is unhandled exception and we should end the session
            //and returning something error for the customer journey to end
          }

          return MessageBuilder.withPayload(apiRuntimeException.getErrorResponse())
              .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, apiRuntimeException.getHttpStatus())
              .build();
        }
      }

      log.error("unhandled exception - http status {} | error message :",
          HttpStatus.INTERNAL_SERVER_ERROR, payload.getCause());

      log.info("clearing session");
      //SecurityContextHolder.clearContext(); <-- actually this is unhandled exception and we should end the session
      //and returning something error for the customer journey to end

      return MessageBuilder.withPayload(Strings.EMPTY)
          .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.INTERNAL_SERVER_ERROR).build();
    });
  }

}

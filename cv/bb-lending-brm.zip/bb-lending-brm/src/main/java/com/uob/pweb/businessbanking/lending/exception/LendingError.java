package com.uob.pweb.businessbanking.lending.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum LendingError {
  AppExpired("AppExpired", "Application expired"),
  AppSubmitted("AppSubmitted", "Application already submitted"),
  AppNotFound("AppNotFound", "Application not found"),
  ApplicantNotFound("ApplicantNotFound", "Applicant not found"),
  ApplicantSubmitted("ApplicantSubmitted", "Applicant already submitted"),
  InvalidRequest("InvalidRequest", "Application not existed or already submitted"),// save & submit
  InvalidApplication("InvalidRequest", "Invalid Application"), //incorrect person structure
  SessionShared("SessionShared", "Session Shared"), // multiple tabs open
  InvalidEntityStatus("InvalidEntityStatus", "Entity Status not support"),
  MyInfoRequired("MyInfoRequired", "Mandatory fields missing"),
  InvalidProductCode("InvalidProductCode","Product Code not supported - "),
  InvalidAdditionalAppointment("InvalidRequest","Invalid Additional Appointment details");

  @Getter
  private final String code;
  @Getter
  private final String message;
}

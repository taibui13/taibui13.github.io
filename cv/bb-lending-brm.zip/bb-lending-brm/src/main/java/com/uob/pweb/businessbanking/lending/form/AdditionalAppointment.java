package com.uob.pweb.businessbanking.lending.form;

import java.io.Serializable;

import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalAppointment implements Serializable {
  
  private static final long serialVersionUID = 1L;
  
  @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
  private String name;
  private String legalId;
  private String emailAddress;
  private String mobileNumber;
}

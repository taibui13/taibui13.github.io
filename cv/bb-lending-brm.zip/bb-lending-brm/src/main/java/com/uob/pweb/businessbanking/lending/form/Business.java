package com.uob.pweb.businessbanking.lending.form;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.exception.LendingError;
import com.uob.pweb.common.framework.enums.AddressType;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.myinfo.BusinessConstitution;
import com.uob.pweb.common.framework.myinfo.CompanyType;
import com.uob.pweb.common.framework.myinfo.EntityType;
import com.uob.pweb.common.framework.myinfo.ShareType;
import com.uob.pweb.common.framework.myinfo.types.entity.Entity;
import com.uob.pweb.common.framework.myinfo.types.entity.EntityAddress;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Slf4j
public class Business implements Serializable {

  private static final long serialVersionUID = 1L;

  @NotNull
  @Valid
  private BasicProfile basicProfile;

  private List<PreviousName> previousNames;
  private List<PreviousUen> previousUens;
  @Valid
  private List<Address> addresses;
  private List<Financial> financials;
  private List<Capital> capitals;
  private List<Appointment> appointments;
  private List<Shareholder> shareholders;
  private List<Grant> grants;

  public static class BusinessBuilder {
    public BusinessBuilder financials(List<Financial> financials) {
      // Send an empty array in case financials.get(0) fields are empty
      this.financials = CollectionUtils.isNotEmpty(financials) && financials.get(0).isEmpty()
          ? new ArrayList<>() : financials;
      return this;
    }
    public BusinessBuilder grants(List<Grant> grants) {
      // Send an empty array in case grants.get(0) fields are empty
      this.grants = CollectionUtils.isNotEmpty(grants) && grants.get(0).isEmpty()
          ? new ArrayList<>() : grants;
      return this;
    }
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class BasicProfile implements Serializable {
    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    @NotBlank
    @Max(value = 10, message = "Uen should not be greater than 10")
    public String uen;

    @EqualsAndHashCode.Include
    @NotBlank
    @Max(value = 256, message = "Entity name should not be greater than 256")
    public String entityName;

    @EqualsAndHashCode.Include
    @Max(value = 16, message = "Entity type should not be greater than 16")
    public String entityType;

    @EqualsAndHashCode.Include
    @Max(value = 16, message = "Company type should not be greater than 16")
    public String companyType;

    @EqualsAndHashCode.Include
    @Max(value = 16, message = "Business constitution should not be greater than 16")
    public String businessConstitution;

    @EqualsAndHashCode.Include
    @Max(value = 10, message = "Entity status should not be greater than 10")
    public String entityStatus;

    @EqualsAndHashCode.Include
    @Max(value = 30, message = "Ownership should not be greater than 30")
    public String ownership;

    @EqualsAndHashCode.Include
    @DateTimeFormat(pattern = "YYYY-MM-DD")
    @Past(message = "Only past date is valid")
    public String registrationDate;

    @EqualsAndHashCode.Include
    @Max(value = 50, message = "Primary activity code should not be greater than 50")
    public String primaryActivityCode;

    @EqualsAndHashCode.Include
    @Max(value = 210,
        message = "Primary activity description should not be greater than 210")
    public String primaryActivityDesc;

    @EqualsAndHashCode.Include
    @Max(value = 50, message = "Secondary activity code should not be greater than 50")
    public String secondaryActivityCode;

    @EqualsAndHashCode.Include
    @Max(value = 210,
        message = "Secondary activity description should not be greater than 210")
    public String secondaryActivityDesc;

    @EqualsAndHashCode.Include
    @Max(value = 2, message = "Country of incorporation should not be greater than 2")
    @Builder.Default
    public String countryOfIncorporation = "SG";

    @EqualsAndHashCode.Include
    @DateTimeFormat(pattern = "YYYY-MM-DD")
    @Future(message = "Only future date is valid")
    public String businessExpiryDate;

  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class PreviousName implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    public String historyName;
    @EqualsAndHashCode.Include
    public String historyNameEffectiveDate;

  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class PreviousUen implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    private String previousUen;
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  public static class Address implements Serializable {

    private static final long serialVersionUID = 1L;

    private String format;
    private String type;
    private String standard;
    private String unitNo;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
    private String street;
    private String block;
    private String postalCode;
    private String floor;
    private String building;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
    private String city;
    private String country;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
    private String line1;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
    private String line2;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
    private String line3;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "No html tags accepted")
    private String line4;

  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class Financial implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    private String currentPeriodStartDate;
    @EqualsAndHashCode.Include
    private String currentPeriodEndDate;
    @EqualsAndHashCode.Include
    private Boolean isAudited;
    @EqualsAndHashCode.Include
    private String currency;
    @EqualsAndHashCode.Include
    private BigDecimal companyRevenue;
    @EqualsAndHashCode.Include
    private BigDecimal companyProfitLossBeforeTax;
    @EqualsAndHashCode.Include
    private BigDecimal companyProfitLossAfterTax;
    @EqualsAndHashCode.Include
    private BigDecimal groupRevenue;
    @EqualsAndHashCode.Include
    private BigDecimal groupCapitalPaidUpCapitalAmount;
    @EqualsAndHashCode.Include
    private BigDecimal groupProfitLossBeforeTax;
    @EqualsAndHashCode.Include
    private BigDecimal groupProfitLossAfterTax;

    boolean isEmpty() {
      return StringUtils.isAllBlank(currentPeriodStartDate, currentPeriodEndDate, currency)
          || companyRevenue == null || companyProfitLossBeforeTax == null || companyProfitLossAfterTax == null
          || groupRevenue == null || groupCapitalPaidUpCapitalAmount == null || groupProfitLossBeforeTax == null
          || groupProfitLossAfterTax == null;
    }
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class Capital implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    private String capitalType;
    @EqualsAndHashCode.Include
    private BigDecimal shareAllottedAmount;
    @EqualsAndHashCode.Include
    private BigDecimal issuedCapitalAmount;
    @EqualsAndHashCode.Include
    private BigDecimal paidUpCapitalAmount;
    @EqualsAndHashCode.Include
    private String currency;
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class Appointment implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    private String category;
    @EqualsAndHashCode.Include
    private String positionCode;
    @EqualsAndHashCode.Include
    private String positionDesc;
    @EqualsAndHashCode.Include
    private String appointmentDate;
    @EqualsAndHashCode.Include
    private PersonReference personReference;
    @EqualsAndHashCode.Include
    private EntityReference entityReference;

    public boolean ofIndividualOwned() {
      return null != personReference;
    }

    public boolean ofSamePerson(String nric) {
      return personReference != null && personReference.getIdno() != null
          && personReference.getIdno()
              .equalsIgnoreCase(nric);
    }
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class Shareholder implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    public PersonReference personReference;
    @EqualsAndHashCode.Include
    public EntityReference entityReference;
    @EqualsAndHashCode.Include
    public String category;
    @EqualsAndHashCode.Include
    public String shareType;
    @EqualsAndHashCode.Include
    public Integer allocation;
    @EqualsAndHashCode.Include
    public String currency;
    @EqualsAndHashCode.Include
    private String appointmentDate;

   
    public boolean ofOrdinaryCapital() {
      return ShareType.ORDINARY_CAPITAL.getCode()
          .equals(shareType);
    }

    public boolean ofIndividualOwned() {
      return null != personReference;
    }

    public boolean ofSamePerson(String nric) {
      return personReference != null && personReference.getIdno() != null
          && personReference.getIdno()
              .equalsIgnoreCase(nric);
    }
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class PersonReference implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    private String idno;
    @EqualsAndHashCode.Include
    private String personName;
    @EqualsAndHashCode.Include
    private String nationality;
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class EntityReference implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    private String uen;
    @EqualsAndHashCode.Include
    private String entityName;
    @EqualsAndHashCode.Include
    private String entityType;
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  @EqualsAndHashCode(onlyExplicitlyIncluded = true)
  public static class Grant implements Serializable {

    private static final long serialVersionUID = 1L;

    @EqualsAndHashCode.Include
    public String grantType;
    @EqualsAndHashCode.Include
    public String grantStatus;
    @EqualsAndHashCode.Include
    public String functionalArea;
    @EqualsAndHashCode.Include
    public String developmentCategory;
    @EqualsAndHashCode.Include
    public Integer approvedAmount;
    @EqualsAndHashCode.Include
    public String submittedDate;
    @EqualsAndHashCode.Include
    public String lastUpdatedDate;

    boolean isEmpty() {
      return StringUtils.isAllBlank(grantType, grantStatus, functionalArea, developmentCategory, submittedDate, lastUpdatedDate)
          || approvedAmount == null;
    }
  }

  public boolean equalsWith(Object o) {
    if (this == o) { return true; }
    if (!(o instanceof Business)) { return false; }

    Business entity = (Business) o;

    if (basicProfile != null ? !basicProfile.equals(entity.basicProfile)
        : entity.basicProfile != null) {
      return false;
    }
    if (!CollectionUtils.isEmpty(previousNames)
        ? !CollectionUtils.isEqualCollection(previousNames, entity.previousNames)
        : !CollectionUtils.isEmpty(entity.previousNames)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(previousUens)
        ? !CollectionUtils.isEqualCollection(previousUens, entity.previousUens)
        : !CollectionUtils.isEmpty(entity.previousUens)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(addresses)
        ? !CollectionUtils.isEqualCollection(addresses, entity.addresses)
        : !CollectionUtils.isEmpty(entity.addresses)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(financials)
        ? !CollectionUtils.isEqualCollection(financials, entity.financials)
        : !CollectionUtils.isEmpty(entity.financials)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(capitals)
        ? !CollectionUtils.isEqualCollection(capitals, entity.capitals)
        : !CollectionUtils.isEmpty(entity.capitals)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(appointments)
        ? !CollectionUtils.isEqualCollection(appointments, entity.appointments)
        : !CollectionUtils.isEmpty(entity.appointments)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(shareholders)
        ? !CollectionUtils.isEqualCollection(shareholders, entity.shareholders)
        : !CollectionUtils.isEmpty(entity.shareholders)) {
      return false;
    }
    if (!CollectionUtils.isEmpty(grants)
        ? !CollectionUtils.isEqualCollection(grants, entity.grants)
        : !CollectionUtils.isEmpty(entity.grants)) {
      return false;
    }

    return true;
  }

  public boolean ofSoleProprietor() {
    return EntityType.BUSINESS.getCode()
        .equalsIgnoreCase(this.getBasicProfile()
            .getEntityType())
        && BusinessConstitution.SOLE_PROPRIETORSHIP.getCode()
            .equalsIgnoreCase(this.getBasicProfile()
                .getBusinessConstitution());
  }

  public boolean ofPartnership() {
    if (EntityType.BUSINESS.getCode()
        .equalsIgnoreCase(this.getBasicProfile()
            .getEntityType())
        && BusinessConstitution.PARTNERSHIP.getCode()
            .equalsIgnoreCase(this.getBasicProfile()
                .getBusinessConstitution())) {
      return true;
    } else if (EntityType.LIMITED_PARTNERSIPS.getCode()
        .equalsIgnoreCase(this.getBasicProfile()
            .getEntityType())) {
      return true;
    } else
      return EntityType.LIMITED_LIABILITY_PARTNERSHIPS.getCode()
          .equalsIgnoreCase(this.getBasicProfile()
              .getEntityType());
  }

  public boolean ofOthers() {
    return EntityType.LOCAL_COMPANY.getCode()
        .equalsIgnoreCase(this.getBasicProfile()
            .getEntityType())
        && (CompanyType.PRIVATE_COMPANY_LIMITED_BY_SHARES.getCode()
            .equalsIgnoreCase(this.getBasicProfile()
                .getCompanyType())
            || CompanyType.EXEMPT_PRIVATE_COMPANY_LIMITED_BY_SHARES.getCode()
                .equalsIgnoreCase(this.getBasicProfile()
                    .getCompanyType()));

  }

  public static Business init(String uen, Entity businessEntity,
      ObjectMapper objectMapper) {
   
	 
    // map entity address
    List<Address> addressList = Optional.ofNullable(businessEntity.getAddresses())
        .orElse(new ArrayList<EntityAddress>())
        .stream()
        .filter(k -> {
          if (((k.getAddressSg() != null && StringUtils.isAllBlank(k.getAddressSg()
              .getPostal(),
              k.getAddressSg()
                  .getUnit(),
              k.getAddressSg()
                  .getBlock(),
              k.getAddressSg()
                  .getStreet(),
              k.getAddressSg()
                  .getFloor(),
              k.getAddressSg()
                  .getBuilding()))
              || k.getAddressSg() == null)
              && ((k.getAddressUnformatted() != null && StringUtils.isAllBlank(
                  k.getAddressUnformatted()
                      .getLine1(),
                  k.getAddressUnformatted()
                      .getLine2(),
                  k.getAddressUnformatted()
                      .getCountry()))
                  || k.getAddressUnformatted() == null)) {
            log.error("Mandatory Myinfo Field 'address' for entity {} is empty/blank",
                uen);
            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
                LendingError.MyInfoRequired.getCode(),
                LendingError.MyInfoRequired.getMessage());
          }
          return true;
        })
        .map(v -> {
          Address address = null;
          if (Optional.ofNullable(v.getAddressSg())
              .isPresent()) {
            address = Address.builder()
                .type(AddressType.R.toString())
                .format("L")
                .standard(v.getStandard())
                .unitNo(v.getAddressSg()
                    .getUnit())
                .street(v.getAddressSg()
                    .getStreet())
                .block(v.getAddressSg()
                    .getBlock())
                .postalCode(v.getAddressSg()
                    .getPostal())
                .floor(v.getAddressSg()
                    .getFloor())
                .building(v.getAddressSg()
                    .getBuilding())
                .country(v.getAddressSg()
                    .getCountry())
                .build();
          }
          if (Optional.ofNullable(v.getAddressUnformatted())
              .isPresent()) {
            address.setLine1(v.getAddressUnformatted()
                .getLine1());
            address.setLine2(v.getAddressUnformatted()
                .getLine2());
            address.setFormat("F");
          }
          return address;
        })
        .collect(Collectors.toList());
    
    Business entity = objectMapper.convertValue(businessEntity, Business.class);
    if (StringUtils.isBlank(entity.getBasicProfile().getCountryOfIncorporation())) {
         entity.getBasicProfile().setCountryOfIncorporation("SG");
       } 

    entity.setAddresses(addressList);

    return entity;
  }
}

package com.uob.pweb.businessbanking.lending.form;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.configuration.LookupConfiguration;
import com.uob.pweb.businessbanking.lending.exception.LendingError;
import com.uob.pweb.common.framework.enums.AddressType;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.myinfo.ResidentialStatus;
import com.uob.pweb.common.framework.myinfo.types.person.CommonRecord;
import com.uob.pweb.common.framework.myinfo.types.person.NoaHistory;
import com.uob.pweb.common.framework.myinfo.types.person.Person;
import com.uob.pweb.common.framework.myinfo.v3.MyInfoPersonResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class LendingApplicant implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -4315778461675082260L;

  private BasicInfo basicInfo;
  private PersonalInfo personalInfo;

  private List<OnlineFormAddress> addresses;
  private List<Noa> noaHistory;
 
  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class BasicInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Size(max = 25)
    @NotNull(message = "legal Id cannot be null")
    private String legalId;
    private AlternateNames alternateNames;
    @Size(max = 1)
    private String residentialStatus;
    @Size(max = 70)
    @NotNull(message = "principle name cannot be null")
    private String principalName;
    @Size(max = 60)
    @NotNull(message = "email cannot be null")
    // @Email(message = "invalid email")
    private String emailAddress;
    @Size(max = 30)
    @NotNull(message = "mobile number cannot be null")
    private String mobileNumber;
  }

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor

  public static class AlternateNames implements Serializable {

    private static final long serialVersionUID = 1L;

    @Size(max = 70)
    private String hanYuPinYinName;
    @Size(max = 70)
    private String hanYuPinYinAliasName;
    @Size(max = 70)
    private String marriedName;
    @Size(max = 70)
    private String alias;

  }

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class PersonalInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Size(max = 10)
    private String dateOfBirth;
    private String gender;
    @Size(max = 1)
    private String maritalStatus;
    @Size(max = 2)
    private String nationality;
    @Size(max = 2)
    private String countryOfBirth;
   
  }

  @Getter
  @Setter
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class OnlineFormAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    private String type;
    private String unitNo;
    private String street;
    private String block;
    private String postalCode;
    private String floor;
    private String building;
    private String city;
    private String country;
    private String line1;
    private String line2;
    private String line3;
    private String line4;
    private String propertyType;

  }

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor

  public static class OnlineFormCpfContribution implements Serializable {

    private static final long serialVersionUID = 1L;

    private String date;

    private String amount;

    private String month;

    private String employer;

  }

  @Setter
  @Getter
  @Builder(toBuilder = true)
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString

  public static class OnlineFormEmployment implements Serializable {

    private static final long serialVersionUID = 1L;

    private String type;

    private String nameOfEmployer;

    private String natureOfEmployment;

    private String percentageOfOwnership;

    private String jobTitle;

    private String occupation;

    private String industry;

    @JsonProperty("length")

    private String employmentDuration;
  }

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Noa implements Serializable {
    private static final long serialVersionUID = 1L;
    private BigDecimal amount;
    private String yearOfAssessment;
    private BigDecimal employment;
    private BigDecimal trade;
    private BigDecimal rent;
    private BigDecimal interest;
    private String taxClearance;
    private String category;
 }

  public void updateEmailAddress(String email) {
    this.getBasicInfo().setEmailAddress(email);
  }

  public String findPrincipalName() {
    return this.getBasicInfo().getPrincipalName();
  }

  public String findLegalId() {
    return this.getBasicInfo().getLegalId();
  }

	public String findEmailAddress(Person person) {
		String email = "";
		if (StringUtils.isBlank(this.getBasicInfo().getEmailAddress()))
			email = person.getEmail().getValue();
		else {
			email = this.getBasicInfo().getEmailAddress();
		}
		return email;
	}
  
  public LendingApplicant initMainApplicant(String legalId, Person person, ObjectMapper objectMapper) {
	  if (Strings.isBlank(person.getMobileno().getNbr())) {
	      log.error("Mandatory Myinfo Field 'mobile number' for customer {} is empty/blank", legalId);

	      throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, LendingError.MyInfoRequired.getCode(),
	          LendingError.MyInfoRequired.getMessage());
	    }

	    boolean isSGPr = person.getResidentialstatus() != null && (ResidentialStatus.CITIZEN.getCode()
	        .equalsIgnoreCase(person.getResidentialstatus().getValue())
	        || ResidentialStatus.PR.getCode()
	            .equalsIgnoreCase(person.getResidentialstatus().getValue()));

	    if (isSGPr && StringUtils.isAllBlank(person.getRegadd().getUnit(),
	        person.getRegadd().getStreet(), person.getRegadd().getBlock(),
	        person.getRegadd().getPostal(), person.getRegadd().getFloor())) {
	      log.error(
	          "Mandatory Myinfo Fields in Residential Address for SG/PR customer {} is empty/blank",
	          legalId);

	      throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, LendingError.MyInfoRequired.getCode(),
	          LendingError.MyInfoRequired.getMessage());
	    }

	    
	    AlternateNames alternateNames = AlternateNames.builder()
	        .alias(Optional.ofNullable(person.getAliasname()).orElse(new CommonRecord()).getValue())
	        .hanYuPinYinAliasName(Optional.ofNullable(person.getHanyupinyinaliasname())
	            .orElse(new CommonRecord()).getValue())
	        .hanYuPinYinName(
	            Optional.ofNullable(person.getHanyupinyinname()).orElse(new CommonRecord()).getValue())
	        .marriedName(
	            Optional.ofNullable(person.getMarriedname()).orElse(new CommonRecord()).getValue())
	        .build();

	    BasicInfo basicInfo =
	        BasicInfo.builder().legalId(legalId).principalName(person.getName().getValue())
	            .alternateNames(alternateNames)
	            .emailAddress(this.getBasicInfo().getEmailAddress())
	            .mobileNumber(person.getMobileno().getPrefix() + person.getMobileno().getCode()
	                + person.getMobileno().getNbr())
	            .residentialStatus(Optional.ofNullable(person.getResidentialstatus())
	                .orElse(new CommonRecord()).getValue())
	            .build();

	    String myinfoDob = person.getDob().getValue();
	    DateTimeFormatter dtfIn = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    LocalDate dtIn = LocalDate.parse(myinfoDob, dtfIn);
	    DateTimeFormatter dtfOut = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    String finalDob = dtIn.format(dtfOut);

	    // set personal info
	    PersonalInfo personalDetails = PersonalInfo.builder()
	        .countryOfBirth(
	            Optional.ofNullable(person.getBirthcountry()).orElse(new CommonRecord()).getValue())
	        .dateOfBirth(finalDob).gender(person.getSex().getValue())
	        .maritalStatus(LookupConfiguration.getMaritalStatus(
	            Optional.ofNullable(person.getMarital()).orElse(new CommonRecord()).getValue()))
	        .nationality(person.getNationality().getValue()).build();
	    // set main applicant
	    this.setBasicInfo(basicInfo);
	    this.setPersonalInfo(personalDetails);

	    // set property type code
	    String propertyTypeCode = Strings
	        .isBlank(Optional.ofNullable(person.getHousingtype()).orElse(new CommonRecord()).getValue())
	            ? Optional.ofNullable(person.getHdbtype()).orElse(new CommonRecord()).getValue()
	            : Optional.ofNullable(person.getHousingtype()).orElse(new CommonRecord()).getValue();

	    // set address
	    OnlineFormAddress residentialAddress = OnlineFormAddress.builder()
	        .type("C".equalsIgnoreCase(person.getRegadd().getClassification())
	            ? AddressType.R.toString()
	            : StringUtils.EMPTY)
	        .block(person.getRegadd().getBlock()).building(person.getRegadd().getBuilding())
	        .country(person.getRegadd().getCountry()).floor(person.getRegadd().getFloor())
	        .postalCode(person.getRegadd().getPostal()).street(person.getRegadd().getStreet())
	        .unitNo(person.getRegadd().getUnit())
	        .propertyType(LookupConfiguration.getHouseType(propertyTypeCode)).build();
	   
	    List<Noa> noaHistory = Optional
	        .ofNullable(Optional.ofNullable(person.getNoahistory()).orElse(new NoaHistory()).getList())
	        .orElse(new ArrayList<>()).stream().map(v -> objectMapper.convertValue(v, Noa.class))
	        .collect(Collectors.toList());

	    this.setNoaHistory(noaHistory);
	    this.setAddresses(Stream.of(residentialAddress).collect(Collectors.toList()));

	    return this;
	  }
		
	
  public LendingApplicant init(String legalId, MyInfoPersonResponse person, ObjectMapper objectMapper) {
    
    if(!isValidMandatoryFields(person)) {
      throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
      LendingError.MyInfoRequired.getCode(),LendingError.MyInfoRequired.getMessage());
    }

    
    AlternateNames alternateNames = AlternateNames.builder()
        .alias(person.getAliasname().getValue())
        .hanYuPinYinAliasName(person.getHanyupinyinaliasname().getValue())
        .hanYuPinYinName(person.getHanyupinyinname().getValue())
        .marriedName(person.getMarriedname().getValue())
        .build();

    BasicInfo basicInfo =
        BasicInfo.builder().legalId(legalId)
            .principalName(person.getName().getValue())
            .emailAddress(person.getEmail().getValue())
            .alternateNames(alternateNames)
            .mobileNumber(person.getMobileno().getPrefix().getValue() + person.getMobileno().getAreacode().getValue()
              + person.getMobileno().getNbr().getValue())
            .residentialStatus(person.getResidentialstatus().getCode())
            .build();
  
    String myinfoDob = person.getDob().getValue();
    DateTimeFormatter dtfIn = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    LocalDate dtIn = LocalDate.parse(myinfoDob, dtfIn);
    DateTimeFormatter dtfOut = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String finalDob = dtIn.format(dtfOut);

    // set personal info
    PersonalInfo personalDetails = PersonalInfo.builder()
        .countryOfBirth(person.getBirthcountry().getCode()) 
        .dateOfBirth(finalDob)
        .gender(person.getSex().getCode())
        .maritalStatus(LookupConfiguration.getMaritalStatus(person.getMarital().getCode()))
        .nationality(person.getNationality().getCode()).build();
    
    // set partner applicant
    this.setBasicInfo(basicInfo);
    this.setPersonalInfo(personalDetails);

    // set property type code
    String propertyTypeCode = Strings.isBlank(person.getHousingtype().getCode())
        ? person.getHdbtype().getCode()
        : person.getHousingtype().getCode();

    // set address
    OnlineFormAddress residentialAddress = OnlineFormAddress.builder()
        .type("C".equalsIgnoreCase(person.getRegadd().getClassification()) ? "R" : Strings.EMPTY)
        .block(person.getRegadd().getBlock().getValue())
        .building(person.getRegadd().getBuilding().getValue())
        .country(person.getRegadd().getCountry().getCode())
        .floor(person.getRegadd().getFloor().getValue())
        .postalCode(person.getRegadd().getPostal().getValue())
        .street(person.getRegadd().getStreet().getValue())
        .unitNo(person.getRegadd().getUnit().getValue())
        .propertyType(LookupConfiguration.getHouseType(propertyTypeCode))
        .build();
    this.setAddresses(Stream.of(residentialAddress).collect(Collectors.toList()));
    
    if (Optional.ofNullable(person.getNoahistory()).isPresent() &&
        !CollectionUtils.isEmpty(person.getNoahistory().getNoas())) {
      List<Noa> noaHistory = person.getNoahistory().getNoas().stream()
          .map(v -> Noa.builder()
            .amount(v.getAmount() != null ? v.getAmount().getValue(): null)
            .yearOfAssessment(v.getYearOfAssessment() != null ? v.getYearOfAssessment().getValue() : Strings.EMPTY)
            .employment(v.getEmployment() != null ? v.getEmployment().getValue() : null)
            .trade(v.getTrade() != null ? v.getTrade().getValue() : null)
            .rent(v.getRent() != null ? v.getRent().getValue() : null)
            .interest(v.getInterest() != null ? v.getInterest().getValue() : null)
            .taxClearance(v.getTaxClearance() != null ? v.getTaxClearance().getValue() : Strings.EMPTY)
            .category(v.getCategory() != null ? v.getCategory().getValue() : Strings.EMPTY)
            .build()).collect(Collectors.toList());
      this.setNoaHistory(noaHistory);
    }

    return this;
  }

 
 
  public LendingApplicant sync(LendingApplicant lendingApplicant) {
   // log.info("*******current this {} and upcoming lending applicant ",this,lendingApplicant);
	this.getPersonalInfo().setMaritalStatus(lendingApplicant.getPersonalInfo().getMaritalStatus());
    if (lendingApplicant.getBasicInfo() != null) {
      this.getBasicInfo().setEmailAddress(lendingApplicant.getBasicInfo().getEmailAddress());
    }
    return this;
  }
  
  public boolean isValidMandatoryFields(MyInfoPersonResponse person) {
    
		
	boolean isValid = true;
    if(Strings.isBlank(person.getLegalId())) {
      log.error("Myinfo Legal ID is empty");
      isValid = false;
    }
    if(person.getName() == null || Strings.isBlank(person.getName().getValue())) {
      log.error("MyInfo Name is blank");
      isValid = false;
    }
    if(person.getMobileno() == null || Strings.isBlank(person.getMobileno().getNbr().getValue())) {
      log.error("MyInfo Mobile Number is blank");
      isValid = false;
    }
    if(person.getDob() == null || Strings.isBlank(person.getDob().getValue())) {
      log.error("MyInfo DOB is blank");
      isValid = false;
    }
    if(person.getBirthcountry() == null || Strings.isBlank(person.getBirthcountry().getCode())) {
      log.error("MyInfo Birth Country is blank");
      isValid = false;
    }
    if(person.getSex() == null || Strings.isBlank(person.getSex().getCode())) {
      log.error("MyInfo Sex is blank");
      isValid = false;
    }
    if(person.getNationality() == null || Strings.isBlank(person.getNationality().getCode())) {
      log.error("MyInfo Nationality is blank");
      isValid = false;
    }
    boolean isSGPr = person.getResidentialstatus() != null && (ResidentialStatus.CITIZEN.getCode()
        .equalsIgnoreCase(person.getResidentialstatus().getValue())
        || ResidentialStatus.PR.getCode()
        .equalsIgnoreCase(person.getResidentialstatus().getValue()));
    if (isSGPr && (person.getRegadd() == null
        || StringUtils.isAllBlank(person.getRegadd().getUnit().getValue(),
            person.getRegadd().getStreet().getValue(), person.getRegadd().getBlock().getValue(),
            person.getRegadd().getPostal().getValue(), person.getRegadd().getFloor().getValue()))) {
      log.error("Residential Address for SG/PR customer is empty/blank");
      isValid = false;
    }
    if (StringUtils.isAllBlank(
        person.getHousingtype() != null ? person.getHousingtype().getCode() : Strings.EMPTY,
        person.getHdbtype() != null ? person.getHdbtype().getCode() : Strings.EMPTY)) {
      log.error("Myinfo Housing type and HDB type is empty/blank");
      isValid = false;
    }
    return isValid;
  }
}   

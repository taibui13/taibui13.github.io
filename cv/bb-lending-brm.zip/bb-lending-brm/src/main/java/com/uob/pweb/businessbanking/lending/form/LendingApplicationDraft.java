package com.uob.pweb.businessbanking.lending.form;

import org.apache.commons.lang3.StringUtils;
import com.uob.pweb.component.brm.BrmDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LendingApplicationDraft {

  private String id;
  private String applicantId;
  private String productTitle;
  private String referenceNo;
  private String companyName;
  private String createdDate;
  private String expiryDate;

  public static LendingApplicationDraft from(
      LendingApplicationForm lendingApplicationForm) {

    return StringUtils.isEmpty(lendingApplicationForm.getId()) ? null
        : LendingApplicationDraft.builder()
            .id(lendingApplicationForm.getId())
            .productTitle(lendingApplicationForm.getProduct()
                .getCode())
            .referenceNo(lendingApplicationForm.getReferenceNumber())
            .companyName(lendingApplicationForm.getEntity()
                .getBasicProfile()
                .getEntityName())
            .createdDate(lendingApplicationForm.getCreatedDate())
            .expiryDate(lendingApplicationForm.getExpiryDate())
            .build();
  }
}

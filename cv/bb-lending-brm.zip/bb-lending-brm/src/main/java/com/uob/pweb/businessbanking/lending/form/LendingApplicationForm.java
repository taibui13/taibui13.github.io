package com.uob.pweb.businessbanking.lending.form;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.uob.pweb.businessbanking.lending.exception.LendingError;
import com.uob.pweb.businessbanking.lending.form.Business.Appointment;
import com.uob.pweb.businessbanking.lending.form.Business.Capital;
import com.uob.pweb.businessbanking.lending.form.Business.Shareholder;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.BasicInfo;
import com.uob.pweb.businessbanking.lending.specification.Product;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.myinfo.CapitalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Builder(toBuilder = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class LendingApplicationForm implements Serializable {

  private static final long serialVersionUID = 1L;

  private String referenceNumber;
  private String id;
  private String sourceType;
  private String status;
  private String expiryDate;
  private String initiateDate;
 
  private String createdDate;

  private String MainApplicantName;

  @Valid
  private Business entity;
  private List<LendingApplicant> person;

  private Boolean isKeymanApply;

  @Valid
  private List<AdditionalAppointment> additionalAppointment;

  @JsonIgnore
  private Product product;

  public boolean withPrivateLimitedEntity() {
    return entity.ofOthers();
  }

  public boolean withOrdinaryCapital() {
    return entity.getCapitals()
        .stream()
        .anyMatch(capital -> CapitalType.ORDINARY_CAPITAL.getCode()
            .equals(capital.getCapitalType()));
  }

  public BigDecimal calculateEntityShareAllottedAmount() {
    Optional<Capital> capitalOptional = entity.getCapitals()
        .stream()
        .filter(capital -> CapitalType.ORDINARY_CAPITAL.getCode()
            .equals(capital.getCapitalType()))
        .findFirst();
    if (capitalOptional.isPresent()) {
      return capitalOptional.get().getShareAllottedAmount();
    }
    return BigDecimal.ZERO;
  }

  public List<Shareholder> findEntityShareholders() {
    return entity.getShareholders();
  }

  public String findEmailAddress() {
    return findCurrentApplicant().getBasicInfo()
        .getEmailAddress();
  }

  public String findCurrentApplicantPrincipalName() {
    return findCurrentApplicant().findPrincipalName();
  }

  public String findCurrentApplicantLegalId() {
    return findCurrentApplicant().getBasicInfo()
        .getLegalId();
  }

  public void clearIncome() {
    this.findCurrentApplicant()
        .setNoaHistory(null);
  }

  public LendingApplicant findCurrentApplicant() {
	  
	  if (CollectionUtils.isEmpty(person)) {
      throw new ApiRuntimeException(HttpStatus.FORBIDDEN,
          LendingError.InvalidApplication.getCode(),
          LendingError.InvalidApplication.getMessage());
    }
 
	return person.get(0);
    //return person.iterator()
      //  .next();
  }

  // TODO cannot be like this
  public String findMobileNum() {
    return findCurrentApplicant().getBasicInfo()
        .getMobileNumber();
//        .replaceAll("\\+65", "");
  }

  public String getMobileNum() {
	 String plus = "+";   
	 return plus.concat(findCurrentApplicant().getBasicInfo()
	        .getMobileNumber());
	        
	  }
  
  
  public String findEntityType() {
    return entity.getBasicProfile()
        .getEntityType();
  }

  public BasicInfo retrieveMainApplicantInfo() {
	if (CollectionUtils.isEmpty(person)) {
      throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
          LendingError.InvalidApplication.getCode(),
          LendingError.InvalidApplication.getMessage());
    }
	/**person.iterator()
	        .next()
	        .getBasicInfo(); */
	return person.get(0).getBasicInfo();
	    
  }

  public LendingApplicationForm init(String productCode,
      SpecificationService specificationService) {

    // set product
    this.setProduct(specificationService.flow(productCode));

    log.info("start - initiate application  product Code {} -  source {}",
        this.getProduct()
            .getCode(),
        this.getSourceType());

    // director list
    log.info("calculate shareholders for applicant {} and entity type {}",
        this.findCurrentApplicantLegalId(), this.findEntityType());

    setApplicationAdditionalAppointments(specificationService);

    log.info("end - initiate application {}", this);

    return this;
  }

  public void setApplicationAdditionalAppointments(SpecificationService specificationService) {
    List<String> directorPositionCodes = this.getEntity()
        .ofSoleProprietor()
            ? specificationService.getSpec()
                .getLendingConfig()
                .getS()
            : (this.getEntity()
                .ofPartnership()
                    ? specificationService.getLendingConfig()
                        .getP()
                    : specificationService.getLendingConfig()
                        .getO());

    log.info(
        "The entity type is {}, populate additional applicants with position codes {}",
        this.findEntityType(), directorPositionCodes);

    // get all directors from entity appointments using director code
    List<Appointment> directors = Optional.ofNullable(this.getEntity()
        .getAppointments())
        .orElse(new ArrayList<Appointment>())
        .stream()
        .filter(appointment -> appointment.getPersonReference() != null
            && directorPositionCodes.contains(appointment.getPositionCode()))
        .collect(Collectors.toList());

    String currentApplicantLegalId = this.findCurrentApplicantLegalId();

    // is main applicant a director
    this.setIsKeymanApply(directors.stream()
        .anyMatch(a -> currentApplicantLegalId.equalsIgnoreCase(a.getPersonReference()
            .getIdno())));

    // additional appointments
    List<AdditionalAppointment> additionalAppointments = directors.stream()
        .filter(appointment -> appointment.ofIndividualOwned()
            && (!appointment.ofSamePerson(this.findCurrentApplicantLegalId())))
        .map(individualAppointment -> AdditionalAppointment.builder()
            .name(individualAppointment.getPersonReference()
                .getPersonName())
            .legalId(individualAppointment.getPersonReference()
                .getIdno())
            .build())
        .collect(Collectors.toList());

    // calculate shares
    if (this.withPrivateLimitedEntity()) {
      if (this.withOrdinaryCapital()) {
        log.info(
            "Ordinary capital with code {} exists, calculating shareholding based on share allotted amount",
            CapitalType.ORDINARY_CAPITAL.getCode());
        BigDecimal minimumAllocation = this.calculateEntityShareAllottedAmount().multiply(new BigDecimal(0.25));

        this.findEntityShareholders()
            .stream()
            .filter(shareholder -> shareholder.ofOrdinaryCapital()
                && shareholder.ofIndividualOwned()
                && !shareholder.ofSamePerson(this.findCurrentApplicantLegalId())
                && shareholder.getAllocation() >= minimumAllocation.intValue())
            .forEach(
                shareholder -> additionalAppointments.add(AdditionalAppointment.builder()
                    .name(shareholder.getPersonReference()
                        .getPersonName())
                    .legalId(shareholder.getPersonReference()
                        .getIdno())
                    .build()));

      } else {
        log.info("Ordinary capital does not exist.");
      }
    }

    log.info("remove duplicated partners"); // add from above
    HashSet<Object> seen = new HashSet<>();
    additionalAppointments.removeIf(per -> !seen.add(per.getLegalId()));

    this.setAdditionalAppointment(additionalAppointments);
  }

  public LendingApplicationForm sync(LendingApplicationForm lendingApplicationForm) {
    // if no mailing then is same as registered both submit and update share this will always pass all
    this.getEntity()
        .setAddresses(lendingApplicationForm.getEntity()
            .getAddresses());

    // will always pass all
    this.setAdditionalAppointment(lendingApplicationForm.getAdditionalAppointment());

    // will always pass all
    findCurrentApplicant().sync(lendingApplicationForm.findCurrentApplicant());

    return this;
  }

  public LendingApplicant findLendingApplicant(String id) {
    return null;
  }

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ApplicationResponse {
    private String referenceNumber;
  }

}

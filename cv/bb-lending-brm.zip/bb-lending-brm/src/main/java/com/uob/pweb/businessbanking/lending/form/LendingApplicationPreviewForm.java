package com.uob.pweb.businessbanking.lending.form;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LendingApplicationPreviewForm {

  private String applicationId;
  private String applicantId;
  private String productCode;
  private String referenceNumber;
  private String entityName;
  private String expiryDate;

  public static LendingApplicationPreviewForm from(
      LendingApplicationForm lendingApplicationForm) {
    return LendingApplicationPreviewForm.builder()
        .applicationId(lendingApplicationForm.getId())
        .expiryDate(lendingApplicationForm.getExpiryDate())
        .entityName(lendingApplicationForm.getEntity()
            .getBasicProfile()
            .getEntityName())
        .productCode(lendingApplicationForm.getProduct()
            .getCode())
        .referenceNumber(lendingApplicationForm.getReferenceNumber())
        .build();
  }
}

package com.uob.pweb.businessbanking.lending.form;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.security.core.context.SecurityContextHolder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.exception.LendingError;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.myinfo.EntityStatus;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;
import com.uob.pweb.component.EntityPersonResponse;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class LendingValidator {

  @Autowired
  private MyInfoValidation validation;

  @Autowired
  private SpecificationService specificationService;

  @Bean
  public IntegrationFlow corppassValidator() {
    return f -> f.handle(m -> {

      log.info("start - validate data from corppass");
      EntityPersonResponse myResponse = (EntityPersonResponse) m.getPayload();

      com.uob.pweb.common.framework.myinfo.types.entity.EntityPersonResponse response =
          new ObjectMapper().convertValue(myResponse,
              com.uob.pweb.common.framework.myinfo.types.entity.EntityPersonResponse.class);

      List<String> errors = validation.validate(response,
          new HashSet<String>(Arrays.asList(specificationService.getLendingConfig()
              .getCorppassRequired()
              .split(","))));

      if (!CollectionUtils.isEmpty(errors)) {
        throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
            LendingError.MyInfoRequired.getCode(),
            LendingError.MyInfoRequired.getMessage());
      }

      if (EntityStatus.NON_LIVE.getCode()
          .equalsIgnoreCase(response.getEntityPerson()
              .getEntity()
              .getBasicProfile()
              .getEntityStatus())) {
        log.error("entity status not allowed");
        throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
            LendingError.InvalidEntityStatus.getCode(),
            LendingError.InvalidEntityStatus.getMessage());
      }

      log.info("end - validate data from corppass");

    });
  }

  @Bean
  public IntegrationFlow beanValidator(Validator beanValidator) {
    return f -> f.handle(m -> {

      log.info("start - bean validation");
      LendingApplicationForm payload = (LendingApplicationForm) m.getPayload();
      Set<ConstraintViolation<Object>> errors = beanValidator.validate(payload);
      if (!org.springframework.util.CollectionUtils.isEmpty(errors))
        throw new ConstraintViolationException(errors);
      log.info("end - bean validation");

    });
  }

  @Bean
  public IntegrationFlow additionalAppointmentValidator() {
    return f -> f.handle(m -> {
      log.info("start - additional appointment validation");
      LendingApplicationForm application = (LendingApplicationForm) m.getPayload();
      List<String> legalIds = application.getAdditionalAppointment()
          .stream()
          .map(AdditionalAppointment::getLegalId)
          .collect(Collectors.toList());
      legalIds.add(((Authentication) SecurityContextHolder.getContext()
          .getAuthentication()).getLendingApplicationForm()
              .retrieveMainApplicantInfo()
              .getLegalId());
      if (legalIds.stream()
          .distinct()
          .count() != legalIds.size()) {
        log.info("duplicate partner exists");
        throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
            LendingError.InvalidAdditionalAppointment.getCode(),
            LendingError.InvalidAdditionalAppointment.getMessage());
      }
      log.info("end - additional appointment validation");

    });
  }

}

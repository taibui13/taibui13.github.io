package com.uob.pweb.businessbanking.lending.form.flow;

import static org.springframework.integration.http.HttpHeaders.STATUS_CODE;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.client.RestTemplate;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.component.OtpBuilder.OtpRequest;
import com.uob.pweb.component.OtpBuilder.OtpResponse;
import com.uob.pweb.component.OtpBuilder.OtpVerificationRequest;

@Configuration
public class LendingApplicantFlow {

  @Autowired
  @Qualifier("myinfoRestTemplate")
  private RestTemplate restTemplate;

  // Anonymous -> Business Verified
  @Bean
  public IntegrationFlow getBusinessInfo() {
    return IntegrationFlows.from(Http.inboundGateway("/applicants/business/info")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .headerExpression("state", "#requestParams.getFirst('state')")
        .headerExpression("code", "#requestParams.getFirst('code')")
        .headerExpression("scope", "#requestParams.getFirst('scope')")
        .headerExpression("client_id", "#requestParams.getFirst('client_id')")
        .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[start]-get business info")
        .wireTap("requestLoggingFlow.input")
        .gateway(Authentication.create())
        .gateway("verifyBusinessInfo.input")
        .get();
  }

  // Partner Verifiying -> Partner Verified
  @Bean
  public IntegrationFlow getPartnersInfo() {
    return IntegrationFlows.from(Http.inboundGateway("/applicants/partners/info")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .headerExpression("state", "#requestParams.getFirst('state')")
        .headerExpression("code", "#requestParams.getFirst('code')")
        .headerExpression("scope", "#requestParams.getFirst('scope')")
        .headerExpression("client_id", "#requestParams.getFirst('client_id')")
        .headerExpression("application_id", "#requestParams.getFirst('application_id')")
        .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[start]-get partner info")
        .wireTap("requestLoggingFlow.input")
        .gateway("verifyPartnerInfo.input")
        .gateway("enrichPartnerInfo.input")
        .wireTap(
            saveApplication -> saveApplication
                .<LendingApplicationForm>handle(
                    (lendingApplicationForm, headers) -> Authentication
                        .save(Authentication.current()
                            .toBuilder()
                            .lendingApplicationForm(lendingApplicationForm)
                            .authorities(Arrays.asList(new SimpleGrantedAuthority(
                                Authentication.PARTNER_VERIFIED)))
                            .build())
                        .getLendingApplicationForm()))
        .get();
  }

  // Anonymous
  @Bean
  public IntegrationFlow getOtp(@Value("${otp.url.send:}") String sendOtpUrl) {
    return IntegrationFlows.from(Http.inboundGateway("/applicants/otp")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .errorChannel("globalErrorFlow.input"))
        .wireTap("requestLoggingFlow.input")
        .log(LoggingHandler.Level.INFO, this.getClass()
            .getName(), m -> "[start]-send otp")
        .handle((p, h) -> OtpRequest.builder()
            .mobileNumber(Authentication.current()
                .getLendingApplicationForm()
                .findMobileNum())
            .build())
        .log(LoggingHandler.Level.INFO, this.getClass()
            .getName(), m -> "[start]-send otp" + m.getPayload())
        .enrichHeaders(
            e -> e.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
        .handle(Http.outboundGateway(sendOtpUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(HttpHeaders.CONTENT_TYPE)
            .expectedResponseType(OtpResponse.class))
        .wireTap(saveIdentity -> saveIdentity.<OtpResponse>handle((otpResponse,
            headers) -> Authentication.save(Authentication.current()
                .toBuilder()
                .identity(otpResponse.getRequestIdentity())
                .build())))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[end]-send sms otp request")
        .<OtpResponse>handle((otpResponse, headers) -> {
          return MessageBuilder.withPayload(otpResponse)
              .setHeader(STATUS_CODE, HttpStatus.OK)
              .build();
        })
        .get();
  }

  // Anonymous -> Business Verified
  @Bean
  public IntegrationFlow verifyOtp(@Value("${otp.url.verify:}") String verifyOtpUrl) {
    return IntegrationFlows.from(Http.inboundGateway("/applicants/otp/{code}")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .headerExpression("code", "#pathVariables.code")
        .errorChannel("globalErrorFlow.input"))
        .log(LoggingHandler.Level.INFO, this.getClass()
            .getName(), m -> "[start]-verifying sms otp request for" + m.getPayload())
        .wireTap("requestLoggingFlow.input")
        .handle(
            (payload, headers) -> new OtpVerificationRequest((String) headers.get("code"),
                Authentication.current()
                    .getIdentity()))
        .enrichHeaders(
            e -> e.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
        .handle(Http.outboundGateway(verifyOtpUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(HttpHeaders.CONTENT_TYPE)
            .expectedResponseType(OtpResponse.class))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[end]-sms otp verified")
        .handle((payload, headers) -> {
          return MessageBuilder.withPayload("{}")
              .setHeader(STATUS_CODE, HttpStatus.OK)
              .build();
        })
        .get();
  }

}

package com.uob.pweb.businessbanking.lending.form.flow;

import static org.springframework.integration.http.HttpHeaders.STATUS_CODE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.exception.LendingError;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationDraft;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationPreviewForm;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.myinfo.types.entity.EntityPerson;
import com.uob.pweb.component.EntityPersonResponse;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class LendingApplicationFlow {

  // Business Verified - have funny query parameters...
  @Bean
  public IntegrationFlow createLendingApplication(SpecificationService specificationService,
      ObjectMapper objectMapper) {
    return IntegrationFlows
        .from(Http.inboundGateway("/applications").requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(LendingApplicationForm.class)
            .headerExpression("productCode", "#requestParams.getFirst('productCode')")
            .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass().getName(), m -> "[start]-initiate application")
        .wireTap("requestLoggingFlow.input")
        .wireTap("validateApplicationForSafeHtml.input")
        .<LendingApplicationForm>handle((p, h) -> {
          String url = h.get(HttpHeaders.REQUEST_URL).toString();
          p.setSourceType(url.indexOf("?") > 0 ? url.substring(url.indexOf("?") + 1) : Strings.EMPTY);
          return p;
        })
        .gateway("enrichBusinessInfo.input")
        .<LendingApplicationForm>handle((p, h) -> 
          p.init((String) h.get("productCode"), specificationService))
        .gateway(f -> f.gateway("createApplication.input"))
        .wireTap(sf -> sf.<LendingApplicationForm>handle((p, h) -> Authentication
                .save(Authentication.current().toBuilder()
                    .lendingApplicationForm(p)
                    .build())
                .getLendingApplicationForm()))
        .get();
  }
  
  // Business Verified
  // Partner Verified
  @Bean
  public IntegrationFlow updateLendingApplication() {
    return IntegrationFlows
        .from(Http.inboundGateway("/applications/{id}")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(LendingApplicationForm.class)
            .headerExpression("applicationId", "#pathVariables.id")
            .errorChannel("globalErrorFlow.input"))
        .log(LoggingHandler.Level.INFO, this.getClass().getName(),
            m -> "[start]-update application")
        .wireTap("requestLoggingFlow.input")
        .wireTap("validateApplicationForSafeHtml.input")
        .gateway(businessOrPartners("updateApplication.input", "updateApplicant.input"))
        .get();
  }

  // Business Verified -> Anonymous
  // Partner Verified -> Anonymous
  @Bean
  public IntegrationFlow submitLendingApplication() {
    return IntegrationFlows
        .from(Http.inboundGateway("/applications/{id}/submit")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(LendingApplicationForm.class)
            .headerExpression("applicationId", "#pathVariables.id")
            .errorChannel("globalErrorFlow.input"))
        .log(LoggingHandler.Level.INFO, this.getClass().getName(), m -> "[start]-submit application")
        .wireTap("requestLoggingFlow.input")
        .wireTap("validateApplicationForSafeHtml.input")
        .gateway(businessOrPartners("updateApplication.input", "updateApplicant.input"))
        .gateway(businessOrPartners("submitApplication.input", "submitApplicant.input"))
        .get();
  }

  public IntegrationFlow businessOrPartners(String application, String applicant) {
    return with -> with.wireTap(validateLendingApplicationIdInHeader())
        .gateway(f -> f.route(LendingApplicationForm.class,p -> Authentication.current().isBusinessVerified(),
                    isBusiness -> isBusiness
                        .subFlowMapping(Boolean.TRUE,
                            then -> then
                                .<LendingApplicationForm>handle((p, h) -> Authentication.current()
                                    .getLendingApplicationForm().sync(p))
                                .wireTap("additionalAppointmentValidator.input")
                                .routeToRecipients(r -> r.recipient(application)))
                        .subFlowMapping(Boolean.FALSE,
                            then -> then.logAndReply(Level.INFO, this.getClass().getName(), m -> "[log]-not a business")))
                .route(LendingApplicationForm.class, p -> Authentication.current().isPartnerVerified(),
                    isPartner -> isPartner
                        .subFlowMapping(Boolean.TRUE,
                            then -> then
                                .<LendingApplicationForm>handle((p, h) -> Authentication.current().getLendingApplicationForm()
                                        .findCurrentApplicant().sync(p.findCurrentApplicant()))
                                .routeToRecipients(r -> r.recipient(applicant)))
                        .subFlowMapping(Boolean.FALSE, 
                            then -> then.logAndReply(Level.INFO, this.getClass().getName(), m -> "[log]-not a partner"))));
  }

  public IntegrationFlow validateLendingApplicationIdInHeader() {
    return validateApplicationId -> validateApplicationId
        .log(LoggingHandler.Level.INFO, this.getClass()
            .getName(), m -> "[validate]-application id")
        .filter(Message.class, m -> Optional.ofNullable(m.getHeaders()
            .get("applicationId"))
            .orElseThrow(() -> new RuntimeException())
            .equals(Optional.ofNullable(Authentication.current())
                .map(authentication -> authentication.getLendingApplicationForm())
                .map(lendingApplicationForm -> lendingApplicationForm.getId())
                .orElseThrow(() -> new RuntimeException())),
            orElse -> orElse.discardFlow(then -> then.handle((p, h) -> {
              throw new RuntimeException();
            })));
  }

  // Anonymous -> Partner Verifiying
  @Bean
  public IntegrationFlow getPreview() {
    return IntegrationFlows
        .from(Http
            .inboundGateway(
                "/applications/{applicationId}/applicants/{applicantId}/preview")
            .requestMapping(m -> m.methods(HttpMethod.GET))
            .headerExpression("applicationId", "#pathVariables.applicationId")
            .headerExpression("applicantId", "#pathVariables.applicantId")
            .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "start - verify application")
        .wireTap("requestLoggingFlow.input")
        .gateway(Authentication.create())
        .gateway("getApplication.input")
        .wireTap(save -> save.
            <LendingApplicationForm>handle((lendingApplicationForm, headers) ->
                Authentication.save(Authentication.current()
                .toBuilder()
                .lendingApplicationForm(lendingApplicationForm)
                .authorities(Arrays
                    .asList(new SimpleGrantedAuthority(Authentication.PARTNER_VERIFYING)))
                .build())))
         .<LendingApplicationForm, LendingApplicationPreviewForm>transform(
            lendingApplicationForm -> LendingApplicationPreviewForm
                .from(lendingApplicationForm))
        .get();
  }

  // Business Verified
  @Bean
  public IntegrationFlow getLendingApplicationList(
      SpecificationService specificationService, ObjectMapper objectMapper) {
    return IntegrationFlows.from(Http.inboundGateway("/applications")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .headerExpression("productCode", "#requestParams.getFirst('productCode')")
        .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[start]-get application list")
        .wireTap("requestLoggingFlow.input")
        .enrichHeaders(e -> e.headerFunction("companyUenNo", m -> {
          return ((EntityPersonResponse) Authentication.current()
              .getBusinessInfo()).getUen();
        }, true))
        .enrichHeaders(e -> e.headerFunction("productCode", m -> {
          return specificationService.flow((String) m.getHeaders()
              .get("productCode"))
              .getBrm();
        }, true))
        .enrichHeaders(e -> e.headerFunction("status", m -> {
          return "WIP-Online";
        }, true))
        .enrichHeaders(e -> e.headerFunction("idNo", m -> {
          return ((EntityPersonResponse) Authentication.current()
              .getBusinessInfo()).getUinfin();
        }, true))
        .gateway("getApplicationDraft.input")
        .wireTap(save -> save.<LendingApplicationForm>handle((lendingApplicationForm,
            headers) -> Authentication.save(Authentication.current()
                .toBuilder()
                .lendingApplicationForm(lendingApplicationForm.toBuilder()
                    .person(Arrays.asList(LendingApplicant.builder()
                        .build()
                        .initMainApplicant(((EntityPersonResponse) Authentication.current()
                            .getBusinessInfo()).getUinfin(),
                            objectMapper
                                .convertValue(
                                    ((EntityPersonResponse) Authentication.current()
                                        .getBusinessInfo()).getEntityPerson(),
                                    EntityPerson.class)
                                .getPerson(),
                            objectMapper)))
                    .build())
                .build())))
        .<LendingApplicationForm, List<LendingApplicationDraft>>transform(
            lendingApplicationForm -> {
              return LendingApplicationDraft.from(lendingApplicationForm) == null
                  ? new ArrayList<>()
                  : Arrays.asList(LendingApplicationDraft.from(lendingApplicationForm));
            })
        .get();
  }

  // Business Verified
  @Bean
  public IntegrationFlow getLendingApplication() {
    return IntegrationFlows.from(Http.inboundGateway("/applications/{id}")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .headerExpression("applicationId", "#pathVariables.id")
        .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[start]-get application")
        .wireTap("requestLoggingFlow.input")
       //.gateway("getApplication.input")
        .handle((p,h) -> {
        		return Authentication.current().getLendingApplicationForm();
        	})
        .wireTap(save -> save
            .<LendingApplicationForm>handle((lendingApplicationForm, headers) -> {
              return Authentication.save(Authentication.current()
                  .toBuilder()
                  .lendingApplicationForm(lendingApplicationForm)
                  .build())
                  .getLendingApplicationForm();
            }))
        .gateway(update -> update.route(LendingApplicationForm.class,
            p -> Authentication.current()
                .isBusinessVerified(),
            isBusiness -> isBusiness.subFlowMapping(Boolean.TRUE,
                then -> then.filter(LendingApplicationForm.class,
                    lendingApplicationForm -> !"WIP-Online"
                        .equals(lendingApplicationForm.getStatus()),
                    orElse -> orElse.discardFlow(andThen -> andThen.handle((p, h) -> {
                      Map<String, Object> response = new HashMap<>();
                      response.put("errorCode", "AppSubmitted");

                      return MessageBuilder.withPayload(response)
                          .setHeader(STATUS_CODE, HttpStatus.BAD_REQUEST)
                          .build();
                    })))
                    .logAndReply(Level.INFO, this.getClass()
                        .getName(), m -> "[filter]-valid status"))
                .subFlowMapping(Boolean.FALSE,
                    then -> then.logAndReply(Level.INFO, this.getClass()
                        .getName(), m -> "[log]-not a business"))))
        .get();
  }

  // Business Verified
  @Bean
  public IntegrationFlow getLendingApplicationBusiness() {
    return IntegrationFlows.from(Http.inboundGateway("/applications/{id}/business/{uen}")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .headerExpression("applicationId", "#pathVariables.id")
        .headerExpression("uen", "#pathVariables.uen")
        .errorChannel("globalErrorFlow.input"))
        .log(Level.INFO, this.getClass()
            .getName(), m -> "[start]-get application business")
        .wireTap("requestLoggingFlow.input")
        .transform(payload -> Authentication.current()
            .getLendingApplicationForm())
        .filter(Message.class, message -> message.getHeaders()
            .get("uen")
            .equals(((LendingApplicationForm) message.getPayload()).getEntity()
                .getBasicProfile()
                .getUen()),
            orElse -> orElse.discardFlow(then -> then.handle((payload, headers) -> {
              return MessageBuilder.withPayload(null)
                  .setHeader(STATUS_CODE, HttpStatus.NOT_FOUND)
                  .build();
            })))
        .wireTap(
            save -> save
                .<LendingApplicationForm>handle(
                    (lendingApplicationForm, headers) -> Authentication
                        .save(Authentication.current()
                            .toBuilder()
                            .authorities(Arrays.asList(new SimpleGrantedAuthority(
                                Authentication.BUSINESS_VERIFIED)))
                            .build())
                        .getLendingApplicationForm()))
        .get();
  }
  
  @Bean
  public IntegrationFlow validateApplicationForSafeHtml(Validator validator) {
    return f -> f.handle(m -> {
      log.info("start - validate Application for SafeHtml");
      LendingApplicationForm app = (LendingApplicationForm) m.getPayload();
      Set<ConstraintViolation<Object>> errors = validator.validate(app);
      if (!org.springframework.util.CollectionUtils.isEmpty(errors)) {
    	  for(ConstraintViolation<Object> cv : errors) {
    		  if(cv.getMessage().contains("html tags")) {
    			  throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
    			          LendingError.InvalidRequest.getCode(), LendingError.InvalidRequest.getCode() + ":SafeHtml");  
    		  }
    	  }
      };
      log.info("end - validate Application for SafeHtml");
    });
  }
  
}

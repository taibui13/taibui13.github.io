package com.uob.pweb.businessbanking.lending.form.flow;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.form.Business;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.myinfo.types.MyInfoRequest;
import com.uob.pweb.common.framework.myinfo.types.entity.EntityPerson;
import com.uob.pweb.common.framework.myinfo.v3.MyInfoPersonResponse;
import com.uob.pweb.component.EntityPersonResponse;

@Configuration
public class LendingVerificationFlow {

  @Value("${corppass.clientSecret:}")
  private String corppassClientSecretKey;

  @Value("${corppass.redirectUrl:}")
  private String corppassRedirectUrl;

  @Value("${service-url.myinfo-entity-person:}")
  private String myInfoCorppassUrl;

  @Value("${myinfo.clientSecret:}")
  private String myInfoClientSecretKey;

  @Value("${myinfo.redirectUrl:}")
  private String myinfoRedirectUrl;

  @Value("${service-url.myinfo-person:}")
  private String myInfoPersonUrl;

  @Autowired
  @Qualifier("myinfoRestTemplate")
  private RestTemplate restTemplate;

  @Bean
  public IntegrationFlow verifyBusinessInfo() {
    // need myinfo validator TODO
    return start -> start.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-verify business info")
        .transform(Message.class, m -> MessageBuilder.withPayload(MyInfoRequest.builder()
            .authorisationtoken(m.getHeaders()
                .get("code")
                .toString())
            .clientsecretidentity(corppassClientSecretKey)
            .applicationidentity(m.getHeaders()
                .get("client_id")
                .toString())
            .clientidentity(m.getHeaders()
                .get("client_id")
                .toString())
            .redirectUrl(corppassRedirectUrl)
            .attributes(m.getHeaders()
                .get("scope")
                .toString())
            .state(m.getHeaders()
                .get("state")
                .toString())
            .build())
            .copyHeadersIfAbsent(m.getHeaders())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
            .build())
        .handle(Http.outboundGateway(myInfoCorppassUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .expectedResponseType(EntityPersonResponse.class))
        .wireTap("corppassValidator.input")
        .wireTap(saveApplication -> saveApplication
            .<EntityPersonResponse>handle((entityPersonResponse, header) -> {
              return Authentication.save(Authentication.current()
                  .toBuilder()
                  .businessInfo(entityPersonResponse)
                  .authorities(Arrays.asList(
                      new SimpleGrantedAuthority(Authentication.BUSINESS_VERIFIED)))
                  .build())
                  .getBusinessInfo();
            }));
  }

  @Bean
  public IntegrationFlow verifyPartnerInfo() {
    // need myinfo validator TODO
    return start -> start.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-verify partner info")
        .enrichHeaders(h -> h.headerFunction("client-id", message -> message.getHeaders().get("client_id").toString()))
        .enrichHeaders(h -> h.headerFunction("app-id", message -> message.getHeaders().get("client_id").toString()))
        .enrichHeaders(h -> h.headerFunction("client-secret", message -> myInfoClientSecretKey))
        .enrichHeaders(h -> h.headerFunction("redirect-uri", message -> myinfoRedirectUrl))
        .handle(Http.outboundGateway(
          m -> UriComponentsBuilder.fromHttpUrl(myInfoPersonUrl)
              .queryParam("code", m.getHeaders().get("code"))
              .queryParam("attributes", m.getHeaders().get("scope").toString())
              .build().encode().toUriString(), restTemplate)
            .expectedResponseType(MyInfoPersonResponse.class)
            .mappedRequestHeaders("client-id", "client-secret", "app-id", "redirect-uri")
            .httpMethod(HttpMethod.GET))
        .filter(MyInfoPersonResponse.class, personResponse -> Optional
            .ofNullable(Authentication.current())
            .map(authentication -> authentication.getLendingApplicationForm())
            .map(lendingApplicationForm -> lendingApplicationForm.findCurrentApplicant())
            .map(lendingApplicant -> lendingApplicant.findLegalId())
            .orElseThrow(() -> new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR,
                "partner.applicant", "Cannot find partner applicant"))
            .equals(Optional.ofNullable(personResponse)
                .orElseThrow(
                    () -> new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR,
                        "partner.applicant", "Cannot find legal id"))
                .getLegalId()),
            orElse -> orElse.discardFlow(then -> then.handle((p, h) -> {
              throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR,
                  "partner.applicant", "Legal id not match");
            })));
  }

  @Bean
  public IntegrationFlow enrichBusinessInfo(ObjectMapper objectMapper) {
    return f -> 
       f.log(Level.INFO, this.getClass().getName(), m -> "[start]-enrich business info")
        .<LendingApplicationForm>handle((p, h) -> {
          
          EntityPersonResponse corpPassResponse = (EntityPersonResponse) Authentication.current().getBusinessInfo();
          EntityPerson entityPerson = objectMapper.convertValue(corpPassResponse.getEntityPerson(), EntityPerson.class);
          p.setEntity(Business.init(corpPassResponse.getUen(), entityPerson.getEntity(), objectMapper));
          LendingApplicant currentApplicant = 
              p.findCurrentApplicant().initMainApplicant(corpPassResponse.getUinfin(), entityPerson.getPerson(), objectMapper);
          p.setPerson(Stream.of(currentApplicant).collect(Collectors.toList()));
          return p;
        })
        .wireTap(sf -> sf.<LendingApplicationForm>handle((p,h) -> Authentication.save(Authentication.current()
                .toBuilder()
                .lendingApplicationForm(p)
                .build())
                .getLendingApplicationForm()));
  }

  @Bean
  public IntegrationFlow enrichPartnerInfo(ObjectMapper objectMapper) {
    return i -> i.log(Level.INFO, this.getClass()
        .getName(), m -> "[start]-enrich partner info")
        .<MyInfoPersonResponse, LendingApplicationForm>transform(partnerInfo -> {
          LendingApplicationForm lendingApplicationForm = Authentication.current()
              .getLendingApplicationForm()
              .toBuilder()
              .person(Stream.of(Authentication.current()
                  .getLendingApplicationForm()
                  .findCurrentApplicant()
                  .init(partnerInfo.getLegalId(), partnerInfo, objectMapper))
                  .collect(Collectors.toList()))
              .build();
          return lendingApplicationForm;
        });
  }
}

package com.uob.pweb.businessbanking.lending.security;

import java.util.List;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import com.uob.pweb.businessbanking.lending.component.ApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
public class Authentication extends AbstractAuthenticationToken {

  private static final long serialVersionUID = 1L;

  // new roles
  public static final String BUSINESS_VERIFYING = "BUSINESS_VERIFYING";
  public static final String PARTNER_VERIFYING = "PARTNER_VERIFYING";

  public static final String BUSINESS_VERIFIED = "BUSINESS_VERIFIED";
  public static final String PARTNER_VERIFIED = "PARTNER_VERIFIED";

  private ApplicationForm applicationForm;
  private LendingApplicationForm lendingApplicationForm;
  private Object businessInfo;
  private String identity;
  private List<GrantedAuthority> authorities;

  public Authentication(ApplicationForm applicationForm,
      LendingApplicationForm lendingApplicationForm, Object businessInfo, String identity,
      List<GrantedAuthority> authorities) {
    super(authorities);
    this.authorities = authorities;
    this.setAuthenticated(true);
    this.setApplicationForm(applicationForm);
    this.setLendingApplicationForm(lendingApplicationForm);
    this.setBusinessInfo(businessInfo);
    this.identity = identity;
  }

  @Override
  public Object getCredentials() { return null; }

  public boolean isBusinessVerified() {
    return authorities.contains(new SimpleGrantedAuthority(BUSINESS_VERIFIED));
  }

  public boolean isPartnerVerified() {
    return authorities.contains(new SimpleGrantedAuthority(PARTNER_VERIFIED));
  }

  @Override
  public Object getPrincipal() {
    return lendingApplicationForm != null ? new StringBuilder("BIZ_LOAN_")
        .append(lendingApplicationForm.getReferenceNumber())
        .append("_")
        .append(lendingApplicationForm.getPerson()
            .get(0)
            .getBasicInfo()
            .getLegalId())
        .toString() : new StringBuilder("BIZ_LOAN_");
  }

  public static IntegrationFlow create() {
    return i -> i.handle((p, h) -> {
      Authentication.save(Authentication.builder()
          .build());
      return p;
    });
  }

  public static IntegrationFlow get() {
    return i -> i.handle((p, h) -> {
      return Authentication.current();
    });
  }

  public static IntegrationFlow invalidate() {
    return i -> i.handle((p, h) -> {
      SecurityContextHolder.clearContext();
      return p;
    });
  }

  public static Authentication current() {
    if (SecurityContextHolder.getContext()
        .getAuthentication() instanceof Authentication) {
      return (Authentication) SecurityContextHolder.getContext()
          .getAuthentication();
    }
    throw new RuntimeException();
  }

  public static Authentication save(Authentication authentication) {
    SecurityContextHolder.getContext()
        .setAuthentication(authentication);
    return authentication;
  }
}

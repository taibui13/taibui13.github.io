package com.uob.pweb.businessbanking.lending.security;

import java.io.IOException;
import java.util.Optional;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.util.Strings;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.session.ConcurrentSessionControlAuthenticationStrategy;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.filter.GenericFilterBean;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;

public class ConcurrentFilter extends GenericFilterBean {

  private ConcurrentSessionControlAuthenticationStrategy ccas;

  private AntPathRequestMatcher matcher;

  public ConcurrentFilter(ConcurrentSessionControlAuthenticationStrategy ccas) {
    this.ccas = ccas;
    matcher = new AntPathRequestMatcher("/**/applications/**");
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response,
      FilterChain chain) throws IOException, ServletException {

    HttpServletRequest httpRequest = (HttpServletRequest) request;

    if (matcher.matches(httpRequest) && SecurityContextHolder.getContext()
        .getAuthentication() instanceof Authentication) {

      Authentication currentAuth = (Authentication) SecurityContextHolder
          .getContext().getAuthentication();
      Optional<LendingApplicationForm> op =
          Optional.ofNullable(currentAuth.getLendingApplicationForm());

      if (op.isPresent() && !Strings.isBlank(op.get().getId())) {
        ccas.onAuthentication(currentAuth, httpRequest,
            (HttpServletResponse) response);
      }
    }

    chain.doFilter(request, response);
  }
}

package com.uob.pweb.businessbanking.lending.security;

import java.util.Arrays;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.session.ConcurrentSessionControlAuthenticationStrategy;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.security.SpringSessionBackedSessionRegistry;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import lombok.extern.slf4j.Slf4j;

@EnableWebSecurity
@Slf4j
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

  @Autowired
  Environment env;

  // TODO
  // need to set permission
  
  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.cors().and().csrf().disable().sessionManagement()
        .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
        .maximumSessions(1)
        .expiredSessionStrategy(concurrentSessionExpiredStrategy())
        .sessionRegistry(sessionRegistry()).and().and().headers()
        .httpStrictTransportSecurity().and()
        .referrerPolicy(ReferrerPolicy.SAME_ORIGIN).and().xssProtection().and()
        .frameOptions().sameOrigin().and().authorizeRequests().anyRequest()
        .permitAll();
  }

  @Bean
  public SessionInformationExpiredStrategy concurrentSessionExpiredStrategy() {
    return event -> {
      HttpServletResponse response = event.getResponse();
      response.getWriter()
          .print("This session has been expired (possibly due to multiple concurrent " + "logins being attempted as the same user).");
      log.info("clear session due to concurrent Session occured for principal name {}", event.getSessionInformation()
          .getPrincipal()
          .toString());
      SecurityContextHolder.clearContext();

      response.setStatus(HttpStatus.FORBIDDEN.value());
      response.flushBuffer();
    };
  }

  @Bean
  public CorsConfigurationSource corsConfigurationSource() {
    CorsConfiguration configuration = new CorsConfiguration();
    configuration.setAllowedOrigins(Arrays.asList(env.getProperty("app.cors-headers.Access-Control-Allow-Origin")
        .split(",")));
    configuration.setAllowedMethods(Arrays.asList(env.getProperty("app.cors-headers.Access-Control-Allow-Methods")
        .split(",")));
    configuration.setMaxAge(Long.valueOf(env.getProperty("app.cors-headers.Access-Control-Max-Age")));
    configuration.setAllowedHeaders(Arrays.asList(env.getProperty("app.cors-headers.Access-Control-Allow-Headers")
        .split(",")));
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", configuration);
    return source;
  }

  @SuppressWarnings("rawtypes")
  @Autowired
  FindByIndexNameSessionRepository sessionRepository;

  @Override
  public void configure(WebSecurity web) {
    web.ignoring()
        .antMatchers("/db/**");
  }

  @Bean
  public ConcurrentSessionControlAuthenticationStrategy concurrentSessionControlAuthenticationStrategy() {
    return new ConcurrentSessionControlAuthenticationStrategy(sessionRegistry());
  }

  @SuppressWarnings("unchecked")
  @Bean
  public SpringSessionBackedSessionRegistry<Session> sessionRegistry() {
    return new SpringSessionBackedSessionRegistry<Session>(this.sessionRepository);
  }
}

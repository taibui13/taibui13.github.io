package com.uob.pweb.businessbanking.lending.specification;

import java.io.Serializable;
import java.util.Optional;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.uob.pweb.businessbanking.lending.specification.Specification.Flow;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = {"code"})
@Slf4j
public class Product implements Serializable {

  private static final long serialVersionUID = 1L;

  private String code;
  private String name;
  @JsonProperty(access = Access.WRITE_ONLY)
  private String email;
  @JsonProperty(access = Access.WRITE_ONLY)
  private String refId;
  private Flow flow;
  private String brm;

  public void init(Set<Flow> flows) {
    Optional<Flow> op = flows.stream()
        .filter(p -> p.getId()
            .equals(refId))
        .findAny();
    if (!op.isPresent()) {
      log.error("{} not configured in properties", refId);
      throw new RuntimeException(refId + " not configured in properties");
    }
    this.flow = op.get();
  }

}

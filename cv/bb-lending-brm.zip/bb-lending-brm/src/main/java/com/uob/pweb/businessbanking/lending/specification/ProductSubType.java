package com.uob.pweb.businessbanking.lending.specification;

public enum ProductSubType {
  B,
  C
}


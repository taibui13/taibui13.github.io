package com.uob.pweb.businessbanking.lending.specification;

public enum ProductType {
  LENDING
}

package com.uob.pweb.businessbanking.lending.specification;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Specification {

  @JsonProperty("main_form")
  private Object mainFormContents;

  @JsonProperty("partner_form")
  private Object partnerFormContents;

  @JsonProperty("flows")
  private Set<Flow> flows;

  @JsonProperty("products")
  private Set<Product> products;

  @JsonProperty("config")
  private LendingConfig lendingConfig;

  
  
  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class BrmMapping implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("house_type")
    private Map<String, String> houseTypes;

    @JsonProperty("shareholderCategory")
    private Map<String, String> shareholderCategories;

    @JsonProperty("shareType")
    private Map<String, String> shareTypes;
  
  }
  
  
  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  @EqualsAndHashCode(of = {"id"})
  public static class Flow implements Serializable {

    private static final long serialVersionUID = 1L;

    private ProductType type;
    private ProductSubType subType;

    @JsonProperty(access = Access.WRITE_ONLY)
    private String id;

    @JsonProperty(access = Access.WRITE_ONLY)
    private String partnerVerifyUrl;

  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  public static class LendingConfig {
    @JsonProperty("S_position_code")
    private List<String> S;

    @JsonProperty("P_position_code")
    private List<String> P;

    @JsonProperty("O_position_code")
    private List<String> O;

    private int expiry;

    @JsonProperty("corppass_required")
    private String corppassRequired;

    @JsonProperty("singpass_required")
    private String singpassRequired;

    @JsonProperty("brm_mapping")
    private BrmMapping brmMapping;
    
  }

}

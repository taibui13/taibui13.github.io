package com.uob.pweb.businessbanking.lending.specification;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.exception.LendingError;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import lombok.extern.slf4j.Slf4j;

/**
 * this class is to load file based on file modification event - json: Front End configuration,
 * product information..
 * 
 */
@Service
@Slf4j
public class SpecificationService {

  private static Map<String, Product> products = new HashMap<String, Product>();

  private static Specification spec = null;

  public void initiate(Resource jsonResource, ObjectMapper objectMapper) {
    try (InputStream input = jsonResource.getInputStream()) {
      Specification specTemp = objectMapper.readValue(input, Specification.class);
      Map<String, Product> productTemp = new HashMap<String, Product>();

      specTemp.getProducts()
          .forEach(p -> {
            p.init(specTemp.getFlows());
            productTemp.put(p.getCode(), p);
          });

      if (specTemp != null && !CollectionUtils.isEmpty(productTemp)) {
        log.info("initiate Business Banking Json file successful");
        products = productTemp;
        spec = specTemp;
      } else {
        log.error("ignore changes because sth is wrong in json data file");
      }
        
    } catch (Exception ex) {
      log.error("Error in innitiating Business Banking Json file: ", ex);
    }
  }

  public Product flow(String productCode) {
    if (!products.containsKey(productCode)) {
      throw new ApiRuntimeException(HttpStatus.BAD_REQUEST,
          LendingError.InvalidProductCode.getCode(),
          LendingError.InvalidProductCode.getMessage() + productCode);
    }
    return products.get(productCode);
  }

  public Product getProductByCode(String code) {
	    for (Product product : products.values()) {
	      if (code.equals(product.getCode())) { return product; }
	    }
	    throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR, "product.error",
	        "Product not found.");
	  }
  
  public Product getProductByBrm(String brm) {
    for (Product product : products.values()) {
      if (brm.equals(product.getBrm())) { return product; }
    }
    throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR, "product.error",
        "Product not found.");
  }

  public Specification getSpec() { return spec; }

  public Specification.LendingConfig getLendingConfig() {
    return spec.getLendingConfig();
  }

  public static Specification.BrmMapping brmMapping() {
	    return spec.getLendingConfig().getBrmMapping();
	  }
  
}

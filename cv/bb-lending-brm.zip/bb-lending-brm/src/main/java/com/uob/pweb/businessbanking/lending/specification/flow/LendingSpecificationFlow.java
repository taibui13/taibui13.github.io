package com.uob.pweb.businessbanking.lending.specification.flow;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.http.dsl.Http;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;

@Configuration
public class LendingSpecificationFlow {

  @Autowired
  private SpecificationService specificationService;

  // Anonymous
  @Bean
  public IntegrationFlow specification(ObjectMapper objectMapper) {
    return IntegrationFlows.from(Http.inboundGateway("/specifications/business")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .errorChannel("globalErrorFlow.input"))
        .log(LoggingHandler.Level.INFO, this.getClass()
            .getName(), m -> "start - get specification")
        .wireTap("requestLoggingFlow.input")
        .transform(p -> specificationService.getSpec()
            .getMainFormContents())
        .get();
  }

  // Anonymous
  @Bean
  public IntegrationFlow partnerSpecification(ObjectMapper objectMapper) {
    return IntegrationFlows.from(Http.inboundGateway("/specifications/partners")
        .requestMapping(m -> m.methods(HttpMethod.GET))
        .errorChannel("globalErrorFlow.input"))
        .log(LoggingHandler.Level.INFO, this.getClass()
            .getName(), m -> "start - get partner specification")
        .wireTap("requestLoggingFlow.input")
        .transform(p -> specificationService.getSpec()
            .getPartnerFormContents())
        .get();
  }
}

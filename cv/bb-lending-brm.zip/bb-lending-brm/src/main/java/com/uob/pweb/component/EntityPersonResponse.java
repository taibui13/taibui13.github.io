package com.uob.pweb.component;

import java.io.Serializable;
import lombok.Data;

@Data
public class EntityPersonResponse implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -4433957283561787998L;
  private String uen;
  private String uinfin;
  private Object entityPerson;

}

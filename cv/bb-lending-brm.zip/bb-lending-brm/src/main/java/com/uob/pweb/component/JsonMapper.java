package com.uob.pweb.component;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONArray;

@Getter
@Slf4j
public class JsonMapper {

  private final ObjectMapper objectMapper;
  private final Map<String, String> mapperMap;

  public JsonMapper(ObjectMapper objectMapper, Map<String, String> mapperMap) {
    this.objectMapper = objectMapper;
    this.mapperMap = mapperMap;
  }

  public <T> T map(String mapper, Object data, Class<T> response) {
    try {
      return objectMapper
          .convertValue(getNode(objectMapper.readTree(mapperMap.get(mapper)),
              JsonPath.parse(objectMapper.writeValueAsString(data))), response);
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public JsonNode getNode(JsonNode jsonNode, DocumentContext context) {
    if (jsonNode.isObject()) {
      mapValue(jsonNode, context);
    } else if (jsonNode.isArray() && jsonNode.get(0) != null) {
      ArrayNode arrayNode = (ArrayNode) jsonNode;

      // always only 1 array at mapper
      JsonNode node = arrayNode.get(0);
      do {

        if (!node.isArray()) {
          if (node.isObject()) {
            // create new object
            mapArrayIndex(jsonNode, 0, context);
            // remove first object of the mapper in the array
            ((ArrayNode) jsonNode).remove(0);
          }

        } else {
          getNode(node, context);
        }
      } while (arrayNode.has(0) && ((ObjectNode) arrayNode.get(0)).has("_length"));
    }
    return jsonNode;
  }

  public void mapValue(JsonNode jsonNode, DocumentContext myContext) {

    Iterator<Map.Entry<String, JsonNode>> iter = jsonNode.fields();

    DocumentContext context = myContext;

    // check if got new context
    if (jsonNode.has("_context")) {
      try {
        context = JsonPath
            .parse(objectMapper.writeValueAsString(context.read(jsonNode.get("_context")
                .asText()
                .substring(1, jsonNode.get("_context")
                    .asText()
                    .length() - 1))));

        if ("[]".equals(context.jsonString())) {
          ((ObjectNode) jsonNode).put("_length", -1);
        }
      } catch (JsonProcessingException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    while (iter.hasNext()) {
      Map.Entry<String, JsonNode> entry = iter.next();

      // check if it is array with value
      if (jsonNode.get("_length") != null && ((String) jsonNode.get("_length")
          .asText()).startsWith("{") && ((String) jsonNode.get("_length")
              .asText()).endsWith("}")) {

        try {
          Integer size = context.read(jsonNode.get("_length")
              .asText()
              .substring(1, jsonNode.get("_length")
                  .asText()
                  .length() - 1));

          if (size == null || size <= 0) {
            // array no value
            ((ObjectNode) jsonNode).put("_length", -1);
            return;
          }
        } catch (PathNotFoundException e) {
          log.info(e.getMessage());
        }
      }

      if (entry.getValue()
          .isValueNode()) {
        try {
          // multi value
          if (entry.getValue()
              .asText()
              .split("\\},\\{").length > 1) {

            String[] multiValue = entry.getValue()
                .asText()
                .split("\\},\\{");

            String values = new String();

            for (String value : multiValue) {

              String defaultValue = null;

              if (value.startsWith("{")) {
                value = value += "}";
              } else if (value.endsWith("}")) {
                value = "{" + value;
              } else if (value.startsWith("$")) {
                value = "{" + value + "}";
              }

              String exp = value.substring(1, value.length() - 1);

              String[] array = exp.split("\\|\\|\\|");
              exp = array[0];

              final Object objectValue = context.read(exp);

              Object otherValue =
                  objectValue instanceof String || objectValue instanceof JSONArray
                      ? objectValue.toString()
                          .replaceFirst("\\[\\\"", "")
                          .replaceFirst("\\\"\\]", "")
                          .replaceFirst("\\[", "")
                          .replaceFirst("\\]", "")
                      : objectValue;

              for (int i = 1; i < array.length; i++) {
                defaultValue = array[i];

                if (defaultValue != null) {
                  try {
                    Map<String, Object> map = objectMapper
                        .readValue(defaultValue.replaceAll("'", "\""), Map.class);

                    Map<String, Object> otherMap = new HashMap<>();

                    // check if key has expression
                    for (Entry<String, Object> entryMap : map.entrySet()) {
                      if (entryMap.getKey() instanceof String
                          && (entryMap.getKey()).startsWith("{")
                          && (entryMap.getKey()).endsWith("}")) {
                        try {
                          otherMap.put(context.read(entryMap.getKey()
                              .substring(1, entryMap.getKey()
                                  .length() - 1)),
                              entryMap.getValue());
                        } catch (PathNotFoundException e2) {
                          log.info(e2.getMessage());
                        }
                      }
                    }

                    map.putAll(otherMap);

                    final Object key = otherValue == null ? "null" : otherValue;
                    Object mapValue = map.get(key);

                    if (mapValue instanceof String) {
                      if (((String) mapValue).startsWith("{")
                          && ((String) mapValue).endsWith("}")) {
                        try {
                          mapValue = context.read(((String) mapValue).substring(1,
                              ((String) mapValue).length() - 1));
                        } catch (PathNotFoundException e2) {
                          log.info(e2.getMessage());
                        }
                      }
                    }
                    otherValue = mapValue != null ? mapValue : key;

                  } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                  }
                }
              }

              values += otherValue;
            }
            ((ObjectNode) jsonNode).put(entry.getKey(), values);
          } else {
            // single value
            if (entry.getValue()
                .asText()
                .startsWith("{")
                && entry.getValue()
                    .asText()
                    .endsWith("}")) {

              String defaultValue = null;
              String exp = entry.getValue()
                  .asText()
                  .substring(1, entry.getValue()
                      .asText()
                      .length() - 1);

              String[] array = exp.split("\\|\\|\\|");
              exp = array[0];

              final Object objectValue = context.read(exp);

              Object value =
                  objectValue instanceof String || objectValue instanceof JSONArray
                      ? objectValue.toString()
                          .replaceFirst("\\[\\\"", "")
                          .replaceFirst("\\\"\\]", "")
                          .replaceFirst("\\[", "")
                          .replaceFirst("\\]", "")
                      : objectValue;

              for (int i = 1; i < array.length; i++) {
                defaultValue = array[i];

                if (defaultValue != null) {
                  try {
                    Map<String, Object> map = objectMapper
                        .readValue(defaultValue.replaceAll("'", "\""), Map.class);

                    Map<String, Object> otherMap = new HashMap<>();

                    // check if key has expression
                    for (Entry<String, Object> entryMap : map.entrySet()) {
                      if (entryMap.getKey() instanceof String
                          && (entryMap.getKey()).startsWith("{")
                          && (entryMap.getKey()).endsWith("}")) {
                        try {
                          otherMap.put(context.read(entryMap.getKey()
                              .substring(1, entryMap.getKey()
                                  .length() - 1)),
                              entryMap.getValue());
                        } catch (PathNotFoundException e2) {
                          log.info(e2.getMessage());
                        }
                      }
                    }

                    map.putAll(otherMap);

                    final Object key = value == null ? "null" : value;
                    Object mapValue = map.get(key);

                    if (mapValue instanceof String) {
                      if (((String) mapValue).startsWith("{")
                          && ((String) mapValue).endsWith("}")) {
                        try {
                          mapValue = context.read(((String) mapValue).substring(1,
                              ((String) mapValue).length() - 1));
                        } catch (PathNotFoundException e2) {
                          log.info(e2.getMessage());
                        }
                      }
                    }

                    value = mapValue != null ? mapValue : key;

                  } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                  }
                }
              }

              ((ObjectNode) jsonNode).putPOJO(entry.getKey(), value);

              // super hard code for now
              if ((entry.getKey()
                  .contains("Date")
                  || entry.getKey()
                      .contains("date"))
                  && value instanceof String && value.toString()
                      .endsWith("000Z")) {

                try {
                  SimpleDateFormat format =
                      new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
                  Date date = format.parse(value.toString());

                  SimpleDateFormat brmFormat = new SimpleDateFormat("yyyy-MM-dd");

                  ((ObjectNode) jsonNode).put(entry.getKey(), brmFormat.format(date));
                } catch (ParseException e) {
                  log.info(e.getMessage());
                }

              } else if (entry.getKey()
                  .contains("Date") && value instanceof String) {
                try {
                  SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                  Date date = format.parse(value.toString());

                  SimpleDateFormat brmFormat =
                      new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

                  ((ObjectNode) jsonNode).put(entry.getKey(), brmFormat.format(date));
                } catch (ParseException e) {
                  log.info(e.getMessage());
                }
              }
            }
          }
        } catch (PathNotFoundException e) {
          log.info(e.getMessage());

          // not found default value
          String defaultValue = null;
          String exp = entry.getValue()
              .asText()
              .substring(1, entry.getValue()
                  .asText()
                  .length() - 1);

          String[] array = exp.split("\\|\\|\\|");

          // no value
          Object value = defaultValue;

          for (int i = 1; i < array.length; i++) {
            defaultValue = array[i];

            if (defaultValue != null) {
              try {
                Map<String, Object> map =
                    objectMapper.readValue(defaultValue.replaceAll("'", "\""), Map.class);

                Map<String, Object> otherMap = new HashMap<>();

                // check if key has expression
                for (Entry<String, Object> entryMap : map.entrySet()) {
                  if (entryMap.getKey() instanceof String
                      && (entryMap.getKey()).startsWith("{")
                      && (entryMap.getKey()).endsWith("}")) {
                    try {
                      otherMap.put(context.read(entryMap.getKey()
                          .substring(1, entryMap.getKey()
                              .length() - 1)),
                          entryMap.getValue());
                    } catch (PathNotFoundException e2) {
                      log.info(e2.getMessage());
                    }
                  }
                }

                map.putAll(otherMap);

                final Object key = value == null ? "null" : value;
                Object mapValue = map.get(key);

                if (mapValue instanceof String) {
                  if (((String) mapValue).startsWith("{")
                      && ((String) mapValue).endsWith("}")) {
                    try {
                      mapValue = context.read(((String) mapValue).substring(1,
                          ((String) mapValue).length() - 1));
                    } catch (PathNotFoundException e2) {
                      log.info(e2.getMessage());
                    }
                  }
                }

                value = mapValue != null ? mapValue : key;

              } catch (IOException e2) {
                e.printStackTrace();
              }
            }
          }

          ((ObjectNode) jsonNode).putPOJO(entry.getKey(), value);
        }
      } else {
        getNode(entry.getValue(), context);
      }
    }
  }

  public void replaceArrayIndex(JsonNode newNode, Integer i) {

    Iterator<Map.Entry<String, JsonNode>> iter = newNode.fields();

    // replace first index
    while (iter.hasNext()) {
      Map.Entry<String, JsonNode> entry = iter.next();

      if (entry.getValue()
          .isValueNode()
          && entry.getValue()
              .asText()
              .startsWith("{")
          && entry.getValue()
              .asText()
              .endsWith("}")) {
        if (!StringUtils.isEmpty(entry.getValue()
            .asText())) {
          // multi value
          if (entry.getValue()
              .asText()
              .split("\\},\\{").length > 1) {

            String[] multiValue = entry.getValue()
                .asText()
                .split("\\},\\{");

            String values = new String();

            int j = 0;

            for (String value : multiValue) {
              if (j != 0) {
                values += "},{";
              }

              if (value.contains("|||")) {

                String[] data = value.split("\\|\\|\\|");

                for (int k = 0; k < data.length; k++) {
                  if (k == 0) {
                    values += data[k].replaceFirst("\\[index\\]", "[" + i + "]");;
                  } else {
                    values += "|||" + data[k].replaceAll("\\[index\\]", "[" + i + "]");
                  }
                }

              } else {
                values += value.replaceFirst("\\[index\\]", "[" + i + "]");
              }

              j++;
            }

            ((ObjectNode) newNode).put(entry.getKey(), values);

          } else {
            // single value
            // replace one from exp and all from map
            String value = new String();

            if (entry.getValue()
                .asText()
                .contains("|||")) {

              String[] data = entry.getValue()
                  .asText()
                  .split("\\|\\|\\|");

              for (int k = 0; k < data.length; k++) {
                if (k == 0) {
                  value += data[k].replaceFirst("\\[index\\]", "[" + i + "]");
                } else {
                  value += "|||" + data[k].replaceAll("\\[index\\]", "[" + i + "]");
                }
              }

              ((ObjectNode) newNode).put(entry.getKey(), value);

            } else {
              ((ObjectNode) newNode).put(entry.getKey(), entry.getValue()
                  .asText()
                  .replaceFirst("\\[index\\]", "[" + i + "]"));
            }
          }
        }
      } else {
        replaceArrayIndex(entry.getValue(), i);
      }
    }
  }

  public void mapArrayIndex(JsonNode parentNode, Integer i, DocumentContext context) {
    // always get first node from mapper
    JsonNode node = parentNode.get(0);

    ObjectNode newNode = null;

    if (node.has("_replace")) {
      final String replace = node.get("_replace")
          .asText();

      newNode = ((ObjectNode) node.get(replace)).deepCopy();
    } else {
      newNode = ((ObjectNode) node).deepCopy();
    }

    // replaceArrayIndex
    replaceArrayIndex(newNode, i);

    // map new node
    mapValue(newNode, context);

    // remove context
    ((ObjectNode) newNode).remove("_context");

    Integer length = 0;

    // find length
    // check context
    DocumentContext myContext = context;

    // check if got new context
    if (node.has("_context")) {
      try {
        myContext = JsonPath
            .parse(objectMapper.writeValueAsString(context.read(node.get("_context")
                .asText()
                .substring(1, node.get("_context")
                    .asText()
                    .length() - 1))));

      } catch (JsonProcessingException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    if (node.get("_length") != null) {

      final String lengthExp = node.get("_length")
          .asText();
      try {
        if (lengthExp.startsWith("{") && ((String) lengthExp).endsWith("}")) {
          length = myContext.read(node.get("_length")
              .asText()
              .substring(1, node.get("_length")
                  .asText()
                  .length() - 1));

          if (length == null || length == 0) {
            // means nothing in array
            length = -1;
          }
        } else {
          length = Integer.parseInt(lengthExp);
        }
      } catch (PathNotFoundException e) {
        log.info(e.getMessage());
      }
    }

    if (length == 1) {
      // remove length when last array
      ((ObjectNode) node).remove("_length");
    } else {
      // decrease length by 1 when not last array
      ((ObjectNode) node).put("_length", length - 1);
    }

    // do not show length in node
    newNode.remove("_length");

    if (length >= 0) {
      // add node to array when only have value
      if (!(newNode.has("_condition") && (newNode.get("_condition")
          .asText()
          .equals("0")
          || StringUtils.isEmpty(newNode.get("_condition")
              .asText())))) {
        if (node.has("_replace")) {
          // need add the parent node
          ObjectNode newParentNode = ((ObjectNode) node).deepCopy();
          newParentNode.replace(node.get("_replace")
              .asText(), newNode);

          newParentNode.remove("_length");
          newParentNode.remove("_replace");

          ((ArrayNode) parentNode).add(newParentNode);
        } else {
          ((ArrayNode) parentNode).add(newNode);
        }
      }

      // do not show condition
      newNode.remove("_condition");
    }

    if (length > 1) {
      mapArrayIndex(parentNode, i + 1, context);
    } else {
      ((ObjectNode) node).remove("_replace");
    }
  }

}

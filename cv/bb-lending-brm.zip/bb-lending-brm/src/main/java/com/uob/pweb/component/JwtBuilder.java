package com.uob.pweb.component;

import java.security.PrivateKey;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.function.Function;
import java.util.function.Supplier;

import org.springframework.context.annotation.Bean;

import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import lombok.Data;

public interface JwtBuilder {

  @Bean
  default public Jwt jwt(JwtConfig jwtConfig) {
    Jwt jwt = new Jwt(jwtConfig);
    jwt.startDate = startDate();
    jwt.expiryDate = expiryDate();
    return jwt;
  }

  default public Supplier<Date> startDate() {
    return () -> Date.from(LocalDateTime.now()
        .atZone(ZoneId.systemDefault())
        .toInstant());
  }

  default public Function<JwtConfig, Date> expiryDate() {
    return jwtConfig -> Date.from(LocalDateTime.now()
        .plus(jwtConfig.expiredIn, jwtConfig.getChronoUnit())
        .atZone(ZoneId.systemDefault())
        .toInstant());
  }

  public class Jwt {

    private JwtConfig jwtConfig;
    private Supplier<Date> startDate;
    private Function<JwtConfig, Date> expiryDate;

    public Jwt(JwtConfig jwtConfig) {
      this.jwtConfig = jwtConfig;
    }

    public String getToken() {
      return ((ThrowingSupplier<String>) () -> {
        JWSSigner signer = new RSASSASigner(jwtConfig.getPrivateKey());

        JWTClaimsSet claimsSet =
            new JWTClaimsSet.Builder().subject(jwtConfig.getSubject())
                .notBeforeTime(startDate.get())
                .expirationTime(expiryDate.apply(jwtConfig))
                .issuer(jwtConfig.getIss())
                .build();

        SignedJWT signedJWT =
            new SignedJWT(new JWSHeader.Builder(jwtConfig.getJwsAlgorithm())
                .type(jwtConfig.getJoseObjectType())
                .build(), claimsSet);

        signedJWT.sign(signer);

        return signedJWT.serialize();
      }).get();
    }
  }

  @Data
  public class JwtConfig {

    private String subject;
    private String iss;
    private Integer expiredIn = 2;

    private ChronoUnit chronoUnit = ChronoUnit.MINUTES;

    private PrivateKey privateKey;

    private JWSAlgorithm jwsAlgorithm = JWSAlgorithm.RS256;
    private JOSEObjectType joseObjectType = JOSEObjectType.JWT;
  }

}

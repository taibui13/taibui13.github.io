package com.uob.pweb.component;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStore.PrivateKeyEntry;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import com.uobgroup.encrypt.UPwdUtil;
import lombok.Data;

public interface KeyManagementBuilder {

  @Bean
  default public KeyManagement keyManagement(KeyManagementConfig keyManagementConfig)
      throws FileNotFoundException, KeyStoreException, NoSuchAlgorithmException,
      CertificateException, UnrecoverableEntryException, IOException {
    KeyManagement keyManagement = new KeyManagement();
    keyManagement.setPrivateKey(privateKey(keyManagementConfig));
    keyManagement.setPublicKey(publicKey(keyManagementConfig));

    return keyManagement;
  }

  default public PrivateKey privateKey(KeyManagementConfig keyManagementConfig) {
    return keyManagementConfig.hasPrivateKey() ? ((ThrowingSupplier<PrivateKey>) () -> {
      KeyManagementConfig.PrivateKey privateKey = keyManagementConfig.getPrivateKey();
      KeyManagementConfig.PrivateKey.File file = privateKey.getFile();

      try (InputStream privateKeyStream = new FileInputStream(privateKey.getPath())) {
        String storepass = StringUtils.isEmpty(privateKey.getStorepass())
            ? UPwdUtil.getPassword(file.getKey1(), file.getKey2(), file.getPwd())
            : privateKey.getStorepass();

        KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
        keystore.load(privateKeyStream, storepass.toCharArray());

        PrivateKeyEntry entry = (PrivateKeyEntry) keystore.getEntry(privateKey.getAlias(),
            new KeyStore.PasswordProtection(storepass.toCharArray()));

        return entry.getPrivateKey();
      }
    }).get() : null;
  }

  default public PublicKey publicKey(KeyManagementConfig keyManagementConfig) {
    return keyManagementConfig.hasPublicKey() ? ((ThrowingSupplier<PublicKey>) () -> {
      KeyManagementConfig.PublicKey publicKey = keyManagementConfig.getPublicKey();

      try (InputStream publicKeyStream = new FileInputStream(publicKey.getPath())) {
        Certificate cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(publicKeyStream);
        return cert.getPublicKey();
      }
    }).get() : null;
  }

  @Data
  public class KeyManagement {
    private PrivateKey privateKey;
    private PublicKey publicKey;
  }

  @Data
  public class KeyManagementConfig {

    private PrivateKey privateKey;
    private PublicKey publicKey;

    @Data
    public static class PublicKey {
      private String path;
    }

    @Data
    public static class PrivateKey {

      private String path;
      private String alias;
      private String storepass;

      private File file;

      @Data
      public static class File {
        private String key1;
        private String key2;
        private String pwd;
      }
    }

    public Boolean hasPrivateKey() {
      return Optional.ofNullable(privateKey)
          .filter(privateKey -> !StringUtils.isEmpty(privateKey.getPath()))
          .isPresent();
    }

    public Boolean hasPublicKey() {
      return Optional.ofNullable(publicKey)
          .filter(publicKey -> !StringUtils.isEmpty(publicKey.getPath()))
          .isPresent();
    }
  }
}

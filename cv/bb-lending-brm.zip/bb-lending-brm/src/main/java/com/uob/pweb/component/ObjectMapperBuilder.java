package com.uob.pweb.component;

import java.text.SimpleDateFormat;
import java.util.Optional;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.support.json.Jackson2JsonObjectMapper;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.Data;

public interface ObjectMapperBuilder {

  @Bean
  default public Jackson2JsonObjectMapper mapper(ObjectMapper objectMapper) {
    Jackson2JsonObjectMapper mapper = new Jackson2JsonObjectMapper(objectMapper);
    return mapper;
  }

  default public ObjectMapper objectMapper(ObjectMapperConfig objectMapperConfig) {
    ObjectMapper objectMapper = new ObjectMapper()
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
        .configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false)
        .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
        .configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN,true)
        .setSerializationInclusion(objectMapperConfig.getInclude())
        .setPropertyNamingStrategy(objectMapperConfig.getPropertyNamingStrategy());
      Optional.ofNullable(objectMapperConfig.getModules())
        .map(modules -> objectMapper.registerModules(modules));

    objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss:SSS'Z'"));
    
    return objectMapper;
  }

  @Data
  public class ObjectMapperConfig {
    private PropertyNamingStrategy propertyNamingStrategy =
        PropertyNamingStrategy.LOWER_CAMEL_CASE;
    private Include include = Include.ALWAYS;
    private Module[] modules;
  }
}

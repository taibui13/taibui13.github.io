package com.uob.pweb.component;

import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uob.pweb.component.ObjectMapperBuilder.ObjectMapperConfig;

public class ObjectMapperUtil {

	
  public static ObjectMapper getObjectMapper() {
	  ObjectMapperConfig objectMapperConfig = new ObjectMapperConfig();
	   objectMapperConfig.setPropertyNamingStrategy(PropertyNamingStrategy.UPPER_CAMEL_CASE);  
	  ObjectMapper objectMapper = new ObjectMapper()
	        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
	        .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
	        .configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false)
	        .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
	        .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
	        .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
	        .configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN,true)
	        .setSerializationInclusion(objectMapperConfig.getInclude())
	        .setPropertyNamingStrategy(objectMapperConfig.getPropertyNamingStrategy())
	        .registerModule(new JavaTimeModule());
	    return objectMapper;
	  }
	
}

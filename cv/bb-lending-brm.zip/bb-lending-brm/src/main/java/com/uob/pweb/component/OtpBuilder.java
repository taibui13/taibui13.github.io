package com.uob.pweb.component;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public interface OtpBuilder {

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class OtpRequest {
    private String mobileNumber;
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class OtpResponse {
    private String prefix;
    private String requestIdentity;
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class OtpVerificationRequest {
    @NotNull
    private String otp;
    @NotNull
    private String requestIdentity;
  }
}

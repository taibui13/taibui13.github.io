package com.uob.pweb.component;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.OkHttp3ClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;

public interface RestTemplateBuilder {

  @Bean
  default public RestTemplate restTemplate(RestTemplateConfig restTemplateConfig) {

    RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(
        new OkHttp3ClientHttpRequestFactory(okHttpClient(restTemplateConfig))));

    if(interceptors() != null) {
      restTemplate.setInterceptors(interceptors());
    }

    restTemplate.setMessageConverters(messageConverters());

    return restTemplate;
  }

  public ObjectMapper objectMapper();

  default public List<HttpMessageConverter<?>> messageConverters() {
    StringHttpMessageConverter stringHttpMessageConverter =
        new StringHttpMessageConverter(StandardCharsets.UTF_8);
    stringHttpMessageConverter.setWriteAcceptCharset(false);

    return Arrays.asList(new HttpMessageConverter<?>[] {stringHttpMessageConverter,
        new MappingJackson2HttpMessageConverter(objectMapper())});
  }

  default public List<ClientHttpRequestInterceptor> interceptors() {
    return Arrays.asList(new RequestLoggingInterceptor(true, true, true));
  }

  default public OkHttpClient okHttpClient(RestTemplateConfig restTemplateConfig) {
    return new OkHttpClient.Builder()
        .sslSocketFactory(sslSocketFactory(restTemplateConfig), trustManager())
        .readTimeout(restTemplateConfig.getTimeout()
            .getRead(), TimeUnit.SECONDS)
        .connectTimeout(restTemplateConfig.getTimeout()
            .getConnect(), TimeUnit.SECONDS)
        .proxy(proxy(restTemplateConfig))
        .proxyAuthenticator(proxyAuthenticator(restTemplateConfig))
        .hostnameVerifier((host, sslSession) -> true)
        .build();
  }

  default public SSLSocketFactory sslSocketFactory(
      RestTemplateConfig restTemplateConfig) {
    return ((ThrowingSupplier<SSLSocketFactory>) () -> {
      SSLContext sslContext = SSLContext.getInstance(restTemplateConfig.getSsl()
          .getProtocol());
      sslContext.init(null, new TrustManager[] {trustManager()}, new SecureRandom());
      return sslContext.getSocketFactory();
    }).get();
  }

  default public X509TrustManager trustManager() {
    X509TrustManager trustManager = new X509TrustManager() {
      @Override
      public void checkClientTrusted(X509Certificate[] certificate, String alias)
          throws CertificateException {}

      @Override
      public void checkServerTrusted(X509Certificate[] arg0, String alias)
          throws CertificateException {}

      @Override
      public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    };
    return trustManager;
  }

  default public Authenticator proxyAuthenticator(RestTemplateConfig restTemplateConfig) {
    return new Authenticator() {
      @Override
      public Request authenticate(Route route, Response response) throws IOException {
        RestTemplateConfig.Proxy restTemplateProxy = restTemplateConfig.getProxy();
        return restTemplateConfig.hasProxyAuthenticator() ? response.request()
            .newBuilder()
            .header(RestTemplateConfig.Proxy.AUTHORIZATION,
                restTemplateProxy.credentials())
            .headers(Headers.of(restTemplateProxy.getProxyHeader()))
            .build() : null;
      }
    };
  }

  default public Proxy proxy(RestTemplateConfig restTemplateConfig) {
    RestTemplateConfig.Proxy restTemplateProxy = restTemplateConfig.getProxy();
    return restTemplateConfig.hasProxy()
        ? new Proxy(restTemplateProxy.getType(),
            new InetSocketAddress(restTemplateProxy.getHost(),
                restTemplateProxy.getPort()))
        : null;
  }

  @Data
  public class RestTemplateConfig {

    private Proxy proxy;
    private Ssl ssl = new Ssl();
    private Timeout timeout = new Timeout();

    @Data
    class Timeout {
      private Long read = 60L;
      private Long connect = 60L;;
    }

    @Data
    class Ssl {
      private String protocol = "TLSv1.2";
    }

    @Data
    class Proxy {
      public static final String AUTHORIZATION = "Proxy-Authorization";
      public static final String CONNECTION = "Proxy-Connection";

      private Type type = Type.HTTP;

      private String host;
      private Integer port;
      private String user;
      private String pwd;

      private Map<String, String> proxyHeader = new Supplier<Map<String, String>>() {
        @Override
        public Map<String, String> get() {
          Map<String, String> proxyHeader = new HashMap<>();
          proxyHeader.put(RestTemplateConfig.Proxy.CONNECTION, "Keep-Alive");
          return proxyHeader;
        }
      }.get();

      public String credentials() {
        return Credentials.basic(user, pwd);
      }
    }

    public Boolean hasProxy() {
      return Optional.ofNullable(proxy)
          .filter(
              proxy -> !StringUtils.isEmpty(proxy.getHost()) && proxy.getPort() != null)
          .isPresent();
    }

    public Boolean hasProxyAuthenticator() {
      return Optional.ofNullable(proxy)
          .filter(proxy -> !StringUtils.isEmpty(proxy.getUser())
              && !StringUtils.isEmpty(proxy.getPwd()))
          .isPresent();
    }
  }
}

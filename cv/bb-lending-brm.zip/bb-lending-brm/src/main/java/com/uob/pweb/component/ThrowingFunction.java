package com.uob.pweb.component;

import java.util.function.Function;

@FunctionalInterface
public interface ThrowingFunction<T, R> extends Function<T, R> {
  R doApply(T t) throws Throwable;

  default R apply(T t) {
    try {
      return doApply(t);
    } catch (Throwable e) {
      throw new RuntimeException(e);
    }
  }
}
package com.uob.pweb.component;

import java.util.function.Supplier;

@FunctionalInterface
public interface ThrowingSupplier<R> extends Supplier<R> {
  R doGet() throws Throwable;

  default R get() {
    try {
      return doGet();
    } catch (Throwable e) {
      throw new RuntimeException(e);
    }
  }
}

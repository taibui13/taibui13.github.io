package com.uob.pweb.component.brm;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.businessbanking.lending.component.Application;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrmApplicationRequest {

  @JsonProperty("Application")
  private Application application;

}

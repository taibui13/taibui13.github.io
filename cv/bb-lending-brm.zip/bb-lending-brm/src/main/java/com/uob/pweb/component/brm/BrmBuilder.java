package com.uob.pweb.component.brm;

import java.util.UUID;
import org.springframework.context.annotation.Bean;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.http.HttpMethod;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.http.dsl.Http;
import org.springframework.web.client.RestTemplate;
import com.uob.pweb.component.JwtBuilder.Jwt;
import lombok.Data;

public interface BrmBuilder {

  @Bean
  default public IntegrationFlow brmHeaderEnrich(BrmConfig brmConfig) {
    return with -> with
        .enrichHeaders(headers -> headers.headerFunction("Authorization",
            m -> brmConfig.getJwt()
                .getToken(),
            true))
        .enrichHeaders(headers -> headers.headerFunction("CountryCode", m -> "SG", true))
        .enrichHeaders(headers -> headers.headerFunction("RequestId",
            m -> UUID.randomUUID()
                .toString(),
            true))
        .enrichHeaders(headers -> headers.headerFunction("Source", m -> "PWEB", true));
  }

  @Bean
  default public IntegrationFlow brmGet(BrmConfig brmConfig) {
    return to -> to.gateway(brm(brmConfig, HttpMethod.GET));
  }

  @Bean
  default public IntegrationFlow brmPost(BrmConfig brmConfig) {
    return to -> to.gateway(brm(brmConfig, HttpMethod.POST));
  }

  default public IntegrationFlow brm(BrmConfig brmConfig, HttpMethod httpMethod) {
    return to -> to.gateway(brmHeaderEnrich(brmConfig))
        .transform(Transformers.toJson())
        .handle(Http
            .outboundGateway(
                new SpelExpressionParser().parseExpression(brmConfig.getBrmExp()),
                brmConfig.getRestTemplate())
            .httpMethod(httpMethod)
            .mappedRequestHeaders("Authorization", "CountryCode", "RequestId", "Source",
                "Content-Type")
            .expectedResponseType(BrmResponse.class));
  }

  @Data
  public class BrmConfig {
    private Jwt jwt;
    private RestTemplate restTemplate;

    private String brm = "brm";
    private String brmExp = "headers['" + brm + "']";
  }
}

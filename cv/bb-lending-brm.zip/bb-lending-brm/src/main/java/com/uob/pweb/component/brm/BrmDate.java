package com.uob.pweb.component.brm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.logging.log4j.util.Strings;
import org.springframework.http.HttpStatus;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BrmDate {

  public static String brmDateformat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    
  public static String getBrmDate(String dateStr) {
	    try {
	      if(Strings.isBlank(dateStr)) return dateStr;
	      SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	      Date date = format.parse(dateStr);
	      SimpleDateFormat brmFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	     // brmFormat.setTimeZone(TimeZone.getTimeZone("UTC"));	      
	      return brmFormat.format(date);
	    } catch(Exception ex) {
	      log.error("could not parse date {} in correct format", dateStr);
	      return Strings.EMPTY;
	    }
	  }
    
  public static String from(String brmDate) {

    try {
      SimpleDateFormat format = new SimpleDateFormat(brmDateformat);
      Date date = format.parse(brmDate);

      SimpleDateFormat brmFormat = new SimpleDateFormat("yyyy-MM-dd");

      return brmFormat.format(date);
    } catch (ParseException e) {
      throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR, "invalid.date",
          "Date format error");
    }
  }

}

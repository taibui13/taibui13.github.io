package com.uob.pweb.component.brm;

public class BrmMapper {

  // 
  
}

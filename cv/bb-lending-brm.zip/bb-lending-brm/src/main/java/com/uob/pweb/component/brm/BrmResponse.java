package com.uob.pweb.component.brm;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.uob.pweb.businessbanking.lending.brm.BrmApplication;
import com.uob.pweb.businessbanking.lending.component.ApplicationForm;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BrmResponse {

  protected Object responseHeader;
  protected Object responseBody;
  protected List<Object> errorMessage;

  public Boolean isSuccess() {
    return "200".equals(JsonPath.parse(responseHeader)
        .read("$.ResponseCode"));
  }
  
  
  public String findExpiryDate() {
	return JsonPath.parse(responseBody)
		        .read("$.ExpiryDate");	  
  }
    
  public String findApplicationId() {
    return JsonPath.parse(responseBody)
        .read("$.ApplicationId");
  }

   
  public String findReferenceNumber() {
    return JsonPath.parse(responseBody)
        .read("$.ApplicationReferenceNumber");
  }
  
  public String findInitiateDate() {
	    SimpleDateFormat brmFormat =
	              new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	          brmFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
	       String initiateDate = brmFormat.format(new Date());	          
     return initiateDate;   
  }
  
  public ApplicationForm findApplicationForm() {
    DocumentContext documentContext = JsonPath.using(Configuration.builder()
        .options(Option.SUPPRESS_EXCEPTIONS)
        .build())
        .parse(responseBody);
    return BrmApplication.builder()
        .applicationId(documentContext.read("$.Application.ApplicationId"))
        .applicationReferenceNumber(
            documentContext.read("$.Application.ApplicationReferenceNo"))
        .productCode(documentContext.read("$.Application.ProductCode"))
        .companyDetails(documentContext.read("$.Application.CompanyDetails"))
        .principalList(documentContext.read("$.Application.PrincipalList"))
        .supplementaryInfo(documentContext.read("$.Application.SupplementaryInfo"))  
        .initiateDate(documentContext.read("$.Application.InitiateDate")) 
        .expiryDate(documentContext.read("$.Application.ExpiredDate"))
        .build();
  }

  
  public ApplicationForm findDraftApplicationForm() {
    DocumentContext documentContext = JsonPath.using(Configuration.builder()
        .options(Option.SUPPRESS_EXCEPTIONS)
        .build())
        .parse(responseBody);
    return BrmApplication.builder()
        .applicationId(documentContext.read("$.Applications[0].ApplicationId"))
        .applicationReferenceNumber(
            documentContext.read("$.Applications[0].ApplicationReferenceNumber"))
        .expiryDate(documentContext.read("$.Applications[0].ExpiryDate"))
        .productCode(documentContext.read("$.Applications[0].ProductCode"))
        .companyDetails(documentContext.read("$.Applications[0].CompanyDetails"))
        .createdDate(documentContext.read("$.Applications[0].CreatedDate"))
        .build();
  }

}

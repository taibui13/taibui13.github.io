package com.uob.pweb.component.brm;

import org.apache.logging.log4j.util.Strings;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum IdType {
	  
	  Individual_Employment_Pass("EMPL"),
	  Individual_NRIC("NRIC"),
	  Individual_Passport("PASS"),
	  Individual_Work("Permit WORK"),
	  Non_Individual_Registry_Of_Business_Document("RB"),
	  Non_Individual_Registry_Of_Company_Document("RC");
	  
	private String code;
	
	public static String getIndividualType(String legalId) {
	    String idType = null;
	    if(Strings.isBlank(legalId)) idType = Strings.EMPTY;
	    else if(legalId.startsWith("S") || legalId.startsWith("T")) idType = IdType.Individual_NRIC.getCode();
	    else  idType = Individual_Employment_Pass.getCode();
	    return idType;
	  }
	  
	
}

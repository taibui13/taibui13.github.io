package com.uob.pweb.businessbanking.lending.test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.uob.pweb.businessbanking.lending.specification.Product;
import com.uob.pweb.businessbanking.lending.specification.Specification.LendingConfig;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.common.framework.CommonConfig;
import com.uob.pweb.common.framework.myinfo.MyInfoConfig;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;
import com.uob.pweb.component.JsonMapper;
import com.uob.pweb.component.JwtBuilder;
import com.uob.pweb.component.KeyManagementBuilder;
import com.uob.pweb.component.ObjectMapperBuilder;
import com.uob.pweb.component.RestTemplateBuilder;
import com.uob.pweb.component.brm.BrmBuilder;

@SpringBootApplication
@Import({CommonConfig.class, MyInfoConfig.class, MyInfoValidation.class})
public class ApplicationTest implements RestTemplateBuilder, ObjectMapperBuilder,
    BrmBuilder, JwtBuilder, KeyManagementBuilder {

  @Mock
  SpecificationService specificationService;

  @Mock
  LendingConfig lendingConfig;

  @Autowired
  RestTemplate restTemplate;

  @Bean
  public SpecificationService specificationService() {

    MockitoAnnotations.initMocks(this);

    when(lendingConfig.getCorppassRequired()).thenReturn("");
    when(specificationService.getLendingConfig()).thenReturn(lendingConfig);
    when(specificationService.flow(any())).thenReturn(new Product());
    when(specificationService.getProductByBrm(any())).thenReturn(new Product());

    return specificationService;
  }

  public static void main(String[] args) {
    SpringApplication.run(ApplicationTest.class, args);
  }

  @Bean
  public JsonMapper jsonMapper(@Value("classpath:json/brm-0.13.json") Resource brmJson,
      @Value("classpath:json/bb-1.0.0.json") Resource bbJson) throws IOException {

    Map<String, String> mapperMap = new HashMap<String, String>();
    mapperMap.put("brm-0.13.json",
        new BufferedReader(new InputStreamReader(brmJson.getInputStream())).lines()
            .collect(Collectors.joining(System.lineSeparator())));
    mapperMap.put("bb-1.0.0.json",
        new BufferedReader(new InputStreamReader(bbJson.getInputStream())).lines()
            .collect(Collectors.joining(System.lineSeparator())));

    return new JsonMapper(
        new ObjectMapperBuilder() {}.objectMapper(new ObjectMapperConfig()), mapperMap);
  }

  @Bean
  public HttpSessionEventPublisher httpSessionEventPublisher() {
    return new HttpSessionEventPublisher();
  }

  @Bean
  public CookieSerializer cookieSerializer() {
    DefaultCookieSerializer serializer = new DefaultCookieSerializer();
    serializer.setCookieName("JSESSIONID");
    return serializer;
  }

  @Bean
  public RestTemplateConfig restTemplateConfig() {
    return new RestTemplateConfig();
  }

  @Bean
  public KeyManagementConfig keyManagementConfig() {
    KeyManagementConfig.PrivateKey privateKey = new KeyManagementConfig.PrivateKey();
    privateKey.setAlias("bbbrm");
    // privateKey.setPath("/prodlib/PIBSGOF/keymanagement/bbbrm.jks");
    privateKey.setPath(
        "C:\\Users\\vencd8\\Documents\\bb-lending-edgeservice\\src\\main\\resources\\bbbrm.jks");
    privateKey.setStorepass("123456");

    KeyManagementConfig keyManagementConfig = new KeyManagementConfig();
    keyManagementConfig.setPrivateKey(privateKey);

    return keyManagementConfig;
  }

  @Bean
  public JwtConfig jwtConfig(KeyManagement keyManagement) {
    JwtConfig jwtConfig = new JwtConfig();
    jwtConfig.setSubject("{\"id\":\"16b552caa631f54419dc8ce4938c17fd\"}");
    jwtConfig.setIss("https://PWEB.com.sg");
    jwtConfig.setPrivateKey(keyManagement.getPrivateKey());

    return jwtConfig;
  }

  @Bean
  public BrmConfig brmConfig(Jwt jwt, RestTemplate restTemplate) {
    BrmConfig brmConfig = new BrmConfig();
    brmConfig.setJwt(jwt);
    brmConfig.setRestTemplate(restTemplate);

    return brmConfig;
  }

  @Override
  public ObjectMapper objectMapper() {
    ObjectMapperConfig objectMapperConfig = new ObjectMapperConfig();
    objectMapperConfig.setPropertyNamingStrategy(PropertyNamingStrategy.UPPER_CAMEL_CASE);

    return this.objectMapper(objectMapperConfig);
  }

  @Override
  public List<ClientHttpRequestInterceptor> interceptors() {
    return null;
  }

}

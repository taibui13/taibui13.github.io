package com.uob.pweb.businessbanking.lending.test;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.queryParam;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.dsl.context.IntegrationFlowContext.IntegrationFlowRegistration;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.brm.BrmApplicationFlow;
import com.uob.pweb.businessbanking.lending.exception.GlobalExceptionHandlingFlow;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingValidator;
import com.uob.pweb.businessbanking.lending.form.flow.LendingApplicationFlow;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingIntegrationFlow;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;
import com.uob.pweb.component.EntityPersonResponse;

@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ApplicationTest.class, GlobalExceptionHandlingFlow.class,
    RequestLoggingIntegrationFlow.class, BrmApplicationFlow.class, MyInfoValidation.class,
    LendingValidator.class})
@TestPropertySource(
    properties = {"outbound.application.list=http://localhost/application/list"})
@DirtiesContext
public class GetApplicationListFlowTest {

  @Autowired
  private WebApplicationContext wac;

  @Autowired
  private IntegrationFlowContext integrationFlowContext;

  @Autowired
  private SpecificationService specificationService;

  private MockMvc mockMvc;

  private MockRestServiceServer mockServer;

  private IntegrationFlowRegistration flowRegistration;

  @Autowired
  private RestTemplate restTemplate;

  @Before
  public void setup() throws InvalidKeySpecException, NoSuchAlgorithmException,
      IOException, CertificateException {
    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
        .build();

    SecurityContextHolder.getContext()
        .setAuthentication(Authentication.builder()
            .lendingApplicationForm(LendingApplicationForm.builder()
                .build())
            .businessInfo(new ObjectMapper().readValue(
                "{\"uen\":\"53235113D\",\"uinfin\":\"S6005052Z\",\"entityPerson\":{\"entity\":{\"basic-profile\":{\"entity-type\":\"BN\",\"business-expiry-date\":\"2022-07-29\",\"entity-status\":\"LIVE\",\"primary-activity-desc\":\"Renting and Leasing of Other Personal and Household Goods\",\"entity-name\":\"Certain Beauty Parlor\",\"registration-date\":\"2006-09-08\",\"primary-activity-code\":\"7729\",\"business-constitution\":\"P\",\"secondary-activity-code\":\"3099\",\"secondary-activity-desc\":\"Manufacture of Other Transport Equipment n.e.c.\",\"uen\":\"53235113D\"}},\"person\":{ \"name\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"TAN XIAO HUI\" }, \"sex\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"F\" }, \"nationality\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"dob\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"1958-05-17\" }, \"regadd\": { \"country\": \"SG\", \"unit\": \"128\", \"street\": \"BEDOK NORTH AVENUE 1\", \"lastupdated\": \"2016-03-11\", \"block\": \"548\", \"source\": \"1\", \"postal\": \"460548\", \"classification\": \"C\", \"floor\": \"09\", \"building\": \"\" }, \"email\": { \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"value\": \"test@gmail.com\" }, \"mobileno\": { \"code\": \"65\", \"prefix\": \"+\", \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"nbr\": \"97324992\" } }}}",
                EntityPersonResponse.class))
            .build());

    LendingApplicationFlow lendingApplicationFlow = new LendingApplicationFlow();
    flowRegistration = this.integrationFlowContext
        .registration(lendingApplicationFlow
            .getLendingApplicationList(specificationService, new ObjectMapper()))
        .register();
  }

  @Test
  public void flowTest() throws Exception {

    this.mockServer = MockRestServiceServer.createServer(restTemplate);

    this.mockServer.expect(requestTo(
        "http://localhost/application/list?CompanyUenNo=UEN1416881234&ProductCode=BM001&Status=New&IDNo=123"))
        .andExpect(queryParam("CompanyUenNo", "UEN1416881234"))
        .andExpect(queryParam("ProductCode", "BM001"))
        .andExpect(queryParam("Status", "New"))
        .andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess(
            "{\"ResponseHeader\":{\"ResponseCode\":\"200\"},\"ResponseBody\":{\"Application\":[{\"ApplicationId\":\"5cce8d14-5c0e-469e-8e51-d36222d7af4d\",\"ProductCode\":\"BM001\",\"CompanyDetails\":{\"BasicDetails\":{\"ContactPerson\":\"sayed\",\"Email\":\"test@test.com\",\"ContactNumber\":\"55221147\"},\"BusinessDetails\":{\"BusinessRegistrationNo\":\"UEN1416881234\",\"RegisteredBusinessName\":\"SUPER DUPER CREAMY CAKE!\",\"EntityType\":\"string\",\"BusinessStatus\":\"Live\",\"PrimaryBusinessActivity\":\"string\",\"SecondaryBusinessActivity\":\"string\",\"DateOfIncorporation\":\"2009-01-23T13:34:00.000\",\"CountryOfIncorporation\":\"SG\",\"BusinessOwnership\":\"string\",\"BusinessExpiryDate\":\"2019-01-23T13:34:00.000\",\"CompanyAddressList\":[{\"AddressType\":\"R\",\"AddressFormat\":\"Y\",\"Block\":\"221\",\"StreetName\":\"ABC\",\"Floor\":\"12\",\"UnitNo\":\"04\",\"PostalCode\":\"521445\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":\"string\",\"AddressLine2\":\"string\",\"AddressLine3\":\"string\",\"AddressLine4\":\"string\",\"City\":\"string\",\"Country\":\"SG\"},{\"AddressType\":\"M\",\"AddressFormat\":\"F\",\"Block\":\"string\",\"StreetName\":\"string\",\"Floor\":\"string\",\"UnitNo\":\"string\",\"PostalCode\":\"string\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":\"BLK 522\",\"AddressLine2\":\"Unit No 1123\",\"AddressLine3\":\"string\",\"AddressLine4\":\"Andheri\",\"City\":\"Mumbai\",\"Country\":\"IND\"}]},\"EntityDetails\":{\"PreviousBusinessDetails\":[{\"BusinessRegistrationNo\":\"string\",\"CompanyName\":\"string\",\"EffectiveDate\":\"2019-01-23T13:34:00.000\"}],\"BusinessCapitalDetails\":[{\"BusinessType\":\"Preference\",\"SharedAllottedAmount\":\"150\",\"Category\":\"Issued\",\"CapitalAmount\":\"1500\",\"Currency\":\"SGD\"},{\"Category\":\"Issued\",\"BusinessType\":\"Ordinary\",\"SharedAllottedAmount\":\"120\",\"CapitalAmount\":\"1670\",\"Currency\":\"SGD\"},{\"Category\":\"Paidup\",\"BusinessType\":\"Preference\",\"SharedAllottedAmount\":\"180\",\"CapitalAmount\":\"1200\",\"Currency\":\"SGD\"},{\"Category\":\"Paidup\",\"BusinessType\":\"Ordinary\",\"SharedAllottedAmount\":\"165\",\"CapitalAmount\":\"2000\",\"Currency\":\"SGD\"}],\"FinancialDetails\":[{\"FYStartDate\":\"2018-01-23\",\"FYEndDate\":\"2019-01-23\",\"IsAudited\":\"YES/NO\",\"BusinessRevenue\":0,\"BusinessProfitLossBeforeTax\":0,\"BusinessProfitLossAfterTax\":0,\"GroupRevenue\":0,\"GroupCapitalPaidUpCapitalAmount\":0,\"GroupProfitLossBeforeTax\":0,\"Currency\":\"SGD\",\"GroupProfitLossAfterTax\":0}],\"Grants\":[{\"GrantsType\":\"string\",\"Status\":\"string\",\"FunctionalArea\":\"string\",\"DevelopmentCategory\":\"string\",\"Amount\":0,\"SubmittedDate\":\"2019-01-23T13:34:00.000\",\"LastUpdatedDate\":\"2019-01-23T13:34:00.000\"}]}},\"PrincipalList\":[{\"PersonalDetails\":{\"Name\":\"Sayed\",\"Email\":\"sayed122@GMAIL.COM\",\"ContactNo\":\"55884458\",\"Alias\":\"string\",\"HanYuPinYinName\":\"string\",\"HanYuPinYinAliasName\":\"string\",\"MarriedName\":\"string\",\"IdNo\":\"string\",\"Nric\":\"S5048335F\",\"Gender\":\"M\",\"MaritalStatus\":\"M\",\"DateOfBirth\":\"1987-06-08T00:00:00Z\",\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\",\"PermanentResident\":true,\"Category\":\"string\",\"Currency\":\"SGD\",\"ShareType\":\"string\",\"ShareholderPercentage\":\"string\",\"Allocation\":\"string\",\"AppointmentDate\":\"2019-05-23T13:34:00.000\",\"ApproveSignatory\":true,\"Positions\":[{\"PositionType\":\"AE\",\"ShareholdingPercentage\":\"20\",\"Company\":\"ABC Ltd\"},{\"PositionType\":\"PD\",\"ShareholdingPercentage\":\"30\",\"Company\":\"XYZ\"},{\"PositionType\":\"HB\",\"ShareholdingPercentage\":\"50\",\"Company\":\"TEST\"}],\"PersonalRegisteredAddress\":{\"AddressFormat\":\"Y\",\"Block\":\"112\",\"Street\":\"ABCD STREET\",\"buildingName\":\"TEST BUILDING\",\"StoreyNo\":\"25\",\"UnitNo\":\"123\",\"Country\":\"SG\",\"PostalCode\":\"558877\",\"AddressLine1\":\"string\",\"AddressLine2\":\"string\",\"AddressLine3\":\"string\",\"AddressLine4\":\"string\"},\"IncomeDetails\":[{\"YearlyAssessableIncomeInSGD\":\"1730000\",\"YearOfAssessment\":\"2018\",\"TradeIncome\":\"110000\",\"EmploymentIncome\":\"130000\",\"RentalIncome\":\"150000\",\"Currency\":\"SGD\",\"Category\":\"string\",\"TaxClearenceIndicator\":true}]}}],\"ApplicationReferenceNumber\":\"SG-2019-1560912915299-01\"}]}}",
            MediaType.APPLICATION_JSON));

    this.mockMvc.perform(get("/applications").param("companyUenNo", "UEN1416881234")
        .param("productCode", "BM001")
        .param("status", "New")
        .param("idNo", "123")
        .contentType(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());

    this.mockServer.verify();
  }

  @After
  public void finish() {
    flowRegistration.destroy();
  }

}

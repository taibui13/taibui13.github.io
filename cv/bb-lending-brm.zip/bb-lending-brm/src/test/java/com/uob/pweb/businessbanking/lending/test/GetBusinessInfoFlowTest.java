package com.uob.pweb.businessbanking.lending.test;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.dsl.context.IntegrationFlowContext.IntegrationFlowRegistration;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.uob.pweb.businessbanking.lending.exception.GlobalExceptionHandlingFlow;
import com.uob.pweb.businessbanking.lending.form.LendingValidator;
import com.uob.pweb.businessbanking.lending.form.flow.LendingApplicantFlow;
import com.uob.pweb.businessbanking.lending.form.flow.LendingVerificationFlow;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingIntegrationFlow;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;

@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ApplicationTest.class, GlobalExceptionHandlingFlow.class,
    RequestLoggingIntegrationFlow.class, LendingVerificationFlow.class,
    MyInfoValidation.class, LendingValidator.class})
@TestPropertySource(
    properties = {"service-url.myinfo-entity-person=http://localhost/corppass"})
@DirtiesContext
public class GetBusinessInfoFlowTest {

  @Autowired
  private WebApplicationContext wac;

  @Autowired
  private IntegrationFlowContext integrationFlowContext;

  private MockMvc mockMvc;

  private MockRestServiceServer mockServer;

  private IntegrationFlowRegistration flowRegistration;

  @Autowired
  @Qualifier("myinfoRestTemplate")
  private RestTemplate restTemplate;

  @Before
  public void setup() throws InvalidKeySpecException, NoSuchAlgorithmException,
      IOException, CertificateException {
    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
        .build();

    LendingApplicantFlow lendingApplicantFlow = new LendingApplicantFlow();
    flowRegistration =
        this.integrationFlowContext.registration(lendingApplicantFlow.getBusinessInfo())
            .register();
  }

  @Test
  public void flowTest() throws Exception {

    restTemplate.setInterceptors(new ArrayList<ClientHttpRequestInterceptor>());
    this.mockServer = MockRestServiceServer.createServer(restTemplate);

    this.mockServer.expect(requestTo("http://localhost/corppass"))
        .andExpect(method(HttpMethod.POST))
        .andRespond(withSuccess(
            "{\"uen\":\"53235113D\",\"uinfin\":\"S6005052Z\",\"entityPerson\":{\"entity\":{\"basic-profile\":{\"entity-type\":\"BN\",\"business-expiry-date\":\"2022-07-29\",\"entity-status\":\"LIVE\",\"primary-activity-desc\":\"Renting and Leasing of Other Personal and Household Goods\",\"entity-name\":\"Certain Beauty Parlor\",\"registration-date\":\"2006-09-08\",\"primary-activity-code\":\"7729\",\"business-constitution\":\"P\",\"secondary-activity-code\":\"3099\",\"secondary-activity-desc\":\"Manufacture of Other Transport Equipment n.e.c.\",\"uen\":\"53235113D\"}},\"person\":{}}}",
            MediaType.APPLICATION_JSON));

    this.mockMvc.perform(get("/applicants/business/info").param("code", "213")
        .param("scope", "123")
        .param("client_id", "123")
        .param("state", "123")
        .contentType(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());

    this.mockServer.verify();

  }

  @After
  public void finish() {
    flowRegistration.destroy();
  }

}

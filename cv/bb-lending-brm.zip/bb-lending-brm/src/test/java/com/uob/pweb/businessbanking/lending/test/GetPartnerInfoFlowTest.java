package com.uob.pweb.businessbanking.lending.test;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.dsl.context.IntegrationFlowContext.IntegrationFlowRegistration;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.uob.pweb.businessbanking.lending.exception.GlobalExceptionHandlingFlow;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.BasicInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingValidator;
import com.uob.pweb.businessbanking.lending.form.flow.LendingApplicantFlow;
import com.uob.pweb.businessbanking.lending.form.flow.LendingVerificationFlow;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingIntegrationFlow;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;

@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ApplicationTest.class, GlobalExceptionHandlingFlow.class,
    RequestLoggingIntegrationFlow.class, LendingVerificationFlow.class,
    MyInfoValidation.class, LendingValidator.class})
@TestPropertySource(properties = {"service-url.myinfo-person=http://localhost/person"})
@DirtiesContext
public class GetPartnerInfoFlowTest {

  @Autowired
  private WebApplicationContext wac;

  @Autowired
  private IntegrationFlowContext integrationFlowContext;

  private MockMvc mockMvc;

  private MockRestServiceServer mockServer;

  private IntegrationFlowRegistration flowRegistration;

  @Autowired
  @Qualifier("myinfoRestTemplate")
  private RestTemplate restTemplate;

  @Before
  public void setup() throws InvalidKeySpecException, NoSuchAlgorithmException,
      IOException, CertificateException {
    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
        .build();

    LendingApplicant lendingApplicant = new LendingApplicant();
    BasicInfo basicInfo = new BasicInfo();
    basicInfo.setLegalId("123");
    lendingApplicant.setBasicInfo(basicInfo);

    SecurityContextHolder.getContext()
        .setAuthentication(Authentication.builder()
            .lendingApplicationForm(LendingApplicationForm.builder()
                .person(Arrays.asList(lendingApplicant))
                .build())
            .build());

    LendingApplicantFlow lendingApplicantFlow = new LendingApplicantFlow();
    flowRegistration =
        this.integrationFlowContext.registration(lendingApplicantFlow.getPartnersInfo())
            .register();
  }

  @Test
  public void flowTest() throws Exception {

    restTemplate.setInterceptors(new ArrayList<ClientHttpRequestInterceptor>());
    this.mockServer = MockRestServiceServer.createServer(restTemplate);

    this.mockServer.expect(requestTo("http://localhost/person"))
        .andExpect(method(HttpMethod.POST))
        .andRespond(withSuccess(
            "{\"legalId\" : \"123\", \"person\" : { \"name\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"TAN XIAO HUI\" }, \"hanyupinyinname\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"CHEN XIAO HUI\" }, \"aliasname\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"TRICIA TAN XIAO HUI\" }, \"hanyupinyinaliasname\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"\" }, \"marriedname\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"\" }, \"sex\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"F\" }, \"race\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"CN\" }, \"secondaryrace\": { \"lastupdated\": \"2017-08-25\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"EU\" }, \"dialect\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"nationality\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"dob\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"1958-05-17\" }, \"birthcountry\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"residentialstatus\": { \"lastupdated\": \"2017-08-25\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"C\" }, \"passportnumber\": { \"lastupdated\": \"2017-08-25\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"E35463874W\" }, \"passportexpirydate\": { \"lastupdated\": \"2017-08-25\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"2020-01-01\" }, \"regadd\": { \"country\": \"SG\", \"unit\": \"128\", \"street\": \"BEDOK NORTH AVENUE 1\", \"lastupdated\": \"2016-03-11\", \"block\": \"548\", \"source\": \"1\", \"postal\": \"460548\", \"classification\": \"C\", \"floor\": \"09\", \"building\": \"\" }, \"mailadd\": { \"country\": \"SG\", \"unit\": \"128\", \"street\": \"BEDOK NORTH AVENUE 1\", \"lastupdated\": \"2016-03-11\", \"block\": \"548\", \"source\": \"2\", \"postal\": \"460548\", \"classification\": \"C\", \"floor\": \"09\", \"building\": \"\" }, \"billadd\": { \"country\": \"SG\", \"unit\": \"\", \"street\": \"\", \"lastupdated\": \"\", \"block\": \"\", \"source\": \"\", \"postal\": \"\", \"classification\": \"\", \"floor\": \"\", \"building\": \"\" }, \"housingtype\": { \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"\" }, \"hdbtype\": { \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"111\" }, \"ownerprivate\": { \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"N\" }, \"email\": { \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"value\": \"test@gmail.com\" }, \"homeno\": { \"code\": \"65\", \"prefix\": \"+\", \"lastupdated\": \"2017-11-20\", \"source\": \"2\", \"classification\": \"C\", \"nbr\": \"66132665\" }, \"mobileno\": { \"code\": \"65\", \"prefix\": \"+\", \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"nbr\": \"97324992\" }, \"marital\": { \"lastupdated\": \"2017-03-29\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"1\" }, \"marriagecertno\": { \"lastupdated\": \"2018-03-02\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"123456789012345\" }, \"countryofmarriage\": { \"lastupdated\": \"2018-03-02\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"marriagedate\": { \"lastupdated\": \"\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"\" }, \"divorcedate\": { \"lastupdated\": \"\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"\" }, \"childrenbirthrecords\": [ { \"dialect\": \"HK\", \"race\": \"CN\", \"tob\": \"0901\", \"sex\": \"F\", \"source\": \"1\", \"classification\": \"C\", \"birthcertno\": \"S5562882C\", \"hanyupinyinname\": \"Cheng Pei Ni\", \"hanyupinyinaliasname\": \"\", \"marriedname\": \"\", \"aliasname\": \"\", \"dob\": \"2011-09-10\", \"name\": \"Jo Tan Pei Ni\", \"lastupdated\": \"2018-05-16\", \"secondaryrace\": \"\" }, { \"dialect\": \"HK\", \"race\": \"CN\", \"tob\": \"2021\", \"sex\": \"F\", \"source\": \"1\", \"classification\": \"C\", \"birthcertno\": \"S8816582I\", \"hanyupinyinname\": \"Cheng Wei Ling\", \"hanyupinyinaliasname\": \"\", \"marriedname\": \"\", \"aliasname\": \"\", \"dob\": \"2015-07-18\", \"name\": \"Joyce Tan Wei Ling\", \"lastupdated\": \"2018-05-16\", \"secondaryrace\": \"\" }, { \"dialect\": \"HK\", \"race\": \"CN\", \"tob\": \"0901\", \"sex\": \"F\", \"source\": \"1\", \"classification\": \"C\", \"birthcertno\": \"T0202564C\", \"hanyupinyinname\": \"Cheng Shu Hui\", \"hanyupinyinaliasname\": \"\", \"marriedname\": \"\", \"aliasname\": \"\", \"dob\": \"2012-09-10\", \"name\": \"Joycelyn Tan Shu Hui\", \"lastupdated\": \"2018-05-16\", \"secondaryrace\": \"\" } ], \"relationships\": [ { \"passportno\": \"\", \"name\": \"TAN AH MUI\", \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"type\": \"REL201\", \"idno\": \"S9999999C\" }, { \"passportno\": \"\", \"name\": \"TAN CHIN SOON\", \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"type\": \"REL202\", \"idno\": \"S9999998E\" } ], \"edulevel\": { \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"value\": \"3\" }, \"gradyear\": { \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"value\": \"1978\" }, \"schoolname\": { \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"value\": \"T07GS3011J\", \"desc\": \"SIGLAP SECONDARY SCHOOL\" }, \"occupation\": { \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"value\": \"53201\", \"desc\": \"HEALTHCARE ASSISTANT\" }, \"employment\": { \"lastupdated\": \"2017-10-11\", \"source\": \"2\", \"classification\": \"C\", \"value\": \"ALPHA\" }, \"workpassstatus\": { \"lastupdated\": \"2018-03-02\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"Live\" }, \"workpassexpirydate\": { \"lastupdated\": \"2018-03-02\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"2018-12-31\" }, \"householdincome\": { \"high\": \"5999\", \"low\": \"5000\", \"lastupdated\": \"2017-10-24\", \"source\": \"2\", \"classification\": \"C\" }, \"assessableincome\": { \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"1456789.00\" }, \"assessyear\": { \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"2015\" }, \"cpfcontributions\": { \"cpfcontribution\": [ { \"date\": \"2016-12-01\", \"amount\": \"500.00\", \"month\": \"2016-11\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2016-12-12\", \"amount\": \"500.00\", \"month\": \"2016-12\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2016-12-21\", \"amount\": \"500.00\", \"month\": \"2016-12\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-01-01\", \"amount\": \"500.00\", \"month\": \"2016-12\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-01-12\", \"amount\": \"500.00\", \"month\": \"2017-01\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-01-21\", \"amount\": \"500.00\", \"month\": \"2017-01\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-02-01\", \"amount\": \"500.00\", \"month\": \"2017-01\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-02-12\", \"amount\": \"500.00\", \"month\": \"2017-02\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-02-21\", \"amount\": \"500.00\", \"month\": \"2017-02\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-03-01\", \"amount\": \"500.00\", \"month\": \"2017-02\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-03-12\", \"amount\": \"500.00\", \"month\": \"2017-03\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-03-21\", \"amount\": \"500.00\", \"month\": \"2017-03\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-04-01\", \"amount\": \"500.00\", \"month\": \"2017-03\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-04-12\", \"amount\": \"500.00\", \"month\": \"2017-04\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-04-21\", \"amount\": \"500.00\", \"month\": \"2017-04\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-05-01\", \"amount\": \"500.00\", \"month\": \"2017-04\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-05-12\", \"amount\": \"500.00\", \"month\": \"2017-05\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-05-21\", \"amount\": \"500.00\", \"month\": \"2017-05\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-06-01\", \"amount\": \"500.00\", \"month\": \"2017-05\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-06-12\", \"amount\": \"500.00\", \"month\": \"2017-06\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-06-21\", \"amount\": \"500.00\", \"month\": \"2017-06\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-07-01\", \"amount\": \"500.00\", \"month\": \"2017-06\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-07-12\", \"amount\": \"500.00\", \"month\": \"2017-07\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-07-21\", \"amount\": \"500.00\", \"month\": \"2017-07\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-08-01\", \"amount\": \"500.00\", \"month\": \"2017-07\", \"employer\": \"Crystal Horse Invest Pte Ltd\" }, { \"date\": \"2017-08-12\", \"amount\": \"750.00\", \"month\": \"2017-08\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-08-21\", \"amount\": \"750.00\", \"month\": \"2017-08\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-09-01\", \"amount\": \"750.00\", \"month\": \"2017-08\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-09-12\", \"amount\": \"750.00\", \"month\": \"2017-09\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-09-21\", \"amount\": \"750.00\", \"month\": \"2017-09\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-10-01\", \"amount\": \"750.00\", \"month\": \"2017-09\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-10-12\", \"amount\": \"750.00\", \"month\": \"2017-10\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-10-21\", \"amount\": \"750.00\", \"month\": \"2017-10\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-11-01\", \"amount\": \"750.00\", \"month\": \"2017-10\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-11-12\", \"amount\": \"750.00\", \"month\": \"2017-11\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-11-21\", \"amount\": \"750.00\", \"month\": \"2017-11\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-12-01\", \"amount\": \"750.00\", \"month\": \"2017-11\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-12-12\", \"amount\": \"750.00\", \"month\": \"2017-12\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2017-12-21\", \"amount\": \"750.00\", \"month\": \"2017-12\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2018-01-01\", \"amount\": \"750.00\", \"month\": \"2017-12\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2018-01-12\", \"amount\": \"750.00\", \"month\": \"2018-01\", \"employer\": \"Delta Marine Consultants PL\" }, { \"date\": \"2018-01-21\", \"amount\": \"750.00\", \"month\": \"2018-01\", \"employer\": \"Delta Marine Consultants PL\" } ], \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\" }, \"cpfbalances\": { \"oa\": \"1581.48\", \"ma\": \"11470.70\", \"lastupdated\": \"2015-12-23\", \"source\": \"1\", \"classification\": \"C\", \"sa\": \"21967.09\" }, \"vehno\": { \"lastupdated\": \"\", \"source\": \"2\", \"classification\": \"C\", \"value\": \"\" } }}",
            MediaType.APPLICATION_JSON));

    this.mockMvc.perform(get("/applicants/partners/info").param("code", "213")
        .param("scope", "123")
        .param("client_id", "123")
        .param("state", "123")
        .contentType(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());

    this.mockServer.verify();

  }

  @After
  public void finish() {
    flowRegistration.destroy();
  }

}

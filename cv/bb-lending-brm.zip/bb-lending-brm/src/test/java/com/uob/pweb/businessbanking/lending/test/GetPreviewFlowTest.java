package com.uob.pweb.businessbanking.lending.test;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.dsl.context.IntegrationFlowContext.IntegrationFlowRegistration;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.uob.pweb.businessbanking.lending.brm.BrmApplicationFlow;
import com.uob.pweb.businessbanking.lending.exception.GlobalExceptionHandlingFlow;
import com.uob.pweb.businessbanking.lending.form.LendingValidator;
import com.uob.pweb.businessbanking.lending.form.flow.LendingApplicationFlow;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingIntegrationFlow;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;

@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ApplicationTest.class, GlobalExceptionHandlingFlow.class,
    RequestLoggingIntegrationFlow.class, BrmApplicationFlow.class, MyInfoValidation.class,
    LendingValidator.class})
@TestPropertySource(
    properties = {"outbound.application.get=http://localhost/application/get"})
@DirtiesContext
public class GetPreviewFlowTest {

  @Autowired
  private WebApplicationContext wac;

  @Autowired
  private IntegrationFlowContext integrationFlowContext;

  private MockMvc mockMvc;

  private MockRestServiceServer mockServer;

  private IntegrationFlowRegistration flowRegistration;

  @Autowired
  private RestTemplate restTemplate;

  @Before
  public void setup() throws InvalidKeySpecException, NoSuchAlgorithmException,
      IOException, CertificateException {
    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
        .build();

    LendingApplicationFlow lendingApplicationFlow = new LendingApplicationFlow();
    flowRegistration =
        this.integrationFlowContext.registration(lendingApplicationFlow.getPreview())
            .register();
  }

  @Test
  public void flowTest() throws Exception {

    this.mockServer = MockRestServiceServer.createServer(restTemplate);

    this.mockServer
        .expect(requestTo(
            "http://localhost/application/get?ApplicationId=123&ApplicantId=123"))
        .andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess(
            "{ \"ResponseHeader\": { \"ResponseCode\": \"200\" }, \"ResponseBody\": { \"Application\": { \"ApplicationId\": \"76285e05-dfb7-4a59-96b5-e5ba1e44499d\", \"ApplicationStatus\": \"WIP-Online\", \"ProductCode\": \"BP001G\", \"CompanyDetails\": { \"BasicDetails\": { \"ContactPerson\": \"WONG WAI MUN\", \"Email\": \"123123123@gmail.com\", \"ContactNumber\": \"6597399245\" }, \"BusinessDetails\": { \"BusinessRegistrationNo\": \"S48844292K\", \"RegisteredBusinessName\": \"LEVEL PRESS LIMITED\", \"EntityType\": \"F\", \"BusinessStatus\": \"Live\", \"PrimaryBusinessActivity\": \"Airport operation services\", \"SecondaryBusinessActivity\": \"Manufacture of cards, envelopes and stationery, unprinted\", \"DateOfIncorporation\": \"1990-03-15T00:00:00.000Z\", \"CountryOfIncorporation\": \"SG\", \"BusinessOwnership\": \"Both Individual and Corporate Entity Shareholders\", \"BusinessExpiryDate\": null, \"CompanyAddressList\": [ { \"AddressType\": \"R\", \"AddressFormat\": \"L\", \"Block\": \"16\", \"StreetName\": \"COLLYER QUAY\", \"Floor\": \"30\", \"UnitNo\": \"1\", \"PostalCode\": \"049318\", \"IsSameAsRegisteredAddress\": null, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null, \"City\": null, \"Country\": \"SG\" }, { \"AddressType\": \"M\", \"AddressFormat\": null, \"Block\": null, \"StreetName\": null, \"Floor\": null, \"UnitNo\": null, \"PostalCode\": null, \"IsSameAsRegisteredAddress\": false, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null, \"City\": null, \"Country\": null } ] }, \"EntityDetails\": { \"PreviousBusinessDetails\": [ { \"BusinessRegistrationNo\": \"195735221O\", \"CompanyName\": \"Follow Press Limited\", \"EffectiveDate\": \"1977-03-11T00:00:00.000Z\" }, { \"BusinessRegistrationNo\": \"195991101K\", \"CompanyName\": \"Banner Press Limited\", \"EffectiveDate\": \"1968-10-29T00:00:00.000Z\" }, { \"BusinessRegistrationNo\": \"187256077T\", \"CompanyName\": \"Suntan Press Limited\", \"EffectiveDate\": \"1954-12-14T00:00:00.000Z\" }, { \"BusinessRegistrationNo\": \"185450727U\", \"CompanyName\": \"Needle Press Limited\", \"EffectiveDate\": \"1948-10-16T00:00:00.000Z\" }, { \"BusinessRegistrationNo\": \"180759913F\", \"CompanyName\": \"Rifle Press Limited\", \"EffectiveDate\": \"1933-05-18T00:00:00.000Z\" } ], \"BusinessCapitalDetails\": [ { \"BusinessType\": \"Others Capital\", \"SharedAllottedAmount\": 300000, \"Category\": \"Issued\", \"CapitalAmount\": 300000, \"Currency\": \"SGD\" }, { \"BusinessType\": \"Treasury Shares\", \"SharedAllottedAmount\": 200000, \"Category\": \"Issued\", \"CapitalAmount\": 200000, \"Currency\": \"SGD\" }, { \"BusinessType\": \"Ordinary Capital\", \"SharedAllottedAmount\": 500000, \"Category\": \"Issued\", \"CapitalAmount\": 500000, \"Currency\": \"SGD\" }, { \"BusinessType\": \"Others Capital\", \"SharedAllottedAmount\": 300000, \"Category\": \"Paidup\", \"CapitalAmount\": 300000, \"Currency\": \"SGD\" }, { \"BusinessType\": \"Treasury Shares\", \"SharedAllottedAmount\": 200000, \"Category\": \"Paidup\", \"CapitalAmount\": 200000, \"Currency\": \"SGD\" }, { \"BusinessType\": \"Ordinary Capital\", \"SharedAllottedAmount\": 500000, \"Category\": \"Paidup\", \"CapitalAmount\": 500000, \"Currency\": \"SGD\" } ], \"FinancialDetails\": [ { \"FYStartDate\": \"2017-04-01T00:00:00.000Z\", \"FYEndDate\": \"2018-03-31T00:00:00.000Z\", \"IsAudited\": false, \"BusinessRevenue\": 10000000, \"BusinessProfitLossBeforeTax\": 7000000, \"BusinessProfitLossAfterTax\": 5800000, \"GroupRevenue\": 0, \"GroupCapitalPaidUpCapitalAmount\": 0, \"GroupProfitLossBeforeTax\": 0, \"GroupProfitLossAfterTax\": 0, \"Currency\": \"SGD\" }, { \"FYStartDate\": \"2016-04-01T00:00:00.000Z\", \"FYEndDate\": \"2017-03-31T00:00:00.000Z\", \"IsAudited\": true, \"BusinessRevenue\": 8000000, \"BusinessProfitLossBeforeTax\": 5000000, \"BusinessProfitLossAfterTax\": 3400000, \"GroupRevenue\": 0, \"GroupCapitalPaidUpCapitalAmount\": 0, \"GroupProfitLossBeforeTax\": 0, \"GroupProfitLossAfterTax\": 0, \"Currency\": \"SGD\" } ], \"Grants\": [ { \"GrantsType\": \"Market Readiness Assistance\", \"Status\": \"Approved\", \"FunctionalArea\": \"Market Readiness Assistance\", \"DevelopmentCategory\": \"International Expansion\", \"Amount\": 3000, \"SubmittedDate\": \"2014-05-24T00:00:00.000Z\", \"LastUpdatedDate\": \"2017-09-30T00:00:00.000Z\" } ] } }, \"PrincipalList\": [ { \"PersonalDetails\": { \"IsMainApplicant\": true, \"Type\": \"Individual\", \"Name\": \"WONG WAI MUN\", \"Email\": \"123123123@GMAIL.COM\", \"ContactNo\": \"6597399245\", \"Alias\": \"ALYSSA WONG WAI MUN\", \"HanYuPinYinName\": \"WANG WAI MUN\", \"HanYuPinYinAliasName\": \"ALYSSA WANG WAI MUN\", \"MarriedName\": null, \"IdType\": null, \"IdNo\": \"S9812380F\", \"Gender\": \"F\", \"MaritalStatus\": \"S\", \"DateOfBirth\": \"1988-10-06T00:00:00.000Z\", \"CountryOfBirth\": \"SG\", \"CountryOfCitizenship\": \"SG\", \"PermanentResident\": \"False\", \"Category\": null, \"Currency\": null, \"ShareType\": null, \"ShareholderPercentage\": null, \"Allocation\": null, \"AppointmentDate\": \"4/7/2001 12:00:00 AM\", \"OnlineCBSConsentDate\": \"0001-01-01T00:00:00.000Z\", \"Positions\": [ { \"PositionType\": null, \"ShareholdingPercentage\": null, \"Company\": null } ], \"PersonalRegisteredAddress\": { \"AddressFormat\": \"S\", \"Block\": \"18\", \"Street\": \"HAVELOCK ROAD\", \"buildingName\": null, \"StoreyNo\": null, \"UnitNo\": null, \"Country\": \"SG\", \"PostalCode\": \"059764\", \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null }, \"IncomeDetails\": [ { \"YearlyAssessableIncomeInSGD\": \"50200.0000\", \"YearOfAssessment\": \"2016\", \"TradeIncome\": \"0.0000\", \"EmploymentIncome\": \"50200.0000\", \"RentalIncome\": \"0.0000\", \"Currency\": \"SGD\", \"Category\": \"ORIGINAL\", \"TaxClearenceIndicator\": false }, { \"YearlyAssessableIncomeInSGD\": \"50400.0000\", \"YearOfAssessment\": \"2017\", \"TradeIncome\": \"0.0000\", \"EmploymentIncome\": \"50400.0000\", \"RentalIncome\": \"0.0000\", \"Currency\": \"SGD\", \"Category\": \"ORIGINAL\", \"TaxClearenceIndicator\": false } ] } }, { \"PersonalDetails\": { \"IsMainApplicant\": false, \"Type\": \"NonIndividual\", \"Name\": \"SCORE GLOBAL INC\", \"Email\": null, \"ContactNo\": null, \"Alias\": null, \"HanYuPinYinName\": null, \"HanYuPinYinAliasName\": null, \"MarriedName\": null, \"IdType\": \"RC\", \"IdNo\": \"S28FC2994G\", \"Gender\": null, \"MaritalStatus\": null, \"DateOfBirth\": \"0001-01-01T00:00:00.000Z\", \"CountryOfBirth\": null, \"CountryOfCitizenship\": null, \"PermanentResident\": \"False\", \"Category\": \"Foreign Company\", \"Currency\": \"SGD\", \"ShareType\": \"Others Capital\", \"ShareholderPercentage\": null, \"Allocation\": \"300000\", \"AppointmentDate\": null, \"OnlineCBSConsentDate\": \"0001-01-01T00:00:00.000Z\", \"Positions\": [], \"PersonalRegisteredAddress\": { \"AddressFormat\": null, \"Block\": null, \"Street\": null, \"buildingName\": null, \"StoreyNo\": null, \"UnitNo\": null, \"Country\": null, \"PostalCode\": null, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null }, \"IncomeDetails\": [] } }, { \"PersonalDetails\": { \"IsMainApplicant\": null, \"Type\": \"Individual\", \"Name\": null, \"Email\": null, \"ContactNo\": null, \"Alias\": null, \"HanYuPinYinName\": null, \"HanYuPinYinAliasName\": null, \"MarriedName\": null, \"IdType\": null, \"IdNo\": null, \"Gender\": null, \"MaritalStatus\": null, \"DateOfBirth\": \"0001-01-01T00:00:00.000Z\", \"CountryOfBirth\": null, \"CountryOfCitizenship\": null, \"PermanentResident\": \"False\", \"Category\": null, \"Currency\": null, \"ShareType\": null, \"ShareholderPercentage\": null, \"Allocation\": null, \"AppointmentDate\": null, \"OnlineCBSConsentDate\": \"0001-01-01T00:00:00.000Z\", \"Positions\": [], \"PersonalRegisteredAddress\": { \"AddressFormat\": null, \"Block\": null, \"Street\": null, \"buildingName\": null, \"StoreyNo\": null, \"UnitNo\": null, \"Country\": null, \"PostalCode\": null, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null }, \"IncomeDetails\": [] } }, { \"PersonalDetails\": { \"IsMainApplicant\": false, \"Type\": \"Individual\", \"Name\": \"THIS NAME CONTAINS ALPHABETS FOR TESTING ONLY MORE THAN 60 CHARS\", \"Email\": null, \"ContactNo\": null, \"Alias\": null, \"HanYuPinYinName\": null, \"HanYuPinYinAliasName\": null, \"MarriedName\": null, \"IdType\": null, \"IdNo\": \"S9912367B\", \"Gender\": null, \"MaritalStatus\": null, \"DateOfBirth\": \"0001-01-01T00:00:00.000Z\", \"CountryOfBirth\": null, \"CountryOfCitizenship\": null, \"PermanentResident\": \"False\", \"Category\": \"Individual\", \"Currency\": null, \"ShareType\": null, \"ShareholderPercentage\": null, \"Allocation\": null, \"AppointmentDate\": null, \"OnlineCBSConsentDate\": \"0001-01-01T00:00:00.000Z\", \"Positions\": [], \"PersonalRegisteredAddress\": { \"AddressFormat\": null, \"Block\": null, \"Street\": null, \"buildingName\": null, \"StoreyNo\": null, \"UnitNo\": null, \"Country\": null, \"PostalCode\": null, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null }, \"IncomeDetails\": [] } }, { \"PersonalDetails\": { \"IsMainApplicant\": null, \"Type\": \"Individual\", \"Name\": null, \"Email\": null, \"ContactNo\": null, \"Alias\": null, \"HanYuPinYinName\": null, \"HanYuPinYinAliasName\": null, \"MarriedName\": null, \"IdType\": null, \"IdNo\": null, \"Gender\": null, \"MaritalStatus\": null, \"DateOfBirth\": \"0001-01-01T00:00:00.000Z\", \"CountryOfBirth\": null, \"CountryOfCitizenship\": null, \"PermanentResident\": \"False\", \"Category\": null, \"Currency\": null, \"ShareType\": null, \"ShareholderPercentage\": null, \"Allocation\": null, \"AppointmentDate\": null, \"OnlineCBSConsentDate\": \"0001-01-01T00:00:00.000Z\", \"Positions\": [], \"PersonalRegisteredAddress\": { \"AddressFormat\": null, \"Block\": null, \"Street\": null, \"buildingName\": null, \"StoreyNo\": null, \"UnitNo\": null, \"Country\": null, \"PostalCode\": null, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null }, \"IncomeDetails\": [] } }, { \"PersonalDetails\": { \"IsMainApplicant\": false, \"Type\": \"Individual\", \"Name\": \"CLARISSA LIN JIN PING\", \"Email\": null, \"ContactNo\": null, \"Alias\": null, \"HanYuPinYinName\": null, \"HanYuPinYinAliasName\": null, \"MarriedName\": null, \"IdType\": null, \"IdNo\": \"S9812386E\", \"Gender\": null, \"MaritalStatus\": null, \"DateOfBirth\": \"0001-01-01T00:00:00.000Z\", \"CountryOfBirth\": null, \"CountryOfCitizenship\": null, \"PermanentResident\": \"False\", \"Category\": \"Individual\", \"Currency\": null, \"ShareType\": null, \"ShareholderPercentage\": null, \"Allocation\": null, \"AppointmentDate\": null, \"OnlineCBSConsentDate\": \"0001-01-01T00:00:00.000Z\", \"Positions\": [], \"PersonalRegisteredAddress\": { \"AddressFormat\": null, \"Block\": null, \"Street\": null, \"buildingName\": null, \"StoreyNo\": null, \"UnitNo\": null, \"Country\": null, \"PostalCode\": null, \"AddressLine1\": null, \"AddressLine2\": null, \"AddressLine3\": null, \"AddressLine4\": null }, \"IncomeDetails\": [] } } ] } } }",
            MediaType.APPLICATION_JSON));

    this.mockMvc
        .perform(get("/applications/123/applicants/123/preview")
            .contentType(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());

    this.mockServer.verify();
  }

  @After
  public void finish() {
    flowRegistration.destroy();
  }

}

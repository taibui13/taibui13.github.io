package com.uob.pweb.businessbanking.lending.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.uob.pweb.businessbanking.lending.brm.BrmApplication;
import com.uob.pweb.businessbanking.lending.brm.SupplementaryInfo;
import com.uob.pweb.businessbanking.lending.form.AdditionalAppointment;
import com.uob.pweb.businessbanking.lending.form.Business;
import com.uob.pweb.businessbanking.lending.form.Business.Appointment;
import com.uob.pweb.businessbanking.lending.form.Business.EntityReference;
import com.uob.pweb.businessbanking.lending.form.Business.PersonReference;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.AlternateNames;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.BasicInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.Noa;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.OnlineFormAddress;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.PersonalInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.component.JsonMapper;
import com.uob.pweb.component.ObjectMapperBuilder.ObjectMapperConfig;
import com.uob.pweb.component.ObjectMapperUtil;

import ch.qos.logback.core.joran.action.Action;

@RunWith(SpringRunner.class)
public class JsonBbMapperTest {

   
	
  public List<Appointment> SetAppointmentList(LendingApplicationForm lendingApplicationForm, String apmtStr) throws JsonParseException, JsonMappingException, IOException {
	  ObjectMapper objMapper = ObjectMapperUtil.getObjectMapper();
		  List<Appointment> apmtList  = objMapper.readValue(apmtStr, new TypeReference<List<Appointment>>(){});
	      return apmtList;
	 }
	
	public String getBirthDate(String dob) {
	      
	    DateTimeFormatter dtfIn = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    LocalDate dtIn = LocalDate.parse(dob, dtfIn);
	    DateTimeFormatter dtfOut = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    String finaDob = dtIn.format(dtfOut);
	    return finaDob;  
	  }	
	
 //private final String request1 =
   //  "{\"Application\":{\"ApplicationId\":\"7f7fa9be-9e54-4926-9340-195b88a16c1c\",\"ApplicationStatus\":\"WIP-Online\",\"ProductCode\":\"UOBBBBizPC\",\"ApplicationReferenceNo\":\"SG-2019-00113655-01\",\"InitiateDate\":\"2019-08-20T04:00:38.000Z\",\"ExpiredDate\":\"2019-08-27T04:00:38.000Z\",\"CompanyDetails\":{\"BasicDetails\":{\"ContactPerson\":\"MR MYINFO B\",\"Email\":\"venkud@sg.uob\",\"ContactNumber\":\"+6597399245\"},\"BusinessDetails\":{\"BusinessRegistrationNo\":\"896739690Z\",\"RegisteredBusinessName\":\"CEILING VENTURE LIMITED SOCIETY\",\"EntityType\":\"D\",\"BusinessStatus\":\"Live\",\"PrimaryBusinessActivity\":\"Marine insurance\",\"SecondaryBusinessActivity\":\"Game arcade, online game aggregator, LAN game operators and gaming centres\",\"DateOfIncorporation\":\"1997-12-22T00:00:00.000Z\",\"CountryOfIncorporation\":\"SG\",\"BusinessOwnership\":\"Individual Shareholders only\",\"BusinessExpiryDate\":\"2023-08-29T00:00:00.000Z\",\"CompanyAddressList\":[{\"AddressType\":\"R\",\"AddressFormat\":null,\"Block\":\"5002\",\"StreetName\":\"ANG MO KIO AVENUE 5\",\"Floor\":\"2\",\"UnitNo\":\"12\",\"PostalCode\":\"569871\",\"IsSameAsRegisteredAddress\":null,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":\"SG\"},{\"AddressType\":\"M\",\"AddressFormat\":null,\"Block\":null,\"StreetName\":null,\"Floor\":null,\"UnitNo\":null,\"PostalCode\":null,\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":null}]},\"EntityDetails\":{\"PreviousBusinessDetails\":[],\"BusinessCapitalDetails\":[{\"BusinessType\":\"Ordinary Capital\",\"SharedAllottedAmount\":40000.0,\"Category\":\"Issued\",\"CapitalAmount\":40000.0,\"Currency\":\"SGD\"},{\"BusinessType\":\"Ordinary Capital\",\"SharedAllottedAmount\":40000.0,\"Category\":\"Paidup\",\"CapitalAmount\":40000.0,\"Currency\":\"SGD\"}],\"FinancialDetails\":[{\"FYStartDate\":\"2015-01-01T00:00:00.000Z\",\"FYEndDate\":\"2015-12-31T00:00:00.000Z\",\"IsAudited\":true,\"BusinessRevenue\":3.0E7,\"BusinessProfitLossBeforeTax\":1.0246729E7,\"BusinessProfitLossAfterTax\":7395620.0,\"GroupRevenue\":9.8E8,\"GroupCapitalPaidUpCapitalAmount\":1.0E7,\"GroupProfitLossBeforeTax\":2.17493017E8,\"GroupProfitLossAfterTax\":1.52749482E8,\"Currency\":\"SGD\"}],\"Grants\":[{\"GrantsType\":\"Global Company Partnership\",\"Status\":\"Approved\",\"FunctionalArea\":\"Global Company Partnership\",\"DevelopmentCategory\":\"Capability Development\",\"Amount\":5000.0,\"SubmittedDate\":\"2014-10-22T00:00:00.000Z\",\"LastUpdatedDate\":\"2016-06-17T00:00:00.000Z\"}]}},\"PrincipalList\":[{\"PersonalDetails\":{\"IsMainApplicant\":true,\"Type\":\"Individual\",\"Name\":\"MR MYINFO B\",\"Email\":\"VENKUD@SG.UOB\",\"ContactNo\":\"+6597399245\",\"Alias\":\"alias name\",\"HanYuPinYinName\":\"han yu pin yin name\",\"HanYuPinYinAliasName\":\"han yu pin yin alias name\",\"MarriedName\":\"married name\",\"IdType\":\"NRIC\",\"IdNo\":\"S4687771C\",\"Gender\":\"M\",\"MaritalStatus\":\"M\",\"DateOfBirth\":\"1967-11-13T00:00:00.000Z\",\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\",\"PermanentResident\":\"False\",\"Category\":null,\"Currency\":null,\"ShareType\":null,\"ShareholderPercentage\":null,\"Allocation\":null,\"AppointmentDate\":\"12/22/1997 12:00:00 AM\",\"OnlineCBSConsentDate\":null,\"Positions\":[{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"Company\":null}],\"PersonalRegisteredAddress\":{\"AddressFormat\":null,\"Block\":\"288A\",\"Street\":\"JURONG EAST STREET 40\",\"buildingName\":null,\"StoreyNo\":\"11\",\"UnitNo\":\"21\",\"Country\":\"SG\",\"PostalCode\":\"601288\",\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null},\"IncomeDetails\":[{\"YearlyAssessableIncomeInSGD\":\"123456.7000\",\"YearOfAssessment\":\"2017\",\"TradeIncome\":\"3000.0000\",\"EmploymentIncome\":\"120000.7000\",\"RentalIncome\":\"0.0000\",\"Currency\":\"SGD\",\"Category\":\"ADDITIONAL\",\"TaxClearenceIndicator\":true},{\"YearlyAssessableIncomeInSGD\":\"1202367.1200\",\"YearOfAssessment\":\"2015\",\"TradeIncome\":\"3000.0000\",\"EmploymentIncome\":\"120000.7000\",\"RentalIncome\":\"0.0000\",\"Currency\":\"SGD\",\"Category\":\"ORIGINAL\",\"TaxClearenceIndicator\":false},{\"YearlyAssessableIncomeInSGD\":\"120123.1200\",\"YearOfAssessment\":\"2016\",\"TradeIncome\":\"3000.0000\",\"EmploymentIncome\":\"120000.7000\",\"RentalIncome\":\"0.0000\",\"Currency\":\"SGD\",\"Category\":\"ORIGINAL\",\"TaxClearenceIndicator\":true}]}}],\"SupplementaryInfo\":[{\"Name\":\"residentialStatus\",\"Contents\":[\"C\"]},{\"Name\":\"buildingName\",\"Contents\":[\"12\"]},{\"Name\":\"entityType\",\"Contents\":[\"LC\"]},{\"Name\":\"companyType\",\"Contents\":[\"B1\"]},{\"Name\":\"businessConstitution\",\"Contents\":[\"\"]},{\"Name\":\"CountryOfBirth\",\"Contents\":[\"SG\"]}]}}";
	
	
   private final String request =
		     "{ \"Application\":{  \n" + 
		     "      \"ApplicationId\":\"7f7fa9be-9e54-4926-9340-195b88a16c1c\",\n" + 
		     "      \"ApplicationStatus\":\"WIP-Online\",\n" + 
		     "      \"ProductCode\":\"UOBBBBizPC\",\n" + 
		     "      \"ApplicationReferenceNo\":\"SG-2019-00113655-01\",\n" + 
		     "      \"InitiateDate\":\"2019-08-20T04:00:38.000Z\",\n" + 
		     "      \"ExpiredDate\":\"2019-08-27T04:00:38.000Z\",\n" + 
		     "      \"CompanyDetails\":{  \n" + 
		     "         \"BasicDetails\":{  \n" + 
		     "            \"ContactPerson\":\"MR MYINFO B\",\n" + 
		     "            \"Email\":\"venkud@sg.uob\",\n" + 
		     "            \"ContactNumber\":\"+6597399245\"\n" + 
		     "         },\n" + 
		     "         \"BusinessDetails\":{  \n" + 
		     "            \"BusinessRegistrationNo\":\"896739690Z\",\n" + 
		     "            \"RegisteredBusinessName\":\"CEILING VENTURE LIMITED SOCIETY\",\n" + 
		     "            \"EntityType\":\"D\",\n" + 
		     "            \"BusinessStatus\":\"Live\",\n" + 
		     "            \"PrimaryBusinessActivity\":\"Marine insurance\",\n" + 
		     "            \"SecondaryBusinessActivity\":\"Game arcade, online game aggregator, LAN game operators and gaming centres\",\n" + 
		     "            \"DateOfIncorporation\":\"1997-12-22T00:00:00.000Z\",\n" + 
		     "            \"CountryOfIncorporation\":\"SG\",\n" + 
		     "            \"BusinessOwnership\":\"Individual Shareholders only\",\n" + 
		     "            \"BusinessExpiryDate\":\"2023-08-29T00:00:00.000Z\",\n" + 
		     "            \"CompanyAddressList\":[  \n" + 
		     "               {  \n" + 
		     "                  \"AddressType\":\"R\",\n" + 
		     "                  \"AddressFormat\":null,\n" + 
		     "                  \"Block\":\"5002\",\n" + 
		     "                  \"StreetName\":\"ANG MO KIO AVENUE 5\",\n" + 
		     "                  \"Floor\":\"2\",\n" + 
		     "                  \"UnitNo\":\"12\",\n" + 
		     "                  \"PostalCode\":\"569871\",\n" + 
		     "                  \"buildingName\":\"building xyz\",\n" +
		     "                  \"IsSameAsRegisteredAddress\":null,\n" + 
		     "                  \"AddressLine1\":null,\n" + 
		     "                  \"AddressLine2\":null,\n" + 
		     "                  \"AddressLine3\":null,\n" + 
		     "                  \"AddressLine4\":null,\n" + 
		     "                  \"City\":null,\n" + 
		     "                  \"Country\":\"SG\"\n" + 
		     "               },\n" + 
		     "               {  \n" + 
		     "                  \"AddressType\":\"M\",\n" + 
		     "                  \"AddressFormat\":null,\n" + 
		     "                  \"Block\":null,\n" + 
		     "                  \"StreetName\":null,\n" + 
		     "                  \"Floor\":null,\n" + 
		     "                  \"UnitNo\":null,\n" + 
		     "                  \"PostalCode\":null,\n" + 
		     "                  \"IsSameAsRegisteredAddress\":false,\n" + 
		     "                  \"AddressLine1\":null,\n" + 
		     "                  \"AddressLine2\":null,\n" + 
		     "                  \"AddressLine3\":null,\n" + 
		     "                  \"AddressLine4\":null,\n" + 
		     "                  \"City\":null,\n" + 
		     "                  \"Country\":null\n" + 
		     "               }\n" + 
		     "            ]\n" + 
		     "         },\n" + 
		     "         \"EntityDetails\":{  \n" + 
		     "            \"PreviousBusinessDetails\":[  \n" + 
		     "\n" + 
		     "            ],\n" + 
		     "            \"BusinessCapitalDetails\":[  \n" + 
		     "               {  \n" + 
		     "                  \"BusinessType\":\"Ordinary Capital\",\n" + 
		     "                  \"SharedAllottedAmount\":40000.0,\n" + 
		     "                  \"Category\":\"Issued\",\n" + 
		     "                  \"CapitalAmount\":40000.0,\n" + 
		     "                  \"Currency\":\"SGD\"\n" + 
		     "               },\n" + 
		     "               {  \n" + 
		     "                  \"BusinessType\":\"Ordinary Capital\",\n" + 
		     "                  \"SharedAllottedAmount\":40000.0,\n" + 
		     "                  \"Category\":\"Paidup\",\n" + 
		     "                  \"CapitalAmount\":40000.0,\n" + 
		     "                  \"Currency\":\"SGD\"\n" + 
		     "               }\n" + 
		     "            ],\n" + 
		     "            \"FinancialDetails\":[  \n" + 
		     "               {  \n" + 
		     "                  \"FYStartDate\":\"2015-01-01T00:00:00.000Z\",\n" + 
		     "                  \"FYEndDate\":\"2015-12-31T00:00:00.000Z\",\n" + 
		     "                  \"IsAudited\":true,\n" + 
		     "                  \"BusinessRevenue\":3.0E7,\n" + 
		     "                  \"BusinessProfitLossBeforeTax\":1.0246729E7,\n" + 
		     "                  \"BusinessProfitLossAfterTax\":7395620.0,\n" + 
		     "                  \"GroupRevenue\":9.8E8,\n" + 
		     "                  \"GroupCapitalPaidUpCapitalAmount\":1.0E7,\n" + 
		     "                  \"GroupProfitLossBeforeTax\":2.17493017E8,\n" + 
		     "                  \"GroupProfitLossAfterTax\":1.52749482E8,\n" + 
		     "                  \"Currency\":\"SGD\"\n" + 
		     "               }\n" + 
		     "            ],\n" + 
		     "            \"Grants\":[  \n" + 
		     "               {  \n" + 
		     "                  \"GrantsType\":\"Global Company Partnership\",\n" + 
		     "                  \"Status\":\"Approved\",\n" + 
		     "                  \"FunctionalArea\":\"Global Company Partnership\",\n" + 
		     "                  \"DevelopmentCategory\":\"Capability Development\",\n" + 
		     "                  \"Amount\":5000.0,\n" + 
		     "                  \"SubmittedDate\":\"2014-10-22T00:00:00.000Z\",\n" + 
		     "                  \"LastUpdatedDate\":\"2016-06-17T00:00:00.000Z\"\n" + 
		     "               }\n" + 
		     "            ]\n" + 
		     "         }\n" + 
		     "      },\n" + 
		     "      \"PrincipalList\":[  \n" + 
		     "         {  \n" + 
		     "            \"PersonalDetails\":{  \n" + 
		     "               \"IsMainApplicant\":false,\n" + 
		     "               \"Type\":\"Individual\",\n" + 
		     "               \"Name\":\"MR MYINFO B\",\n" + 
		     "               \"Email\":\"VENKUD@SG.UOB\",\n" + 
		     "               \"ContactNo\":\"+6597399245\",\n" + 
		     "               \"Alias\":\"alias name\",\n" + 
		     "               \"HanYuPinYinName\":\"han yu pin yin name\",\n" + 
		     "               \"HanYuPinYinAliasName\":\"han yu pin yin alias name\",\n" + 
		     "               \"MarriedName\":\"married name\",\n" + 
		     "               \"IdType\":\"NRIC\",\n" + 
		     "               \"IdNo\":\"S4687771C\",\n" + 
		     "               \"Gender\":\"M\",\n" + 
		     "               \"MaritalStatus\":\"M\",\n" + 
		     "               \"DateOfBirth\":\"1967-11-13T00:00:00.000Z\",\n" + 
		     "               \"CountryOfBirth\":\"SG\",\n" + 
		     "               \"CountryOfCitizenship\":\"SG\",\n" + 
		     "               \"PermanentResident\":\"False\",\n" + 
		     "               \"Category\":null,\n" + 
		     "               \"Currency\":null,\n" + 
		     "               \"ShareType\":null,\n" + 
		     "               \"ShareholderPercentage\":null,\n" + 
		     "               \"Allocation\":null,\n" + 
		     "               \"AppointmentDate\":\"12/22/1997 12:00:00 AM\",\n" + 
		     "               \"OnlineCBSConsentDate\":null,\n" + 
		     "               \"Positions\":[  \n" + 
		     "                  {  \n" + 
		     "                     \"PositionType\":\"D\",\n" + 
		     "                     \"PositionCode\":\"15\",\n" +
		     "                     \"ShareholdingPercentage\":null,\n" + 
		     "                     \"Company\":null\n" + 
		     "                  }\n" + 
		     "               ],\n" + 
		     "               \"PersonalRegisteredAddress\":{  \n" + 
		     "                  \"AddressFormat\":null,\n" + 
		     "                  \"Block\":\"288A\",\n" + 
		     "                  \"Street\":\"JURONG EAST STREET 40\",\n" + 
		     "                  \"buildingName\": west coast,\n" + 
		     "                  \"StoreyNo\":\"11\",\n" + 
		     "                  \"UnitNo\":\"21\",\n" + 
		     "                  \"Country\":\"SG\",\n" + 
		     "                  \"PostalCode\":\"601288\",\n" + 
		     "                  \"AddressLine1\":null,\n" + 
		     "                  \"AddressLine2\":null,\n" + 
		     "                  \"AddressLine3\":null,\n" + 
		     "                  \"AddressLine4\":null\n" + 
		     "               },\n" + 
		     "               \"IncomeDetails\":[  \n" + 
		     "                  {  \n" + 
		     "                     \"YearlyAssessableIncomeInSGD\":\"123456.7000\",\n" + 
		     "                     \"YearOfAssessment\":\"2017\",\n" + 
		     "                     \"TradeIncome\":\"3000.0000\",\n" + 
		     "                     \"EmploymentIncome\":\"120000.7000\",\n" + 
		     "                     \"RentalIncome\":\"0.0000\",\n" + 
		     "                     \"Currency\":\"SGD\",\n" + 
		     "                     \"Category\":\"ADDITIONAL\",\n" + 
		     "                     \"TaxClearenceIndicator\":true\n" + 
		     "                  },\n" + 
		     "                  {  \n" + 
		     "                     \"YearlyAssessableIncomeInSGD\":\"1202367.1200\",\n" + 
		     "                     \"YearOfAssessment\":\"2015\",\n" + 
		     "                     \"TradeIncome\":\"3000.0000\",\n" + 
		     "                     \"EmploymentIncome\":\"120000.7000\",\n" + 
		     "                     \"RentalIncome\":\"0.0000\",\n" + 
		     "                     \"Currency\":\"SGD\",\n" + 
		     "                     \"Category\":\"ORIGINAL\",\n" + 
		     "                     \"TaxClearenceIndicator\":false\n" + 
		     "                  },\n" + 
		     "                  {  \n" + 
		     "                     \"YearlyAssessableIncomeInSGD\":\"120123.1200\",\n" + 
		     "                     \"YearOfAssessment\":\"2016\",\n" + 
		     "                     \"TradeIncome\":\"3000.0000\",\n" + 
		     "                     \"EmploymentIncome\":\"120000.7000\",\n" + 
		     "                     \"RentalIncome\":\"0.0000\",\n" + 
		     "                     \"Currency\":\"SGD\",\n" + 
		     "                     \"Category\":\"ORIGINAL\",\n" + 
		     "                     \"TaxClearenceIndicator\":true\n" + 
		     "                  }\n" + 
		     "               ]\n" + 
		     "            }\n" + 
		     "         },\n" + 
		     "         {  \n" + 
		     "            \"PersonalDetails\":{  \n" + 
		     "               \"IsMainApplicant\":true,\n" + 
		     "               \"Type\":\"Individual\",\n" + 
		     "               \"Name\":\"MEI TEST\",\n" + 
		     "               \"IdType\":\"NRIC\",\n" + 
		     "               \"IdNo\":\"S1234567D\",\n" + 
		     "               \"Category\":\"Individual\",\n" + 
		     "               \"Currency\":null,\n" + 
		     "               \"Positions\":[  \n" + 
		     "                  {  \n" + 
		     "                     \"PositionType\":\"G\",\n" + 
		     "                     \"ShareholdingPercentage\":null,\n" + 
		     "                     \"EffectiveShareholding\":null,\n" + 
		     "                     \"Company\":null\n" + 
		     "                  },\n" + 
		     "                  {  \n" + 
		     "                     \"PositionType\":\"P\",\n" + 
		     "                     \"ShareholdingPercentage\":null,\n" + 
		     "                     \"EffectiveShareholding\":null,\n" + 
		     "                     \"Company\":null\n" + 
		     "                  }\n" + 
		     "               ],\n" + 
		     "               \"CountryOfBirth\":\"VA\",\n" + 
		     "               \"CountryOfCitizenship\":\"VA\",\n" + 
		     "               \"ContactNo\":\"+6588692675\",\n" + 
		     "               \"Email\":\"venkud@sg.uob\"\n" +
		     "            }\n" + 
		     "         }\n" + 
		     "      ],\n" + 
		     "      \"SupplementaryInfo\":[  \n" + 
		     "         {  \n" + 
		     "            \"Name\":\"residentialStatus\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"C\"\n" + 
		     "            ]\n" + 
		     "         },\n" + 
		     "         {  \n" + 
		     "            \"Name\":\"buildingName\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"12\"\n" + 
		     "            ]\n" + 
		     "         },\n" + 
		     "         {  \n" + 
		     "            \"Name\":\"entityType\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"LC\"\n" + 
		     "            ]\n" + 
		     "         },\n" + 
		     "         {  \n" + 
		     "            \"Name\":\"trackingCode\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"productCode=B001F\"\n" + 
		     "            ]\n" + 
		     "         },\n" + 
		     "         {  \n" + 
		     "            \"Name\":\"Appoitment\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"[{\\\"category\\\":\\\"category1\\\",\\\"positionCode\\\":\\\"15\\\",\\\"positionDesc\\\":\\\"Directror\\\",\\\"appointmentDate\\\":\\\"12-11-2019\\\",\\\"personReference\\\":null,\\\"entityReference\\\":null},{\\\"category\\\":\\\"category2\\\",\\\"positionCode\\\":\\\"16\\\",\\\"positionDesc\\\":\\\"Directror2\\\",\\\"appointmentDate\\\":\\\"12-11-2019\\\",\\\"personReference\\\":null,\\\"entityReference\\\":null}]\"\n" + 
		     "            ]\n" + 
		     "         },\n" + 
 
		     "         {  \n" + 
		     "            \"Name\":\"businessConstitution\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"\"\n" + 
		     "            ]\n" + 
		     "         },\n" + 
		     "         {  \n" + 
		     "            \"Name\":\"DateOfBirth\",\n" + 
		     "            \"Contents\":[  \n" + 
		     "               \"2019-04-15\"\n" + 
		     "            ]\n" + 
		     "         }\n" + 
		     "      ]\n" + 
		     "   }}";
	//private final String request1 =
	  //    "{\"Application\":{\"ApplicationId\":\"e713e43e-7e0d-4273-add8-8ee181d39bcf\",\"ApplicationStatus\":\"WIP-Complete\",\"ProductCode\":\"BS001G\",\"ApplicationReferenceNo\":\"SG-2019-00113466-01\",\"InitiateDate\":\"2019-08-19T02:57:37.000Z\",\"ExpiredDate\":\"2019-08-26T02:57:37.000Z\",\"CompanyDetails\":{\"BasicDetails\":{\"ContactPerson\":\"MR MYINFO A\",\"Email\":\"veny12@sg.uob\",\"ContactNumber\":\"+6597399245\"},\"BusinessDetails\":{\"BusinessRegistrationNo\":\"532353888D\",\"RegisteredBusinessName\":\"CEILING VENTURE LIMITED\",\"EntityType\":\"B\",\"BusinessStatus\":\"Live\",\"PrimaryBusinessActivity\":\"Marine insurance\",\"SecondaryBusinessActivity\":\"Game arcade, online game aggregator, LAN game operators and gaming centres\",\"DateOfIncorporation\":\"1997-12-22T00:00:00.000Z\",\"CountryOfIncorporation\":\"SG\",\"BusinessOwnership\":\"Individual Shareholders only\",\"BusinessExpiryDate\":\"2023-08-29T00:00:00.000Z\",\"CompanyAddressList\":[{\"AddressType\":\"R\",\"AddressFormat\":null,\"Block\":\"5002\",\"StreetName\":\"ANG MO KIO AVENUE 5\",\"Floor\":\"4\",\"UnitNo\":\"5\",\"PostalCode\":\"569871\",\"IsSameAsRegisteredAddress\":null,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":\"SG\"},{\"AddressType\":\"M\",\"AddressFormat\":null,\"Block\":\"496B\",\"StreetName\":\"TAMPINES STREET 43\",\"Floor\":\"09\",\"UnitNo\":\"09\",\"PostalCode\":\"525496\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":\"SG\"}]},\"EntityDetails\":{\"PreviousBusinessDetails\":[{\"BusinessRegistrationNo\":\"T95LP9713E\",\"CompanyName\":\"Expose Publications LLP\",\"EffectiveDate\":\"1957-09-16T00:00:00.000Z\"},{\"BusinessRegistrationNo\":\"T97LP3034K\",\"CompanyName\":\"Jungle Publications LLP\",\"EffectiveDate\":\"1944-06-24T00:00:00.000Z\"},{\"BusinessRegistrationNo\":\"T67LP6684X\",\"CompanyName\":\"Navy Publications LLP\",\"EffectiveDate\":\"1915-06-15T00:00:00.000Z\"}],\"BusinessCapitalDetails\":[{\"BusinessType\":\"Ordinary Capital\",\"SharedAllottedAmount\":40000.0,\"Category\":\"Issued\",\"CapitalAmount\":40000.0,\"Currency\":\"SGD\"},{\"BusinessType\":\"Ordinary Capital\",\"SharedAllottedAmount\":40000.0,\"Category\":\"Paidup\",\"CapitalAmount\":40000.0,\"Currency\":\"SGD\"}],\"FinancialDetails\":[{\"FYStartDate\":\"2015-01-01T00:00:00.000Z\",\"FYEndDate\":\"2015-12-31T00:00:00.000Z\",\"IsAudited\":true,\"BusinessRevenue\":3.0E7,\"BusinessProfitLossBeforeTax\":1.0246729E7,\"BusinessProfitLossAfterTax\":7395620.0,\"GroupRevenue\":9.8E8,\"GroupCapitalPaidUpCapitalAmount\":1.0E7,\"GroupProfitLossBeforeTax\":2.17493017E8,\"GroupProfitLossAfterTax\":1.52749482E8,\"Currency\":\"SGD\"}],\"Grants\":[{\"GrantsType\":\"Global Company Partnership\",\"Status\":\"Approved\",\"FunctionalArea\":\"Global Company Partnership\",\"DevelopmentCategory\":\"Capability Development\",\"Amount\":5000.0,\"SubmittedDate\":\"2014-10-22T00:00:00.000Z\",\"LastUpdatedDate\":\"2016-06-17T00:00:00.000Z\"}]}},\"PrincipalList\":[{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Individual\",\"Name\":\"KRYSTIE LEE\",\"Email\":\"VENY12@SG.UOB\",\"ContactNo\":\"+6599999999\",\"Alias\":null,\"HanYuPinYinName\":null,\"HanYuPinYinAliasName\":null,\"MarriedName\":null,\"IdType\":\"NRIC\",\"IdNo\":\"S8809064J\",\"Gender\":null,\"MaritalStatus\":null,\"DateOfBirth\":null,\"CountryOfBirth\":null,\"CountryOfCitizenship\":null,\"PermanentResident\":\"False\",\"Category\":null,\"Currency\":null,\"ShareType\":null,\"ShareholderPercentage\":null,\"Allocation\":null,\"AppointmentDate\":null,\"OnlineCBSConsentDate\":null,\"Positions\":[{\"PositionType\":\"G\",\"ShareholdingPercentage\":null,\"Company\":null}],\"PersonalRegisteredAddress\":{\"AddressFormat\":null,\"Block\":null,\"Street\":null,\"buildingName\":null,\"StoreyNo\":null,\"UnitNo\":null,\"Country\":null,\"PostalCode\":null,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null},\"IncomeDetails\":[]}}],\"SupplementaryInfo\":[{\"Name\":\"residentialStatus\",\"Contents\":[\"C\"]},{\"Name\":\"buildingName\",\"Contents\":[\"Buiding JE\"]},{\"Name\":\"entityType\",\"Contents\":[\"BN\"]},{\"Name\":\"companyType\",\"Contents\":[\"\"]},{\"Name\":\"businessConstitution\",\"Contents\":[\"S\"]}]}}\n" + 
	    // "";

	
	 
	 
  @Value("json/bb-1.0.0.json")
  private Resource bbJson;

  @Test
  public void read() throws IOException {
    BasicInfo basicInfo = new BasicInfo();
    basicInfo.setAlternateNames(new AlternateNames());

    LendingApplicant lendingApplicant = new LendingApplicant();
    lendingApplicant.setAddresses(Arrays.asList(new OnlineFormAddress()));
    lendingApplicant.setBasicInfo(basicInfo);
    lendingApplicant.setNoaHistory(Arrays.asList(new Noa()));
    lendingApplicant.setPersonalInfo(new PersonalInfo());

    Business.Appointment businessAppointment = new Business.Appointment();
    businessAppointment.setEntityReference(new EntityReference());
    businessAppointment.setPersonReference(new PersonReference());

    Business business = new Business();
    business.setAddresses(Arrays.asList(new Business.Address()));
    business.setAppointments(Arrays.asList(businessAppointment));
    business.setBasicProfile(new Business.BasicProfile());
    business.setCapitals(Arrays.asList(new Business.Capital()));
    business.setFinancials(Arrays.asList(new Business.Financial()));
    business.setGrants(Arrays.asList(new Business.Grant()));
    business.setPreviousNames(Arrays.asList(new Business.PreviousName()));
    business.setPreviousUens(Arrays.asList(new Business.PreviousUen()));
    business.setShareholders(Arrays.asList(new Business.Shareholder()));

    LendingApplicationForm lendingApplicationForm = new LendingApplicationForm();
    lendingApplicationForm
        .setAdditionalAppointment(Arrays.asList(new AdditionalAppointment()));
    lendingApplicationForm.setEntity(business);
    lendingApplicationForm.setId("123");
    lendingApplicationForm.setIsKeymanApply(true);
    lendingApplicationForm.setPerson(Arrays.asList(lendingApplicant));
    lendingApplicationForm.setProduct(null);
    lendingApplicationForm.setReferenceNumber("123");
    lendingApplicationForm.setSourceType("123");

    System.err.println(new ObjectMapper().writeValueAsString(lendingApplicationForm));
  }

  @Test
  public void write() throws IOException {

    Map<String, String> mapperMap = new HashMap<String, String>();

    mapperMap.put("bb-1.0.0.json",
        new BufferedReader(new InputStreamReader(bbJson.getInputStream())).lines()
            .collect(Collectors.joining(System.lineSeparator())));
  	  ObjectMapper objMapperTest = ObjectMapperUtil.getObjectMapper();
     
    ObjectMapper objMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
            .configure(DeserializationFeature.READ_ENUMS_USING_TO_STRING, true)
            .configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false)
            .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
            .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
            .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
            .configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN,true)
            .registerModule(new JavaTimeModule());
    
    JsonMapper jsonMapper = new JsonMapper(objMapper, mapperMap);
    
    DocumentContext documentContext = JsonPath.using(Configuration.builder()
            .options(Option.SUPPRESS_EXCEPTIONS)
            .build())
            .parse(request);
    BrmApplication brmApplication =  BrmApplication.builder()
            .applicationId(documentContext.read("$.Application.ApplicationId"))
            .applicationReferenceNumber(
                documentContext.read("$.Application.ApplicationReferenceNo"))
            .productCode(documentContext.read("$.Application.ProductCode"))
            .companyDetails(documentContext.read("$.Application.CompanyDetails"))
            .principalList(documentContext.read("$.Application.PrincipalList"))
            .supplementaryInfo(documentContext.read("$.Application.SupplementaryInfo"))  
          .build();
          
    List<Map<String,Object>> personalDetails = JsonPath.parse(brmApplication.getPrincipalList()) .read("$..PersonalDetails");
    System.out.println("=====personalDetails===="+personalDetails + "BrmApplication****"+brmApplication.getApplicationReferenceNumber());
      
    Object principalList = JsonPath.parse(brmApplication.getPrincipalList()) .read("$..PersonalDetails[?(@.IsMainApplicant == true)]");
    if (principalList != null && ((List<Map<String, Object>>) principalList).iterator().hasNext())
         {
       
      Map<String, Object> mainApplicant = ((List<Map<String, Object>>) principalList).iterator().next();
      System.out.println("*******main applicant*****"+mainApplicant + "---size-------"+((List<Map<String, Object>>) principalList).size());	
      for (int i = 0; i <((List<Map<String, Object>>) principalList).size();i++) {
         
    	  Map<String, Object> lendingApplicant = (Map<String, Object>)(brmApplication).principalList.get(i);
    	  System.out.println("*********lendingApplicant*******"+lendingApplicant);
    	  if (((Map<String, Object>) lendingApplicant.get("PersonalDetails")).get("IdNo").equals(mainApplicant.get("IdNo"))) {
          
          	
          Map<String, Object> firstApplicant = (Map<String, Object>) brmApplication.principalList.get(0);
          System.out.println("*********firstApplicant*******"+firstApplicant);
          brmApplication.principalList.set(0, lendingApplicant);
          brmApplication.principalList.set(i, firstApplicant);

          break;
        }
      }
    }
    System.out.println("**********pricipalList*******"+brmApplication.principalList);
    
   for(Map<String,Object> PersonalDetails : personalDetails) {
    	/**boolean isMain = (Boolean)PersonalDetails.get("IsMainApplicant");
    	if(isMain == true) {
    		 System.out.println("=====isMain===="+isMain);
    	
    	} */
      	List<Map<String, Object>> incDetails = (List<Map<String, Object>>)PersonalDetails.get("IncomeDetails");
      	if(Objects.nonNull(incDetails))
    	    for(Map<String, Object> incObj : incDetails) {
    		 System.out.println(incObj.get("TaxClearenceIndicator"));
    	     if((Boolean)incObj.get("TaxClearenceIndicator") == true) {
    	    	// incObj.put("TaxClearenceIndicator", "Y");
    	    	 }
    	    	 else {
    	    		// incObj.put("TaxClearenceIndicator", "N");
    	    		}
   	        }
        }
     
    
    List<SupplementaryInfo> supplementaryInfoList  = brmApplication.getSupplementaryInfo();
    LendingApplicationForm lendingApplicationForm = jsonMapper.map("bb-1.0.0.json",
    		brmApplication, LendingApplicationForm.class);
    //lendingApplicationForm.setReferenceNumber(brmApplication.appl);
    for(int i=0;i<supplementaryInfoList.size();i++) {
    	 Map<String, Object> info = (Map<String, Object>)supplementaryInfoList.get(i);
         	 
    	 /** info.entrySet().forEach(action -> {
    		 System.out.println("===action key===="+action.getKey());
    		 System.out.println("===action.getValue()===="+action.getValue());
         List<Map<String, List<Integer>>> maps = new ArrayList<>();
        maps.add(map2);
        maps.forEach(map -> 
            map.forEach(
                (k, v) -> map1.merge(k, v, (l1, l2) -> {l1.addAll(l2); return l1;})
            )
        );
        map1.entrySet().forEach(System.out::println);
    }    
}
    	 	 
    	 });*/
    	 
    	 String name = (String) info.get("Name");
    	 List<String> contents = (List<String>) info.get("Contents");
  	   
    	  if(name.equalsIgnoreCase("residentialStatus")) 
     	  	lendingApplicationForm.findCurrentApplicant().getBasicInfo().setResidentialStatus(contents.get(0));
     	  	else if (name.equalsIgnoreCase("entityType"))
			   lendingApplicationForm.getEntity().getBasicProfile().setEntityType(contents.get(0));
     	   else if (name.equalsIgnoreCase("trackingCode"))
			   lendingApplicationForm.setSourceType(contents.get(0));
     	  	else if (name.equalsIgnoreCase("companyType"))
			   lendingApplicationForm.getEntity().getBasicProfile().setCompanyType(contents.get(0));
		   else if (name.equalsIgnoreCase("businessConstitution"))
			   lendingApplicationForm.getEntity().getBasicProfile().setBusinessConstitution(contents.get(0));
		   else if (name.equalsIgnoreCase("buildingName"))
			   lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null).setBuilding(contents.get(0));
		   else if (name.equalsIgnoreCase("CountryOfBirth"))
			   lendingApplicationForm.findCurrentApplicant().getPersonalInfo().setCountryOfBirth(contents.get(0));
		   else if (name.equalsIgnoreCase("propertyType"))
			   lendingApplicationForm.findCurrentApplicant().getAddresses().stream().filter(addrs->addrs.getType().equals("R")).findFirst().orElse(null).setPropertyType(contents.get(0));
		   else if (name.equalsIgnoreCase("DateOfBirth"))
			   lendingApplicationForm.findCurrentApplicant().getPersonalInfo().setDateOfBirth(getBirthDate(contents.get(0))); 
		   else if (name.equalsIgnoreCase("Appoitment"))
			   lendingApplicationForm.getEntity().setAppointments(SetAppointmentList(lendingApplicationForm,contents.get(0)));
    
    }
     System.err.println(new ObjectMapper().writeValueAsString(lendingApplicationForm));

  }

}

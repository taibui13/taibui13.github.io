package com.uob.pweb.businessbanking.lending.test;

import static org.junit.Assert.assertEquals;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.Strings;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;
import com.uob.pweb.businessbanking.lending.brm.BrmApplication;
import com.uob.pweb.businessbanking.lending.brm.SupplementaryInfo;
import com.uob.pweb.businessbanking.lending.form.Business.Appointment;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.OnlineFormAddress;
import com.uob.pweb.businessbanking.lending.specification.SpecificationService;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;

import com.uob.pweb.component.JsonMapper;
import com.uob.pweb.component.ObjectMapperUtil;
import com.uob.pweb.component.ObjectMapperBuilder.ObjectMapperConfig;

@RunWith(SpringRunner.class)
public class JsonBrmMapperTest {

	private final String result = "{\"ApplicationId\":null,\"ProductCode\":null,\"SourceType\":\"PWEB - MyInfo\",\"ApplicationStatus\":null,\"TrackingCode\":null,\"CompanyDetails\":{\"BasicDetails\":{\"ContactPerson\":\"MR MYINFO A\",\"Email\":\"myinfotesting@gmail.com\",\"ContactNumber\":\"+6597399245\"},\"BusinessDetails\":{\"BusinessRegistrationNo\":\"T14LP0063A\",\"RegisteredBusinessName\":\"Panel Consultancy Limited\",\"EntityType\":\"D\",\"BusinessStatus\":\"LIVE\",\"PrimaryBusinessActivity\":\"MANUFACTURE OF FURNITURE\",\"SecondaryBusinessActivity\":\"Fast Food Outlets, Food Courts and Food Kiosks\",\"DateOfIncorporation\":\"2010-07-13T00:00:00.000Z\",\"CountryOfIncorporation\":\"SG\",\"BusinessOwnership\":\"Individual Shareholders only\",\"BusinessExpiryDate\":null,\"CompanyAddressList\":[{\"AddressType\":\"R\",\"AddressFormat\":null,\"Block\":\"10\",\"StreetName\":\"Ubi Cresent\",\"Floor\":\"4\",\"UnitNo\":\"88\",\"PostalCode\":\"408564\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":\"SG\"},{\"AddressType\":\"R\",\"AddressFormat\":\"F\",\"Block\":null,\"StreetName\":null,\"Floor\":null,\"UnitNo\":null,\"PostalCode\":null,\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":\"\",\"AddressLine2\":\"\",\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":\"\"}]},\"EntityDetails\":{\"PreviousBusinessDetails\":[{\"BusinessRegistrationNo\":\"T65LP6344U\",\"CompanyName\":\"Mother Tailor\",\"EffectiveDate\":\"1967-04-02T00:00:00.000Z\"}],\"BusinessCapitalDetails\":[{\"BusinessType\":\"Preference Capital\",\"SharedAllottedAmount\":\"20000\",\"Category\":\"Paidup\",\"CapitalAmount\":\"20000\",\"Currency\":\"SGD\"}],\"FinancialDetails\":[{\"FYStartDate\":\"2015-01-01T00:00:00.000Z\",\"FYEndDate\":\"2015-12-31T00:00:00.000Z\",\"IsAudited\":true,\"BusinessRevenue\":30000000,\"BusinessProfitLossBeforeTax\":10246729,\"BusinessProfitLossAfterTax\":7395620,\"GroupRevenue\":0,\"GroupCapitalPaidUpCapitalAmount\":10000000,\"GroupProfitLossBeforeTax\":217493017,\"Currency\":\"SGD\",\"GroupProfitLossAfterTax\":0}],\"Grants\":[{\"GrantsType\":\"CDG Product Development (AIP)\",\"Status\":\"Approved\",\"FunctionalArea\":\"Automation/Equipment\",\"DevelopmentCategory\":\"International Expansion\",\"Amount\":2000,\"SubmittedDate\":\"2013-12-04T00:00:00.000Z\",\"LastUpdatedDate\":\"2018-03-16T00:00:00.000Z\"}]}},\"PrincipalList\":[{\"PersonalDetails\":{\"IsMainApplicant\":true,\"Type\":\"Individual\",\"Name\":\"MR MYINFO A\",\"Email\":\"myinfotesting@gmail.com\",\"ContactNo\":\"+6597399245\",\"Alias\":\"MYINFOALIAS E\",\"HanYuPinYinName\":\"\",\"HanYuPinYinAliasName\":\"ALIAS HANYUB\",\"MarriedName\":\"WATTNANASUPAN\",\"IdType\":\"NRIC\",\"IdNo\":\"S6005051A\",\"Gender\":\"M\",\"MaritalStatus\":\"M\",\"DateOfBirth\":\"1967-11-13T00:00:00.000Z\",\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\",\"PermanentResident\":false,\"Category\":\"1\",\"Currency\":\"SGD\",\"ShareType\":\"1\",\"ShareholderPercentage\":null,\"Allocation\":\"8000\",\"AppointmentDate\":\"2010-07-13T00:00:00.000Z\",\"OnlineCBSConsentDate\":null,\"Positions\":[{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null},{\"PositionType\":\"S\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}],\"PersonalRegisteredAddress\":{\"AddressFormat\":\"H\",\"Block\":\"288A\",\"Street\":\"JURONG EAST STREET 40\",\"BuildingName\":\"\",\"StoreyNo\":\"08\",\"UnitNo\":\"367\",\"Country\":\"SG\",\"PostalCode\":\"601288\",\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null},\"IncomeDetails\":[{\"YearlyAssessableIncomeInSGD\":\"5000.31\",\"YearOfAssessment\":\"2017\",\"TradeIncome\":\"0.00\",\"EmploymentIncome\":\"0.00\",\"RentalIncome\":\"0.00\",\"Currency\":\"SGD\",\"Category\":\"ORIGINAL\",\"TaxClearenceIndicator\":false},{\"YearlyAssessableIncomeInSGD\":\"0\",\"YearOfAssessment\":\"2015\",\"TradeIncome\":\"0.00\",\"EmploymentIncome\":\"0.00\",\"RentalIncome\":\"0.00\",\"Currency\":\"SGD\",\"Category\":\"ORIGINAL\",\"TaxClearenceIndicator\":false}]}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Individual\",\"Name\":\"TIMOTHY TAN CHENG GUAN\",\"IdType\":\"FN\",\"IdNo\":\"G9912374E\",\"Category\":\"Individual\",\"Currency\":\"SGD\",\"ShareType\":\"Ordinary Capital\",\"ShareholderPercentage\":null,\"Allocation\":12000,\"Positions\":[{\"PositionType\":\"G\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null},{\"PositionType\":\"S\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}],\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\"}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Non Individual\",\"Name\":\"TEST COMPANY\",\"IdType\":\"RC\",\"IdNo\":\"S6005051A\",\"Category\":\"Individual\",\"Currency\":\"SGD\",\"ShareType\":\"Ordinary Capital\",\"ShareholderPercentage\":null,\"Allocation\":12000,\"Positions\":[{\"PositionType\":\"G\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null},{\"PositionType\":\"S\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}],\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\"}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Non Individual\",\"Name\":\"TEST COMPANY 2\",\"IdType\":\"RC\",\"IdNo\":\"S6005051AA\",\"Category\":\"Individual\",\"Currency\":\"SGD\",\"ShareType\":\"Ordinary Capital\",\"ShareholderPercentage\":null,\"Allocation\":90000,\"Positions\":[{\"PositionType\":\"G\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null},{\"PositionType\":\"S\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}],\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\"}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Non Individual\",\"Name\":\"TEST COMPANY\",\"IdType\":\"RC\",\"IdNo\":\"S6005051A\",\"Category\":\"Individual\",\"Currency\":null,\"Positions\":[{\"PositionType\":\"G\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null},{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":\"TEST COMPANY\"}],\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\"}}],\"SupplementaryInfo\":[],\"ApplicationReferenceNumber\":null}";

	@Value("json/brm-0.13.json")
	private Resource brmJson;

	@Value("json/myinfo-biz-1.0.json")
	private Resource myinfobizJson;

	@Test
	public void read() throws IOException {

		JsonMapper jsonMapper = new JsonMapper(new ObjectMapper(), null);

		String brmJsonString = new BufferedReader(new InputStreamReader(brmJson.getInputStream())).lines()
				.collect(Collectors.joining(System.lineSeparator()));

		String myinfobizJsonString = new BufferedReader(new InputStreamReader(myinfobizJson.getInputStream())).lines()
				.collect(Collectors.joining(System.lineSeparator()));

		ObjectNode objectNode = (ObjectNode) new ObjectMapper().readTree(brmJsonString);

		jsonMapper.getNode(objectNode, JsonPath.parse(myinfobizJsonString));

		assertEquals(result, new ObjectMapper().writeValueAsString(objectNode));
	}

	@Test
	public void convert() throws IOException {
		new ObjectMapper().readValue("{'null':0}".replaceAll("'", "\""), Map.class);
	}

	@Test
	public void test() throws IOException {
		new ObjectMapper().readValue(result, BrmApplication.class);
	}

	@Test
	public void TestJson() throws IOException {
		List<Appointment> apmtList = new ArrayList<Appointment>();
		List<String> contents = new ArrayList<String>();
		LendingApplicationForm lendingApplicationForm = new LendingApplicationForm();
		Appointment apmt = new Appointment();
		apmt.setAppointmentDate("12-11-2019");
		apmt.setCategory("category1");
		apmt.setPositionCode("15");
		apmt.setPositionDesc("Directror");
		Appointment apmt1 = new Appointment();
		apmt1.setAppointmentDate("12-11-2019");
		apmt1.setCategory("category2");
		apmt1.setPositionCode("16");
		apmt1.setPositionDesc("Directror2");
		apmtList.add(apmt);
		apmtList.add(apmt1);
		ObjectMapperConfig objectMapperConfig = new ObjectMapperConfig();
		ObjectMapper objectMapper = new ObjectMapper()
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false)
				.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
				.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
				.configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
				.configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN, true)
				.setSerializationInclusion(objectMapperConfig.getInclude())
				.setPropertyNamingStrategy(objectMapperConfig.getPropertyNamingStrategy());

		String jsonString = objectMapper.writeValueAsString(apmtList);
		System.out.println("===apmtLst json====" + jsonString);
		contents.add(jsonString);
		// List<Appointment> ppl2 =
		// (List<Appointment>)(Arrays.asList(mapper.readValue(jsonString,
		// Appointment.class)));
		List<Appointment> alst = objectMapper.readValue(contents.get(0), new TypeReference<List<Appointment>>() {
		});
		System.out.println("==========json desrilization=====" + objectMapper.writeValueAsString(alst));
	}

	@Test
	public void write() throws IOException {
		SupplementaryInfo info = new SupplementaryInfo();
		List<SupplementaryInfo> supplementaryInfoList = new ArrayList<SupplementaryInfo>();
		List<Appointment> apmtList = new ArrayList<Appointment>();
		List<String> contents = new ArrayList<String>();
		LendingApplicationForm lendingApplicationForm = new LendingApplicationForm();

		ObjectMapper objMapper = ObjectMapperUtil.getObjectMapper();

		/**
		 * ObjectMapper objectMapper = new ObjectMapper()
		 * .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
		 * .configure(MapperFeature.DEFAULT_VIEW_INCLUSION, false)
		 * .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
		 * .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
		 * .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
		 * .configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN,true)
		 * .setSerializationInclusion(objectMapperConfig.getInclude())
		 * .setPropertyNamingStrategy(objectMapperConfig.getPropertyNamingStrategy());
		 */

		OnlineFormAddress onlineFormAddress = new OnlineFormAddress();
		onlineFormAddress.setPropertyType("131");
		
		Appointment apmt = new Appointment();
		apmt.setAppointmentDate("12-11-2019");
		apmt.setCategory("category1");
		apmt.setPositionCode("15");
		apmt.setPositionDesc("Directror");
		Appointment apmt1 = new Appointment();
		apmt1.setAppointmentDate("12-11-2019");
		apmt1.setCategory("category2");
		apmt1.setPositionCode("16");
		apmt1.setPositionDesc("Directror2");
		apmtList.add(apmt);
		apmtList.add(apmt1);
		String jsonString = objMapper.writer(SerializationFeature.INDENT_OUTPUT).writeValueAsString(apmtList);

		contents.add(jsonString);
		info.setName("Appoitment");
		info.setContents(contents);
		supplementaryInfoList.add(info);

		Map<String, String> mapperMap = new HashMap<String, String>();
		mapperMap.put("brm-0.13.json", new BufferedReader(new InputStreamReader(brmJson.getInputStream())).lines()
				.collect(Collectors.joining(System.lineSeparator())));

		JsonMapper jsonMapper = new JsonMapper(new ObjectMapper(), mapperMap);

		String myinfobizJsonString = new BufferedReader(new InputStreamReader(myinfobizJson.getInputStream())).lines()
				.collect(Collectors.joining(System.lineSeparator()));

		BrmApplication brmApplication = jsonMapper.map("brm-0.13.json",
				new ObjectMapper().readValue(myinfobizJsonString, Map.class), BrmApplication.class);
		brmApplication.setSupplementaryInfo(supplementaryInfoList);
		 
		List<Map<String,Object>> personalDetails = JsonPath.parse(brmApplication.getPrincipalList()) .read("$..PersonalDetails[?(@.IsMainApplicant == true)]");
		 for(Map<String,Object> PersonalDetails : personalDetails) {
			    @SuppressWarnings("unchecked")
				Map<String, Object>pra = (Map<String,Object>)PersonalDetails.get("PersonalRegisteredAddress");
			    pra.put("AddressFormat","HT");
			   }	              
	
		System.err.println(new ObjectMapper().writer(SerializationFeature.INDENT_OUTPUT).withDefaultPrettyPrinter()
				.writeValueAsString(brmApplication));
		assertEquals(result,
				new ObjectMapper().writer(SerializationFeature.INDENT_OUTPUT).writeValueAsString(brmApplication));

	}
}

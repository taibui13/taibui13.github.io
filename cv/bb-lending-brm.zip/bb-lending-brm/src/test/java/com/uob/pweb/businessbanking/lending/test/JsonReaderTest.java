package com.uob.pweb.businessbanking.lending.test;

import static org.junit.Assert.assertEquals;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import com.jayway.jsonpath.JsonPath;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {ApplicationTest.class})
public class JsonReaderTest {

  @Test
  public void testFilter() throws Exception {

    String json =
        "{\"CompanyAddressList\": [ { \"AddressType\": \"R\", \"AddressFormat\": \"Y\", \"Block\": \"221\", \"StreetName\": \"ABC\", \"Floor\": \"12\", \"UnitNo\": \"04\", \"PostalCode\": \"521445\", \"IsSameAsRegisteredAddress\": false, \"AddressLine1\": \"string\", \"AddressLine2\": \"string\", \"AddressLine3\": \"string\", \"AddressLine4\": \"string\", \"City\": \"string\", \"Country\": \"SG\" }, { \"AddressType\": \"M\", \"AddressFormat\": \"F\", \"Block\": \"string\", \"StreetName\": \"string\", \"Floor\": \"string\", \"UnitNo\": \"string\", \"PostalCode\": \"string\", \"IsSameAsRegisteredAddress\": false, \"AddressLine1\": \"BLK 522\", \"AddressLine2\": \"Unit No 1123\", \"AddressLine3\": \"string\", \"AddressLine4\": \"Andheri\", \"City\": \"Mumbai\", \"Country\": \"IND\" } ]}";

    List<Map<String, Object>> listMap = JsonPath.parse(json)
        .read("$.CompanyAddressList[?(@.AddressType == 'M')]");

    assertEquals(listMap.toString(),
        "[{\"AddressType\":\"M\",\"AddressFormat\":\"F\",\"Block\":\"string\",\"StreetName\":\"string\",\"Floor\":\"string\",\"UnitNo\":\"string\",\"PostalCode\":\"string\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":\"BLK 522\",\"AddressLine2\":\"Unit No 1123\",\"AddressLine3\":\"string\",\"AddressLine4\":\"Andheri\",\"City\":\"Mumbai\",\"Country\":\"IND\"}]");
  }

  @Test
  public void testAnd() throws Exception {

    String json =
        "{\"CompanyAddressList\": [ { \"AddressType\": \"R\", \"AddressFormat\": \"Y\", \"Block\": \"221\", \"StreetName\": \"ABC\", \"Floor\": \"12\", \"UnitNo\": \"04\", \"PostalCode\": \"521445\", \"IsSameAsRegisteredAddress\": false, \"AddressLine1\": \"string\", \"AddressLine2\": \"string\", \"AddressLine3\": \"string\", \"AddressLine4\": \"string\", \"City\": \"string\", \"Country\": \"SG\" }, { \"AddressType\": \"M\", \"AddressFormat\": \"F\", \"Block\": \"string\", \"StreetName\": \"string\", \"Floor\": \"string\", \"UnitNo\": \"string\", \"PostalCode\": \"string\", \"IsSameAsRegisteredAddress\": false, \"AddressLine1\": \"BLK 522\", \"AddressLine2\": \"Unit No 1123\", \"AddressLine3\": \"string\", \"AddressLine4\": \"Andheri\", \"City\": \"Mumbai\", \"Country\": \"IND\" } ]}";

    List<Map<String, Object>> listMap = JsonPath.parse(json)
        .read("$.CompanyAddressList[?(@.AddressType == 'M' && @.AddressFormat == 'F')]");

    assertEquals(listMap.toString(),
        "[{\"AddressType\":\"M\",\"AddressFormat\":\"F\",\"Block\":\"string\",\"StreetName\":\"string\",\"Floor\":\"string\",\"UnitNo\":\"string\",\"PostalCode\":\"string\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":\"BLK 522\",\"AddressLine2\":\"Unit No 1123\",\"AddressLine3\":\"string\",\"AddressLine4\":\"Andheri\",\"City\":\"Mumbai\",\"Country\":\"IND\"}]");
  }

  @Test
  public void testCurrent() throws Exception {

    String json =
        "{\"PrincipalList\":[{\"PersonalDetails\":{\"Name\":\"Sayed\",\"Email\":\"sayed122@GMAIL.COM\",\"ContactNo\":\"55884458\",\"Alias\":\"string\",\"HanYuPinYinName\":\"string\",\"HanYuPinYinAliasName\":\"string\",\"MarriedName\":\"string\",\"IdNo\":\"string\",\"Nric\":\"S5048335F\",\"Gender\":\"M\",\"MaritalStatus\":\"M\",\"DateOfBirth\":\"1987-06-08T00:00:00Z\",\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\",\"PermanentResident\":true,\"Category\":\"string\",\"Currency\":\"SGD\",\"ShareType\":\"string\",\"ShareholderPercentage\":\"string\",\"Allocation\":\"string\",\"AppointmentDate\":\"2019-05-23T13:34:00.000\",\"ApproveSignatory\":true,\"Positions\":[{\"PositionType\":\"AE\",\"ShareholdingPercentage\":\"20\",\"Company\":\"ABC Ltd\"},{\"PositionType\":\"PD\",\"ShareholdingPercentage\":\"30\",\"Company\":\"XYZ\"},{\"PositionType\":\"HB\",\"ShareholdingPercentage\":\"50\",\"Company\":\"TEST\"}],\"PersonalRegisteredAddress\":{\"AddressFormat\":\"Y\",\"Block\":\"112\",\"Street\":\"ABCD STREET\",\"buildingName\":\"TEST BUILDING\",\"StoreyNo\":\"25\",\"UnitNo\":\"123\",\"Country\":\"SG\",\"PostalCode\":\"558877\",\"AddressLine1\":\"string\",\"AddressLine2\":\"string\",\"AddressLine3\":\"string\",\"AddressLine4\":\"string\"},\"IncomeDetails\":[{\"YearlyAssessableIncomeInSGD\":\"1730000\",\"YearOfAssessment\":\"2018\",\"TradeIncome\":\"110000\",\"EmploymentIncome\":\"130000\",\"RentalIncome\":\"150000\",\"Currency\":\"SGD\",\"Category\":\"string\",\"TaxClearenceIndicator\":true}]}}]}";

    JsonPath.parse(json)
        .jsonString();
  }

}

package com.uob.pweb.businessbanking.lending.test;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.dsl.context.IntegrationFlowContext.IntegrationFlowRegistration;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.brm.BrmApplication;
import com.uob.pweb.businessbanking.lending.brm.BrmApplicationFlow;
import com.uob.pweb.businessbanking.lending.exception.GlobalExceptionHandlingFlow;
import com.uob.pweb.businessbanking.lending.form.Business;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.BasicInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.PersonalInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingValidator;
import com.uob.pweb.businessbanking.lending.form.flow.LendingApplicationFlow;
import com.uob.pweb.businessbanking.lending.form.flow.LendingVerificationFlow;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingIntegrationFlow;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;
import com.uob.pweb.component.EntityPersonResponse;

@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ApplicationTest.class, GlobalExceptionHandlingFlow.class,
    RequestLoggingIntegrationFlow.class, BrmApplicationFlow.class, MyInfoValidation.class,
    LendingVerificationFlow.class, LendingValidator.class})
@DirtiesContext
@TestPropertySource(
    properties = {"outbound.application.submit=http://localhost/application/submit"})
public class SubmitApplicationFlow {

  @Autowired
  private WebApplicationContext wac;

  @Autowired
  private IntegrationFlowContext integrationFlowContext;

  private MockRestServiceServer mockServer;

  private MockMvc mockMvc;

  private IntegrationFlowRegistration flowRegistration;

  @Mock
  LendingApplicationForm lendingApplicationForm;

  @Autowired
  private RestTemplate restTemplate;

  @Before
  public void setup() throws InvalidKeySpecException, NoSuchAlgorithmException,
      IOException, CertificateException {
    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
        .build();

    SecurityContextHolder.getContext()
        .setAuthentication(Authentication.builder()
            .lendingApplicationForm(LendingApplicationForm.builder()
                .id("123")
                .entity(Business.builder()
                    .build())
                .person(Arrays.asList(LendingApplicant.builder()
                    .basicInfo(BasicInfo.builder()
                        .legalId("123")
                        .build())
                    .personalInfo(PersonalInfo.builder()
                        .build())
                    .build()))
                .referenceNumber("312312312")
                .build())
            .businessInfo(new ObjectMapper().readValue(
                "{\"uen\":\"53235113D\",\"uinfin\":\"S6005052Z\",\"entityPerson\":{\"entity\":{\"basic-profile\":{\"entity-type\":\"BN\",\"business-expiry-date\":\"2022-07-29\",\"entity-status\":\"LIVE\",\"primary-activity-desc\":\"Renting and Leasing of Other Personal and Household Goods\",\"entity-name\":\"Certain Beauty Parlor\",\"registration-date\":\"2006-09-08\",\"primary-activity-code\":\"7729\",\"business-constitution\":\"P\",\"secondary-activity-code\":\"3099\",\"secondary-activity-desc\":\"Manufacture of Other Transport Equipment n.e.c.\",\"uen\":\"53235113D\"}},\"person\":{ \"name\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"TAN XIAO HUI\" }, \"sex\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"F\" }, \"nationality\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"dob\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"1958-05-17\" }, \"regadd\": { \"country\": \"SG\", \"unit\": \"128\", \"street\": \"BEDOK NORTH AVENUE 1\", \"lastupdated\": \"2016-03-11\", \"block\": \"548\", \"source\": \"1\", \"postal\": \"460548\", \"classification\": \"C\", \"floor\": \"09\", \"building\": \"\" }, \"email\": { \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"value\": \"test@gmail.com\" }, \"mobileno\": { \"code\": \"65\", \"prefix\": \"+\", \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"nbr\": \"97324992\" } }}}",
                EntityPersonResponse.class))
            .applicationForm(new ObjectMapper().readValue(
                "{\"ApplicationId\":null,\"ProductCode\":\"BP001G\",\"SourceType\":\"PWEB - MyInfo\",\"ApplicationStatus\":null,\"TrackingCode\":\"productCode=BB-BPL\",\"CompanyDetails\":{\"BasicDetails\":{\"ContactPerson\":\"WONG WAI MUN\",\"Email\":\"123123123@gmail.com\",\"ContactNumber\":\"6597399245\"},\"BusinessDetails\":{\"BusinessRegistrationNo\":\"S54422292S\",\"RegisteredBusinessName\":\"Level Press Limited\",\"EntityType\":\"F\",\"BusinessStatus\":\"LIVE\",\"PrimaryBusinessActivity\":\"Airport operation services\",\"SecondaryBusinessActivity\":\"Manufacture of cards, envelopes and stationery, unprinted\",\"DateOfIncorporation\":\"1990-03-15T00:00:00.000Z\",\"CountryOfIncorporation\":\"SG\",\"BusinessOwnership\":\"Both Individual and Corporate Entity Shareholders\",\"BusinessExpiryDate\":null,\"CompanyAddressList\":[{\"AddressType\":\"R\",\"AddressFormat\":\"L\",\"Block\":\"16\",\"StreetName\":\"Collyer Quay\",\"Floor\":\"30\",\"UnitNo\":\"1\",\"PostalCode\":\"049318\",\"IsSameAsRegisteredAddress\":false,\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null,\"City\":null,\"Country\":\"SG\"}]},\"EntityDetails\":{\"PreviousBusinessDetails\":[{\"BusinessRegistrationNo\":\"195735221O\",\"CompanyName\":\"Follow Press Limited\",\"EffectiveDate\":\"1977-03-11T00:00:00.000Z\"},{\"BusinessRegistrationNo\":\"195991101K\",\"CompanyName\":\"Banner Press Limited\",\"EffectiveDate\":\"1968-10-29T00:00:00.000Z\"},{\"BusinessRegistrationNo\":\"187256077T\",\"CompanyName\":\"Suntan Press Limited\",\"EffectiveDate\":\"1954-12-14T00:00:00.000Z\"},{\"BusinessRegistrationNo\":\"185450727U\",\"CompanyName\":\"Needle Press Limited\",\"EffectiveDate\":\"1948-10-16T00:00:00.000Z\"},{\"BusinessRegistrationNo\":\"180759913F\",\"CompanyName\":\"Rifle Press Limited\",\"EffectiveDate\":\"1933-05-18T00:00:00.000Z\"}],\"BusinessCapitalDetails\":[{\"BusinessType\":\"Others Capital\",\"SharedAllottedAmount\":300000,\"Category\":\"Issued\",\"CapitalAmount\":300000,\"Currency\":\"SGD\"},{\"BusinessType\":\"Treasury Shares\",\"SharedAllottedAmount\":200000,\"Category\":\"Issued\",\"CapitalAmount\":200000,\"Currency\":\"SGD\"},{\"BusinessType\":\"Ordinary Capital\",\"SharedAllottedAmount\":500000,\"Category\":\"Issued\",\"CapitalAmount\":500000,\"Currency\":\"SGD\"},{\"BusinessType\":\"Others Capital\",\"SharedAllottedAmount\":300000,\"Category\":\"Paidup\",\"CapitalAmount\":300000,\"Currency\":\"SGD\"},{\"BusinessType\":\"Treasury Shares\",\"SharedAllottedAmount\":200000,\"Category\":\"Paidup\",\"CapitalAmount\":200000,\"Currency\":\"SGD\"},{\"BusinessType\":\"Ordinary Capital\",\"SharedAllottedAmount\":500000,\"Category\":\"Paidup\",\"CapitalAmount\":500000,\"Currency\":\"SGD\"}],\"FinancialDetails\":[{\"FYStartDate\":\"2017-04-01T00:00:00.000Z\",\"FYEndDate\":\"2018-03-31T00:00:00.000Z\",\"IsAudited\":false,\"BusinessRevenue\":10000000,\"BusinessProfitLossBeforeTax\":7000000,\"BusinessProfitLossAfterTax\":5800000,\"GroupRevenue\":0,\"GroupCapitalPaidUpCapitalAmount\":0,\"GroupProfitLossBeforeTax\":0,\"Currency\":\"SGD\",\"GroupProfitLossAfterTax\":0},{\"FYStartDate\":\"2016-04-01T00:00:00.000Z\",\"FYEndDate\":\"2017-03-31T00:00:00.000Z\",\"IsAudited\":true,\"BusinessRevenue\":8000000,\"BusinessProfitLossBeforeTax\":5000000,\"BusinessProfitLossAfterTax\":3400000,\"GroupRevenue\":0,\"GroupCapitalPaidUpCapitalAmount\":0,\"GroupProfitLossBeforeTax\":0,\"Currency\":\"SGD\",\"GroupProfitLossAfterTax\":0}],\"Grants\":[{\"GrantsType\":\"Market Readiness Assistance\",\"Status\":\"Approved\",\"FunctionalArea\":\"Market Readiness Assistance\",\"DevelopmentCategory\":\"International Expansion\",\"Amount\":3000,\"SubmittedDate\":\"2014-05-24T00:00:00.000Z\",\"LastUpdatedDate\":\"2017-09-30T00:00:00.000Z\"}]}},\"PrincipalList\":[{\"PersonalDetails\":{\"IsMainApplicant\":true,\"Type\":\"Individual\",\"Name\":\"WONG WAI MUN\",\"Email\":\"123123123@gmail.com\",\"ContactNo\":\"6597399245\",\"Alias\":\"ALYSSA WONG WAI MUN\",\"HanYuPinYinName\":\"WANG WAI MUN\",\"HanYuPinYinAliasName\":\"ALYSSA WANG WAI MUN\",\"MarriedName\":\"\",\"IdType\":\"IC\",\"IdNo\":\"S9812380F\",\"Gender\":\"F\",\"MaritalStatus\":\"S\",\"DateOfBirth\":\"1988-10-06T00:00:00.000Z\",\"CountryOfBirth\":\"SG\",\"CountryOfCitizenship\":\"SG\",\"PermanentResident\":false,\"Category\":\"\",\"Currency\":\"\",\"ShareType\":\"\",\"ShareholderPercentage\":null,\"Allocation\":\"\",\"AppointmentDate\":\"2001-04-07T00:00:00.000Z\",\"OnlineCBSConsentDate\":null,\"Positions\":[{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}],\"PersonalRegisteredAddress\":{\"AddressFormat\":\"S\",\"Block\":\"18\",\"Street\":\"HAVELOCK ROAD\",\"BuildingName\":\"MINISTRY OF MANPOWER BUILDING\",\"StoreyNo\":\"\",\"UnitNo\":\"\",\"Country\":\"SG\",\"PostalCode\":\"059764\",\"AddressLine1\":null,\"AddressLine2\":null,\"AddressLine3\":null,\"AddressLine4\":null},\"IncomeDetails\":[{\"YearlyAssessableIncomeInSGD\":\"50400.00\",\"YearOfAssessment\":\"2017\",\"TradeIncome\":\"0.00\",\"EmploymentIncome\":\"50400.00\",\"RentalIncome\":\"0.00\",\"Currency\":\"SGD\",\"Category\":\"ORIGINAL\",\"TaxClearenceIndicator\":false},{\"YearlyAssessableIncomeInSGD\":\"50200.00\",\"YearOfAssessment\":\"2016\",\"TradeIncome\":\"0.00\",\"EmploymentIncome\":\"50200.00\",\"RentalIncome\":\"0.00\",\"Currency\":\"SGD\",\"Category\":\"ORIGINAL\",\"TaxClearenceIndicator\":false}]}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Individual\",\"Name\":\"ANDY LAU\",\"IdType\":\"IC\",\"IdNo\":\"S6005048A\",\"Category\":\"Individual\",\"Currency\":\"SGD\",\"ShareType\":\"Ordinary Capital\",\"ShareholderPercentage\":40,\"Allocation\":200000,\"Positions\":[{\"PositionType\":\"S\",\"ShareholdingPercentage\":\"40%\",\"EffectiveShareholding\":40,\"Company\":null}]}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Non Individual\",\"Name\":\"Score Global Inc\",\"IdType\":\"RC\",\"IdNo\":\"S28FC2994G\",\"Category\":\"Foreign Company\",\"Currency\":\"SGD\",\"ShareType\":\"Others Capital\",\"ShareholderPercentage\":60,\"Allocation\":300000,\"Positions\":[{\"PositionType\":\"S\",\"ShareholdingPercentage\":\"60%\",\"EffectiveShareholding\":60,\"Company\":null}]}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Individual\",\"Name\":\"YEE XIN MEI\",\"IdType\":\"IC\",\"IdNo\":\"S9912360E\",\"Category\":\"Individual\",\"Currency\":null,\"Positions\":[{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}]}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Individual\",\"Name\":\"THIS NAME CONTAINS ALPHABETS FOR TESTING ONLY MORE THAN 60 CHARS\",\"IdType\":\"IC\",\"IdNo\":\"S9912367B\",\"Category\":\"Individual\",\"Currency\":null,\"Positions\":[{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}]}},{\"PersonalDetails\":{\"IsMainApplicant\":false,\"Type\":\"Individual\",\"Name\":\"CLARISSA LIN JIN PING\",\"IdType\":\"IC\",\"IdNo\":\"S9812386E\",\"Category\":\"Individual\",\"Currency\":null,\"Positions\":[{\"PositionType\":\"D\",\"ShareholdingPercentage\":null,\"EffectiveShareholding\":null,\"Company\":null}]}}],\"ApplicationReferenceNumber\":null}",
                BrmApplication.class))
            .authorities(Arrays
                .asList(new SimpleGrantedAuthority(Authentication.BUSINESS_VERIFIED)))
            .build());

    LendingApplicationFlow lendingApplicationFlow = new LendingApplicationFlow();
    flowRegistration = this.integrationFlowContext
        .registration(lendingApplicationFlow.submitLendingApplication())
        .register();
  }

  @Test
  public void flowTest() throws Exception {

    this.mockServer = MockRestServiceServer.createServer(restTemplate);

    this.mockServer.expect(requestTo("http://localhost/application/submit"))
        .andExpect(method(HttpMethod.POST))
        .andRespond(withSuccess(
            "{ \"ResponseHeader\": { \"ResponseCode\": \"200\" }, \"ResponseBody\": { \"ApplicationId\": \"5cc10f82-e489-e911-a820-000d3aa06e62\", \"ApplicationReferenceNumber\": \"SG-2019-00047828-01\", \"ErrorMessage\": [] } } ",
            MediaType.APPLICATION_JSON));

    this.mockMvc.perform(post("/applications/123/submit").content(
        "{ \"additionalAppointment\":[ { \"legalId\":\"S9912360E\", \"name\":\"Yee Xin Mei\", \"emailAddress\":\"312312@412412.com\", \"mobileNumber\":\"+6594213111\" } ], \"entity\":{ \"addresses\":[ { \"format\":\"L\", \"type\":\"R\", \"standard\":\"D\", \"unitNo\":\"1\", \"street\":\"Collyer Quay\", \"block\":\"16\", \"postalCode\":\"049318\", \"floor\":\"30\", \"building\":\"Hitachi Tower\", \"city\":null, \"country\":\"SG\", \"line1\":null, \"line2\":null, \"line3\":null, \"line4\":null }, { \"type\":\"M\", \"unitNo\":\"3111\", \"street\":\"LORONG 2 TOA PAYOH\", \"block\":\"141\", \"postalCode\":\"311141\", \"floor\":\"3123\", \"building\":\"\", \"country\":\"SG\", \"city\":\"\", \"line1\":\"\", \"line2\":\"\", \"line3\":\"\", \"line4\":\"\" } ] }, \"person\":[ { \"basicInfo\":{ \"passportNumber\":null, \"passportExpiryDate\":null }, \"personalInfo\":{ \"maritalStatus\":\"S\" } } ] }")
        .contentType(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());

    this.mockServer.verify();

  }

  @After
  public void finish() {
    flowRegistration.destroy();
  }

}

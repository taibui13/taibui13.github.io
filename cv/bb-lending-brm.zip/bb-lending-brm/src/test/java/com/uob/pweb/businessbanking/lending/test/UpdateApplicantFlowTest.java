package com.uob.pweb.businessbanking.lending.test;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.dsl.context.IntegrationFlowContext.IntegrationFlowRegistration;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.pweb.businessbanking.lending.brm.BrmApplication;
import com.uob.pweb.businessbanking.lending.brm.BrmApplicationFlow;
import com.uob.pweb.businessbanking.lending.exception.GlobalExceptionHandlingFlow;
import com.uob.pweb.businessbanking.lending.form.Business;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.BasicInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicant.PersonalInfo;
import com.uob.pweb.businessbanking.lending.form.LendingApplicationForm;
import com.uob.pweb.businessbanking.lending.form.LendingValidator;
import com.uob.pweb.businessbanking.lending.form.flow.LendingApplicationFlow;
import com.uob.pweb.businessbanking.lending.form.flow.LendingVerificationFlow;
import com.uob.pweb.businessbanking.lending.security.Authentication;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingIntegrationFlow;
import com.uob.pweb.common.framework.myinfo.MyInfoValidation;
import com.uob.pweb.common.framework.myinfo.types.entity.EntityPersonResponse;

@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ApplicationTest.class, GlobalExceptionHandlingFlow.class,
    RequestLoggingIntegrationFlow.class, BrmApplicationFlow.class, MyInfoValidation.class,
    LendingVerificationFlow.class, LendingValidator.class})
@DirtiesContext
@TestPropertySource(
    properties = {"outbound.applicant.update=http://localhost/applicant/update"})
public class UpdateApplicantFlowTest {

  @Autowired
  private WebApplicationContext wac;

  @Autowired
  private IntegrationFlowContext integrationFlowContext;

  private MockRestServiceServer mockServer;

  private MockMvc mockMvc;

  private IntegrationFlowRegistration flowRegistration;

  @Mock
  LendingApplicationForm lendingApplicationForm;

  @Autowired
  private RestTemplate restTemplate;

  @Before
  public void setup() throws InvalidKeySpecException, NoSuchAlgorithmException,
      IOException, CertificateException {
    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
        .build();

    SecurityContextHolder.getContext()
        .setAuthentication(Authentication.builder()
            .lendingApplicationForm(LendingApplicationForm.builder()
                .id("123")
                .entity(Business.builder()
                    .build())
                .person(Arrays.asList(LendingApplicant.builder()
                    .basicInfo(BasicInfo.builder()
                        .legalId("123")
                        .build())
                    .personalInfo(PersonalInfo.builder()
                        .maritalStatus("S")
                        .build())
                    .build()))
                .build())
            .businessInfo(new ObjectMapper().readValue(
                "{\"uen\":\"53235113D\",\"uinfin\":\"S6005052Z\",\"entityPerson\":{\"entity\":{\"basic-profile\":{\"entity-type\":\"BN\",\"business-expiry-date\":\"2022-07-29\",\"entity-status\":\"LIVE\",\"primary-activity-desc\":\"Renting and Leasing of Other Personal and Household Goods\",\"entity-name\":\"Certain Beauty Parlor\",\"registration-date\":\"2006-09-08\",\"primary-activity-code\":\"7729\",\"business-constitution\":\"P\",\"secondary-activity-code\":\"3099\",\"secondary-activity-desc\":\"Manufacture of Other Transport Equipment n.e.c.\",\"uen\":\"53235113D\"}},\"person\":{ \"name\": { \"lastupdated\": \"2015-06-01\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"TAN XIAO HUI\" }, \"sex\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"F\" }, \"nationality\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"SG\" }, \"dob\": { \"lastupdated\": \"2016-03-11\", \"source\": \"1\", \"classification\": \"C\", \"value\": \"1958-05-17\" }, \"regadd\": { \"country\": \"SG\", \"unit\": \"128\", \"street\": \"BEDOK NORTH AVENUE 1\", \"lastupdated\": \"2016-03-11\", \"block\": \"548\", \"source\": \"1\", \"postal\": \"460548\", \"classification\": \"C\", \"floor\": \"09\", \"building\": \"\" }, \"email\": { \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"value\": \"test@gmail.com\" }, \"mobileno\": { \"code\": \"65\", \"prefix\": \"+\", \"lastupdated\": \"2017-12-13\", \"source\": \"4\", \"classification\": \"C\", \"nbr\": \"97324992\" } }}}",
                EntityPersonResponse.class))
            .applicationForm(BrmApplication.builder()
                .build())
            .authorities(Arrays
                .asList(new SimpleGrantedAuthority(Authentication.PARTNER_VERIFIED)))
            .build());

    LendingApplicationFlow lendingApplicationFlow = new LendingApplicationFlow();
    flowRegistration = this.integrationFlowContext
        .registration(lendingApplicationFlow.updateLendingApplication())
        .register();
  }

  @Test
  public void flowTest() throws Exception {

    this.mockServer = MockRestServiceServer.createServer(restTemplate);

    this.mockServer.expect(requestTo("http://localhost/applicant/update"))
        .andExpect(method(HttpMethod.POST))
        .andRespond(withSuccess(
            "{ \"ResponseHeader\": { \"ResponseCode\": \"200\" }, \"ResponseBody\": { \"ApplicationId\": \"5cc10f82-e489-e911-a820-000d3aa06e62\", \"ApplicationReferenceNumber\": \"SG-2019-00047828-01\", \"ErrorMessage\": [] } } ",
            MediaType.APPLICATION_JSON));

    this.mockMvc
        .perform(post("/applications/123")
            .content(
                new ObjectMapper().writeValueAsString(LendingApplicationForm.builder()
                    .person(Arrays.asList((LendingApplicant.builder()
                        .basicInfo(BasicInfo.builder()
                            .legalId("123")
                            .build())
                        .personalInfo(PersonalInfo.builder()
                            .maritalStatus("M")
                            .build())
                        .build())))
                    .build()))
            .contentType(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());

    this.mockServer.verify();

  }

  @After
  public void finish() {
    flowRegistration.destroy();
  }

}

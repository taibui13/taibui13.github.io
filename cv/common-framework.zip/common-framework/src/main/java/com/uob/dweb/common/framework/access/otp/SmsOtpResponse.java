package com.uob.dweb.common.framework.access.otp;

import lombok.Data;

@Data
public class SmsOtpResponse {
  
  private String prefix;
  private String requestIdentity;
}

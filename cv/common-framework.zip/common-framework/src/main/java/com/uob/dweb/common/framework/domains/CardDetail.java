package com.uob.dweb.common.framework.domains;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class CardDetail {

  private CardInformation cardInformation;
  private CustomerInformation customerInformation;
  private CustomerDetailedInformation customerDetailedInformation;
  private CustomerContactDetails customerContactDetails;

  /**
   * Dob pattern use ddMMyyyy
   * MobileNumber is max 10 digit
   */
  @JsonIgnore
  public boolean isDobAndMobileNumberMatched(LocalDate dob, String mobileNumber){
    if (this.customerDetailedInformation.getBirthDate() == null) {
      return false;
    }
    LocalDate bd = LocalDate.parse(this.customerDetailedInformation.getBirthDate(),
        DateTimeFormatter.ofPattern("ddMMyyyy"));
    return bd.equals(dob) && Stream.of(this.customerContactDetails.getAlertMobilePhoneNumber(),
        this.customerContactDetails.getPibMobilePhoneNumber(),
        this.customerContactDetails.getThreeDSMobilePhoneNumber())
        .anyMatch(n -> mobileNumber.equals(n));
  }

  public boolean isDobMatched(LocalDate dob){
    if (this.customerDetailedInformation.getBirthDate() == null) {
      return false;
    }
    LocalDate bd = LocalDate.parse(this.customerDetailedInformation.getBirthDate(),
        DateTimeFormatter.ofPattern("ddMMyyyy"));
    return bd.equals(dob);
  }

  public boolean isMobileNumberMatched(String mobileNumber){
    return Stream.of(this.customerContactDetails.getAlertMobilePhoneNumber(),
        this.customerContactDetails.getPibMobilePhoneNumber(),
        this.customerContactDetails.getThreeDSMobilePhoneNumber())
        .anyMatch(n -> mobileNumber.equals(n));
  }

  @JsonIgnore
  public boolean isValidCardTypeAndStatus(){

    // 00 - card status is OK,
    // allowing credit card (C) primary relationship code (P) and/or card type is CashPlus (P)
    return "00".equals(this.cardInformation.getCardStatus())
        && (("C".equals(this.cardInformation.getCardIndicator())
              && "P".equals(this.cardInformation.getRelationshipCode()))
                    || "P".equals(this.cardInformation.getCardIndicator()));
  }

  @JsonIgnore
  public boolean isValidCard() {
    return "00".equals(this.cardInformation.getCardStatus());
  }

  @JsonIgnore
  public String getLegalId(){
    return this.customerDetailedInformation.getLegalIdentity();
  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CardInformation {

    private String cardNumber;
    private String cardType;
    private String cardStatus;
    private String relationshipCode;
    private String cardIndicator;
    private String expiryDate;
    private String primaryAccountNumber;
    private String primaryAccountType;
    private String accountType;
    private String accountNumber;
    private String accountStatus;
    private String accountHoldCodeIndicator;
    private String accountSignatureCondition;
    private String issueDate;
    private String reasonCode;
    private String cardStatusCode;



  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerInformation {

    private String ichKey;
    private String userIdentity;
    private String cifNumber;
    private String userAccessMode;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerDetailedInformation {

    private String legalIdentity;
    private String legalIdentityType;
    private String legalIdentityCountry;
    private String firstName;
    private String lastName;
    private String salutation;
    private String birthDate;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerContactDetails {

    private String alertMobilePhoneNumber;
    private String pibMobilePhoneNumber;
    private String officeEmail;
    private String personalEmail;
    private String notificationEmail;
    private String threeDSMobilePhoneNumber;
    private String mobilePhoneNumber;

  }

}

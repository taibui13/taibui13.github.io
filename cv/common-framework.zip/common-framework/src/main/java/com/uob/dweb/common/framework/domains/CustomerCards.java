package com.uob.dweb.common.framework.domains;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.ObjectUtils;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class CustomerCards {

  public AccountInformation accountInformation;
  public AccountBalances accountBalances;
  public AccountProfile accountProfile;
  public CreditCardAccount creditCardAccount;

  @JsonIgnore
  public boolean accountNotNull() {
    return !ObjectUtils.isEmpty(this.creditCardAccount)
        && !ObjectUtils.isEmpty(this.accountInformation);
  }

  @JsonIgnore
  public boolean isNotAllowedCardType(String... cardTypes) {
    if (this.accountInformation == null) return true;
    return !Stream.of(cardTypes).anyMatch(p -> p.equals(this.accountInformation.accountType));
  }

  @JsonIgnore
  public boolean isNotAllowedProductType(String... productTypes) {
    if (this.accountInformation == null) return true;
    return Stream.of(productTypes).anyMatch(p -> p.equals(this.accountInformation.productType));
  }

  @JsonIgnore
  public boolean isNotAllowedCardStatus(String... statuses) {
    if (this.creditCardAccount == null) return true;
    return !Stream.of(statuses).anyMatch(p -> p.equals(this.creditCardAccount.cardStatus));
  }

  @JsonIgnore
  public boolean isNotPrimaryCard() {
    if (this.creditCardAccount == null) return true;
    return !"P".equals(this.creditCardAccount.relationshipCode);
  }

  @JsonIgnore
  public boolean isNotPersonalCard() {
    if (this.creditCardAccount == null) return true;
    return !"P".equals(this.creditCardAccount.cardCategory);
  }

  @JsonIgnore
  public boolean isNotAllowedBlockCodes(String... codes) {
    if (this.creditCardAccount == null) return true;
    return !Stream.of(codes).anyMatch(p -> p.equals(this.creditCardAccount.cardBlockCode));
  }

  @JsonIgnore
  public boolean isExpired() {
    if (this.creditCardAccount == null) return true;
    YearMonth expiry =
        YearMonth.parse(this.creditCardAccount.expiredDate, DateTimeFormatter.ofPattern("yyMM"));
    return expiry.isBefore(YearMonth.now());
  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class AccountInformation {
    public String accountNumber;
    public String currency;
    public String accountType;
    public String bankCode;
    public String productType;
    public String linkIndicator;
    public String accountName;

    public boolean isAllowedCardType(String... cardTypes) {
      return Stream.of(cardTypes).anyMatch(p -> p.equals(this.accountType));
    }

    public boolean isAllowedproductType(String... productTypes) {
      return Stream.of(productTypes).anyMatch(p -> p.equals(this.productType));
    }
  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class AccountBalances {

    public String availableBalance;
    public String ledgerBalance;
    public String accountBalance;
    public String linkedAssetsSummaryAmount;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class AccountProfile {

    public String relationshipCode;
    public String accountCode;
    public Boolean subAccount;
    public String accountPrimaryIndicator;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CreditCardAccount {

    public Boolean asset;
    public Boolean subAccount;
    public String cardNumber;
    public String relationshipCode;
    public String cardCategory;
    public String expiredDate;
    public String availableCash;
    public String lastStatementBalance;
    public String paymentDueDate;
    public String currentBalance;
    public String lastPaymentAmount;
    public String lastPaymentDate;
    public String creditLimit;
    public String accountResponseIndicator;
    public String customerCreditLine;
    public String customerAvailableCreditLine;
    public String cardStatus;
    public String cardBlockCode;
    public String linkAccountNumber;
    public String inactive;
    public String creditDebitIndicator;
    public String type;
    public String setPinRequired;
    public String cardPrevCardAction;
    public String paymentDueAmount;
    public String cardOpeningDate;
    public String cardIssueDate;
    public String availableInstallment;
    public String minimumPaymentAmount;

    public boolean isCardStatusAllowed(String... statuses) {
      return Stream.of(statuses).anyMatch(p -> p.equals(this.cardStatus));
    }

    public boolean isCardPrimary() {
      return "P".equals(this.relationshipCode);
    }

    public boolean isPersonalCard() {
      return "P".equals(this.cardCategory);
    }

    public boolean isAllowedBlockCodes(String... codes) {
      return Stream.of(codes).anyMatch(p -> p.equals(this.cardBlockCode));
    }

    public boolean isExpired() {
      YearMonth expiry = YearMonth.parse(this.expiredDate, DateTimeFormatter.ofPattern("yyMM"));
      return expiry.isBefore(YearMonth.now());
    }

  }

}

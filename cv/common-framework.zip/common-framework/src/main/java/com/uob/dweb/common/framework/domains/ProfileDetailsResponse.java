package com.uob.dweb.common.framework.domains;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class ProfileDetailsResponse {

  private CardInformation cardInformation;
  private CustomerInformation customerInformation;
  private CustomerDetailedInformation customerDetailedInformation;
  private CustomerContactDetails customerContactDetails;

  public String getLegalId(){
    return this.customerDetailedInformation.getLegalIdentity();
  }


  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CardInformation {

    private String cardNumber;
    private String cardType;
    private String cardStatus;
    private String relationshipCode;
    private String cardIndicator;
    private String expiryDate;
    private String primaryAccountNumber;
    private String primaryAccountType;
    private String accountType;
    private String accountNumber;
    private String accountStatus;
    private String accountHoldCodeIndicator;
    private String accountSignatureCondition;
    private String issueDate;
    private String reasonCode;
    private String cardStatusCode;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerInformation {

    private String ichKey;
    private String userIdentity;
    private String cifNumber;
    private String userAccessMode;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerDetailedInformation {

    private String legalIdentity;
    private String legalIdentityType;
    private String legalIdentityCountry;
    private String firstName;
    private String lastName;
    private String salutation;
    private String birthDate;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerContactDetails {

    private String alertMobilePhoneNumber;
    private String pibMobilePhoneNumber;
    private String officeEmail;
    private String personalEmail;
    private String notificationEmail;
    private String threeDSMobilePhoneNumber;
    private String mobilePhoneNumber;

  }

}

package com.uob.dweb.common.framework.exceptions;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import org.springframework.http.HttpStatus;

public class ApiRuntimeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  @Getter
  private HttpStatus httpStatus;

  @Getter
  private ErrorResponse errorResponse;

  public ApiRuntimeException(HttpStatus httpStatus) {
    this.httpStatus = httpStatus;
    this.errorResponse = new ErrorResponse();
  }

  public ApiRuntimeException(HttpStatus httpStatus, String errorCode, String errorMessage) {
    super(errorMessage);
    this.httpStatus = httpStatus;
    this.errorResponse = new ErrorResponse(errorCode, errorMessage);
  }

  @JsonInclude(Include.NON_NULL)
  public static class ErrorResponse {

    @Getter
    private String errorCode;
    @Getter
    private String errorMessage;

    public ErrorResponse() {}

    public ErrorResponse(String errorCode, String errorMessage) {
      this.errorCode = errorCode;
      this.errorMessage = errorMessage;
    }

  }

}
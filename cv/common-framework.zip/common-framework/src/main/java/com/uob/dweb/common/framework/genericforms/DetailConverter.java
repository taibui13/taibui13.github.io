package com.uob.dweb.common.framework.genericforms;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.persistence.AttributeConverter;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class DetailConverter implements AttributeConverter<Object, Blob> {
  
  @Override
  public Blob convertToDatabaseColumn(Object details) {
    try {
      ObjectMapper mapper = new ObjectMapper();
      byte[] detailAsBytes = mapper.writeValueAsBytes(details);
      Blob blob = new SerialBlob(detailAsBytes);
      return blob;
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    } catch (SerialException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }

  @Override
  public Object convertToEntityAttribute(Blob detail) {
    if (detail==null){
      return null;
    }
    try {
      ObjectMapper mapper = new ObjectMapper();
      int blobLength = (int) detail.length();
      byte[] detailBytes = detail.getBytes(1,blobLength);
      return mapper.readValue(detailBytes, Object.class);
    } catch (SQLException e) {
      e.printStackTrace();
    } catch (JsonParseException e) {
      e.printStackTrace();
    } catch (JsonMappingException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }


}

package com.uob.dweb.common.framework.genericforms;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class FormData {

  private List<CustomerCardInformation> customerCardInformation; //can apply multiple cards
  private CustomerLegalInformation customerLegalInformation;
  private CustomerContactInformation customerContactInformation;
  private CustomerIncomeDetail customerIncomeDetail;
  private String formId;
  private String channelId;
  private Boolean registered;
  private String customerCif;


  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerCardInformation {

    private String cardKeyId;
    private String cardNumber;
    private String cardType;
    private String cardOrg;
    private String cardDescription;
    private String cardTrackingCode;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerLegalInformation {

    private String legalId;
    private String legalIdType;
    private String legalIdCountry;
    private String firstName;
    private String lastName;
    private String salutation;
    private String birthDate;
    private String fullName;

  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerContactInformation {
    private String mobileNumber;
    private String emailAddress;
  }

  @Data
  @Builder(toBuilder = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class CustomerIncomeDetail {
    private String occupation;
    private String monthlyIncome;
    private String employName;
    private String employType;

  }

}

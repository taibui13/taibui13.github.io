package com.uob.dweb.common.framework.genericforms;

import java.util.Map;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author venct4
 *
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class FormRequest {
  
    @NotBlank
	private String formId;
	
	@Size(max=50)
	private String customerName;
	
	private String mobileNo;
	
	@Email
	private String email;
	
	private Map<String, String> formData;
	
	private Map<String, Object> notificationModel;

	private Map<String, String> emailAttachment;
	
}

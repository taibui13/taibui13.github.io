package com.uob.dweb.common.framework.genericforms;

public enum FormRequestStatus {
  INITIATED,
  UPDATED,
  SUBMITTED,
  PROCESSED,
  COMPLETED;
}

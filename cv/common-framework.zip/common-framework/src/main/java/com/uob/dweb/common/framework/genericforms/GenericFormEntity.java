package com.uob.dweb.common.framework.genericforms;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "TOLF_GENERIC_FORMS_SUBMISSION")
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class GenericFormEntity implements Serializable{

  @Transient
  @JsonIgnore
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator="system-uuid")
  @GenericGenerator(name="system-uuid",strategy = "uuid2")
  @Column(name="ID",length=50)
  private String id;

  @Column(name = "REFERENCE_NUMBER", length = 50)
  private String referenceNumber;

  @Column(name = "FORM_ID")
  private String formId;

  @JsonIgnore
  @Column(name = "CUST_NAME")
  private String customerName;
  
  @JsonIgnore
  @Column(name = "BRANCH")
  private String branch;

  @JsonIgnore
  @Column(name = "EMAIL")
  private String email;

  @JsonIgnore
  @Column(name = "MOBILE")
  private String mobileNo;

  @JsonIgnore
  @Column(name = "STATUS")
  @Enumerated(EnumType.STRING)
  private FormRequestStatus status;

  @JsonIgnore
  @Lob
  @Column(name = "FORM_DATA")
  @Convert(converter = DetailConverter.class)
  private Object formData;

  @JsonIgnore
  @Column(name = "CREATED_DT", nullable = false)
  @CreationTimestamp
  private LocalDateTime createdTime;

  @JsonIgnore
  @Column(name = "UPDATED_DT", nullable = false)
  @UpdateTimestamp
  private LocalDateTime updatedTime;
  
  @JsonIgnore
  @Column(name = "EXPIRY_DATE", nullable = true)
  private LocalDateTime expiryDate;

  @JsonIgnore
  @Transient
  private Map<String, Object> notificationModel;

  @JsonIgnore
  @Transient
  private Map<String, String> emailAttachment;

}

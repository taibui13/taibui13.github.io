package com.uob.dweb.common.framework.genericforms.config;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "form")
public class FormConfiguration {
  @JacksonXmlProperty(localName = "report")
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<Report> reports;
  @JacksonXmlProperty(isAttribute = true)
  private String id;
  @JacksonXmlProperty(localName = "reference-number-prefix")
  private String refNumberPrefix;
  @JacksonXmlProperty(localName = "report-display-ref-number")
  private String reportDisplayRefNumber;
  @JacksonXmlProperty(localName = "submission-ack")
  private SubmissionAck submissionAck;
  @JacksonXmlProperty(localName = "save-n-exit")
  private SaveAndExit saveAndExit;
  
  @JacksonXmlProperty(localName = "selected-branch-from")
  private MappingFrom mappingFrom;

  @Data
  public static class SubmissionAck {
    private Customer customer;
    private Internal internal;
  }

  @Data
  public static class Customer {
    private Email email;
  }
  
  @Data
  public static class Report {
    @JacksonXmlProperty(isAttribute = true)
    private String id;
    private String headers;
    private String frequencies;
    private String status;
    private Email email;
    private Timings timings;
    private String title;
  }

  @Data
  public static class Internal {
    private Email email;
  }

  @Data
  public static class Email {
    @JacksonXmlProperty(isAttribute = true)
    private String templateId;
    private String subject;
    private String recipients;
    @JacksonXmlProperty(isAttribute = true, localName = "selected-branch")
    private String emailToSelectedBranch;
    @JacksonXmlProperty(localName = "recipient-map-from")
    private FrequencyMappingFrom freqMapping;
  }

  @Data
  @JacksonXmlRootElement(localName = "selected-branch-from")
  public static class MappingFrom {
    @JacksonXmlProperty(isAttribute = true, localName = "form-key")
    private String formKey;
    @JacksonXmlProperty(localName = "entry")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<EntryMap> entryMap;
  }
  
  @Data
  @JacksonXmlRootElement(localName = "recipient-map-from")
  public static class FrequencyMappingFrom {
    @JacksonXmlProperty(isAttribute = true, localName = "form-key")
    private String formKey;
    @JacksonXmlProperty(localName = "entry")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<EntryMap> entryMap;
  }

  @Data
  public static class EntryMap {
    @JacksonXmlProperty(isAttribute = true)
    private String key;
    private String value;
  }

  @Data
  public static class Timings{
    @JacksonXmlProperty(isAttribute = true, localName = "multi-run")
    private boolean multiRun;
    @JacksonXmlProperty(localName = "daterange")
    private String dateRange;
    private Map<String, String> runs;
  }
  
  @Data
  public static class SaveAndExit {
	@JacksonXmlProperty(localName = "save-resume-validity-period")
	private String retrieveLinkValidity;
    private Email email;
  }
}

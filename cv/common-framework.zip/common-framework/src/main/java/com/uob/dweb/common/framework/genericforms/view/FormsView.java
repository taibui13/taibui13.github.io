package com.uob.dweb.common.framework.genericforms.view;

public class FormsView {

  /**
   * public view
   */
  public static class Public {
  }

  /**
   * private view
   */
  public static class Private {
  }

}

package com.uob.dweb.common.framework.integrations;

import java.nio.file.AccessDeniedException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uob.dweb.common.framework.exceptions.ApiRuntimeException;

import lombok.var;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class CommonIntegrationFlows {

  @Bean
  public IntegrationFlow globalErrorFlow() {
    return f -> f.<RuntimeException, Message<?>>transform(payload -> {
      if (payload.getCause() instanceof ApiRuntimeException) {
        var apiRuntimeException = (ApiRuntimeException) payload.getCause();
        log.error("Handled api exception - http status {} | error message : ",
            apiRuntimeException.getHttpStatus(), payload.getCause());
        return MessageBuilder.withPayload(apiRuntimeException.getErrorResponse())
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, apiRuntimeException.getHttpStatus())
            .build();
      } else if (payload.getCause() instanceof ConstraintViolationException) {
        var validationException = (ConstraintViolationException) payload.getCause();
        log.error("Handled ConstraintViolationException - http status {} | error message : ",
            HttpStatus.BAD_REQUEST, payload.getCause());
        var c = validationException.getConstraintViolations().iterator().next();
        return MessageBuilder
            .withPayload(new ApiRuntimeException.ErrorResponse("invalid.request",
                c.getPropertyPath().toString() + " " + c.getMessage()))
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.BAD_REQUEST).build();
      } else if (payload.getCause() instanceof AccessDeniedException) {
        return MessageBuilder
            .withPayload(
                new ApiRuntimeException.ErrorResponse("invalid.request", "forbidden access"))
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.FORBIDDEN).build();
      } else if (payload.getCause() instanceof HttpClientErrorException) {
        return MessageBuilder
            .withPayload(
                new ApiRuntimeException.ErrorResponse("invalid.request", "invalid.request"))
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.BAD_REQUEST).build();
      }
      log.error("Unhandled exception - http status {} | error message :",
          HttpStatus.INTERNAL_SERVER_ERROR, payload.getCause());
      SecurityContextHolder.clearContext();

      try {
        var apiRuntimeException = (ApiRuntimeException) payload.getCause();
        return MessageBuilder.withPayload(apiRuntimeException.getErrorResponse())
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.INTERNAL_SERVER_ERROR).build();
      } catch (Exception ex) {
        return MessageBuilder.withPayload(Strings.EMPTY)
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.INTERNAL_SERVER_ERROR).build();
      }
    });
  }
  
  @Bean
  public IntegrationFlow validator(Validator validator) {
    return f -> f.handle(m -> {
      var errors = validator.validate(m.getPayload());
      if (!CollectionUtils.isEmpty(errors)) {
        throw new ConstraintViolationException(errors);
      }
    });
  }
  
  @Bean
  public IntegrationFlow requestLoggingFlow() {
    return f -> f.handle(message -> {
      HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
          .getRequest();
      log.info("===========================incoming request details================================================");
      log.info("URI         : {}", message.getHeaders().get(HttpHeaders.REQUEST_URL));
      log.info("Method      : {}", message.getHeaders().get(HttpHeaders.REQUEST_METHOD));
      log.info("User-Agent  : {}", request.getHeader("User-Agent"));
      log.info("Request body: {}", message.getPayload());
      log.info("===================================================================================================");
    });
  }


}
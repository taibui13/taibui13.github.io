package com.uob.dweb.common.framework.logging;

import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Slf4j
@Component
public class RequestLoggingIntegrationFlow {
  @Bean
  public IntegrationFlow requestLoggingFlow() {
    return f -> f.handle(message -> {
      HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
          .getRequest();
      log.info("===========================incoming request details================================================");
      log.info("URI         : {}", message.getHeaders().get(HttpHeaders.REQUEST_URL));
      log.info("Method      : {}", message.getHeaders().get(HttpHeaders.REQUEST_METHOD));
      log.info("User-Agent  : {}", request.getHeader("User-Agent"));
      log.info("Request body: {}", message.getPayload());
      log.info("===================================================================================================");
    });
  }
}
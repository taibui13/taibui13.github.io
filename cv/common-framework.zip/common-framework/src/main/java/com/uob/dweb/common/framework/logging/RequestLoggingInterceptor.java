package com.uob.dweb.common.framework.logging;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

@Slf4j
public class RequestLoggingInterceptor implements ClientHttpRequestInterceptor {

  private boolean ignoreTraceError = false;

  private boolean printBodyRequest = true;

  private boolean printHeadersRequest = true;

  public RequestLoggingInterceptor() {}

  /**
   * Ignore any exception during trace progress.
   *
   * @param ignoreTraceError
   */
  public RequestLoggingInterceptor(boolean ignoreTraceError) {
    this.ignoreTraceError = ignoreTraceError;
  }

  /**
   *
   * @param ignoreTraceError  Ignore any exception during trace progress.
   * @param printHeadersRequest To print all headers in request, default is true.
   * @param printBodyRequest    To print body in request, default is true
   */
  public RequestLoggingInterceptor(boolean ignoreTraceError, boolean printHeadersRequest, boolean printBodyRequest) {
    this.ignoreTraceError = ignoreTraceError;
    this.printHeadersRequest = printHeadersRequest;
    this.printBodyRequest = printBodyRequest;
  }

  @Override
  public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
    traceRequest(request, body);
    ClientHttpResponse response = execution.execute(request, body);
    traceResponse(response);
    return response;
  }

  private void traceRequest(HttpRequest request, byte[] body) throws IOException {
    log.info("===========================request begin================================================");
    log.info("URI         : {}", request.getURI());
    log.info("Method      : {}", request.getMethod());

    if(printHeadersRequest) log.info("Headers     : {}", request.getHeaders() );
    if(printBodyRequest) log.info("Request body: {}", new String(body, "UTF-8"));

    log.info("==========================request end================================================");
  }

  private void traceResponse(ClientHttpResponse response) throws IOException {
    try(BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), "UTF-8"))) {
      StringBuilder inputStringBuilder = new StringBuilder();
      String line = bufferedReader.readLine();
      while (line != null) {
        inputStringBuilder.append(line);
        inputStringBuilder.append('\n');
        line = bufferedReader.readLine();
      }

      log.info("============================response begin==========================================");
      log.info("Status code : {}", response.getStatusCode());
      log.info("Status text : {}", response.getStatusText());
      log.info("Headers     : {}", response.getHeaders());
      log.info("Response body : {}", inputStringBuilder.toString());
      log.info("=======================response end=================================================");

    } catch(IOException ex) {
      log.error("Error in traceResponse ::", ex);
      if(!ignoreTraceError) throw ex;
    }
  }

  public void setIgnoreTraceError(boolean ignoreTraceError) {
    this.ignoreTraceError = ignoreTraceError;
  }

  public void setPrintBodyRequest(boolean printBodyRequest) {
    this.printBodyRequest = printBodyRequest;
  }

  public void setPrintHeadersRequest(boolean printHeadersRequest) {
    this.printHeadersRequest = printHeadersRequest;
  }

}
package com.uob.dweb.common.framework.notification;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class NotificationRequest {

	private List<EmailRequest> emails;

	@Data
	@Builder(toBuilder = true)
	@AllArgsConstructor
	@NoArgsConstructor
	public static class EmailRequest {
		@JsonProperty("recipients")
		private List<String> recipients;

		@JsonProperty("ccList")
		private List<String> ccList;

		@JsonProperty("bccList")
		private List<String> bccList;

		@JsonProperty("template")
		private String template;

		@JsonProperty("model")
		private Map<String, Object> model = new HashMap<String, Object>();

		@JsonProperty("attachments")
		private Map<String, String> attachmentFiles = new HashMap<String, String>();

		@Override
		public String toString() {
			return "EmailRequest [recipients=" + recipients + ", ccList=" + ccList + ", bccList=" + bccList
					+ ", template=" + template + ", model=" + model + ", hasAttachments="
					+ (!CollectionUtils.isEmpty(attachmentFiles)) + "]";
		}
	}

}

package com.uob.dweb.common.framework.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JsonViewSelector {

  @Autowired
  ObjectMapper objectMapper;

  public String applicationViewSelector(Class<?> view, Object payload) {
    try {
      return objectMapper.writerWithView(view).writeValueAsString(payload);

    } catch (JsonProcessingException e) {
      throw new RuntimeException("Unable to serialize object.");
    }
  }
}

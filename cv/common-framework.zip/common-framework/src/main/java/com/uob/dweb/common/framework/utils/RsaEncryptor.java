package com.uob.dweb.common.framework.utils;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.Cipher;
import lombok.var;

public class RsaEncryptor {

  public static KeyPair generateKeyPair(){
    try {
      final var keyGen = KeyPairGenerator.getInstance("RSA");
      keyGen.initialize(2048);
      return keyGen.generateKeyPair();
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException(e);
    }
  }

  public static byte[] encrypt(String data, PublicKey publicKey) {
    try{
      var cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      cipher.init(Cipher.ENCRYPT_MODE, publicKey);
      return cipher.doFinal(data.getBytes());
    }catch (Exception e){
      throw new IllegalArgumentException("Decrypt failed!", e);
    }

  }

  public static byte[] decrypt(byte[] data, PrivateKey privateKey) {
    try {
      var cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      cipher.init(Cipher.DECRYPT_MODE, privateKey);
      return cipher.doFinal(data);
    } catch (Exception e) {
      throw new IllegalArgumentException("Decrypt failed!", e);
    }
  }

}

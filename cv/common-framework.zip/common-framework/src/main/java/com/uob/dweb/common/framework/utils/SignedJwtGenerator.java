package com.uob.dweb.common.framework.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStore.PrivateKeyEntry;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

@Component
public class SignedJwtGenerator {

  @Value("${digibank.service.keystore.path}")
  String keyPath;
  @Value("${digibank.service.keystore.alias}")
  String alias;
  @Value("${digibank.service.clientKey}")
  String clientKey;

  private JWSSigner signer;

  @PostConstruct
  public void init() throws Exception {
    InputStream keystoreFile = null;
    try {
      String storePassStr = clientKey;
      KeyStore keystore = KeyStore.getInstance("PKCS12");
      keystoreFile = new FileInputStream(keyPath);
      keystore.load(keystoreFile, storePassStr.toCharArray());
      PrivateKeyEntry entry = (PrivateKeyEntry) keystore.getEntry(alias,
          new KeyStore.PasswordProtection(storePassStr.toCharArray()));
      signer = new RSASSASigner(entry.getPrivateKey());
    } finally {
      if (keystoreFile != null) {
        keystoreFile.close();
      }
    }
  }

  public String generate(String template) throws JOSEException {
    JWTClaimsSet claims = new JWTClaimsSet.Builder().issuer("PWEB").subject(template).build();
    SignedJWT signedJWT = new SignedJWT(new JWSHeader(JWSAlgorithm.RS512), claims);
    signedJWT.sign(signer);
    return signedJWT.serialize();
  }
}

package com.uob.dweb.common.framework.validation.constaints;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.util.CollectionUtils;

public class EnumListValidatorImpl implements ConstraintValidator<EnumerationList, List<String>> {

  List<String> valueList = null;

  @Override
  public boolean isValid(List<String> values, ConstraintValidatorContext context) {
    if (CollectionUtils.isEmpty(values)) {return false;}
    return values.stream().allMatch(value -> valueList.contains(value.toUpperCase()));
  }

  @Override
  public void initialize(EnumerationList constraintAnnotation) {
    valueList = new ArrayList<String>();
    Class<? extends Enum<?>> enumClass = constraintAnnotation.enumClass();

    @SuppressWarnings("rawtypes")
    Enum[] enumValArr = enumClass.getEnumConstants();

    for(@SuppressWarnings("rawtypes")
        Enum enumVal : enumValArr) {
      valueList.add(enumVal.toString().toUpperCase());
    }

  }

}
package com.uob.dweb.common.framework.validation.files;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.integration.http.multipart.UploadedMultipartFile;

public class FileUploadValidation {
  public static Boolean verifyFileType(UploadedMultipartFile file) throws IOException {
    return file.getContentType().equalsIgnoreCase(getFileType(file.getInputStream()));
  }

  public static String getFileType(InputStream is) throws IOException {
    if (!is.markSupported()) return null;

    is.mark(16);
    int c1 = is.read();
    int c2 = is.read();
    int c3 = is.read();
    int c4 = is.read();
    int c5 = is.read();
    int c6 = is.read();
    int c7 = is.read();
    int c8 = is.read();
    is.reset();

    if (c1 == 137 && c2 == 80 && c3 == 78 && c4 == 71 && c5 == 13 && c6 == 10 && c7 == 26
        && c8 == 10) {
      return "image/png";
    }

    if (c1 == 0xFF && c2 == 0xD8 && c3 == 0xFF) {
      return "image/jpeg";
    }

    if (c1 == 37 && c2 == 80 && c3 == 68 && c4 == 70) {
      return "application/pdf";
    }

    return null;
  }

}

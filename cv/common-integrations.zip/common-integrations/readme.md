Account enquiry
Cards enquiry - done
Otp - wip
Party - done

Register Cif
Register pib

Reset password

Validate Pib card pin
Validate Pib status
Validate Pib username


/api/sg/services/v1/access/sendotp
                /v1/access/verifyotp
                /v1/access/recaptcha/validatetoken
                /v1/parties
                /v1/parties/{cif}/accounts
                /v1/notification
                /v1/cards/{cardnumber}/details -> /v1/cards
                /v1/cards/{cardnumber|/validatepin -> /v1/party

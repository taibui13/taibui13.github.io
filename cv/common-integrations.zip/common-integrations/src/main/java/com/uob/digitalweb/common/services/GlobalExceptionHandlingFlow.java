package com.uob.digitalweb.common.services;

import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;

import com.uob.pweb.common.framework.exception.ApiRuntimeException;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class GlobalExceptionHandlingFlow {

  @Bean
  public IntegrationFlow globalExceptionHandler() {
    return f -> f.<RuntimeException, Message<?>>transform(payload -> {

      if (payload.getCause() instanceof ApiRuntimeException) {
        ApiRuntimeException apiRuntimeException = (ApiRuntimeException) payload.getCause();
        log.error("Handled api exception - http status {} | error message : ",
            apiRuntimeException.getHttpStatus(), apiRuntimeException.getErrorResponse());

        return MessageBuilder.withPayload(apiRuntimeException.getErrorResponse())
            .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, apiRuntimeException.getHttpStatus())
            .build();
      }
      
      if (payload.getCause() instanceof MessagingException) {
        if (((MessagingException) payload).getRootCause() instanceof ApiRuntimeException) {
          ApiRuntimeException apiRuntimeException =
              (ApiRuntimeException) ((MessagingException) payload).getRootCause();
          log.error("Handled api exception - http status {} | error message : ",
              apiRuntimeException.getHttpStatus(), apiRuntimeException);

          return MessageBuilder.withPayload(apiRuntimeException.getErrorResponse())
              .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, apiRuntimeException.getHttpStatus())
              .build();
        }
      }

      log.error("unhandled exception - http status {} | error message : {}",
          HttpStatus.INTERNAL_SERVER_ERROR, payload.getCause());

      return MessageBuilder.withPayload(Strings.EMPTY)
          .setHeaderIfAbsent(HttpHeaders.STATUS_CODE, HttpStatus.INTERNAL_SERVER_ERROR).build();
    });
  }
}
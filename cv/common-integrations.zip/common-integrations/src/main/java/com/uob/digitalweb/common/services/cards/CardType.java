package com.uob.digitalweb.common.services.cards;

/**
 * Card Types
 * 
 * @author Adrian Chia
 *
 */
public enum CardType {
  ATM,
  VSA,
  RBK,
  ID;
}

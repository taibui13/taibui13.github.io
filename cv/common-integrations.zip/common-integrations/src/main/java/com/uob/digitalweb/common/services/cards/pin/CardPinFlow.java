package com.uob.digitalweb.common.services.cards.pin;

import javax.validation.Validator;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.dsl.Http;
import org.springframework.web.client.RestTemplate;

import com.uob.pweb.common.framework.exception.ApiRuntimeException;

@Configuration
public class CardPinFlow {

  @Bean
  public IntegrationFlow cardPinValidationFlow(
      @Value("${service-url.validate-cardpin}") String validateCardPinUrl,
      RestTemplate restTemplate, Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/card/verifypin")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(CardPinRequest.class)
            .errorChannel("globalExceptionHandler.input"))
        .filter(CardPinRequest.class, p -> validator.validate(p).isEmpty(),
            e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", "Please provide all the mandatory Fields");
            })))
        .log(Level.INFO, m -> "start - card pin validation flow ")
        .wireTap("requestLoggingFlow.input")
        .<CardPinRequest, CardPinIntegrationRequest>transform(p -> new CardPinIntegrationRequest(p))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(validateCardPinUrl, restTemplate)
                .httpMethod(HttpMethod.POST)
                .mappedRequestHeaders(HttpHeaders.CONTENT_TYPE)
                .expectedResponseType(CardPinIntegrationResponse.class))
        .filter(CardPinIntegrationResponse.class, p -> (!p.isError()), //need to check PIB error code in case of invalid PIN
            e -> e.discardFlow(flow -> flow.<CardPinIntegrationResponse>handle((p,h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",  p.getResponse());
            })))
        .transform(p -> Strings.EMPTY)
        .get();
  }
}

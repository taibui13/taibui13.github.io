package com.uob.digitalweb.common.services.cards.pin;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.digitalweb.common.services.cards.CardType;

import lombok.Data;

@Data
public class CardPinIntegrationRequest {

  @JsonProperty("serviceRequestHeader")
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

  @JsonProperty("doValidateCardPinRequestBody")
  private RequestBody body = new RequestBody ();


  public CardPinIntegrationRequest(CardPinRequest cardPinRequest){

    EncryptionInformation encryptionInformation = new EncryptionInformation ();
    encryptionInformation.setEncryptedPassword(cardPinRequest.getEncryptedNewPassword());
    encryptionInformation.setKeyIndex(String.format("%04d", Integer.parseInt(cardPinRequest.getKeyIndex())));
    encryptionInformation.setRandomAccessNumber(cardPinRequest.getRandomAccessNumber());
    encryptionInformation.setEncodingParameter(cardPinRequest.getEncodingParameter());

    CustomerInformation customerInformation = new CustomerInformation();
    customerInformation.setCifnumber(cardPinRequest.getCifNumber());

    CustomerLegalInformation customerLegalInformation = new CustomerLegalInformation();
    customerLegalInformation.setLegalIdentity(cardPinRequest.getLegalId());
    customerLegalInformation.setLegalIdentityType(cardPinRequest.getLegalType());
    customerLegalInformation.setLegalIdentityCountry(cardPinRequest.getLegalCountry());

    body.setEncryptionInformation(encryptionInformation);
    body.setCustomerInformation(customerInformation);
    body.setCustomerLegalInformation(customerLegalInformation);
    body.setCardNumber(cardPinRequest.getCardnumber());
    body.setCardType(cardPinRequest.getCardType());
  }

  @Data
  public static class RequestBody {
    
    @JsonProperty("cardNumber")
    private String cardNumber;

    @JsonProperty("cardType")
    private CardType cardType;

    @JsonProperty("track2Data")
    private String track2Data;

    @JsonProperty("encryptionInformation")
    private EncryptionInformation encryptionInformation;

    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
    
    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;

  }

  @Data
  public static class EncryptionInformation {

    @JsonProperty("encryptedPassword")
    private String encryptedPassword;
    @JsonProperty("pinReferenceNo")
    private String pinReferenceNo;
    @JsonProperty("publicKeyIndex")
    private String keyIndex;
    @JsonProperty("randomAccessNumber")
    private String randomAccessNumber;
    @JsonProperty("encodingParameter")
    private String encodingParameter;

  }

  @Data
  public static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cifnumber;
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class CustomerLegalInformation {

      @JsonProperty("legalIdentity")
      private String legalIdentity;
      @JsonProperty("legalIdentityType")
      private String legalIdentityType;
      @JsonProperty("legalIdentityCountry")
      private String legalIdentityCountry;

    }

    @Data
    public static class RequesterContext {

      @JsonProperty("applicationCode")
      private String applicationCode = "WSM";
      @JsonProperty("applicationSubCode")
      private String applicationSubCode = "OAO";
      @JsonProperty("countryCode")
      private String countryCode;
      @JsonProperty("requesterReferenceNumber")
      private String requesterReferenceNumber;
      @JsonProperty("requestTimeInGMT")
      private String requestTimeInGMT;
      @JsonProperty("requesterUserIdentity")
      private String requesterUserIdentity;
      @JsonProperty("userIPAddress")
      private String userIPAddress;
      @JsonProperty("userIPAddressPortNumber")
      private String userIPAddressPortNumber;
      @JsonProperty("sessionIdentity")
      private String sessionIdentity;


    }

    @Data
    public static class ServiceContext {

      @JsonProperty("serviceVersionNumber")
      private String serviceVersionNumber = "2.0";

    }

    @Data
    public static class ServiceRequestHeader {

      @JsonProperty("requesterContext")
      private RequesterContext requesterContext = new RequesterContext();
      @JsonProperty("serviceContext")
      private ServiceContext serviceContext = new ServiceContext();
    }

  }


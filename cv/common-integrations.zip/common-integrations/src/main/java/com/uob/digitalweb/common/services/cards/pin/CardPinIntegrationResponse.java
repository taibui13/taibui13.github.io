package com.uob.digitalweb.common.services.cards.pin;

import java.util.StringJoiner;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CardPinIntegrationResponse {

  @JsonProperty("serviceResponseHeader")
  private ServiceResponseHeader serviceResponseHeader;
  @JsonProperty("doValidateCardPinResponseBody")
  private ResponseBody body;
  
  public boolean isError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }

  public String getResponse() {
    return new StringJoiner("-").add(serviceResponseHeader.getResponseContext().getResponseCode())
        .add(serviceResponseHeader.getResponseContext().getResponseDescription()).toString();
  }
  
  @Data
  public static class ResponseContext {

    @JsonProperty("responseCode")
    private String responseCode;
    @JsonProperty("responseDescription")
    private String responseDescription;
    @JsonProperty("serviceResponseTimeInGMT")
    private String serviceResponseTimeInGMT;
    
  }

  @Data
  public static class ServiceResponseHeader {

    @JsonProperty("responseContext")
    private ResponseContext responseContext;
    @JsonProperty("responseContext")
    public ResponseContext getResponseContext() {
      return responseContext;
    }

  }

  @Data
  public static class ResponseBody {

  }
}

package com.uob.digitalweb.common.services.cards.pin;


import javax.validation.constraints.NotNull;

import com.uob.digitalweb.common.services.cards.CardType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor @AllArgsConstructor
public class CardPinRequest {

  @NotNull
  private String cardnumber;
  @NotNull
  private String encryptedNewPassword;
  @NotNull
  private String keyIndex;
  @NotNull
  private String randomAccessNumber;
  @NotNull
  private String encodingParameter;
  @NotNull
  private String cifNumber;
  @NotNull
  private String legalType;
  @NotNull
  private String legalId;
  @NotNull
  private String legalCountry;

  public CardType getCardType() {
    if (cardnumber.length() == 8) {
      return CardType.ATM;
    }
    return CardType.RBK;
  }

}


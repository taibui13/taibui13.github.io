package com.uob.digitalweb.common.services.customer.accounts;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.dsl.Http;
import org.springframework.web.client.RestTemplate;

import com.uob.pweb.common.framework.exception.ApiRuntimeException;

@Configuration
public class CustomerAccountsFlow {
  @Bean
  public IntegrationFlow getCustomerAccounts(
      @Value("${service-url.accounts-enquiry}") String accountEnquiryUrl, RestTemplate restTemplate,
      Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/customer/{cifnumber}/accounts")
            .requestMapping(m -> m.methods(HttpMethod.GET))
            .payloadExpression("#pathVariables.cifnumber")
            .errorChannel("globalExceptionHandler.input"))
        .log(Level.INFO, m -> "start - retrieving customer's accounts")
        .<String, CustomerAccountsIntegrationRequest>transform(p -> new CustomerAccountsIntegrationRequest(p))
        .wireTap("requestLoggingFlow.input")
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(accountEnquiryUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(CustomerAccountsIntegrationResponse.class))
        .filter(CustomerAccountsIntegrationResponse.class, p -> !p.isError(),
            e -> e.discardFlow(f -> f. <CustomerAccountsIntegrationResponse>handle((p,h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", p.getResponse());})))
        .transform(CustomerAccountsIntegrationResponse.class, p -> p.getCusomerAccounts())
        .get();
  }
}
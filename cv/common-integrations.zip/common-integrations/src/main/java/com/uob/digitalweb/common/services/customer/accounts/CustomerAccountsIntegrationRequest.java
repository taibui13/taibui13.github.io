package com.uob.digitalweb.common.services.customer.accounts;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.domains.CardType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(includeFieldNames = true)
public class CustomerAccountsIntegrationRequest {
  
  @JsonProperty("serviceRequestHeader")
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

  @JsonProperty("getCustomerAccountListRequestBody")
  private RequestBody body = new RequestBody();

  public CustomerAccountsIntegrationRequest(String cif) {
    CustomerInformation customerInformation = new CustomerInformation();
    customerInformation.setCIFNumber(cif);
    body.setCustomerInformation(customerInformation);
  }

  @Data
  public static class RequestBody {

    @JsonProperty("customerAssociationInformation")
    private CustomerAssociationInformation customerAssociationInformation;

    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;

    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
  }

  @Data
  public static class CustomerAssociationInformation {

    @JsonProperty("cardNumber")
    private String cardNumber;
    @JsonProperty("cardType")
    private CardType cardType;
    @JsonProperty("PibCxIntId")
    private String PibCxIntId;
  }

  @Data
  public static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cIFNumber;
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @Data
  public static class CustomerLegalInformation {
    @JsonProperty("legalIdentity")
    private String legalIdentity;
    @JsonProperty("legalIdentityType")
    private String legalIdentityType;
    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;
  }
  
  @Data
  public class RequesterContext {
    @JsonProperty("applicationCode")
    private String applicationCode = "WSM";
    @JsonProperty("applicationSubCode")
    private String applicationSubCode = "OAO";
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
  }

  @Data
  public class ServiceContext {
    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber = "2.0";
  }

  @Data
  public class ServiceRequestHeader {
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext = new RequesterContext();
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext = new ServiceContext();

  }
}
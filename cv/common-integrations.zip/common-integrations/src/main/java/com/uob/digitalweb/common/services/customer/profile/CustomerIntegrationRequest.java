package com.uob.digitalweb.common.services.customer.profile;

import com.uob.digitalweb.common.services.cards.CardType;

import com.uob.pweb.common.framework.domains.PartySearchRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerIntegrationRequest {


  private RequestBody getCustomerDetailsRequestBody = new RequestBody();

  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

  private CustomerIntegrationRequest(CardInformation cardInformation) {
    CustomerLegalInformation customerLegalInformation = new CustomerLegalInformation();
    customerLegalInformation.setLegalIdentity(cardInformation.getLegalIdentity());
    customerLegalInformation.setLegalIdentityType(cardInformation.getLegalIdentityType());
    customerLegalInformation.setLegalIdentityCountry(cardInformation.getLegalIdentityCountry());
    getCustomerDetailsRequestBody.setCustomerLegalInformation(customerLegalInformation);
    getCustomerDetailsRequestBody.getCustomerAssociationInformation().setCardInformation(cardInformation);
    getCustomerDetailsRequestBody.getCustomerAssociationInformation().setNewToBankSearchIndicator("Y");
  }

  public static CustomerIntegrationRequest from(PartySearchRequest partySearchRequest) {
    CardInformation cardInformation = CardInformation.builder()
        .cardType(CardType.ID)
        .legalIdentity(partySearchRequest.getLegalIdentity())
        .legalIdentityType(partySearchRequest.getLegalIdentityType())
        .legalIdentityCountry(partySearchRequest.getLegalIdentityCountry())
        .build();
    return new CustomerIntegrationRequest(cardInformation);
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  static class CustomerLegalInformation {

    private String legalIdentity;
    private String legalIdentityType;
    private String legalIdentityCountry;
  }


  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  static class ServiceRequestHeader {

    private ServiceContext serviceContext = new ServiceContext();
    private RequesterContext requesterContext = new RequesterContext();
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  static class ServiceContext {

    private String serviceVersionNumber = "2.0";

  }


  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  static class RequesterContext {

    private String applicationCode = "WSM";
    private String applicationSubCode = "OAO";
    private String countryCode = "SG";
    private String requesterReferenceNumber;
    private String requestTimeInGMT;
    private String requesterUserIdentity = "PUBLIC";
    private String userIPAddress;
    private String userIPAddressPortNumber;
    private String sessionIdentity;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class RequestBody {


    private CustomerAssociationInformation customerAssociationInformation = new CustomerAssociationInformation();
    private CustomerInformation customerInformation;
    private CustomerLegalInformation customerLegalInformation;
    private TransactionInformation transactionInformation;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  static class TransactionInformation {

    private String transactionCode;
    private String transactionGroupCode;
    private String moduleCode;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  static class CustomerAssociationInformation {
    private String viewType;
    private String addressSequenceNumber;
    private String newToBankSearchIndicator;
    private CardInformation cardInformation;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  static class CustomerInformation {

    private String userIdentity;
    private String groupIdentity;
    private String CIFNumber;
    private String ichKey;
    private String segment;
    private String staffIndicator;
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  @Builder
  static class CardInformation {
    private String cardNumber;
    private CardType cardType; //todo: common framework
    private String cardStatus;
    private String relationshipCode;
    private String cardIndicator;
    private String expiryDate;
    private String primaryAccountNumber;
    private String primaryAccountType;
    private String legalIdentity;
    private String legalIdentityType;
    private String legalIdentityCountry;
  }

}

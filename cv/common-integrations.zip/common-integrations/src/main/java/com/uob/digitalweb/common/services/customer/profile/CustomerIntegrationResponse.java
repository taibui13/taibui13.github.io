package com.uob.digitalweb.common.services.customer.profile;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.digitalweb.common.services.cards.CardType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
public class CustomerIntegrationResponse {

  private ServiceResponseHeader serviceResponseHeader;
  
  @JsonProperty("getCustomerDetailsResponseBody")
  private Party customerDetailsResponseBody;

  public boolean isError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }

  public boolean hasNoRecordFound() {
    return serviceResponseHeader.getResponseContext().getResponseCode().equalsIgnoreCase("82");
  }
  
  public String getResponseCode() {
    return getServiceResponseHeader().getResponseContext().getResponseCode();
  }

  public String getResponseDesc() {
    return getServiceResponseHeader().getResponseContext().getResponseDescription();
  }

  public boolean isICH1660Error() {
    return loopErrorList("1660");
  }

  private boolean loopErrorList(String errorCode) {
    if (null == serviceResponseHeader.getResponseContext().getErrorList()) {
      return false;
    }
    for (ErrorList errorObject : serviceResponseHeader.getResponseContext().getErrorList()) {
      if (errorCode.equals(errorObject.getErrorCode())) {
        return true;
      }
    }
    return false;
  }
  
  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  public class ServiceResponseHeader {

    private ResponseContext responseContext;
    private RequesterContext requesterContext;

  }
    @Data
    @NoArgsConstructor @AllArgsConstructor
    public static class ResponseContext {
      private String responseCode;
      private String responseDescription;
      private String serviceResponseTimeInGMT;
      private List<ErrorList> errorList = null;
    }

    @Data
    @NoArgsConstructor @AllArgsConstructor
    public static class RequesterContext {
      private String applicationCode;
      private String applicationSubCode;
      private String countryCode;
      private String requesterReferenceNumber;
      private String requestTimeInGMT;
      private String requesterUserIdentity;
      private String userIPAddress;
      private String userIPAddressPortNumber;
      private String sessionIdentity;
    }

    @Data
    @NoArgsConstructor @AllArgsConstructor
    public static class ErrorList {
      private String errorSource;
      private String errorCode;
      private String errorDescription;
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Party {

      private CustomerDemographicInformation customerDemographicInformation;
      private CustomerAssociationInformation customerAssociationInformation;

      public String retrieveLegalId() {
        return StringUtils.trim(customerDemographicInformation.getCustomerDetailedInformation().getLegalIdentity());
      }

      public String retrieveLegalIdentityCountry() {
        return StringUtils.trim(customerDemographicInformation.getCustomerDetailedInformation().getLegalIdentityCountry());
      }

      public String retrieveLegalIdentityType() {
        return StringUtils.trim(customerDemographicInformation.getCustomerDetailedInformation().getLegalIdentityType());
      }
      
      
      
      @Data
      @NoArgsConstructor
      @AllArgsConstructor
      public static class CustomerAssociationInformation {
        private CardInformation cardInformation;
      }
        
      
      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      @Builder
      public static class CardInformation {

        private String cardNumber;
        
        private CardType cardType;
        
        private String cardStatus;
        private String relationshipCode;
        private String cardIndicator;
        private String expiryDate;
        private String primaryAccountNumber;
        private String primaryAccountType;
        private String legalIdentity;
        private String legalIdentityType;
        private String legalIdentityCountry;


      }
      
      
      @Data
      @NoArgsConstructor
      @AllArgsConstructor
      public static class CustomerDemographicInformation {

        private CustomerInformation customerInformation;
        private CustomerDetailedInformation customerDetailedInformation;
        private CustomerContactDetails customerContactDetails;
      }
        @Data
        @NoArgsConstructor
        @AllArgsConstructor
        public static class CustomerInformation {
          @JsonProperty(value = "CIFNumber")//, access = Access.READ_WRITE)
          private String cifnumber;
        }

        @Data
        @NoArgsConstructor 
        @AllArgsConstructor
        @Builder
        public static class CustomerDetailedInformation {

          private String legalIdentity;
          private String legalIdentityType;
          private String legalIdentityCountry;
          private String firstName;
          private String lastName;
          private String salutation;
          private String birthDate;
          private String staffIndicator;
          private String maritalStatus;
          private String dateofBirthofIncorporation;
          private String customerType;
          private String blackListInd;
          private String lastMaintenanceDate;
          private String lastMaintenanceTime;
          private String ctryOfCitizenshipIncorp;
          private String sexCode;
          private String raceCode;
          private String ctryOfResBizOp;
          private String blacklistReasonCode;
          private String blacklistReasonCodeDesc;
          private String businessType;
          private String holdMailCode;
          private String holdPromotionalMailIndicator;
          private String serviceRecoveryIndicator;
          private String deceasedIndicator;
          private String deceasedDate;
          private String combinedCycle;
          private String companyID;
          private String staffDepartment;
          private String employeeID;
          private String bankerID;
          private String industrialRiskCode;
          private String decodedCustomerName1;
          private String decodedCustomerName2;
          private String decodedForeignAddress1;
          private String decodedForeignAddress2;
          private String decodedForeignAddress3;
          private String decodedForeignAddress4;
          private String suffixforPrimarySalutation;
          private String englishNameSalutation;
          private String englishName1;
          private String englishName2;
          private String suffixforEnglishNameSalutation;
          private String defaultEnglishName1;
          private String defaultEnglishName2;
          private String primaryIndustryCode;
          private String secondaryIndustryCode;
          private String tertiaryIndustryCode;
          private String riskIndustryCode;
          private String reviewDate;
          private String placeofBirth;
          private String localCustomerType;
          private String localSubCustomerType;
          private String subCustomerType;
          private String relatedPartyIndicator;
          private String verifyAddrIndicator;
          private String lastMaintainUserId;
          private String insiderCode;
          private String cpfno;
          private String cdpno;
          private String idexpiryDate;
          private String prstatus;
          private String uiccode1;
          private String siccode8;
          private String ctocode;
          private String vipcustCode;
          private String masindustrialCode;
          private String hkmaindustryCode;
          private String cisnumber;
          private String idplaceofIssue;
          private String ntbindicator;

        }

        @Data
        @NoArgsConstructor @AllArgsConstructor
        public static class CustomerContactDetails {

          private String alertMobilePhoneNumber;
          private String pibmobilePhoneNumber;
          @JsonProperty("3DSMobilePhoneNumber")
          private String threeDSMobilePhoneNumber;
          private String mobilePhoneNummber;
          private String undeliverableAddrInd; // CR - q3 undeliverable flag PIB Instant Registration

        }

    }

  }
  



package com.uob.digitalweb.common.services.customer.profile;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

import javax.validation.Validator;

import com.uob.pweb.common.framework.domains.PartySearchRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.http.HttpHeaders;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.web.client.RestTemplate;

import com.uob.digitalweb.common.services.customer.profile.CustomerIntegrationResponse.Party;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;

@Configuration
public class PartyFlow {

  @Bean
  public IntegrationFlow partySearch(Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/parties")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(PartySearchRequest.class)
            .errorChannel("globalExceptionHandler.input"))
        .filter(PartySearchRequest.class, p -> validator.validate(p).isEmpty(),
          e -> e.discardFlow(f -> f.handle(p -> {
            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", "Please provide all the mandatory Fields");
          })))
        .wireTap("requestLoggingFlow.input")
        .handle((p, h) -> MessageBuilder.withPayload(Party.builder().build())
            .setHeader("partySearchRequest", p)
            .copyHeadersIfAbsent(h).build())
        .enrich(e -> e.requestChannel("partyByCardFlow.input")
            .requestPayload(message -> message.getHeaders().get("partySearchRequest"))
            .propertyExpression("customerAssociationInformation","payload.customerAssociationInformation")
            .propertyExpression("customerDemographicInformation","payload.customerDemographicInformation"))
        .enrich(e -> e.requestChannel("partyByCustomerFlow.input")
            .requestPayload(message -> message.getHeaders().get("partySearchRequest"))
            .propertyExpression("customerDemographicInformation.customerDetailedInformation","payload.customerDemographicInformation.customerDetailedInformation"))
        .handle((p, h) -> MessageBuilder.withPayload(p).setHeader(HttpHeaders.STATUS_CODE, HttpStatus.OK).build()) //?? testing
        .get();
  }


  @Bean
  public IntegrationFlow partyByCardFlow(
      @Value("${service-url.cards-enquiry}") String cardsEnquiryUrl, RestTemplate restTemplate) {
    return f -> f
        .<PartySearchRequest, CustomerIntegrationRequest>transform(p -> CustomerIntegrationRequest.from(p))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(cardsEnquiryUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(CustomerIntegrationResponse.class))
        .filter(CustomerIntegrationResponse.class,p-> !p.isICH1660Error() && !p.isError() ,e -> e.discardFlow(flow -> flow.handle(p -> {
            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",((CustomerIntegrationResponse)p.getPayload()).getResponseCode());
         })))
        .<CustomerIntegrationResponse,Party>transform(p->p.getCustomerDetailsResponseBody());

  }

  @Bean
  public IntegrationFlow partyByCustomerFlow(
      @Value("${service-url.get-customer-details}") String getCustomerDetailsUrl,
      RestTemplate restTemplate) {
    return f -> f
        .<PartySearchRequest, CustomerIntegrationRequest>transform(p -> CustomerIntegrationRequest.from(p))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(getCustomerDetailsUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(CustomerIntegrationResponse.class))
        .filter(CustomerIntegrationResponse.class,p-> !p.hasNoRecordFound() && !p.isError() ,e -> e.discardFlow(flow -> flow.handle(p -> {
            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",((CustomerIntegrationResponse)p.getPayload()).getResponseCode());
         })))
        .<CustomerIntegrationResponse,Party>transform(p->p.getCustomerDetailsResponseBody());
  }

}

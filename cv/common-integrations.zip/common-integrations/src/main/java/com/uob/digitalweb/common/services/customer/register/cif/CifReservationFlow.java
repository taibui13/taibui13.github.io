package com.uob.digitalweb.common.services.customer.register.cif;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

import com.uob.pweb.common.framework.domains.CifReservation;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.http.dsl.Http;
import org.springframework.web.client.RestTemplate;

@Configuration
public class CifReservationFlow {

  @Bean
  public IntegrationFlow customerCifReservation(
      @Value("${service-url.reserve-cif}") String cifReservationUrl, RestTemplate restTemplate,
      Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/customer/cif/reserve")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(CifReservation.class)
            .errorChannel("globalExceptionHandler.input"))
        .filter(CifReservation.class, p -> validator.validate(p).isEmpty(),
            e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", "Please provide all the mandatory Fields");
            })))
        .wireTap("requestLoggingFlow.input")
        .<CifReservation, CifReservationRequest>transform(p -> CifReservationRequest.from(p))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(cifReservationUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(CifReservationResponse.class))
        .filter(CifReservationResponse.class, p -> p.isSuccess(),
            e -> e.discardFlow(f -> f. <CifReservationResponse>handle((p,h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", p.getResponse());})))
        .filter(CifReservationResponse.class, p -> p.isSuccess() || !p.isError(),
            e -> e.discardFlow(f -> f. <CifReservationResponse>handle((p,h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", p.getResponse());})))
        .transform(CifReservationResponse.class, p -> p.getCustomerInfo())
        .get();
  }
}

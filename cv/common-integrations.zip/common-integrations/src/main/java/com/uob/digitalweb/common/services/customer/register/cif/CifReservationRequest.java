package com.uob.digitalweb.common.services.customer.register.cif;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.domains.CifReservation;
import lombok.Builder;
import lombok.Data;

@Data
public class CifReservationRequest {

  @JsonProperty("doCIFReservationRequestBody")
  private RequestBody body = new RequestBody();

  @JsonProperty("serviceRequestHeader")
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();


  public static CifReservationRequest from(CifReservation cifReservation) {
    return new CifReservationRequest(cifReservation);
  }

  private CifReservationRequest(CifReservation cifReservation) {
    CustomerLegalInformation customerLegalInformation = CustomerLegalInformation.builder()
        .legalIdentityType(cifReservation.getLegalIdentityType())
        .legalIdentityCountry(cifReservation.getLegalIdentityCountry())
        .legalIdentity(cifReservation.getLegalIdentity())
        .build();
    body.setCustomerLegalInformation(customerLegalInformation);

    CustomerDetailInformation customerDetailInformation = CustomerDetailInformation.builder()
        .firstName(cifReservation.getFirstName())
        .lastName(cifReservation.getLastName())
        .customerType("I")
        .build();
    body.setCustomerDetailInformation(customerDetailInformation);
  }

  @Data
  public static class RequestBody {

    @JsonProperty("customerDetailInformation")
    private CustomerDetailInformation customerDetailInformation;

    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation = new CustomerInformation();

    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;
  }


  @Data
  static class ServiceRequestHeader {

    @JsonProperty("serviceContext")
    private ServiceContext serviceContext = new ServiceContext();
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext = new RequesterContext();
  }

  @Data
  static class ServiceContext {

    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber = "2.0";

  }

  @Data
  @Builder
  static class CustomerLegalInformation {

    @JsonProperty("legalIdentity")
    private String legalIdentity;
    @JsonProperty("legalIdentityType")
    private String legalIdentityType;
    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;
  }

  @Data
  static class RequesterContext {

    @JsonProperty("applicationCode")
    private String applicationCode = "WSM";
    @JsonProperty("applicationSubCode")
    private String applicationSubCode = "OAO";
    @JsonProperty("countryCode")
    private String countryCode = "SG";
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
  }

  @Data
  @Builder
  public static class CustomerDetailInformation {

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("customerType")
    private String customerType;

    @JsonProperty("contactType1")
    private String contactType1;

    @JsonProperty("contactInfo1")
    private String contactInfo1;

    @JsonProperty("contactType2")
    private String contactType2;

    @JsonProperty("contactInfo2")
    private String contactInfo2;

    @JsonProperty("contactType3")
    private String contactType3;

    @JsonProperty("contactInfo3")
    private String contactInfo3;

    @JsonProperty("creationDate")
    private String creationDate;

    @JsonProperty("creationID")
    private String creationID;

    @JsonProperty("createSystemID")
    private String createSystemID;

    @JsonProperty("remarks")
    private String remarks;
  }

  @Data
  static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cifNumber = "0000000000000000000";
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }
}

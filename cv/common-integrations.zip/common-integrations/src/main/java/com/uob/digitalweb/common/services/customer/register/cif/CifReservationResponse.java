package com.uob.digitalweb.common.services.customer.register.cif;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.StringJoiner;
import lombok.Data;

@Data
public class CifReservationResponse {

  @JsonProperty("serviceResponseHeader")
  private ServiceResponseHeader serviceResponseHeader;

  @JsonProperty("doCIFReservationResponseBody")
  private ResponseBody body;


  public boolean isError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }

  public boolean isSuccess() {
    return serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$") ||
        serviceResponseHeader.getResponseContext().getResponseCode().equals("83") ||
        serviceResponseHeader.getResponseContext().getResponseCode().equals("750");
  }

  public String getResponse() {
    return new StringJoiner("-").add(serviceResponseHeader.getResponseContext().getResponseCode())
        .add(serviceResponseHeader.getResponseContext().getResponseDescription()).toString();
  }


  public String getCifNumber() {
    return body.getCustomerDemographicInformation().getCustomerInformation().getCifNumber();
  }

  public CustomerInformation getCustomerInfo() {
    return body.getCustomerDemographicInformation().getCustomerInformation();
  }

  @Data
  static class ResponseBody {

    @JsonProperty("customerDemographicInformation")
    private CustomerDemographicInformation customerDemographicInformation;
  }

  @Data
  static class CustomerDemographicInformation {

    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
    @JsonProperty("customerDetailedInformation")
    private CustomerDetailedInformation customerDetailedInformation;
  }

  @Data
  static class CustomerInformation {

    @JsonProperty("CIFNumber")
    private String cifNumber;
  }

  @Data
  static class CustomerDetailedInformation {

    @JsonProperty("legalIdentity")
    private String legalIdentity;
    @JsonProperty("legalIdentityType")
    private String legalIdentityType;
    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("customerType")
    private String customerType;
    @JsonProperty("contactType1")
    private String contactType1;
    @JsonProperty("contactInfo1")
    private String contactInfo1;
    @JsonProperty("contactType2")
    private String contactType2;
    @JsonProperty("contactInfo2")
    private String contactInfo2;
    @JsonProperty("contactType3")
    private String contactType3;
    @JsonProperty("contactInfo3")
    private String contactInfo3;
    @JsonProperty("creationID")
    private String creationID;
    @JsonProperty("createSystemID")
    private String createSystemID;
    @JsonProperty("remarks")
    private String remarks;
    @JsonProperty("utilizeDate")
    private String utilizeDate;
    @JsonProperty("utilizeID")
    private String utilizeID;
    @JsonProperty("utilizeSystemID")
    private String utilizeSystemID;
    @JsonProperty("deleteFlag")
    private String deleteFlag;
    @JsonProperty("deletionDate")
    private String deletionDate;
    @JsonProperty("deletionUserID")
    private String deletionUserID;
    @JsonProperty("deleteBySystemID")
    private String deleteBySystemID;
  }

  @Data
  public static class ResponseContext {

    @JsonProperty("responseCode")
    private String responseCode;
    @JsonProperty("responseDescription")
    private String responseDescription;
    @JsonProperty("serviceResponseTimeInGMT")
    private String serviceResponseTimeInGMT;
    @JsonProperty("errorList")
    private List<ErrorList> errorList = null;
  }

  @Data
  static class ServiceContext {

    @JsonProperty("serviceCode")
    private String serviceCode;
    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber;
  }

  @Data
  static class ErrorList {

    @JsonProperty("errorSource")
    private String errorSource;
    @JsonProperty("errorCode")
    private String errorCode;
    @JsonProperty("errorDescription")
    private String errorDescription;
  }

  @Data
  static public class ServiceResponseHeader {

    @JsonProperty("responseContext")
    private ResponseContext responseContext;
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext;
  }
}

package com.uob.digitalweb.common.services.customer.register.pib;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

import com.uob.digitalweb.common.services.customer.register.cif.CifReservationResponse;
import com.uob.pweb.common.framework.domains.RegisterPibRequest;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.http.dsl.Http;
import org.springframework.web.client.RestTemplate;

@Configuration
public class PibRegistrationFlow {

  @Bean
  public IntegrationFlow customerPibRegistration(
      @Value("${service-url.por-registration}") String pibRegistrationUrl, RestTemplate restTemplate,
      Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/customer/registration")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(RegisterPibRequest.class)
            .errorChannel("globalExceptionHandler.input"))
        .filter(RegisterPibRequest.class, p -> validator.validate(p).isEmpty(),
            e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  "Please provide all the mandatory Fields");
            })))
        .wireTap("requestLoggingFlow.input")
        .<RegisterPibRequest, PibRegistrationRequest>transform(p -> PibRegistrationRequest.from(p))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(pibRegistrationUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(PibRegistrationResponse.class))
        .filter(PibRegistrationResponse.class, p -> !p.isError(),
            e -> e.discardFlow(f -> f.<PibRegistrationResponse>handle((p, h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  p.getResponse());
            })))
        .transform(PibRegistrationResponse.class, p -> p.getBody())
        .get();
  }

}


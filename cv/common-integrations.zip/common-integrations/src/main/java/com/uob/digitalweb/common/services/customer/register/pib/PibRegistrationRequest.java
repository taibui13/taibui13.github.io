package com.uob.digitalweb.common.services.customer.register.pib;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.domains.RegisterPibRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@NoArgsConstructor @AllArgsConstructor
public class PibRegistrationRequest {

  @JsonProperty("serviceRequestHeader")
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

  @JsonProperty("doRegisterApplicationUserRequestBody")
  private RequestBody body = new RequestBody ();


  public static PibRegistrationRequest from(RegisterPibRequest registerPibRequest) {
    return new PibRegistrationRequest (registerPibRequest);
  }

  private PibRegistrationRequest(RegisterPibRequest registerPibRequest) {

    CustomerInformation customerInformation = CustomerInformation.builder()
        .userIdentity(registerPibRequest.getUserIdentity())
        .cIFNumber(registerPibRequest.getCifNumber())
        .build();
    body.setCustomerInformation(customerInformation);

    CustomerLegalInformation customerLegalInformation= CustomerLegalInformation.builder()
        .legalIdentity(registerPibRequest.getLegalIdentity())
        .legalIdentityCountry(registerPibRequest.getLegalIdentityCountry())
        .legalIdentityType(registerPibRequest.getLegalIdentityType())
        .build();
    body.setCustomerLegalInformation(customerLegalInformation);

    EncryptionInformation encryptionInformation = EncryptionInformation.builder()
        .encryptedPassword(registerPibRequest.getEncryptedPassword())
        .encryptedNewPassword(registerPibRequest.getEncryptedNewPassword())
        .keyIndex(String.format("%04d", Integer.parseInt(registerPibRequest.getKeyIndex())))
        .randomAccessNumber(registerPibRequest.getRandomAccessNumber())
        .encodingParameter(registerPibRequest.getEncodingParameter())
        .build();
    body.setEncryptionInformation(encryptionInformation);

    RegistrationUserInformation registrationUserInformation = RegistrationUserInformation.builder()
        .registrationType(registerPibRequest.getRegistrationType())
        .accountNumber(registerPibRequest.getAccountNumber())
        .accountType(registerPibRequest.getAccountType())
        .phoneNumber(registerPibRequest.getPhoneNumber())
        .twoFAMode(registerPibRequest.getTwoFAMode())
        .build();
    body.setRegistrationUserInformation(registrationUserInformation);

  }



  @Data
  public static class RequestBody {

    @JsonProperty("registrationUserInformation")
    private RegistrationUserInformation registrationUserInformation;
    @JsonProperty("encryptionInformation")
    private EncryptionInformation encryptionInformation;
    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;
  }

  @Data
  @Builder
  public static class RegistrationUserInformation {

    @JsonProperty("registrationType")
    private String registrationType;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("accountType")
    private String accountType;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("twoFAMode")
    private String twoFAMode;
  }

  @Data
  @Builder
  public static class EncryptionInformation {

    @JsonProperty("encryptedPassword")
    private String encryptedPassword;
    @JsonProperty("encryptedNewPassword")
    private String encryptedNewPassword;
    @JsonProperty("keyIndex")
    private String keyIndex;
    @JsonProperty("randomAccessNumber")
    private String randomAccessNumber;
    @JsonProperty("encodingParameter")
    private String encodingParameter;
  }

  @Data
  @Builder
  static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cIFNumber;
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }

  @Data
  @Builder
  public static class CustomerLegalInformation {

    @JsonProperty("legalIdentity")
    private String legalIdentity;

    @JsonProperty("legalIdentityType")
    private String legalIdentityType;

    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;
  }

  @Data
  public class RequesterContext {

    @JsonProperty("applicationCode")
    private String applicationCode = "WSM";
    @JsonProperty("applicationSubCode")
    private String applicationSubCode = "OAO";
    @JsonProperty("countryCode")
    private String countryCode = "SG";
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
  }

  @Data
  public class ServiceContext {

    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber = "2.0";
  }

  @Data
  public class ServiceRequestHeader {

    @JsonProperty("requesterContext")
    private RequesterContext requesterContext = new RequesterContext();
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext = new ServiceContext();
  }
}

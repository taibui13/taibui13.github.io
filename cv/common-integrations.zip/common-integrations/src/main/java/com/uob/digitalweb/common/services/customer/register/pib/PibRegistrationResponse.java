package com.uob.digitalweb.common.services.customer.register.pib;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.StringJoiner;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class PibRegistrationResponse {

  @JsonProperty("serviceResponseHeader")
  private ServiceResponseHeader serviceResponseHeader;
  @JsonProperty("doRegisterApplicationUserResponseBody")
  private ResponseBody body;

  public boolean isError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }

  public String getResponse() {
    return new StringJoiner("-").add(serviceResponseHeader.getResponseContext().getResponseCode())
        .add(serviceResponseHeader.getResponseContext().getResponseDescription()).toString();
  }

  @Data
  public static class ResponseBody {

    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;
    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
    @JsonProperty("registrationStatus")
    private RegistrationStatus registrationStatus;
  }

  @Data
  public static class CustomerLegalInformation {

    @JsonProperty("legalIdentity")
    private String legalIdentity;
    @JsonProperty("legalIdentityType")
    private String legalIdentityType;
    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;

  }

  @Data
  public static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cIFNumber;
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }

  @Data
  public static class RegistrationStatus {

    @JsonProperty("registrationType")
    private String registrationType;
    @JsonProperty("applicationUserStatus")
    private String applicationUserStatus;
  }

  @Data
  public static class ResponseContext {

    @JsonProperty("responseCode")
    private String responseCode;
    @JsonProperty("responseDescription")
    private String responseDescription;
    @JsonProperty("serviceResponseTimeInGMT")
    private String serviceResponseTimeInGMT;
  }

  @Data
  public static class ServiceResponseHeader {

    @JsonProperty("responseContext")
    private ResponseContext responseContext;
  }

  }

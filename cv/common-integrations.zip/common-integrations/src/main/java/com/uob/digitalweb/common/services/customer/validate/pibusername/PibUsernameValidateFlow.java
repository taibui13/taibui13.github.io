package com.uob.digitalweb.common.services.customer.validate.pibusername;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

import com.uob.pweb.common.framework.domains.RegisterPibRequest;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.http.dsl.Http;
import org.springframework.web.client.RestTemplate;

@Configuration
public class PibUsernameValidateFlow {

  @Bean
  public IntegrationFlow customerPibUsernameValidate(
      @Value("${service-url.por-registration}") String pibRegistrationUrl, RestTemplate restTemplate,
      Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/customer/{username}/validate")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .headerExpression("username", "#pathVariables.username")
                .requestPayloadType(RegisterPibRequest.class)
            .errorChannel("globalExceptionHandler.input"))
        .wireTap("requestLoggingFlow.input")
        .<RegisterPibRequest>handle((p,h) -> PibUsernameValidationRequest.from((String) h.get("username"), p))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(pibRegistrationUrl, restTemplate)
            .httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(PibUsernameValidationResponse.class))
        .filter(PibUsernameValidationResponse.class, p -> !p.isUserNameExisting(),
            e -> e.discardFlow(f -> f.<PibUsernameValidationResponse>handle((p, h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "username.exists",
                  p.getResponse());
            })))
        .filter(PibUsernameValidationResponse.class, p -> !p.isError(),
            e -> e.discardFlow(f -> f.<PibUsernameValidationResponse>handle((p, h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  p.getResponse());
            })))
        .transform(PibUsernameValidationResponse.class, p -> p.getBody())
        .get();
  }
}

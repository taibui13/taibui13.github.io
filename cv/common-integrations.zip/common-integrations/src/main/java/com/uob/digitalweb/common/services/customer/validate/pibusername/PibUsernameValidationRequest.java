package com.uob.digitalweb.common.services.customer.validate.pibusername;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.domains.RegisterPibRequest;
import lombok.Data;

@Data
public class PibUsernameValidationRequest {

  @JsonProperty("serviceRequestHeader")
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

  @JsonProperty("doRegisterApplicationUserRequestBody")
  private RequestBody body = new RequestBody();


  public static PibUsernameValidationRequest from(String userName, RegisterPibRequest registerPibRequest) {
    return new PibUsernameValidationRequest(userName, registerPibRequest);
  }

  public PibUsernameValidationRequest(String userName, RegisterPibRequest registerPibRequest) {

    CustomerInformation customerInformation = new CustomerInformation();
    customerInformation.setUserIdentity(userName);

    CustomerLegalInformation customerLegalInformation = new CustomerLegalInformation();
    customerLegalInformation.setLegalIdentity(registerPibRequest.getLegalIdentity());
    customerLegalInformation.setLegalIdentityCountry(registerPibRequest.getLegalIdentityCountry());
    customerLegalInformation.setLegalIdentityType(registerPibRequest.getLegalIdentityType());

    body.setCustomerInformation(customerInformation);
    body.setCustomerLegalInformation(customerLegalInformation);

  }


  @Data
  public static class RequestBody {

    @JsonProperty("registrationUserInformation")
    private RegistrationUserInformation registrationUserInformation = new RegistrationUserInformation();
    @JsonProperty("encryptionInformation")
    private EncryptionInformation encryptionInformation;
    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;
  }

  @Data
  public static class RegistrationUserInformation {

    @JsonProperty("registrationType")
    private String registrationType = "7";
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("accountType")
    private String accountType;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("twoFAMode")
    private String twoFAMode;
  }

  @Data
  public static class EncryptionInformation {

    @JsonProperty("encryptedPassword")
    private String encryptedPassword;
    @JsonProperty("encryptedNewPassword")
    private String encryptedNewPassword;
    @JsonProperty("keyIndex")
    private String keyIndex;
    @JsonProperty("randomAccessNumber")
    private String randomAccessNumber;
    @JsonProperty("encodingParameter")
    private String encodingParameter;
  }

  @Data
  public static class CustomerLegalInformation {

    @JsonProperty("legalIdentity")
    private String legalIdentity;
    @JsonProperty("legalIdentityType")
    private String legalIdentityType;
    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;
  }

  @Data
  public static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cIFNumber;
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }

  @Data
  public class RequesterContext {

    @JsonProperty("applicationCode")
    private String applicationCode = "WSM";
    @JsonProperty("applicationSubCode")
    private String applicationSubCode = "OAO";
    @JsonProperty("countryCode")
    private String countryCode = "SG";
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
  }

  @Data
  public class ServiceContext {

    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber = "2.0";
  }

  @Data
  public class ServiceRequestHeader {

    @JsonProperty("requesterContext")
    private RequesterContext requesterContext = new RequesterContext();
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext = new ServiceContext();
  }
}

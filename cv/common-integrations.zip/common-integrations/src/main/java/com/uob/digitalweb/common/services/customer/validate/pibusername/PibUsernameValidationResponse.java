package com.uob.digitalweb.common.services.customer.validate.pibusername;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.StringJoiner;
import lombok.Data;

@Data
public class PibUsernameValidationResponse {
  @JsonProperty("serviceResponseHeader")
  private ServiceResponseHeader serviceResponseHeader;
  @JsonProperty("doRegisterApplicationUserResponseBody")
  private ResponseBody body;

  public boolean isUserNameExisting() {
    return serviceResponseHeader.getResponseContext().getResponseCode().matches("1270");
  }

  public boolean isError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }

  public String getResponse() {
    return new StringJoiner("-").add(serviceResponseHeader.getResponseContext().getResponseCode())
        .add(serviceResponseHeader.getResponseContext().getResponseDescription()).toString();
  }

  @Data
  public static class ResponseBody {

    @JsonProperty("customerLegalInformation")
    private CustomerLegalInformation customerLegalInformation;
    @JsonProperty("customerInformation")
    private CustomerInformation customerInformation;
    @JsonProperty("registrationStatus")
    private RegistrationStatus registrationStatus;
  }

  @Data
  public static class CustomerLegalInformation {

    @JsonProperty("legalIdentity")
    private String legalIdentity;
    @JsonProperty("legalIdentityType")
    private String legalIdentityType;
    @JsonProperty("legalIdentityCountry")
    private String legalIdentityCountry;
  }

  @Data
  public static class CustomerInformation {

    @JsonProperty("userIdentity")
    private String userIdentity;
    @JsonProperty("groupIdentity")
    private String groupIdentity;
    @JsonProperty("CIFNumber")
    private String cIFNumber;
    @JsonProperty("ichKey")
    private String ichKey;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("staffIndicator")
    private String staffIndicator;
  }


  @Data
  public static class RegistrationStatus {

    @JsonProperty("registrationType")
    private String registrationType;
    @JsonProperty("applicationUserStatus")
    private String applicationUserStatus;
  }


  @Data
  static class RequesterContext {

    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("applicationCode")
    private String applicationCode;
    @JsonProperty("applicationSubCode")
    private String applicationSubCode;
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
  }

  @Data
  public static class ResponseContext {

    @JsonProperty("responseCode")
    private String responseCode;
    @JsonProperty("responseDescription")
    private String responseDescription;
    @JsonProperty("serviceResponseTimeInGMT")
    private String serviceResponseTimeInGMT;
  }

  @Data
  static class ServiceContext {

    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber;
  }

  @Data
  public static class ServiceResponseHeader {

    @JsonProperty("responseContext")
    private ResponseContext responseContext;
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext;
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext;
  }
}

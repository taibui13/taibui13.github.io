package com.uob.digitalweb.common.services.fileUpload;

import com.uob.pweb.common.framework.domains.FileCopyRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.mapping.HeaderMapper;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.io.IOException;

@Configuration
@Slf4j
public class CommonFileCopyFlow {

    @Bean
    public IntegrationFlow handleCommonFileCopy(HeaderMapper<HttpHeaders> headerMapper) {
        return IntegrationFlows.from(Http.inboundGateway("/v1/file/copy")
                .headerMapper(headerMapper)
                .errorChannel("globalExceptionHandler.input")
                .requestMapping(m -> {
                    m.methods(HttpMethod.POST);
                }).requestPayloadType(FileCopyRequest.class))
                .wireTap("requestLoggingFlow.input")
                .<FileCopyRequest>handle((p, h) -> {
                    File destinationDir = new File(p.getDestination());
                    if (!CollectionUtils.isEmpty(p.getMultipartFiles())) {
                        p.getMultipartFiles().forEach((name, multipartFile) -> {
                            try {
                                File file = new File(destinationDir.getAbsoluteFile()+ "/" +name);
                                if(!file.exists()) {
                                    FileUtils.writeByteArrayToFile(file, multipartFile);
                                    log.info("copy file {} to EWF {}", name, destinationDir.getAbsoluteFile());
                                } else{
                                    log.info(" file {} already exists", name);
                                }
                            } catch (IOException e) {
                                log.error("Failed copy file {} to EWF {}", name, destinationDir.getAbsoluteFile());
                            }
                        });
                    }
                    return Strings.EMPTY;
                })
                .get();
    }

}
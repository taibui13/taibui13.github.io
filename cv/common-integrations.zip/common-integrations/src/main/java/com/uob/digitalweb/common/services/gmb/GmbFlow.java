package com.uob.digitalweb.common.services.gmb;

import java.io.FileInputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.Validator;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.http.dsl.Http;

import com.google.api.client.googleapis.GoogleUtils;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.mybusinessprovider.v1.MyBusinessProvider;
import com.google.api.services.mybusinessprovider.v1.model.GenerateVerificationTokenRequest;
import com.google.api.services.mybusinessprovider.v1.model.GenerateVerificationTokenResponse;
import com.google.api.services.mybusinessprovider.v1.model.Location;
import com.google.api.services.mybusinessprovider.v1.model.PostalAddress;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.http.HttpTransportFactory;
import com.google.auth.oauth2.GoogleCredentials;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.SignalType;
import reactor.core.scheduler.Schedulers;

@Configuration
@Slf4j
public class GmbFlow {

	@Bean
	public IntegrationFlow generateGmbTokens(@Value("${gmb.credential.path}") String gmbCredentialPath,
			@Value("${gmb.program.id}") String gmbProgramId,
			@Value("${gmb.timeout.millis:60000}") String gmbTimeoutMillis,
			@Value("${gmb.refreshtoken.flag}") String gmbRefreshTokenFlag,
			@Value("${gmb.dryrun.flag}") String gmbDryRunFlag,
			@Value("${gmb.dummy.flag}") String gmbDummyFlag,
			@Value("${gmb.proxy.flag:false}") String gmbProxyFlag,
			@Value("${gmb.proxy.host:}") String gmbProxyHost,
			@Value("${gmb.proxy.port:}") String gmbProxyPort,
			Validator validator) {

		return IntegrationFlows
				.from(Http.inboundGateway("/v1/mybusinessprovider/tokens")
						.requestMapping(m -> m.methods(HttpMethod.POST)).requestPayloadType(GmbRequest.class)
						.errorChannel("globalExceptionHandler.input"))
				.log(LoggingHandler.Level.INFO, this.getClass().getName(), m -> "start - gmb token request")
				.wireTap("requestLoggingFlow.input")
				.filter(GmbRequest.class, p -> validator.validate(p).isEmpty(), e -> e.discardFlow(f -> f.handle(p -> {
					throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
							"address cannot be empty/incomplete");
				})))
				.filter(GmbRequest.class, p -> !hasDuplicateAddress(p), e -> e.discardFlow(f -> f.handle(p -> {
					throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
							"cannot have duplicate address");
				})))
				.<GmbRequest>handle((gmbReq, h) -> {
					try {
						if(Boolean.valueOf(gmbDummyFlag)) {
							log.info("gmbDummyFlag is {} - generating dummy tokens", gmbDummyFlag);
							gmbReq.getAddress().forEach(address -> {
				        		address.setGmbCode(RandomStringUtils.randomAlphanumeric(9).toUpperCase());
				        	});
						} else {
							log.info("preparing GoogleCredentials");
							HttpTransport httpTransport = proxyHttpTransport(gmbProxyFlag, gmbProxyHost, gmbProxyPort);
							GoogleCredentials credentials;
							if(httpTransport != null) {
								credentials = GoogleCredentials.fromStream(
										new FileInputStream(gmbCredentialPath),
										new HttpTransportFactory() {
											@Override
											public HttpTransport create() {
												return httpTransport;
											}
										})
										.createScoped(Arrays.asList("https://www.googleapis.com/auth/mybusinessprovider"));
							} else {
								credentials = GoogleCredentials.fromStream(new FileInputStream(gmbCredentialPath))
										.createScoped(Arrays.asList("https://www.googleapis.com/auth/mybusinessprovider"));
							}
							
							int idx = 0;
							for(OutletAddress add : gmbReq.getAddress()) {
								add.setIndex(idx++);
							}
							List<OutletAddress> procAdds = new ArrayList<OutletAddress>();
							
							try {
								Flux.fromIterable(gmbReq.getAddress())
								.flatMap(add ->
										 Mono.fromCallable(() -> 
										 	generateToken(add, 
										 			credentials,
										 			Long.valueOf(gmbProgramId),
										 			Boolean.valueOf(gmbRefreshTokenFlag),
										 			Boolean.valueOf(gmbDryRunFlag),
										 			httpTransport))
										 	.subscribeOn(Schedulers.elastic()))
								.subscribeOn(Schedulers.elastic())
								.doOnEach(signal -> {
									log.info("" + Thread.currentThread().getName() + " SignalType: {}", signal.getType());
									if(signal.getType().equals(SignalType.ON_NEXT) ||
											signal.getType().equals(SignalType.ON_CONTEXT) ||
											signal.getType().equals(SignalType.ON_ERROR)) {
										procAdds.add(signal.get());
										log.info("" + Thread.currentThread().getName() + " completed: {}", signal.get().getIndex());
										if(signal.hasError()) {
											log.info("Error encountered: {}", signal.getThrowable().getMessage());
										}
									}
								})
								.doOnComplete(() -> gmbReq.setAddress(procAdds))
								.blockLast(Duration.ofMillis(Integer.valueOf(gmbTimeoutMillis)));
							} catch (RuntimeException e) {
								e.printStackTrace();
							}
							gmbReq.getAddress().sort((a1, a2) -> Integer.compareUnsigned(a1.getIndex(), a2.getIndex()));
						}
					} catch (Exception ex) {
						ex.printStackTrace();
						throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR);
					}
					log.info("end - gmb token request");
					return gmbReq;
				}).get();
	}
	
	private HttpTransport proxyHttpTransport(String gmbProxyFlag, String gmbProxyHost, String gmbProxyPort) {
		HttpTransport httpTransport = null;
		if(Boolean.valueOf(gmbProxyFlag)) {
			log.info("preparing proxy");
		    try {
		    	Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(gmbProxyHost, Integer.valueOf(gmbProxyPort)));
				httpTransport = new NetHttpTransport.Builder()
						.setProxy(proxy)
						.trustCertificates(GoogleUtils.getCertificateTrustStore())
						.build();
				log.info("proxy config: {}", proxy.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return httpTransport;
	}

	private OutletAddress generateToken(OutletAddress address,
			GoogleCredentials credentials,
			long programId,
			boolean allowRefreshToken,
			boolean isDryRun,
			HttpTransport httpTransport) {

		try {
			log.info("" + Thread.currentThread().getName() + " start - preparing request for outlet address");
			credentials.refreshIfExpired();
			HttpRequestInitializer requestInitializer = new HttpCredentialsAdapter(credentials);
			
			if(httpTransport == null) {
				log.info("no proxy set");
				httpTransport = GoogleNetHttpTransport.newTrustedTransport();
			}
			
			MyBusinessProvider myBusinessProvider = new MyBusinessProvider(
					httpTransport,
					JacksonFactory.getDefaultInstance(),
					requestInitializer);
			
			GenerateVerificationTokenRequest request = new GenerateVerificationTokenRequest()
					.setLocation(new Location()
							.setLocationName(address.getLocationName())
							.setAddress(new PostalAddress()
									.setRevision(0)
									.setRegionCode("SG")
									.setPostalCode(address.getPostalCode())
									//address: building-block-street-floor-unit
									.setAddressLines(Arrays.asList(
											 (StringUtils.isBlank(address.getBuilding()) ? "" : address.getBuilding() + " ") +
											 address.getBlock() + " " +
											 address.getStreet() + " " +
											 address.getFloor() + "-" +
											 address.getUnit()))))
					.setProgramId(programId)
					.setAllowRefreshExistingToken(allowRefreshToken)
					.setDryRun(isDryRun);
			
			log.info("" + Thread.currentThread().getName() + " Sending google token request: {}", request);
			
			GenerateVerificationTokenResponse response = 
					myBusinessProvider.verificationTokens().generate(request).execute();
			address.setGmbResponse(response);
			if(response != null && response.getVerificationToken() != null) {
				address.setGmbCode(response.getVerificationToken().getVerificationCode());
			}
			log.info("" + Thread.currentThread().getName() + " end - updated outlet address: {}", address);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return address;
	}
	
	private boolean hasDuplicateAddress(GmbRequest gmbRequest) {
		for(OutletAddress address : gmbRequest.getAddress()) {
			long x = gmbRequest.getAddress().stream().filter(add -> add.equals(address)).count();
			if(x > 1) {
				return true;
			}
		}
		return false;
	}
  
}

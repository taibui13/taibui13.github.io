/**
 * 
 */
package com.uob.digitalweb.common.services.gmb;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.google.api.services.mybusinessprovider.v1.model.GenerateVerificationTokenResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author ventyd
 *
 */
@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString
@JsonInclude(Include.NON_NULL)
public class OutletAddress implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int index;
	
	@NotNull
	@EqualsAndHashCode.Include
	private String block;

	private String building;

	@NotNull
	@EqualsAndHashCode.Include
	private String floor;
	
	@NotNull
	private String locationName;

	@NotNull
	@EqualsAndHashCode.Include
	private String postalCode;

	@NotNull
	@EqualsAndHashCode.Include
	private String street;

	@NotNull
	@EqualsAndHashCode.Include
	private String unit;
	
	private String gmbCode;
	
	private GenerateVerificationTokenResponse gmbResponse;

}

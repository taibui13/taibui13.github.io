package com.uob.digitalweb.common.services.otp;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

import javax.persistence.EntityManager;
import javax.validation.Validator;

import com.uob.pweb.common.framework.domains.SendOtpRequest;
import com.uob.pweb.common.framework.domains.SendOtpResponse;
import com.uob.pweb.common.framework.domains.VerifySmsRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.jpa.dsl.Jpa;
import org.springframework.integration.jpa.support.PersistMode;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.digitalweb.common.services.otp.SendOtpIntegrationResponse.SendOtpIntegrationResponseBody;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;

@Configuration
public class OtpFlow {

  @Bean
  public IntegrationFlow sendSmsOtpFlow(
      @Value("${service-url.generate-sms-otp}") String generateOtpUrl,
      ObjectMapper objectMapper, EntityManager entityManager,
      RestTemplate restTemplate, Validator validator) {

    return IntegrationFlows
        .from(Http.inboundGateway("/v1/access/sendotp")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(SendOtpRequest.class).errorChannel("globalExceptionHandler.input"))
        .log(LoggingHandler.Level.INFO, this.getClass().getName(), m -> "start - sms otp request")
        .wireTap("requestLoggingFlow.input")
        .filter(SendOtpRequest.class, p -> validator.validate(p).isEmpty(),
            e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  "mobilenumber cannot be empty");
            })))
        .<SendOtpRequest, SendOtpIntegrationRequest>transform(
            p -> SendOtpIntegrationRequest.with(p.getMobileNumber()))
        .transform(Transformers.toJson())
        .handle(Http.outboundGateway(generateOtpUrl, restTemplate).httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(SendOtpIntegrationResponse.class))
        .filter(SendOtpIntegrationResponse.class, p -> !p.isWithError(),
            e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR, "invalid.request",
                  ((SendOtpIntegrationResponse) p).getResponseCode());
            })))
        .<SendOtpIntegrationResponse, SmsOtpEntity>transform(p -> {
          SendOtpIntegrationResponseBody smsOtp = ((SendOtpIntegrationResponse) p).getSmsOtp();
          SmsOtpEntity smsOtpEntity = objectMapper.convertValue(smsOtp, SmsOtpEntity.class);
          return smsOtpEntity;
        })
        .handle(Jpa.updatingGateway(entityManager).entityClass(SmsOtpEntity.class)
            .persistMode(PersistMode.MERGE), e -> e.transactional())
        .<SmsOtpEntity, SendOtpResponse>transform(
            p -> new SendOtpResponse(p.getSmsPrefix(), p.getRequestIdentity()))
        .get();
  }


  @Bean
  public IntegrationFlow verifySmsOtpFlow(
      @Value("${service-url.validate-sms-otp}") String verifyOtpUrl, EntityManager entityManager,
      RestTemplate restTemplate, Validator validator) {
    return IntegrationFlows
        .from(Http.inboundGateway("/v1/access/verifyotp")
            .requestMapping(m -> m.methods(HttpMethod.POST))
            .requestPayloadType(VerifySmsRequest.class).errorChannel("globalExceptionHandler.input"))
        .log(LoggingHandler.Level.INFO, this.getClass().getName(),
            m -> "start - verify sms otp request")
        .wireTap("requestLoggingFlow.input").filter(VerifySmsRequest.class,
            p -> validator.validate(p).isEmpty(), e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  "otpcode need to be 6 chars & cannot be empty");
            })))
        .enrichHeaders(h -> h.headerExpression("requestIdentity", "payload.requestIdentity"))
        .enrichHeaders(h -> h.headerExpression("otpcode", "payload.otpCode"))
        .<VerifySmsRequest, String>transform(p -> p.getRequestIdentity())
        .handle(Jpa.retrievingGateway(entityManager)
            .jpaQuery("from SmsOtpEntity s where s.requestIdentity = :requestIdentity")
            .expectSingleResult(true).parameterExpression("requestIdentity", "payload"))
        .transform(Message.class, m -> {
          return MessageBuilder
              .withPayload(VerifyOtpIntegrationRequest.from((SmsOtpEntity) m.getPayload(),
                  (String) m.getHeaders().get("otpcode")))
              .copyHeaders(m.getHeaders()).build();
        }).transform(Transformers.toJson())
        .handle(Http.outboundGateway(verifyOtpUrl, restTemplate).httpMethod(HttpMethod.POST)
            .mappedRequestHeaders(CONTENT_TYPE)
            .expectedResponseType(VerifyOtpIntegrationResponse.class))
        .filter(VerifyOtpIntegrationResponse.class, p -> !p.isInvalidOrExpired(),
            e -> e.discardFlow(f -> f.<VerifyOtpIntegrationResponse> handle((p,h) -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", p.getResponseCode());
            })))
        .filter(VerifyOtpIntegrationResponse.class, p -> !p.isError(),
            e -> e.discardFlow(f -> f.<VerifyOtpIntegrationResponse>handle((p,h) -> {
              throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR);
            })))
        .transform(Message.class, message -> {
          return MessageBuilder.withPayload((String) message.getHeaders().get("requestIdentity"))
              .copyHeaders(message.getHeaders()).build();
        })
        .handle(Jpa.updatingGateway(entityManager).persistMode(PersistMode.DELETE)
            .jpaQuery("delete from SmsOtpEntity s where s.requestIdentity = :requestIdentity")
            .parameterExpression("requestIdentity", "payload"), e -> e.transactional())
        .<Integer, String>transform(p -> StringUtils.EMPTY).get();
  }
}

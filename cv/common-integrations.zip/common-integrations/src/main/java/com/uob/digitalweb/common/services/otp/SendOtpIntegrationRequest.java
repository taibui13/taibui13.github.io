package com.uob.digitalweb.common.services.otp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SendOtpIntegrationRequest {

  @JsonProperty("generateSMSOTPRequestBody")
  private RequestBody body = new RequestBody();
  
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

  private SendOtpIntegrationRequest(String mobileNumber) {
    this.body.setMobileNumber(mobileNumber);
  }

  public static SendOtpIntegrationRequest with(String mobileNumber) {
    return new SendOtpIntegrationRequest(mobileNumber);
  }

  public RequestBody getBody() {
    return body;
  }

  public void setBody(RequestBody body) {
    this.body = body;
  }

  public ServiceRequestHeader getServiceRequestHeader() {
    return serviceRequestHeader;
  }
  
  static class ServiceRequestHeader {

    @JsonProperty("serviceContext")
    private ServiceContext serviceContext = new ServiceContext();
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext = new RequesterContext();

    public ServiceContext getServiceContext() {
      return serviceContext;
    }

    public void setServiceContext(ServiceContext serviceContext) {
      this.serviceContext = serviceContext;
    }

    public RequesterContext getRequesterContext() {
      return requesterContext;
    }

    public void setRequesterContext(RequesterContext requesterContext) {
      this.requesterContext = requesterContext;
    }

    @Override
    public String toString() {
      return String.format("ServiceRequestHeader [serviceContext=%s, requesterContext=%s]",
          serviceContext, requesterContext);
    }
  }

  static class ServiceContext {

    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber;
    @JsonProperty("serviceCode")
    private String serviceCode;

    public String getServiceVersionNumber() {
      return "1.0";
    }

    public void setServiceVersionNumber(String serviceVersionNumber) {
      this.serviceVersionNumber = serviceVersionNumber;
    }

    public String getServiceCode() {
      return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
      this.serviceCode = serviceCode;
    }

    @Override
    public String toString() {
      return String.format("ServiceContext [serviceVersionNumber=%s, serviceCode=%s]",
          serviceVersionNumber, serviceCode);
    }
  }

  static class RequesterContext {

    @JsonProperty("applicationCode")
    private String applicationCode;
    @JsonProperty("applicationSubCode")
    private String applicationSubCode;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;

    public String getApplicationCode() {
      return "WSM";
    }

    public void setApplicationCode(String applicationCode) {
      this.applicationCode = applicationCode;
    }

    public String getApplicationSubCode() {
      return "OAO";
    }

    public void setApplicationSubCode(String applicationSubCode) {
      this.applicationSubCode = applicationSubCode;
    }

    public String getCountryCode() {
      return countryCode;
    }

    public void setCountryCode(String countryCode) {
      this.countryCode = countryCode;
    }

    public String getRequesterReferenceNumber() {
      return requesterReferenceNumber;
    }
    
    public void setRequesterReferenceNumber(String requesterReferenceNumber) {
      this.requesterReferenceNumber = requesterReferenceNumber;
    }

    public String getRequestTimeInGMT() {
      return requestTimeInGMT;
    }

    public void setRequestTimeInGMT(String requestTimeInGMT) {
      this.requestTimeInGMT = requestTimeInGMT;
    }

    public String getRequesterUserIdentity() {
      return requesterUserIdentity;
    }
    
    public void setRequesterUserIdentity(String requesterUserIdentity) {
      this.requesterUserIdentity = requesterUserIdentity;
    }

    public String getUserIPAddress() {
      return userIPAddress;
    }

    public void setUserIPAddress(String userIPAddress) {
      this.userIPAddress = userIPAddress;
    }

    public String getUserIPAddressPortNumber() {
      return userIPAddressPortNumber;
    }

    public void setUserIPAddressPortNumber(String userIPAddressPortNumber) {
      this.userIPAddressPortNumber = userIPAddressPortNumber;
    }

    public String getSessionIdentity() {
      return sessionIdentity;
    }

    public void setSessionIdentity(String sessionIdentity) {
      this.sessionIdentity = sessionIdentity;
    }

    @Override
    public String toString() {
      return String.format(
          "RequesterContext [applicationCode=%s, applicationSubCode=%s, countryCode=%s, requesterReferenceNumber=%s, requestTimeInGMT=%s, requesterUserIdentity=%s, userIPAddress=%s, userIPAddressPortNumber=%s, sessionIdentity=%s]",
          applicationCode, applicationSubCode, countryCode, requesterReferenceNumber,
          requestTimeInGMT, requesterUserIdentity, userIPAddress, userIPAddressPortNumber,
          sessionIdentity);
    }
  }
  
  static class RequestBody {

    private String mobileNumber;

    public String getMobileNumber() {
      return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
      this.mobileNumber = mobileNumber;
    }
  }

}
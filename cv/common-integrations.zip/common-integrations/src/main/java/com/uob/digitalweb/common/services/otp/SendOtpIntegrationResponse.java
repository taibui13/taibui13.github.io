package com.uob.digitalweb.common.services.otp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SendOtpIntegrationResponse {

  private ServiceResponseHeader serviceResponseHeader;
  
  @JsonProperty("generateSMSOTPResponseBody")
  private SendOtpIntegrationResponseBody smsOtp;

  public ServiceResponseHeader getServiceResponseHeader() {
    return serviceResponseHeader;
  }

  public void setServiceResponseHeader(ServiceResponseHeader serviceResponseHeader) {
    this.serviceResponseHeader = serviceResponseHeader;
  }

  public SendOtpIntegrationResponseBody getSmsOtp() {
    return smsOtp;
  }

  public void setSmsOtp(SendOtpIntegrationResponseBody smsOtp) {
    this.smsOtp = smsOtp;
  }

  public boolean isWithError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }

  public String getResponseCode() {
    return getServiceResponseHeader().getResponseContext().getResponseCode();
  }

  public String getResponseDesc() {
    return getServiceResponseHeader().getResponseContext().getResponseDescription();
  }
  public static class ServiceResponseHeader {

    @JsonProperty("responseContext")
    private ResponseContext responseContext;
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext;
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext;

    public ResponseContext getResponseContext() {
      return responseContext;
    }
    
    public void setResponseContext(ResponseContext responseContext) {
      this.responseContext = responseContext;
    }

    public RequesterContext getRequesterContext() {
      return requesterContext;
    }

    public void setRequesterContext(RequesterContext requesterContext) {
      this.requesterContext = requesterContext;
    }

    public ServiceContext getServiceContext() {
      return serviceContext;
    }

    public void setServiceContext(ServiceContext serviceContext) {
      this.serviceContext = serviceContext;
    }

    @Override
    public String toString() {
      return String.format(
          "ServiceResponseHeader [responseContext=%s, requesterContext=%s, serviceContext=%s]",
          responseContext, requesterContext, serviceContext);
    } 
  }

  static class RequesterContext {

    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("applicationCode")
    private String applicationCode;
    @JsonProperty("applicationSubCode")
    private String applicationSubCode;
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;

    public String getRequestTimeInGMT() {
      return requestTimeInGMT;
    }

    public void setRequestTimeInGMT(String requestTimeInGMT) {
      this.requestTimeInGMT = requestTimeInGMT;
    }
    
    public String getApplicationCode() {
      return applicationCode;
    }

    public void setApplicationCode(String applicationCode) {
      this.applicationCode = applicationCode;
    }

    public String getApplicationSubCode() {
      return applicationSubCode;
    }
    
    public void setApplicationSubCode(String applicationSubCode) {
      this.applicationSubCode = applicationSubCode;
    }

    public String getRequesterReferenceNumber() {
      return requesterReferenceNumber;
    }

    public void setRequesterReferenceNumber(String requesterReferenceNumber) {
      this.requesterReferenceNumber = requesterReferenceNumber;
    }

    public String getCountryCode() {
      return countryCode;
    }

    public void setCountryCode(String countryCode) {
      this.countryCode = countryCode;
    }

    public String getSessionIdentity() {
      return sessionIdentity;
    }

    public void setSessionIdentity(String sessionIdentity) {
      this.sessionIdentity = sessionIdentity;
    }

    public String getUserIPAddress() {
      return userIPAddress;
    }

    public void setUserIPAddress(String userIPAddress) {
      this.userIPAddress = userIPAddress;
    }

    public String getUserIPAddressPortNumber() {
      return userIPAddressPortNumber;
    }

    public void setUserIPAddressPortNumber(String userIPAddressPortNumber) {
      this.userIPAddressPortNumber = userIPAddressPortNumber;
    }

    public String getRequesterUserIdentity() {
      return requesterUserIdentity;
    }

    public void setRequesterUserIdentity(String requesterUserIdentity) {
      this.requesterUserIdentity = requesterUserIdentity;
    }

    @Override
    public String toString() {
      return String.format(
          "RequesterContext [requestTimeInGMT=%s, applicationCode=%s, applicationSubCode=%s, requesterReferenceNumber=%s, countryCode=%s, sessionIdentity=%s, userIPAddress=%s, userIPAddressPortNumber=%s, requesterUserIdentity=%s]",
          requestTimeInGMT, applicationCode, applicationSubCode, requesterReferenceNumber,
          countryCode, sessionIdentity, userIPAddress, userIPAddressPortNumber,
          requesterUserIdentity);
    }
  }

  public static class ResponseContext {

    @JsonProperty("responseCode")
    private String responseCode;
    @JsonProperty("responseDescription")
    private String responseDescription;
    @JsonProperty("serviceResponseTimeInGMT")
    private String serviceResponseTimeInGMT;

    public String getResponseCode() {
      return responseCode;
    }

    public void setResponseCode(String responseCode) {
      this.responseCode = responseCode;
    }

    public String getResponseDescription() {
      return responseDescription;
    }

    public void setResponseDescription(String responseDescription) {
      this.responseDescription = responseDescription;
    }

    public String getServiceResponseTimeInGMT() {
      return serviceResponseTimeInGMT;
    }

    public void setServiceResponseTimeInGMT(String serviceResponseTimeInGMT) {
      this.serviceResponseTimeInGMT = serviceResponseTimeInGMT;
    }

    @Override
    public String toString() {
      return String.format(
          "ResponseContext [responseCode=%s, responseDescription=%s, serviceResponseTimeInGMT=%s]",
          responseCode, responseDescription, serviceResponseTimeInGMT);
    }
  }

  static class ServiceContext {

    @JsonProperty("serviceCode")
    private String serviceCode;
    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber;

    public String getServiceCode() {
      return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
      this.serviceCode = serviceCode;
    }

    public String getServiceVersionNumber() {
      return serviceVersionNumber;
    }

    public void setServiceVersionNumber(String serviceVersionNumber) {
      this.serviceVersionNumber = serviceVersionNumber;
    }

    @Override
    public String toString() {
      return String.format("ServiceContext [serviceCode=%s, serviceVersionNumber=%s]", serviceCode,
          serviceVersionNumber);
    }
  }
  
  static class SendOtpIntegrationResponseBody {
    
    private String smsRequestIdentity;
    private String expiryDate;
    private String smsRandonNumber;
    private String smsPrefix;
    private TransactionInformation transactionInformation;

    public String getTransactionReferenceNumber () {
      return transactionInformation.getTransactionReferenceNumber();
    }
    
    public String getSmsRequestIdentity() {
      return smsRequestIdentity;
    }

    public void setSmsRequestIdentity(String smsRequestIdentity) {
      this.smsRequestIdentity = smsRequestIdentity;
    }

    public String getExpiryDate() {
      return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
      this.expiryDate = expiryDate;
    }

    public String getSmsRandonNumber() {
      return smsRandonNumber;
    }

    public void setSmsRandonNumber(String smsRandonNumber) {
      this.smsRandonNumber = smsRandonNumber;
    }

    public String getSmsPrefix() {
      return smsPrefix;
    }

    public void setSmsPrefix(String smsPrefix) {
      this.smsPrefix = smsPrefix;
    }

    public TransactionInformation getTransactionInformation() {
      return transactionInformation;
    }

    public void setTransactionInformation(TransactionInformation transactionInformation) {
      this.transactionInformation = transactionInformation;
    }
    
    @Override
    public String toString() {
      return String.format(
          "SmsOtp [smsRequestIdentity=%s, expiryDate=%s, smsRandonNumber=%s, smsPrefix=%s, transactionInformation=%s]",
          smsRequestIdentity, expiryDate, smsRandonNumber, smsPrefix, transactionInformation);
    }

    static class TransactionInformation {

      private String transactionReferenceNumber;
      private String journalIdentity;
      private String activitySequenceIdentity;

      public String getTransactionReferenceNumber() {
        return transactionReferenceNumber;
      }

      public void setTransactionReferenceNumber(String transactionReferenceNumber) {
        this.transactionReferenceNumber = transactionReferenceNumber;
      }

      public String getJournalIdentity() {
        return journalIdentity;
      }

      public void setJournalIdentity(String journalIdentity) {
        this.journalIdentity = journalIdentity;
      }

      public String getActivitySequenceIdentity() {
        return activitySequenceIdentity;
      }

      public void setActivitySequenceIdentity(String activitySequenceIdentity) {
        this.activitySequenceIdentity = activitySequenceIdentity;
      }

      @Override
      public String toString() {
        return String.format(
            "TransactionInformation [transactionReferenceNumber=%s, journalIdentity=%s, activitySequenceIdentity=%s]",
            transactionReferenceNumber, journalIdentity, activitySequenceIdentity);
      }
    }
  }

}

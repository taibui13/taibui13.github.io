package com.uob.digitalweb.common.services.otp;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TOLF_SMSOTP_CACHE")
@Getter
@Setter
@Builder
@ToString(includeFieldNames = true)
@NoArgsConstructor
@AllArgsConstructor
public class SmsOtpEntity {
  
  @Id
  @JsonProperty("smsRequestIdentity")
  @Column(name = "ID")
  private String requestIdentity;
  
  
  @JsonProperty("smsRandonNumber")
  @Column(name = "RANDOM_NUMBER")
  private String randomNumber;
  

  @Column(name = "SMS_PREFIX")
  private String smsPrefix;
  
  @Column(name = "TXN_REF_NUMBER")
  private String transactionReferenceNumber;

  @Temporal(TemporalType.TIMESTAMP)
  @CreationTimestamp
  @Column(name = "CREATEDDT")
  private Date createdDate;

  
  @Temporal(TemporalType.TIMESTAMP)
  @UpdateTimestamp
  @Column(name = "UPDATEDDT")
  private Date updatedDate;

}


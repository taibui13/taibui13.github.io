package com.uob.digitalweb.common.services.otp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VerifyOtpIntegrationRequest {
  
  private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();
  
  @JsonProperty("validateSMSOTPRequestBody")
  private RequestBody body = new RequestBody();
  
  private VerifyOtpIntegrationRequest(String otpData, String requestIdentity, String randomNumber, String transactionReferenceNumber) {
    body.setSmsOTPData(otpData);
    body.setSmsRequestIdentity(requestIdentity);
    body.setSmsRandonNumber(randomNumber);
    body.setTransactionReferenceNumber(transactionReferenceNumber);
  }
  

  
  public static VerifyOtpIntegrationRequest from (SmsOtpEntity otp,String otpCode) {
    return new VerifyOtpIntegrationRequest(otpCode, otp.getRequestIdentity(), otp.getRandomNumber(), otp.getTransactionReferenceNumber());
  }
  
  
  public ServiceRequestHeader getServiceRequestHeader() {
    return serviceRequestHeader;
  }
  public void setServiceRequestHeader(ServiceRequestHeader serviceRequestHeader) {
    this.serviceRequestHeader = serviceRequestHeader;
  }
  
  public RequestBody getBody() {
    return body;
  }

  static class ServiceRequestHeader {

    @JsonProperty("serviceContext")
    private ServiceContext serviceContext = new ServiceContext();
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext = new RequesterContext();

    public ServiceContext getServiceContext() {
      return serviceContext;
    }

    public RequesterContext getRequesterContext() {
      return requesterContext;
    }

    @Override
    public String toString() {
      return String.format("ServiceRequestHeader [serviceContext=%s, requesterContext=%s]",
          serviceContext, requesterContext);
    }
  }

  static class ServiceContext {

    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber;
    @JsonProperty("serviceCode")
    private String serviceCode;

    public String getServiceVersionNumber() {
      return "1.0";
    }

    public String getServiceCode() {
      return serviceCode;
    }

    @Override
    public String toString() {
      return String.format("ServiceContext [serviceVersionNumber=%s, serviceCode=%s]",
          serviceVersionNumber, serviceCode);
    }
  }

  static class RequesterContext {

    @JsonProperty("applicationCode")
    private String applicationCode;
    @JsonProperty("applicationSubCode")
    private String applicationSubCode;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;

    public String getApplicationCode() {
      return "WSM";
    }

    public void setApplicationCode(String applicationCode) {
      this.applicationCode = applicationCode;
    }

    public String getApplicationSubCode() {
      return "OAO";
    }

    public void setApplicationSubCode(String applicationSubCode) {
      this.applicationSubCode = applicationSubCode;
    }

    public String getCountryCode() {
      return countryCode;
    }

    public void setCountryCode(String countryCode) {
      this.countryCode = countryCode;
    }

    public String getRequesterReferenceNumber() {
      return requesterReferenceNumber;
    }
    
    public void setRequesterReferenceNumber(String requesterReferenceNumber) {
      this.requesterReferenceNumber = requesterReferenceNumber;
    }

    public String getRequestTimeInGMT() {
      return requestTimeInGMT;
    }

    public void setRequestTimeInGMT(String requestTimeInGMT) {
      this.requestTimeInGMT = requestTimeInGMT;
    }

    public String getRequesterUserIdentity() {
      return requesterUserIdentity;
    }
    
    public void setRequesterUserIdentity(String requesterUserIdentity) {
      this.requesterUserIdentity = requesterUserIdentity;
    }

    public String getUserIPAddress() {
      return userIPAddress;
    }

    public void setUserIPAddress(String userIPAddress) {
      this.userIPAddress = userIPAddress;
    }

    public String getUserIPAddressPortNumber() {
      return userIPAddressPortNumber;
    }

    public void setUserIPAddressPortNumber(String userIPAddressPortNumber) {
      this.userIPAddressPortNumber = userIPAddressPortNumber;
    }

    public String getSessionIdentity() {
      return sessionIdentity;
    }

    public void setSessionIdentity(String sessionIdentity) {
      this.sessionIdentity = sessionIdentity;
    }

    @Override
    public String toString() {
      return String.format(
          "RequesterContext [applicationCode=%s, applicationSubCode=%s, countryCode=%s, requesterReferenceNumber=%s, requestTimeInGMT=%s, requesterUserIdentity=%s, userIPAddress=%s, userIPAddressPortNumber=%s, sessionIdentity=%s]",
          applicationCode, applicationSubCode, countryCode, requesterReferenceNumber,
          requestTimeInGMT, requesterUserIdentity, userIPAddress, userIPAddressPortNumber,
          sessionIdentity);
    }
  }
  
  static class RequestBody {

    private String smsRequestIdentity;
    private String smsOTPData;
    private String transactionReferenceNumber;
    private String smsRandonNumber;

    public String getSmsRequestIdentity() {
      return smsRequestIdentity;
    }

    public void setSmsRequestIdentity(String smsRequestIdentity) {
      this.smsRequestIdentity = smsRequestIdentity;
    }

    public String getSmsOTPData() {
      return smsOTPData;
    }

    public void setSmsOTPData(String smsOTPData) {
      this.smsOTPData = smsOTPData;
    }

    public String getTransactionReferenceNumber() {
      return transactionReferenceNumber;
    }

    public void setTransactionReferenceNumber(String transactionReferenceNumber) {
      this.transactionReferenceNumber = transactionReferenceNumber;
    }

    public String getSmsRandonNumber() {
      return smsRandonNumber;
    }

    public void setSmsRandonNumber(String smsRandonNumber) {
      this.smsRandonNumber = smsRandonNumber;
    }

    @Override
    public String toString() {
      return String.format(
          "RequestBody [smsRequestIdentity=%s, smsOTPData=%s, transactionReferenceNumber=%s, smsRandonNumber=%s]",
          smsRequestIdentity, smsOTPData, transactionReferenceNumber, smsRandonNumber);
    }
  } 
}
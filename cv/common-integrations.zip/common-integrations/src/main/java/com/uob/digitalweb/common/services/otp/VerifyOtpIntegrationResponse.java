package com.uob.digitalweb.common.services.otp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VerifyOtpIntegrationResponse {

  private ServiceResponseHeader serviceResponseHeader;

  public ServiceResponseHeader getServiceResponseHeader() {
    return serviceResponseHeader;
  }

  public void setServiceResponseHeader(ServiceResponseHeader serviceResponseHeader) {
    this.serviceResponseHeader = serviceResponseHeader;
  }
  
  public boolean isInvalidOrExpired() {
    return serviceResponseHeader.getResponseContext().getResponseCode().equalsIgnoreCase("SEC02-PBE000105");
  }
  
  public boolean isError() {
    return !serviceResponseHeader.getResponseContext().getResponseCode().matches("^0+$");
  }
  
  public String getResponseCode() {
    return getServiceResponseHeader().getResponseContext().getResponseCode();
  }

  public String getResponseDesc() {
    return getServiceResponseHeader().getResponseContext().getResponseDescription();
  }
  
  public static class ServiceResponseHeader {

    @JsonProperty("responseContext")
    private ResponseContext responseContext;
    @JsonProperty("requesterContext")
    private RequesterContext requesterContext;
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext;

    public ResponseContext getResponseContext() {
      return responseContext;
    }

    public void setResponseContext(ResponseContext responseContext) {
      this.responseContext = responseContext;
    }

    public RequesterContext getRequesterContext() {
      return requesterContext;
    }

    public void setRequesterContext(RequesterContext requesterContext) {
      this.requesterContext = requesterContext;
    }

    public ServiceContext getServiceContext() {
      return serviceContext;
    }

    public void setServiceContext(ServiceContext serviceContext) {
      this.serviceContext = serviceContext;
    }

    @Override
    public String toString() {
      return String.format(
          "ServiceResponseHeader [responseContext=%s, requesterContext=%s, serviceContext=%s]",
          responseContext, requesterContext, serviceContext);
    }
  }

  static class RequesterContext {

    @JsonProperty("requestTimeInGMT")
    private String requestTimeInGMT;
    @JsonProperty("applicationCode")
    private String applicationCode;
    @JsonProperty("applicationSubCode")
    private String applicationSubCode;
    @JsonProperty("requesterReferenceNumber")
    private String requesterReferenceNumber;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("sessionIdentity")
    private String sessionIdentity;
    @JsonProperty("userIPAddress")
    private String userIPAddress;
    @JsonProperty("userIPAddressPortNumber")
    private String userIPAddressPortNumber;
    @JsonProperty("requesterUserIdentity")
    private String requesterUserIdentity;

    public String getRequestTimeInGMT() {
      return requestTimeInGMT;
    }

    public void setRequestTimeInGMT(String requestTimeInGMT) {
      this.requestTimeInGMT = requestTimeInGMT;
    }
    
    public String getApplicationCode() {
      return applicationCode;
    }

    public void setApplicationCode(String applicationCode) {
      this.applicationCode = applicationCode;
    }

    public String getApplicationSubCode() {
      return applicationSubCode;
    }

    public void setApplicationSubCode(String applicationSubCode) {
      this.applicationSubCode = applicationSubCode;
    }

    public String getRequesterReferenceNumber() {
      return requesterReferenceNumber;
    }

    public void setRequesterReferenceNumber(String requesterReferenceNumber) {
      this.requesterReferenceNumber = requesterReferenceNumber;
    }

    public String getCountryCode() {
      return countryCode;
    }

    public void setCountryCode(String countryCode) {
      this.countryCode = countryCode;
    }

    public String getSessionIdentity() {
      return sessionIdentity;
    }

    public void setSessionIdentity(String sessionIdentity) {
      this.sessionIdentity = sessionIdentity;
    }

    public String getUserIPAddress() {
      return userIPAddress;
    }

    public void setUserIPAddress(String userIPAddress) {
      this.userIPAddress = userIPAddress;
    }

    public String getUserIPAddressPortNumber() {
      return userIPAddressPortNumber;
    }
    
    public void setUserIPAddressPortNumber(String userIPAddressPortNumber) {
      this.userIPAddressPortNumber = userIPAddressPortNumber;
    }

    public String getRequesterUserIdentity() {
      return requesterUserIdentity;
    }

    public void setRequesterUserIdentity(String requesterUserIdentity) {
      this.requesterUserIdentity = requesterUserIdentity;
    }

    @Override
    public String toString() {
      return String.format(
          "RequesterContext [requestTimeInGMT=%s, applicationCode=%s, applicationSubCode=%s, requesterReferenceNumber=%s, countryCode=%s, sessionIdentity=%s, userIPAddress=%s, userIPAddressPortNumber=%s, requesterUserIdentity=%s]",
          requestTimeInGMT, applicationCode, applicationSubCode, requesterReferenceNumber,
          countryCode, sessionIdentity, userIPAddress, userIPAddressPortNumber,
          requesterUserIdentity);
    }
  }

  public static class ResponseContext {

    @JsonProperty("responseCode")
    private String responseCode;
    @JsonProperty("responseDescription")
    private String responseDescription;
    @JsonProperty("serviceResponseTimeInGMT")
    private String serviceResponseTimeInGMT;
    
    public String getResponseCode() {
      return responseCode;
    }

    public void setResponseCode(String responseCode) {
      this.responseCode = responseCode;
    }

    public String getResponseDescription() {
      return responseDescription;
    }

    public void setResponseDescription(String responseDescription) {
      this.responseDescription = responseDescription;
    }

    public String getServiceResponseTimeInGMT() {
      return serviceResponseTimeInGMT;
    }

    public void setServiceResponseTimeInGMT(String serviceResponseTimeInGMT) {
      this.serviceResponseTimeInGMT = serviceResponseTimeInGMT;
    }
    
    @Override
    public String toString() {
      return String.format(
          "ResponseContext [responseCode=%s, responseDescription=%s, serviceResponseTimeInGMT=%s]",
          responseCode, responseDescription, serviceResponseTimeInGMT);
    }
  }

  static class ServiceContext {

    @JsonProperty("serviceCode")
    private String serviceCode;
    @JsonProperty("serviceVersionNumber")
    private String serviceVersionNumber;

    public String getServiceCode() {
      return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
      this.serviceCode = serviceCode;
    }

    public String getServiceVersionNumber() {
      return serviceVersionNumber;
    }

    public void setServiceVersionNumber(String serviceVersionNumber) {
      this.serviceVersionNumber = serviceVersionNumber;
    }

    @Override
    public String toString() {
      return String.format("ServiceContext [serviceCode=%s, serviceVersionNumber=%s]", serviceCode,
          serviceVersionNumber);
    }
  }
}

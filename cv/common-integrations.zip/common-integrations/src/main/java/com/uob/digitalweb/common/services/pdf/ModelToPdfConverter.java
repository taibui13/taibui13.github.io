package com.uob.digitalweb.common.services.pdf;

import java.awt.HeadlessException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ModelToPdfConverter {

  String writerTemplate = "pdf-template";

  public ByteArrayOutputStream convertModelToPdf(Configuration freeMarkerConfig,
      Map<String, Object> notificationModel) {
    try {
      Template contentTemplate = freeMarkerConfig.getTemplate(writerTemplate + "_content");
      String pdfContentHtml =
          FreeMarkerTemplateUtils.processTemplateIntoString(contentTemplate, notificationModel);
      OutputStream outputStream = new ByteArrayOutputStream();
      writePdf(outputStream, pdfContentHtml);
      return (ByteArrayOutputStream) outputStream;
    } catch (IOException | TemplateException e) {
      log.info("Error while accessing/processing content template. {}", e);
      return null;
    }
  }

  public static void writePdf(OutputStream outputStream, String contentHtml) {
    Document document = new Document();
    try (InputStream inputStream = new ByteArrayInputStream(contentHtml.getBytes())) {
      PdfWriter writer = PdfWriter.getInstance(document, outputStream);
      document.open();
      XMLWorkerHelper.getInstance().parseXHtml(writer, document, inputStream);
    } catch (DocumentException | HeadlessException | IOException ex) {
      log.error("Exception while writing PDF. {} ", ex);
    } finally {
      document.close();
    }
  }

  public void setTemplate(String template) {
    this.writerTemplate = template;
  }
}

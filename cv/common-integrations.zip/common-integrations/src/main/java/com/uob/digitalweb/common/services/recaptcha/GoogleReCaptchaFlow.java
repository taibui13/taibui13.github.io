package com.uob.digitalweb.common.services.recaptcha;

import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.integrations.logging.RequestLoggingInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import javax.validation.Validator;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

@Configuration
@Slf4j
public class GoogleReCaptchaFlow {

    @Bean
    public IntegrationFlow verifyGoogleResponse(@Value("${google.recaptcha.verify.url}") String reCaptchaUrl,
                                                @Value("${goggle.recaptcha.secret.key}") String secret,
                                                @Value("${goggle.recaptcha.proxy.host}") String proxyHost,
                                                @Value("${goggle.recaptcha.proxy.port}") String proxyPort,
                                                Validator validator) {

        return IntegrationFlows
                .from(Http.inboundGateway("/v1/recaptcha/verify")
                        .requestMapping(m -> m.methods(HttpMethod.GET))
                        .errorChannel("globalExceptionHandler.input")
                        .headerExpression("reCaptchaKey", "#requestParams.getFirst('recaptchakey')"))
                .log(LoggingHandler.Level.INFO, this.getClass().getName(), m -> "start - Re-Captcha verify request")
                .wireTap("requestLoggingFlow.input")
                .filter(Message.class, p -> null != p.getHeaders().get("reCaptchaKey"), e -> e.discardFlow(f -> f.handle(p -> {
                    throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "empty.request", "recaptchakey cannot be empty.");
                })))
                /*.transform(p -> ReCaptchaRequest.builder().build())
                .transform(Transformers.toJson())*/
                .transform(p -> StringUtils.EMPTY)
                .transform(Transformers.toJson())
                .handle(Http.outboundGateway(
                        m -> UriComponentsBuilder.fromHttpUrl(reCaptchaUrl)
                                .queryParam("secret", secret)
                                .queryParam("response", m.getHeaders().get("reCaptchaKey"))
                                .queryParam("remoteip", (((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest()).getRemoteAddr())
                                .build().encode().toUriString(),
                        getRestTemplate(proxyHost, proxyPort)
                )
                        .expectedResponseType(ReCaptchaResponse.class)
                        .mappedRequestHeaders(CONTENT_TYPE)
                        .httpMethod(HttpMethod.POST))
                .filter(ReCaptchaResponse.class, ReCaptchaResponse::isSuccess, e -> e.discardFlow(f -> f.handle(p -> {
                    log.info("Invalid request to google api {}", Arrays.asList(((ReCaptchaResponse) p.getPayload()).getErrorCodes()));
                    throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request", "Re-Captcha key or secret not valid.");
                })))
                .handle((p, h) -> MessageBuilder.withPayload(StringUtils.EMPTY).copyHeadersIfAbsent(h).build())
                .get();
    }

    private RestTemplate getRestTemplate(String googleProxyHost, String googleProxyPort) {
        SimpleClientHttpRequestFactory clientHttpReqFactory = new SimpleClientHttpRequestFactory();
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(googleProxyHost, Integer.valueOf(googleProxyPort)));
        clientHttpReqFactory.setProxy(proxy);

        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(clientHttpReqFactory));
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new RequestLoggingInterceptor(true, true, true, true));
        restTemplate.setInterceptors(interceptors);

        return restTemplate;
    }
}

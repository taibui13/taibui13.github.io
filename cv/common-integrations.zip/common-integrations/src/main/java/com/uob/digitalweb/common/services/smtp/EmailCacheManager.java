package com.uob.digitalweb.common.services.smtp;

import java.io.File;
import java.io.FileInputStream;
import java.util.PropertyResourceBundle;

import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

import com.uob.digitalweb.common.services.smtp.EmailTemplate.MailContent;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;

import freemarker.cache.StringTemplateLoader;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EmailCacheManager {

  @Value("${mail.template.files.path}")
  private String templateFilesPath;
  
  @Value("${mail.template.mapfile.path}")
  private String templateMapFilePath;

  @Autowired
  private Jaxb2Marshaller jaxb2Marshaller;

  @Autowired
  @Qualifier("notificationTemplateLoader")
  private StringTemplateLoader loader;

  /**
   * refresh freemaker template once cache is expired.
   *
   * @param templateId
   * @return
   */
  @Cacheable(value = "properties", key = "#templateId", unless = "#result==null")
  public String refresh(String templateId) {
   log.info("refresh template {}", templateId);
    try(FileInputStream fis = new FileInputStream(templateMapFilePath)) {
      String templateName = new PropertyResourceBundle(fis).getString(templateId).trim();
      
      File templateFile = new File(templateFilesPath + "/" + templateName);
      EmailTemplate emailTemplate =  (EmailTemplate) jaxb2Marshaller.unmarshal(new StreamSource(templateFile));
      MailContent mailContent = emailTemplate.getMailContent();

      synchronized (this) {
        loader.putTemplate(templateId + "_subject", mailContent.getSubject());
        loader.putTemplate(templateId + "_content", mailContent.getContent());
        loader.putTemplate(templateId + "_sender", mailContent.getSender());
      }

      return templateId;
    } catch (Exception e) {
      throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.filename", "Please define the template file name in template.properties ");
    }
  }


}

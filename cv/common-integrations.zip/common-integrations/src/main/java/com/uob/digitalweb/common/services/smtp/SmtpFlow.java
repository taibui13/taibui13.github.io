package com.uob.digitalweb.common.services.smtp;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.uob.digitalweb.common.services.pdf.ModelToPdfConverter;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.notification.NotificationRequest;
import com.uob.pweb.common.framework.notification.NotificationRequest.EmailRequest;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.util.Strings;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.handler.LoggingHandler.Level;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.mapping.HeaderMapper;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.validation.Validator;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;

@org.springframework.context.annotation.Configuration
@Slf4j
public class SmtpFlow {

  @Bean
  public StringTemplateLoader notificationTemplateLoader(Configuration freemarkerConfig) {
    StringTemplateLoader loader = new StringTemplateLoader();
    freemarkerConfig.setTemplateLoader(loader);
    return loader;
  }

  @Bean
  public IntegrationFlow notification(Configuration freemarkerConfig,
      HeaderMapper<org.springframework.http.HttpHeaders> headerMapper, Validator validator,
      EmailCacheManager emailCacheManager, JavaMailSender emailSender) {
    return IntegrationFlows
        .from(
            Http.inboundGateway("/v1/notification").requestMapping(m -> m.methods(HttpMethod.POST))
                .headerMapper(headerMapper).requestPayloadType(NotificationRequest.class)
                .errorChannel("globalExceptionHandler.input"))
        .log(Level.INFO, this.getClass().getName(), m -> "start - sending email notification")
        .wireTap("requestLoggingFlow.input").filter(NotificationRequest.class,
            p -> validator.validate(p).isEmpty(), e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  "recipients and template are mandatory");
            }))).<NotificationRequest, List<NotificationRequest.EmailRequest>>transform(
                p -> p.getEmails())
        .split().<EmailRequest, MimeMessage>transform(p -> {
          MimeMessage message = null;
          try {
            String template = p.getTemplate();
            emailCacheManager.refresh(template);

            Template senderTemplate = freemarkerConfig.getTemplate(template + "_sender");
            Template subjectTemplate = freemarkerConfig.getTemplate(template + "_subject");
            Template contentTemplate = freemarkerConfig.getTemplate(template + "_content");

            message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message,
                MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            helper.setTo(p.getRecipients().toArray(new String[0]));

            if (!CollectionUtils.isEmpty(p.getBccList()))
              helper.setBcc(p.getBccList().toArray(new String[0]));

            if (!CollectionUtils.isEmpty(p.getCcList()))
              helper.setCc(p.getCcList().toArray(new String[0]));

            helper.setText(
                FreeMarkerTemplateUtils.processTemplateIntoString(contentTemplate, p.getModel()),
                true);
            helper.setSubject(
                FreeMarkerTemplateUtils.processTemplateIntoString(subjectTemplate, p.getModel()));
            helper.setFrom(
                FreeMarkerTemplateUtils.processTemplateIntoString(senderTemplate, p.getModel()));

            if (!CollectionUtils.isEmpty(p.getAttachmentFiles())) {
              p.getAttachmentFiles().forEach((name, encodedStr) -> {
                try {
                  helper.addAttachment(name,
                      new ByteArrayResource(Base64.decodeBase64(encodedStr)));
                } catch (MessagingException e) {
                  log.error("Could not attach file {} ", name, e);
                  throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                      "File not in encoded Format");
                }
              });
            }
            return message;
          } catch (MessagingException | IOException | TemplateException ex) {
            log.error("Exception while sending the eMail message :", ex);
            throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR);
          }
        }).<MimeMessage>handle((p, h) -> {
          emailSender.send(p);

          return p;
        }).aggregate()
        .log(Level.INFO, this.getClass().getName(), m -> "end - sending email notification")
        .transform(p -> Strings.EMPTY).get();
  }

  /*
   * Removed Base64 Conversion Accepts Multipart Files instead of Base64 Strings. Uses Map<String,
   * FileToUpload> in NotificationRequest
   */
  @Bean
  public IntegrationFlow notification2(Configuration freemarkerConfig,
      HeaderMapper<org.springframework.http.HttpHeaders> headerMapper, Validator validator,
      EmailCacheManager emailCacheManager, JavaMailSender emailSender) {

    return IntegrationFlows
        .from(
            Http.inboundGateway("/v2/notification").requestMapping(m -> m.methods(HttpMethod.POST))
                .headerMapper(headerMapper).requestPayloadType(NotificationRequest.class)
                .errorChannel("globalExceptionHandler.input"))
        .log(Level.INFO, this.getClass().getName(),
            m -> "start - sending email notification from v2 notification")
        .wireTap("requestLoggingFlow.input").filter(NotificationRequest.class,
            p -> validator.validate(p).isEmpty(), e -> e.discardFlow(f -> f.handle(p -> {
              throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                  "recipients and template are mandatory");
            })))
        .<NotificationRequest, List<EmailRequest>>transform(p -> p.getEmails()).split()
        .<EmailRequest, MimeMessage>transform(p -> {
          MimeMessage message = null;
          try {
            String template = p.getTemplate();
            emailCacheManager.refresh(template);

            Template senderTemplate = freemarkerConfig.getTemplate(template + "_sender");
            Template subjectTemplate = freemarkerConfig.getTemplate(template + "_subject");
            Template contentTemplate = freemarkerConfig.getTemplate(template + "_content");

            message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message,
                MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            helper.setTo(p.getRecipients().toArray(new String[0]));

            if (!CollectionUtils.isEmpty(p.getBccList()))
              helper.setBcc(p.getBccList().toArray(new String[0]));

            if (!CollectionUtils.isEmpty(p.getCcList()))
              helper.setCc(p.getCcList().toArray(new String[0]));

            String contentHtml =
                FreeMarkerTemplateUtils.processTemplateIntoString(contentTemplate, p.getModel());

            helper.setText(contentHtml, true);
            helper.setSubject(
                FreeMarkerTemplateUtils.processTemplateIntoString(subjectTemplate, p.getModel()));
            helper.setFrom(
                FreeMarkerTemplateUtils.processTemplateIntoString(senderTemplate, p.getModel()));
            
            if (null != p.getPdfRequired() && null != p.getFileName()) {
              if (p.getPdfRequired().equals(Boolean.TRUE) && !StringUtils.isEmpty(contentHtml)) {
                emailCacheManager.refresh("pdf-template");
                ModelToPdfConverter modelToPdfConverter = new ModelToPdfConverter();
                byte[] bytes = modelToPdfConverter.convertModelToPdf(freemarkerConfig, p.getModel())
                    .toByteArray();
                helper.addAttachment(p.getFileName() + ".pdf", new ByteArrayResource(bytes));
              }
            }

            if (!CollectionUtils.isEmpty(p.getMultipartFiles())) {
              p.getMultipartFiles().forEach((name, multipartFile) -> {
                try {
                  helper.addAttachment(name, new ByteArrayResource(multipartFile));
                  log.info("Attached file" + multipartFile.toString());
                } catch (MessagingException e) {
                  log.error("Could not attach file {} ", name, e);
                  throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "invalid.request",
                      "File not in encoded Format");
                }
              });
            }

            return message;
          } catch (MessagingException | IOException | TemplateException ex) {
            log.error("Exception while sending the eMail message :", ex);
            throw new ApiRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR);
          }
        }).<MimeMessage>handle((p, h) -> {
          emailSender.send(p);
          return p;
        }).aggregate()
        .log(Level.INFO, this.getClass().getName(), m -> "end - sending email notification")
        .transform(p -> Strings.EMPTY).get();
  }
}

package com.uob.digitalweb.common.services.xrm;

import com.uob.digitalweb.common.services.xrm.initiate.DoInitiateApplicationRequest;
import com.uob.digitalweb.common.services.xrm.initiate.DoInitiateApplicationResponse;
import com.uob.digitalweb.common.services.xrm.retreive.GetCustomerApplicationRequest;
import com.uob.digitalweb.common.services.xrm.retreive.GetCustomerApplicationResponse;
import com.uob.digitalweb.common.services.xrm.submit.DoSubmitCustomerApplicationRequest;
import com.uob.digitalweb.common.services.xrm.submit.DoSubmitCustomerApplicationResponse;
import com.uob.digitalweb.common.services.xrm.upload.DoUploadApplicationAttachmentRequest;
import com.uob.digitalweb.common.services.xrm.upload.DoUploadApplicationAttachmentResponse;
import com.uob.pweb.common.framework.exception.ApiRuntimeException;
import com.uob.pweb.common.framework.xrm.*;
import com.uob.pweb.common.framework.xrm.DocumentUploadRequest.DocumentInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.mapping.HeaderMapper;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;

@Configuration
public class XrmIntegrationFlow {

    @Autowired
    private Environment env;

    @Value("${service-url.retrieve-application-form}")
    private String retrieveServiceURL;

    @Value("${service-url.initiate-application-form}")
    private String initiateServiceURL;

    @Value("${service-url.submit-application-form}")
    private String submitServiceURL;

    @Value("${service-url.upload-attachment}")
    private String uploadServiceURL;

    @Autowired
    RestTemplate fileUploadRestTemplate;

    @Autowired
    RestTemplate restTemplate;

    @Bean
    public IntegrationFlow retrieveXRMApplication (HeaderMapper<HttpHeaders> headerMapper){
        return IntegrationFlows
                .from(Http.inboundGateway("/v1/xrm/retrieve")
                        .requestMapping(m -> m.methods(HttpMethod.POST))
                        .headerMapper(headerMapper)
                        .requestPayloadType(GetApplicationRequest.class)
                        .errorChannel("globalExceptionHandler.input"))
                .log(LoggingHandler.Level.INFO, m -> "start - retrieving application from XRM " )
                .<GetApplicationRequest, GetCustomerApplicationRequest>transform(p -> GetCustomerApplicationRequest.from(p))
                .wireTap("requestLoggingFlow.input")
                .transform(Transformers.toJson())
                .handle(Http.outboundGateway(retrieveServiceURL, restTemplate)
                        .httpMethod(HttpMethod.POST)
                        .mappedRequestHeaders(CONTENT_TYPE)
                        .expectedResponseType(GetCustomerApplicationResponse.class))
                .filter(GetCustomerApplicationResponse.class, p -> !p.isError(),
                        e -> e.discardFlow(f -> f. <GetCustomerApplicationResponse>handle((p, h) -> {
                            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "xrm.request.failed", p.getResponse());
                        })))
                .log(LoggingHandler.Level.INFO, m -> "end - retrieving application from XRM")
                .transform(GetCustomerApplicationResponse.class, p -> p.getGetApplicationResponse())
                .get();

    }

    @Bean
    public IntegrationFlow initiateXRMApplication (HeaderMapper<HttpHeaders> headerMapper){
        return IntegrationFlows
                .from(Http.inboundGateway("/v1/xrm/initiate")
                        .requestMapping(m -> m.methods(HttpMethod.POST))
                        .headerMapper(headerMapper)
                        .requestPayloadType(InitiateApplicationRequest.class)
                        .errorChannel("globalExceptionHandler.input"))
                .log(LoggingHandler.Level.INFO, m -> "start - initiating application to XRM ")
                .<InitiateApplicationRequest, DoInitiateApplicationRequest>transform(p -> DoInitiateApplicationRequest.from(p))
                .wireTap("requestLoggingFlow.input")
                .transform(Transformers.toJson())
                .handle(Http.outboundGateway(initiateServiceURL, restTemplate)
                        .httpMethod(HttpMethod.POST)
                        .mappedRequestHeaders(CONTENT_TYPE)
                        .expectedResponseType(DoInitiateApplicationResponse.class))
                 .filter(DoInitiateApplicationResponse.class, p -> !p.isError(),
                        e -> e.discardFlow(f -> f. <DoInitiateApplicationResponse>handle((p, h) -> {
                            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "xrm.request.failed", p.getResponse());
                        })))
                .log(LoggingHandler.Level.INFO, m -> "end - initiating application to XRM")
                .transform(DoInitiateApplicationResponse.class, p -> p.getInitiateApplicationResponse())
        .get();

    }


    @Bean
    public IntegrationFlow submitXRMApplication (HeaderMapper<HttpHeaders> headerMapper){
        return IntegrationFlows
                .from(Http.inboundGateway("/v1/xrm/submit")
                        .requestMapping(m -> m.methods(HttpMethod.POST))
                        .headerMapper(headerMapper)
                        .requestPayloadType(SubmitApplicationRequest.class)
                        .errorChannel("globalExceptionHandler.input"))
                .log(LoggingHandler.Level.INFO, m -> "start - submitting application to XRM")
                .<SubmitApplicationRequest, DoSubmitCustomerApplicationRequest>transform(p -> DoSubmitCustomerApplicationRequest.from(p))
                .wireTap("requestLoggingFlow.input")
                .transform(Transformers.toJson())
                .handle(Http.outboundGateway(submitServiceURL, restTemplate)
                        .httpMethod(HttpMethod.POST)
                        .mappedRequestHeaders(CONTENT_TYPE)
                        .expectedResponseType(DoSubmitCustomerApplicationResponse.class))
                .filter(DoSubmitCustomerApplicationResponse.class, p -> !p.isError(),
                        e -> e.discardFlow(f -> f. <DoSubmitCustomerApplicationResponse>handle((p,h) -> {
                            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "xrm.request.failed", p.getResponse());
                        })))
                .log(LoggingHandler.Level.INFO, m -> "end - submitting application to XRM")
                .transform(DoSubmitCustomerApplicationResponse.class, p -> p.getSubmitApplicationResponse())
        .get();
    }

    @Bean
    public IntegrationFlow uploadFileToXRM (HeaderMapper<HttpHeaders> headerMapper){
        return IntegrationFlows
                .from(Http.inboundGateway("/v1/xrm/upload")
                        .requestMapping(m -> m.methods(HttpMethod.POST))
                        .headerMapper(headerMapper)
                        .requestPayloadType(DocumentUploadRequest.class)
                        .errorChannel("globalExceptionHandler.input"))
                .log(LoggingHandler.Level.INFO, m -> "start - uploading files to XRM")
                .<DocumentUploadRequest, DoUploadApplicationAttachmentRequest>transform(p -> DoUploadApplicationAttachmentRequest.from(p))
                .wireTap("xrmFileUploadRequestLoggingFlow.input")
                .handle(Http.outboundGateway(uploadServiceURL, fileUploadRestTemplate)
                        .httpMethod(HttpMethod.POST)
                        .mappedRequestHeaders(HttpHeaders.CONTENT_TYPE)
                        .expectedResponseType(DoUploadApplicationAttachmentResponse.class))
                .filter(DoUploadApplicationAttachmentResponse.class , p -> !p.isError(),
                        e -> e.discardFlow(f -> f.<DoUploadApplicationAttachmentResponse>handle((p,h) -> {
                            throw new ApiRuntimeException(HttpStatus.BAD_REQUEST, "xrm.request.failed", p.getResponse());
                        })))
                .log(LoggingHandler.Level.INFO, m -> "start - uploading files to XRM")
                .transform(DoUploadApplicationAttachmentResponse.class, p -> p.getDocumentUploadResponse())
                .get();
    }

}

package com.uob.digitalweb.common.services.xrm.initiate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.xrm.InitiateApplicationRequest;
import lombok.*;

import java.text.SimpleDateFormat;
import java.util.Date;

@Data
@ToString(includeFieldNames = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DoInitiateApplicationRequest {
	@JsonProperty("serviceRequestHeader")
	private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();
	@JsonProperty("doInitiateCustomerApplicationRequestBody")
	private RequestBody requestBody = new RequestBody();

	public DoInitiateApplicationRequest(InitiateApplicationRequest criteria) {
		ApplicationCustomerInformation applicationCustomerInformation = ApplicationCustomerInformation.builder()
				.basicCustomerInformation(BasicCustomerInformation.builder()
						.fullName(criteria.getFullName())
						.firstName(criteria.getFirstName())
						.idType(criteria.getIdType())
						.idNumber(criteria.getIdNumber())
						.idCountry(criteria.getIdCountry())
						.email(criteria.getEmail())
						.countryCode(criteria.getCountryCode())
						.mobileNumber(criteria.getMobileNumber())
						.build())
				.myInfoDetail(MyInfoDetail.builder()
						.myInfoVerified("No")
						.build())
				.build();
		ApplicationBasicInformation applicationBasicInformation = ApplicationBasicInformation.builder()
				.productCode(criteria.getProductCode())
				.build();
		requestBody.setApplicationBasicInformation(applicationBasicInformation);
		requestBody.setApplicationCustomerInformation(applicationCustomerInformation);
	}

	public static DoInitiateApplicationRequest from(
			InitiateApplicationRequest criteria) {
		return new DoInitiateApplicationRequest(criteria);
	}


	@Data
	public static class ServiceRequestHeader {

		@JsonProperty("requesterContext")
		private RequesterContext requesterContext = new RequesterContext();
		@JsonProperty("serviceContext")
		private ServiceContext serviceContext = new ServiceContext();
	}


	@Data
	public static class RequesterContext {
		@JsonProperty("applicationCode")
		private String applicationCode = "WSM";
		@JsonProperty("applicationSubCode")
		private String applicationSubCode = "OAO";
		@JsonProperty("countryCode")
		private String countryCode;
		@JsonProperty("requesterReferenceNumber")
		private String requesterReferenceNumber;
		@JsonProperty("requestTimeInGMT")
		private String requestTimeInGMT;
		@JsonProperty("requesterUserIdentity")
		private String requesterUserIdentity;
		@JsonProperty("userIPAddress")
		private String userIPAddress;
		@JsonProperty("userIPAddressPortNumber")
		private String userIPAddressPortNumber;
		@JsonProperty("sessionIdentity")
		private String sessionIdentity;

	}

	@Data
	public static class ServiceContext {

		@JsonProperty("serviceVersionNumber")
		private String serviceVersionNumber;

		@JsonProperty("serviceVersionNumber")
		public String getServiceVersionNumber() {
			return "3.0";
		}

	}

	@Data
	public static class RequestBody {
		@JsonProperty("applicationCustomerInformation")
		private ApplicationCustomerInformation applicationCustomerInformation;
		@JsonProperty("customerInformation")
		private CustomerInformation customerInformation;
		@JsonProperty("customerLegalInformation")
		private CustomerLegalInformation customerLegalInformation;
		@JsonProperty("applicationBasicInformation")
		private ApplicationBasicInformation applicationBasicInformation;
		@JsonProperty("transactionInformation")
		private TransactionInformation transactionInformation;
	}

	@Data
	@Builder
	public static class ApplicationCustomerInformation {
		@JsonProperty("leadReferenceNumber")
		private String leadReferenceNumber;
		@JsonProperty("myInfoDetail")
		private MyInfoDetail myInfoDetail;
		@JsonProperty("basicCustomerInformation")
		private BasicCustomerInformation basicCustomerInformation;
	}

	@Data
	@Builder
	public static class MyInfoDetail {
		@JsonProperty("myInfoVerified")
		private String myInfoVerified;

	}

	@Data
	@Builder
	public static class BasicCustomerInformation {
		@JsonProperty("fullName")
		private String fullName;
		@JsonProperty("mobileNumber")
		private String mobileNumber;
		@JsonProperty("emailAddress")
		private String email;
		@JsonProperty("firstName")
		private String firstName;
		@JsonProperty("lastName")
		private String lastName;
		@JsonProperty("countryCode")
		private String countryCode;
		@JsonProperty("idType")
		private String idType;
		@JsonProperty("idNumber")
		private String idNumber;
		@JsonProperty("idCountry")
		private String idCountry;
	}

	@Data
	@Builder
	public static class CustomerInformation {
		@JsonProperty("userIdentity")
		private String userIdentity;
		@JsonProperty("groupIdentity")
		private String groupIdentity;
		@JsonProperty("CIFNumber")
		private String cIFNumber;
		@JsonProperty("ichKey")
		private String ichKey;
		@JsonProperty("segment")
		private String segment;
		@JsonProperty("staffIndicator")
		private String staffIndicator;
	}

	@Data
	@Builder
	public static class CustomerLegalInformation {
		@JsonProperty("legalIdentity")
		private String legalIdentity;
		@JsonProperty("legalIdentityType")
		private String legalIdentityType;
		@JsonProperty("legalIdentityCountry")
		private String legalIdentityCountry;
	}

	@Data
	@Builder
	public static class ApplicationBasicInformation {
		@JsonProperty("productCode")
		private String productCode;
	}

	@Data
	public static class TransactionInformation {
		@JsonProperty("transactionCode")
		private String transactionCode = "OLA27";
		@JsonProperty("transactionGroupCode")
		private String transactionGroupCode = "GOLA13";
		@JsonProperty("moduleCode")
		private String moduleCode = "OLA";
	}

	public static String getDateForInput(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"ddMMyyyy");
		return dateFormat.format(date);
	}
}

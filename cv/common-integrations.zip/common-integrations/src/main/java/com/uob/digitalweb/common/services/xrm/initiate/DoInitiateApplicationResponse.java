package com.uob.digitalweb.common.services.xrm.initiate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.xrm.InitiateApplicationResponse;
import lombok.Data;
import lombok.ToString;

import java.util.StringJoiner;

@Data
@ToString
public class DoInitiateApplicationResponse {
	@JsonProperty("serviceResponseHeader")
	private ServiceResponseHeader serviceResponseHeader;

	@JsonProperty("doInitiateCustomerApplicationResponseBody")
	private InitiateApplicationResponse initiateApplicationResponse;

	@JsonProperty("serviceResponseHeader")
	public ServiceResponseHeader getServiceResponseHeader() {
		return serviceResponseHeader;
	}


	public boolean isError() {
		return !serviceResponseHeader.getResponseContext().getResponseCode()
				.matches("^0+$");
	}

	public String getResponse() {
		return new StringJoiner("-").add(serviceResponseHeader.getResponseContext().getResponseCode())
				.add(serviceResponseHeader.getResponseContext().getResponseDescription()).toString();
	}



	@Data
	public class ServiceResponseHeader {
		@JsonProperty("responseContext")
		private ResponseContext responseContext;
		@JsonProperty("requesterContext")
		private RequesterContext requesterContext;
		@JsonProperty("serviceContext")
		private ServiceContext serviceContext;


	}

	@Data
	public static class ResponseContext {
		@JsonProperty("responseCode")
		private String responseCode;
		@JsonProperty("responseDescription")
		private String responseDescription;
		@JsonProperty("serviceResponseTimeInGMT")
		private String serviceResponseTimeInGMT;

	}

	@Data
	public static class RequesterContext {
		@JsonProperty("requestTimeInGMT")
		private String requestTimeInGMT;
		@JsonProperty("applicationCode")
		private String applicationCode;
		@JsonProperty("applicationSubCode")
		private String applicationSubCode;
		@JsonProperty("requesterReferenceNumber")
		private String requesterReferenceNumber;
		@JsonProperty("countryCode")
		private String countryCode;
		@JsonProperty("sessionIdentity")
		private String sessionIdentity;
		@JsonProperty("userIPAddress")
		private String userIPAddress;
		@JsonProperty("userIPAddressPortNumber")
		private String userIPAddressPortNumber;
		@JsonProperty("requesterUserIdentity")
		private String requesterUserIdentity;

	}

	@Data
	public static class ServiceContext {

		@JsonProperty("serviceVersionNumber")
		private String serviceVersionNumber;

	}

}

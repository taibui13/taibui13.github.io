package com.uob.digitalweb.common.services.xrm.submit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.xrm.SubmitApplicationRequest.*;
import com.uob.pweb.common.framework.xrm.SubmitApplicationRequest;
import lombok.*;

import java.util.List;

@Data
@ToString(includeFieldNames = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DoSubmitCustomerApplicationRequest {

    @JsonProperty("serviceRequestHeader")
    private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();


    @JsonProperty("doSubmitCustomerApplicationRequestBody")
    private DoSubmitCustomerApplicationRequestBody requestBody = new DoSubmitCustomerApplicationRequestBody();

    public DoSubmitCustomerApplicationRequest(SubmitApplicationRequest req) {
        requestBody.setLeadList(req.getLeadList());
        requestBody.setApplicationCustomerInformation(req.getApplicationCustomerInformation());
        requestBody.setCustomerInformation(req.getCustomerInformation());
        requestBody.setTransactionInformation(new TransactionInformation());
        requestBody.setCustomerLegalInformation(new CustomerLegalInformation(null, "SG", "IC"));

    }

    public static DoSubmitCustomerApplicationRequest from(
            SubmitApplicationRequest submitApplication) {
        return new DoSubmitCustomerApplicationRequest(submitApplication);
    }


    @Data
    @Builder
    @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class DoSubmitCustomerApplicationRequestBody {

        @JsonProperty("leadList")
        private List<LeadApplicationInfo> leadList;

        @JsonProperty("applicationCustomerInformation")
        private ApplicationCustomerInformation applicationCustomerInformation;

        @JsonProperty("customerInformation")
        private CustomerInformation customerInformation;

        @JsonProperty("customerLegalInformation")
        private CustomerLegalInformation customerLegalInformation;

        @JsonProperty("transactionInformation")
        private TransactionInformation transactionInformation;
    }

    @Data
    @Builder
    @AllArgsConstructor @NoArgsConstructor
    public static class ServiceRequestHeader {

        @JsonProperty("requesterContext")
        private RequesterContext requesterContext = new RequesterContext();
        @JsonProperty("serviceContext")
        private ServiceContext serviceContext = new ServiceContext();
    }


    @Data
    @Builder
    @AllArgsConstructor @NoArgsConstructor
    public static class RequesterContext {
        @JsonProperty("applicationCode")
        private String applicationCode = "WSM";
        @JsonProperty("applicationSubCode")
        private String applicationSubCode = "OAO";
        @JsonProperty("countryCode")
        private String countryCode;
        @JsonProperty("requesterReferenceNumber")
        private String requesterReferenceNumber;
        @JsonProperty("requestTimeInGMT")
        private String requestTimeInGMT;
        @JsonProperty("requesterUserIdentity")
        private String requesterUserIdentity;
        @JsonProperty("userIPAddress")
        private String userIPAddress;
        @JsonProperty("userIPAddressPortNumber")
        private String userIPAddressPortNumber;
        @JsonProperty("sessionIdentity")
        private String sessionIdentity;

    }

    @Data
    @Builder
    @AllArgsConstructor @NoArgsConstructor
    public static class ServiceContext {

        @JsonProperty("serviceVersionNumber")
        private String serviceVersionNumber;

        @JsonProperty("serviceVersionNumber")
        public String getServiceVersionNumber() {
            return "3.0";
        }

    }

    @Data
    @Builder
    @AllArgsConstructor @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class TransactionInformation {
        @JsonProperty("transactionCode")
        private String transactionCode = "OLA10";
        @JsonProperty("transactionGroupCode")
        private String transactionGroupCode = "GOLA07";
        @JsonProperty("moduleCode")
        private String moduleCode = "OLA";
    }
}

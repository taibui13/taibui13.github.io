package com.uob.digitalweb.common.services.xrm.upload;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.uob.pweb.common.framework.xrm.DocumentUploadRequest;
import com.uob.pweb.common.framework.xrm.DocumentUploadRequest.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

public class DoUploadApplicationAttachmentRequest implements Serializable{


	private static final long serialVersionUID = 1L;

	@JsonProperty("doUploadApplicationAttachmentRequestBody")
	private RequestBody requestBody = new RequestBody();

	@JsonProperty("serviceRequestHeader")
	private ServiceRequestHeader serviceRequestHeader = new ServiceRequestHeader();

	@Data
	public class RequestBody implements Serializable {

		private List<DocumentInformation> documentList;
	}

	public DoUploadApplicationAttachmentRequest(DocumentUploadRequest request) {

		requestBody.setDocumentList(request.getDocumentList());
	}


	public static DoUploadApplicationAttachmentRequest from(
			DocumentUploadRequest request) {
		return new DoUploadApplicationAttachmentRequest(request);
	}

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	public static class ServiceRequestHeader {

		@JsonProperty("requesterContext")
		private RequesterContext requesterContext = new RequesterContext();
		@JsonProperty("serviceContext")
		private ServiceContext serviceContext = new ServiceContext();
	}


	@Data
	@Builder
	@AllArgsConstructor
    @NoArgsConstructor
	public static class RequesterContext {
		@JsonProperty("applicationCode")
		private String applicationCode = "WSM";
		@JsonProperty("applicationSubCode")
		private String applicationSubCode = "OAO";
		@JsonProperty("countryCode")
		private String countryCode;
		@JsonProperty("requesterReferenceNumber")
		private String requesterReferenceNumber;
		@JsonProperty("requestTimeInGMT")
		private String requestTimeInGMT;
		@JsonProperty("requesterUserIdentity")
		private String requesterUserIdentity;
		@JsonProperty("userIPAddress")
		private String userIPAddress;
		@JsonProperty("userIPAddressPortNumber")
		private String userIPAddressPortNumber;
		@JsonProperty("sessionIdentity")
		private String sessionIdentity;

	}

	@Data
	@Builder
	@AllArgsConstructor
    @NoArgsConstructor
	public static class ServiceContext {

		@JsonProperty("serviceVersionNumber")
		private String serviceVersionNumber;

		@JsonProperty("serviceVersionNumber")
		public String getServiceVersionNumber() {
			return "3.0";
		}

	}
}

const GLOBAL_CONFIG = {
    API_PATH: "http://pibtsg95.sg.uobnet.com:7098/creditcards",
    formConfig: "./form.json",
    formConfigID: "./formID.json",
    message: "./msg.json",
    messageID: "./msgID.json"
};

var express = require("express");
var app = express();
var fs = require("fs");
var bodyParser = require("body-parser");
var clone = require("lodash/cloneDeep");
var busboy = require("connect-busboy");
var baseResponse = {status: "00000", errorDesc: null, errors: null, data: null};
const SUCCESS = "00000";
const ERROR = "00101";
app.use(busboy());
app.use(
    bodyParser.urlencoded({
        extended: true
    })
);
app.use(bodyParser.json());

app.use((req, res, next) => {
    console.log(req.body);
    next();
});

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use(express.static("public"));


var application = require("./json/application/index.json");
var save = require("./json/save/index.json");
var sendotp = require("./json/sendotp/index.json");
var verifyotp = require("./json/verifyotp/index.json");
var submitApplication = require("./json/submitApplication/index.json");

app.post("/api/v1/applications/application", function (req, res) {
    console.log('first application');
    return res.end(JSON.stringify(application));
});

app.post("/api/v1/applications/dfgyuukiloi8956y45tuihgm5yijhtugyijopk/save", function (req, res) {
    console.log('application');
    return res.end(JSON.stringify(application));
});

app.post("/api/v1/applications/dfgyuukiloi8956y45tuihgm5yijhtugyijopk/submit", function (req, res) {
    return res.end(JSON.stringify(submitApplication));
});

app.post("/api/v1/credit/sendOtp", function (req, res) {
    return res.end(JSON.stringify(sendotp));
});

app.post("/api/v1/credit/verifyOtp", function (req, res) {
    //return res.status(400).end();
    return res.end(JSON.stringify(verifyotp));
});

app.post("/api/v1/applications/dfgyuukiloi8956y45tuihgm5yijhtugyijopk/document", function (req, res) {
  console.log("fileUpload Called");
  req.pipe(req.busboy);
  req.busboy.on("file", function (fieldname, file, filename) {
      console.log(filename);
      file.on("data", function (data) {
          console.log(data.length);
      });
      var fstream = fs.createWriteStream("./tempFiles/" + filename);
      fstream && file.pipe(fstream);
      fstream.on("close", function () {
          var response = clone(baseResponse);
          response.status = SUCCESS;
          setTimeout(function() {
                return res.status(200).send();
        }, 1000);
          
      });
  });
});


var server = app.listen(9090, function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log("Mock REST API listening at http://%s:%s", host, port);
});

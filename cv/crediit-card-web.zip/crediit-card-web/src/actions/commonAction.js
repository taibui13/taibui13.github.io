import * as types from './actionTypes';
import { Action as basicAction }  from '../containers/basicDetails/modules/responseHandler';
import  { Action as personalAction }  from '../containers/personalDetails/modules/responseHandler';
import  { Action as residentialAction }  from '../containers/residentialDetails/modules/responseHandler';
import  { Action as officeAddressAction }  from '../containers/officeAddress/modules/responseHandler';
import  { Action as workDetailsAction }  from '../containers/workDetails/modules/responseHandler';
import request from '../services/request';
import scrollIntoView from 'scroll-into-view';
import {getURLParameter} from '../common/utils';
import {URL_PARAMS, PAGE} from '../constants/common';
import { mappingtoDataJson } from '../common/mappingData';
import api from '../services/api';

export const getInitialData = (lang) => {
  return (dispatch) => {
    request.getInternal(api.getFormData(lang), {}).then(res => {
      dispatch({type: types.INITIAL_APP_DATA, appData: res.data});
    });
    request.getInternal(api.getMessage(lang), {}).then(res => {
      dispatch({type: types.INITIAL_APP_MSG, msg: res.data});
    })
  };
}

export function getMyInfo() {
  return (dispatch, getState) => {
    request.get(api.getAppication, {}, false).then(res => {
      dispatch({type: basicAction.GET_BASIC_DATA_INFO, data: res.data.basicInfo});
      dispatch({type: personalAction.GET_PERSONAL_DATA_INFO, data: res.data.personalInfo});
      dispatch({type: residentialAction.GET_ADDRESS_DATA_INFO, data: res.data.addresses});
      dispatch({type: officeAddressAction.GET_OFFICE_ADDRESS_DATA, data: res.data.addresses});
      dispatch({type: workDetailsAction.GET_WORK_DEATAIL_DATA, data: res.data.employers});
    })
  };
}

export function firstSubmitPartialApplication(payload, goNextStep) {
  return (dispatch, getState) => {
    request.post(api.firstSubmitPartialApplication, mappingtoDataJson(getState(), getURLParameter), false).then(res => {
      dispatch({type: basicAction.GET_DATA, payload: {field: "id", data:res.data.id}});
      goNextStep();      
    })
  };
}

export function submitPartialApplication(payload, goNextStep) {
  return (dispatch, getState) => {
    request.post(api.submitPartialApplication.replace("{id}", payload.id), mappingtoDataJson(getState(), getURLParameter), false).then(res => {
      goNextStep();      
    })
  };
}

export function submitApplication(payload, goNextStep) {
  return (dispatch, getState) => {
    request.post(api.submitApplication.replace("{id}", payload.id), mappingtoDataJson(getState(), getURLParameter), false).then(res => {
      const productId = getURLParameter(URL_PARAMS.PRODUCT_ID);
      goNextStep({pathname: PAGE.COMPLETE, search: window.location.search, state: { id: res.data.referenceNumber, productId: productId}});      
    })
  };
}

/*eslint-disable*/
export function uploadFile(files, goNextStep) {
  return (dispatch) => {
    dispatch(setLoadingStatus(true));
    let count = 0, completedFile = 0;
    for (const i in files) {
      if(files[i].id && files[i].file) {
         count ++;
         request.uploadFile(api.uploadFile, files[i].file, {id: files[i].id, docType: files[i].docType}, {}).then(res => {
          if(res && res.upload) {
            completedFile ++;
            if(count === completedFile) {
              dispatch(setLoadingStatus(false));
              goNextStep && goNextStep();
            }
          }
        });
      }
    } 
  };
}

export function uploadFileNoRequestAPI(files, goNextStep) {
  return (dispatch) => {
    goNextStep && goNextStep();
  };
}

export const setErrorMessage = (messageContent, errorType='error') => {
  return (dispatch) => {
    dispatch({
      type: types.SET_ERROR_CONTENT_MESSAGE,
      messageContent,
      errorType
    })
  };
}

export const setInlineErrorMessage = (inlineMessage) => {
  return {
    type: types.SET_INLINE_ERROR_MESSAGE,
    inlineMessage
  }
}

//set loading status
export const setLoadingStatus = (isLoading) => {
  return (dispatch) => {
    dispatch({
      type: types.SET_APP_LOADING_STATUS,
      isLoading
    });
  };
}


export const setJWTToken = (accessToken) => {
  return {
    type: types.SET_JWT_TOKEN,
    accessToken
  }
}

export const changeCurrentStep = (step) => {
  return (dispatch) => {
    dispatch({
      type: types.CHANGE_CURRENT_STEP,
      step
    });
  };
};

export const scrollBackToSection = (nextStep, section) => {
  return (dispatch) => {
    Promise.resolve().then(() => {
      const element = document.querySelector(`[id='${section}']`);
      scrollIntoView(element, {time: 500, align: {top: 0}});
    });
  }
}

export const scrollToSection = (nextStep, section) => {
  return (dispatch) => {
    Promise.resolve().then(() => {
      dispatch(changeCurrentStep(nextStep));
    }).then(() => {
      const element = document.querySelector(`[id='${section}']`);
      scrollIntoView(element, {time: 500, align: {top: 0}});
    });
  }
}


export const handleChangeData = (hander, payload) => {
  return (dispatch) => {
    dispatch({type: hander, payload: payload});
  };
}


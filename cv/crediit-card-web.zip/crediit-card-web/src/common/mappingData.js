
import {URL_PARAMS} from '../constants/common';

export const mappingtoDataJson = (state, getParams) => {
    let obj = {};
    let addresses = [];
    let employers = [];
    let productInfo = {
        promotionCode: getParams(URL_PARAMS.PROMOTION_CODE),
        channelCode: getParams(URL_PARAMS.CHANNEL_CODE),
        campaignCode: getParams(URL_PARAMS.CAMPAIGN_CODE),
        productId: getParams(URL_PARAMS.PRODUCT_ID),
        mediaType:  getParams(URL_PARAMS.MT),
        mediaSource:  getParams(URL_PARAMS.MS),
        refferalUrl: window.location.href
    }
    let basicInfo = {
        names: {
                firstName: state.basicDetailReducer.firstName.value,
                lastName:  state.basicDetailReducer.lastName.value,
                fullName: state.basicDetailReducer.otherName.value,
                alias: state.basicDetailReducer.alias.value
        },
        legalIdType: state.basicDetailReducer.idType.value,
        legalId: state.basicDetailReducer.idType.value === "IC" ? state.basicDetailReducer.nationID.value : state.basicDetailReducer.passportNumber.value,
        legalIdIssueCountry: state.basicDetailReducer.passpordIssueCountry.value ? state.basicDetailReducer.passpordIssueCountry.value : "ID",
        legalIdExpiryDate: state.basicDetailReducer.passportExpireDate.value,
        prIndicator: state.basicDetailReducer.isPermanantResident ? "Y" : "N",
        emailAddress: state.basicDetailReducer.emailAddress.value,
        mobileNumber: state.basicDetailReducer.mobileNumber.value.replace(/\+|\s+/g, ''),
        homeNumber:  state.basicDetailReducer.homeNumber.value.length > 4 ? state.basicDetailReducer.homeNumber.value.replace(/\+|\s+/g, '') : "",
        residentialStatus: state.basicDetailReducer.isPermanantResident.value,
        dateOfBirth: state.basicDetailReducer.dateOfBirth.value,
        currentCity: state.basicDetailReducer.city.value,
        savingAccIndicator: state.basicDetailReducer.hasUOBAccount.value ? "Y" : "N"
    };
   
    let personalInfo = {
        gender: state.personalDetailsReducer.gender.value,
        maritalStatus: state.personalDetailsReducer.marital.value,
        educationLevel: state.personalDetailsReducer.education.value,
        nationality: state.personalDetailsReducer.nationality.value,
        placeOfBirth: state.personalDetailsReducer.placeOfBirth.value,
        mothersMaidenName: state.personalDetailsReducer.motherName.value,
        noOfDependants: state.personalDetailsReducer.numberOfDependent.value,
    };
    let address = {
        type: "REG",
        addressLine1: state.residentialDetailsReducer.addressComplex.value,
        addressLine2: state.residentialDetailsReducer.addressComplexStreet.value,
        addressLine3: state.residentialDetailsReducer.addressComplexKelurahan.value,
        city: state.residentialDetailsReducer.city.value,
        province: state.residentialDetailsReducer.province.value,
        postalCode: state.residentialDetailsReducer.postalCode.value,
        residentialStatus: state.residentialDetailsReducer.residenceStatus.value,
        lengthOfResidence: state.residentialDetailsReducer.lengthOfResidence.value,
        mailingIndicator: (state.officeAddressReducer.mailToLocation.value === "N" && !state.residentialDetailsReducer.otherAddress) ? "Y" : "N"
    }
    addresses.push(address);
    if(state.residentialDetailsReducer.otherAddress) {
        addresses.push({
            type: "RES",
            addressLine1: state.residentialDetailsReducer.otherAddressComplex.value,
            addressLine2: state.residentialDetailsReducer.otherAddressComplexStreet.value,
            addressLine3: state.residentialDetailsReducer.otherAddressComplexKelurahan.value,
            city: state.residentialDetailsReducer.otherCity.value,
            province: state.residentialDetailsReducer.otherProvince.value,
            postalCode: state.residentialDetailsReducer.otherPostalCode.value,
            mailingIndicator: state.officeAddressReducer.mailToLocation.value === "N" ? "Y" : "N"
        });
    }
    let officeAddress = {
        type: "OFC",
        addressLine1: state.officeAddressReducer.addressComplex.value,
        addressLine2: state.officeAddressReducer.addressComplexStreet.value,
        addressLine3: state.officeAddressReducer.addressComplexKelurahan.value,
        city: state.officeAddressReducer.city.value,
        province: state.officeAddressReducer.province.value,
        postalCode:state.officeAddressReducer.postalCode.value,
        mailingIndicator: state.officeAddressReducer.mailToLocation.value || "N"
    }
    addresses.push(officeAddress);
    let worKDetail = {
        type: "C",
        natureOfEmployment: state.workDetailsReducer.natureOfEmployment.value,
        jobTitle: state.workDetailsReducer.jobTitle.value,
        companyName: state.workDetailsReducer.companyName.value,
        industry: state.workDetailsReducer.industry.value,
        lengthOfEmployment: state.workDetailsReducer.lengthOfEmploymentAndBusiness.value,
        noOfEmployees: state.workDetailsReducer.numberOfEmployee.value,
        entityType: state.workDetailsReducer.entityType.value,
        officeNumber: state.workDetailsReducer.officeNumber.value.replace(/\+|\s+/g, ''),
        officeExt: state.workDetailsReducer.officeExtension.value,
        grossMonthIncome: state.workDetailsReducer.grossMonthlyIncome.value
    }
    employers.push(worKDetail); 
    employers.push({
        type: "P",
        companyName: state.workDetailsReducer.previousCompany.value,
        lengthOfEmployment: state.workDetailsReducer.previousLengthOfEmployment.value
    });
    let declaration = {
        autoPayIndicator: state.summaryReducer.isAutoPay ? "Y" : "N",
        payMinorFull: state.summaryReducer.payMinimum.value,
        uobDebitAccNo: state.summaryReducer.debitingAccount.value,
        creditShieldIndicator: state.summaryReducer.isCreditShield ? "Y" : "N",
        tncIndicator: state.summaryReducer.isConfirm.value ? "Y" : "N",
        dncIndicator: state.summaryReducer.isAgreeConfirm.value ? "Y" : "N",
    };
        
    obj.id = state.basicDetailReducer.id || "";
    obj.lang = getParams(URL_PARAMS.LANG) === "en" ? "en" : "bh";
    obj.productInfo = productInfo;
    obj.basicInfo = basicInfo;
    obj.personalInfo = personalInfo;
    obj.addresses = addresses;
    obj.employers = employers;
    obj.declaration = declaration;
    return obj;
}
import store from '../store/configureStore';

export const getMsgError = (data) => {
  return store.getState().commonReducer.msg;
}
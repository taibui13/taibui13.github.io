import {validateFilledInput, checkSize, isValidDate, checkMaximumAge, checkMinimumAge, checkMinimumMonth} from './validations';

const AGE = {LENGTH: 10, MIN: 21, MAX: 65, FORMAT: "DD/MM/YYYY"};
const PASSPORT = {LENGTH: 10, MIN_MONTH_EXPIRE: 6, FORMAT: "DD/MM/YYYY"};

const birthdayValidations = [validateFilledInput, checkSize.bind(this, AGE.LENGTH), isValidDate.bind(this, AGE.FORMAT), checkMinimumAge.bind(this, AGE.MIN), checkMaximumAge.bind(this, AGE.MAX)];
const passportValidations = [validateFilledInput, checkSize.bind(this, PASSPORT.LENGTH), isValidDate.bind(this, PASSPORT.FORMAT), checkMinimumMonth.bind(this, PASSPORT.MIN_MONTH_EXPIRE)];

export default  {
    birthdayValidations: birthdayValidations,
    passportValidations: passportValidations
}
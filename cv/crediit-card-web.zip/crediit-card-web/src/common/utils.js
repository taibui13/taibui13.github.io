
import { getMsgError } from '../common/message';
export const mapValueToLabel = (arrayOfItems, value) => {
  const item = arrayOfItems.find(x => x.value === value);
  return item ? item.description : value;
};

export const imageExists = (url, callback) => {
  var img = new Image();
  img.onload = function() { callback(true); };
  img.onerror = function() { callback(false); };
  img.src = url;
}

export const bytesToSize = bytes => {
    var sizes = ["Bytes", "KB", "MB", "GB", "TB"];
    if (bytes === 0) {
        return "0 Byte";
    }
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
    return Math.round(bytes / Math.pow(1024, i), 2) + " " + sizes[i];
};

export const sendDataToSparkline = (stepNo, productID, referenceNo = '', isStart = false, isSubmit = false) => {
    if (window._satellite) {
      const pid = 'UOBI Instant Approval';
      const flow = 'NTB';
      if (!window.dataElement) {
        window.dataElement = {};
      }
  
      const dataElement = window.dataElement || {};
      if (isStart) {
        dataElement.event_name = `form_start`;
      } else if (isSubmit) {
        dataElement.event_name = `form_submit`;
      } else {
        dataElement.event_name = `form_complete_step${stepNo}`;
      }
      dataElement.product_id = productID;
      dataElement.product_name = pid;
      dataElement.user_type = flow;
      dataElement.product_category = 'UOBI';
      dataElement.myInfo = 'form_myinfo';;
      if (isSubmit) {
        dataElement.transaction_id = referenceNo;
      }
      window.dtmCustomEventName = dataElement.event_name.replace(/[0-9]+$/, "");
      window._satellite.track(window.dtmCustomEventName);
    }
  };

export const detectPathName = () => {
    const router = ['complete'];
    let pn = window.location.pathname;
    return pn.replace(router.filter(a => pn.indexOf(a) !== -1)[0], "");
};

export const convertObjToArray = (obj, objKey, objValue) => {
    const arr = [];
    Object.keys(obj).map(key => arr.push({ [objKey]: key, [objValue]: obj[key]}));
    return arr;
  };

export const getIndexObject = (obj, key) => {
    return  Object.values(obj).indexOf(key);
}

export const getURLParameter = (name) => {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=([^&;]+?)(&|#|;|$)').exec(window.location.search) || [null, ''])[1].replace(/\+/g, '%20')) || '';
}

export const checkRequiredFields = (fields, action, error, validFields) => {
    let isRequired = false;
    fields.forEach(obj => {
        if(obj.isInitial || (obj.value && obj.value.length < 4 && obj.type === "Phone")) {
          action && action({obj, field: obj.name, errorMsg: error || getMsgError().isRequire});
          isRequired = true;   
        }
        if(!obj.isValid) {
            action && action({obj, field: obj.name, errorMsg: obj.errorMsg});
            isRequired = true;
        }
    });
    (validFields || []).forEach(obj => {
        if(!obj.isValid) {
            isRequired = true;
        }
    })
    return isRequired;
}

export const checkRequiredSection = (fields) => {
    let isRequired = false;
    fields.forEach(obj => {
        if(obj.isInitial || (obj.value && obj.value.length < 4 && obj.type === "Phone")) {
          isRequired = true;   
        }
        if(!obj.isValid) {
            isRequired = true;
        }
    });
    return isRequired;
}

export const resetRequiredFields = (fields, action) => {
    fields.forEach(obj => {
          obj.isValid = true;
          obj.errorMsg = "";
          obj.value = "";   
          obj.isInitial = true;   
          action({field: obj.name, data: obj});
    });
}

export const resetMessageError = (fields, action) => {
    fields.forEach(obj => {
          obj.errorMsg = "";
          obj.isValid = true;
          action({field: obj.name, data: obj});
    });
}

export const resetInputFile = (fields, action) => {
    fields.forEach(obj => {
        obj.fileSize = "";
        obj.inputValue = "";
        obj.progress = "";
        obj.errorMsg = "";
        obj.isValid = true;
        obj.isInitial = true;
        action({field: obj.name, data: obj});
    });
}
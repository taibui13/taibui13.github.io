import { isValidNumber } from 'libphonenumber-js';
import moment from 'moment';
import { getMsgError } from '../common/message';

const sumOfICWithWeightFactor = icNoArray => {
    const weight = [2, 7, 6, 5, 4, 3, 2];
    return icNoArray.map((x, i) => x * weight[i]).reduce((s, v) => s + v, 0);
};

const getICLastLetter = icArray => {
    const mapLetter = ["J", "A", "B", "C", "D", "E", "F", "G", "H", "I", "Z", "J"];
    const icNoArray = icArray.slice(1, -1);
    const total = icArray[0] === "S" ? sumOfICWithWeightFactor(icNoArray) : sumOfICWithWeightFactor(icNoArray) + 4;
    const checkDigit = 11 - total % 11;
    return mapLetter[checkDigit];
};

const validateNRIC = ic => {
    const icArray = ic.split("");
    const icLastLetter = getICLastLetter(icArray);
    const icRegExp = new RegExp(`[S|T][0-9]{7}[${icLastLetter}]`, "g");
    return icRegExp.test(ic);
};

const isNRIC = ic => ic.split("")[0] === "S" || ic.split("")[0] === "T";

const validateTNRIC = ic => {
  const icArray = ic.split("");
  const icLastLetter = getICLastLetter(icArray);
  const icRegExp = new RegExp(`[T][0-9]{7}[${icLastLetter}]`, "g");
  return icRegExp.test(ic);
};

const validateMalaysianIC = value => {
  const regex1 = /^\d{12}$/;
  const regex2 = /^\d{7}$/;
  const regex3 = /^[A-Z]\d{6}$/;
  const regex4 = /^[A-Z]\d{7}$/;
  const regex5 = /^[A-Z]\d{9}$/;
  const testRegexp = value.length === 0 || regex1.test(value) || regex2.test(value) || regex3.test(value) || regex4.test(value) || regex5.test(value);

  return testRegexp;
};

export const validateNRICAndPassport = value => {
  const status = isNRIC(value) ? validateNRIC(value) : true;
  const errorMsg = status ? "" : getMsgError().invalidNRIC;
  return {status, errorMsg};
};

export const checkNRICOrMalaysianIC = value => {
  const status = validateNRIC(value) || validateMalaysianIC(value);
  const errorMsg = status ? "" : getMsgError().invalidNRIC;
  return {status, errorMsg};
};

export const validateOnlYTNRIC = value => {
  const status = validateTNRIC(value);
  const errorMsg = status ? "" : getMsgError().invalidNRIC;
  return {status, errorMsg};
};
export const validatePhoneNumber = (value, maxLenth) => {
  let status = true;
  let errorMsg = "";
  if(value.length >= 3 && value.substr(0,3) !== "+62") {
    status = false;
    errorMsg = getMsgError().allowIndonesiaNumber;
    return {status, errorMsg};
  }
  if(maxLenth && value.replace(/\s+/g, '').length > Number(maxLenth) + 2) {
      status = false;
      errorMsg = getMsgError().invalidMaxSize.replace("{size}", maxLenth);
      return {status, errorMsg};
  }
  if(maxLenth && value.replace(/\s+/g, '').length < 8) {
    status = isValidNumber(value);
  }
  errorMsg = status ? "" : getMsgError().invalidPhone;
  return {status, errorMsg};
};
export const validateFilledInput = value => {
  const status = value.trim().length > 0;
  const errorMsg = status ? "" : getMsgError().fieldEmpty;
  return {status, errorMsg};
};

export const checkFullName = value => {
    const regex = /^([a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-])+$/;
    const testRegexp = regex.test(value);
    const errorMsg = testRegexp ? "" : getMsgError().invalidName;

    return {status: testRegexp, errorMsg};
};

export const checkNumbers = value => {
    const regex = /^([0-9])+$/;
    const testRegexp = value.length === 0 || regex.test(value);
    const errorMsg = testRegexp ? "" : getMsgError().numbersOnly;

    return {status: testRegexp, errorMsg};
};

export const checkAddress = value => {
    const regex = /^([0-9 a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-])+$/;
    const testRegexp = regex.test(value);
    const errorMsg = testRegexp ? "" : getMsgError().invalidAddress;

    return {status: testRegexp, errorMsg};
};

export const checkEmail = value => {
    const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const testRegexp = regex.test(value);
    const errorMsg = testRegexp ? "" : getMsgError().invalidEmail;

    return {status: testRegexp, errorMsg};
};

export const checkDateOfBirthFormat = value => {
    const regex = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)\d{2})$/;
    const testRegexp = regex.test(value);
    const errorMsg = testRegexp ? "" : getMsgError().invalidDate;

    return {status: testRegexp, errorMsg};
};

export const checkMaxSize = (maxSize, value) => {
  const status = value.length <= parseInt(maxSize, 10);
  const errorMsg = status ? "" : getMsgError().invalidMaxSize.replace("{size}", maxSize);

  return {status, errorMsg};
};

export const checkMinSize = (minSize, value) => {
  const status = value.length >= parseInt(minSize, 10);
  const errorMsg = status ? "" : getMsgError().invalidMinSize.replace("{size}", minSize);
  return {status, errorMsg};
};

export const checkSize = (maxSize, value) => {
  const status = value.length === parseInt(maxSize, 10);
  const errorMsg = status ? "" : getMsgError().exactSize.replace("{size}", maxSize);
  return {status, errorMsg};
};

export const checkRange = (minSize, maxSize, value) => {
  const status = value.length >= parseInt(minSize, 10) && value.length <= parseInt(maxSize, 10);
  const errorMsg = status
      ? ""
      : getMsgError().invalidRange.replace("{minSize}", minSize).replace("{maxSize}", maxSize);

  return {status, errorMsg};
};

export const checkDateNotOverTodayDate = value => {
  const dateEntered = moment(value, "DD-MM-YYYY").format("YYYY-MM-DD");
  const dateNow = moment().format("YYYY-MM-DD");
  const status = moment(dateEntered).isSameOrBefore(dateNow);
  const errorMsg = status ? "" : getMsgError().yearExceeded;

  return {status, errorMsg};
};

export const checkMaximumAge = (maxAge, value) => {
  const dob = moment(value, "DD-MM-YYYY").add(maxAge, "years");
  const benchmarkDate = moment();
  const status = dob.isSameOrAfter(benchmarkDate);
  const errorMsg = status ? "" : getMsgError().maxAge.replace("{maxAge}", maxAge);

  return {status, errorMsg};
};

export const checkMinimumAge = (minAge, value) => {
  const dob = moment(value, "DD-MM-YYYY");
  const benchmarkDate = moment().subtract(minAge, "years");
  const status = dob.isSameOrBefore(benchmarkDate, "days");
  const errorMsg = status ? "" : getMsgError().minAge.replace("{minAge}", minAge);

  return { status, errorMsg };
};

export const noValidation = value => {
  const status = value.length === 0 || (value.length > 0 && value.trim().length === value.length);
  const errorMsg = status ? "" : getMsgError().noSpaceAllowed;
  return {status, errorMsg};
};

export const checkKrisFlyer = number => {
  const modulus = parseInt(number.substr(0, 9), 10) % 7 + 3;
  const lastNumber = parseInt(number.substr(9, number.length), 10);
  const status = modulus === lastNumber;
  const errorMsg = status ? "" : getMsgError().invalidKrisFlyer;

  return {status, errorMsg};
};

export const onlyLettersAndSpace = value => {
  const regex = /^[a-zA-Z\s]*$/;
  const testRegexp = value.length === 0 || regex.test(value);
  const errorMsg = testRegexp ? "" : getMsgError().invalidCharacters;

  return {status: testRegexp, errorMsg};
};

export const onlyAlphanumeric = value => {
  const regex = /^[a-z0-9\s]+$/i;
  const testRegexp = value.length === 0 || regex.test(value);
  const errorMsg = testRegexp ? "" : getMsgError().onlyAlphanumeric;

  return {status: testRegexp, errorMsg};
};

export const checkMaxMonths = value => {
  const status = value <= 11;
  const errorMsg = status ? "" : "Maximum 11 months";

  return {status, errorMsg};
};

export const personalLoanMinAmount = (minAmt, value) => {
  const status = Number(value) >= (minAmt || 10000);
  const errorMsg = status ? "" : getMsgError().plMinAmount.replace("{minAmt}", Number(minAmt).toLocaleString());

  return {status, errorMsg};
};

export const balanceTransferMinAmount = (minAmt, value) => {
  const status = Number(value) >= (minAmt || 10000);
  const errorMsg = status ? "" : getMsgError().btMinAmount.replace("{minAmt}", Number(minAmt).toLocaleString());

  return {status, errorMsg};
};

export const minMonth = (minAmt, value) => {
  const status = Number(value) >= minAmt ;
  const errorMsg = status ? "" : getMsgError().minMonth.replace("{minMonth}", Number(minAmt).toLocaleString());

  return {status, errorMsg};
};

export const maxMonth = (maxAmt, value) => {
  const status = Number(value) <= maxAmt ;
  const errorMsg = status ? "" : getMsgError().maxMonth.replace("{maxValue}", Number(maxAmt).toLocaleString());

  return {status, errorMsg};
};

export const isValidDate = (formateDate, value) => {
  let status = true;
  let errorMsg = "";
  if(value.length === 10 && !moment(value, "DD/MM/YYYY")._isValid) {
    status = false;
    errorMsg = getMsgError().formatDate.replace("{formatDate}", formateDate);;
  }
  return {status, errorMsg};
};

export const checkDateFormat =(value) => {
    const regex = /(^\d{2}\/\d{2}\/\d{4}$)/;
    const testRegexp = regex.test(value);
    const errorMsg = testRegexp ? "" : getMsgError().invalidDate;

    return {status: testRegexp, errorMsg};
};

export const validateMobileNumber = value => {
  const regex = /^[89]\d{7}$/;
  const testRegexp = regex.test(value);
  const errorMsg = testRegexp ? "" : getMsgError().invalidMobile;
  return {status: testRegexp, errorMsg};
};

export const checkMinimumMonth = (minMonth, value) => {
  const dateNow = moment().format("YYYY-MM-DD");
  const benchmarkDate = moment(value, "DD-MM-YYYY").subtract(minMonth, "months").format("YYYY-MM-DD");
  const status = moment(dateNow).isSameOrBefore(benchmarkDate);
  const errorMsg = status ? "" : getMsgError().minMonth.replace("{minMonth}", minMonth);
  return { status, errorMsg };
};


export const validators = (rules, value) => {

  for (let i = 0; i < rules.length; i++) {
    const oneRule = rules[i];
    const ruleArray = oneRule.split("|");
    const rule = ruleArray[0];
    if (rule === 'required') {
      let result = validateFilledInput(value);
      if (result.status)
        continue;
      return result;
    } else if (rule === 'isAlphanumeric') {
      let result = onlyAlphanumeric(value);
      if (result.status)
        continue;
      return result;
    } else if (rule === 'isEmail') {
      let result = checkEmail(value);
      if (result.status)
        continue;
      return result;
    } else if (rule === 'isNumber') {
      let result = checkNumbers(value);
      if (result.status)
        continue;
      return result;
    } else if (rule === 'isNRIC') {
      let result = validateNRICAndPassport(value);
      if (result.status)
        continue;
      return result;
    } else if (rule === 'isPhoneNumber') {
      let result = validatePhoneNumber(value, ruleArray[1]);
      if (result.status)
        continue;
      return result;
    }  else if (rule === 'exactSize') {
      let result = checkSize(ruleArray[1],value);
      if (result.status)
        continue;
      return result;
    }  else if (rule === 'maxSize') {
      let result = checkMaxSize(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    }  else if (rule === 'minSize') {
      let result = checkMinSize(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    }  else if (rule === 'onlyLettersAndSpace') {
      let result = onlyLettersAndSpace(value);
      if (result.status)
        continue;

      return result;
    }  else if (rule === 'isFullName') {
      let result = checkFullName(value);
      if (result.status)
        continue;

      return result;
    }  else if (rule === 'isMobileNumber') {
      let result = validateMobileNumber(value, ruleArray[1]);
      if (result.status)
        continue;

      return result;
    } else if (rule === 'notTodayDate') {
      let result = checkDateNotOverTodayDate(value);
      if (result.status)
        continue;

      return result;
    } else if (rule === 'checkDateFormat') {
      let result = checkDateFormat(value);
      if (result.status)
        continue;

      return result;
    } else if (rule === 'minMonth') {
      let result = minMonth(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    } else if (rule === 'maxMonth') {
      let result = maxMonth(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    } else if (rule === 'checkMinimumMonth') {
      let result = checkMinimumMonth(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    } else if (rule === 'isNRICOrMalaysianIC') {
      let result = checkNRICOrMalaysianIC(value);
      if (result.status)
        continue;

      return result;
    }  else if (rule === 'minAmount') {
      let result = balanceTransferMinAmount(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    }
    else if (rule === 'isValidDate') {
      let result = isValidDate(ruleArray[1],value);
      if (result.status)
        continue;

      return result;
    }
  }
  return {status: true, errorMsg: ''};
}

export const validateConditions = (validators, value) => {
  let result = {status: true, errorMsg: ''};
  for (let i = 0; i < validators.length; i++) {
      const obj = validators[i](value);
      if(!obj.status) {
        result = obj;
        break;
      }
  }
  return result;
}

export const addValidations = (arr, ...newArr) => {
  return arr.concate(newArr);
}


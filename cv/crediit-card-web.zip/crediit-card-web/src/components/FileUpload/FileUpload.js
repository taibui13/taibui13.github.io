import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './FileUpload.css';
import {bytesToSize} from './../../common/utils';
import pdfUrl from '../../assets/images/icon/pdf-file.svg';
import PreviewFile from '../PreviewFile/PreviewFile';
const FILE_TYPE = {type: (type) => ['application/pdf'].indexOf(type) > -1 ? "PDF" : "IMAGE"}
const FileUploadContainer = props => {
    const {
      inputStatus,
      progressValue,
      handleUploadFile,
      labelName,
      inputID,
      getFile,
      handleError,
    } = props;
    const checkInputStatus = inputStatus ? inputStatus : 'none';
    const isFileSelected = progressValue > 0 ? " selected" : "";
    let fileInputRef = null;
    const checkFileExtension = (file, allowedExtensions) => allowedExtensions.includes(file.split(".").pop());

    const handleOnChange = () => {
        const file = fileInputRef.files[0];
        const extensionIsAllowed = checkFileExtension(file.name, ["jpg", "png", "pdf", "JPG", "PNG", "PDF"]);
        if (extensionIsAllowed) {
            if (file.size <= 3145728) {
                handleUploadFile(file, bytesToSize(file.size));
                getFile(fileInputRef);
            } else {
                handleError()
            } 
        } 
    };
   
    return (
        <div className="file-upload-button">
            <div className={isFileSelected ? isFileSelected: "process"}> </div>
            <label htmlFor={"file_" + inputID} className='file-upload-button--text'>
                {checkInputStatus === "none" ? labelName : "EDIT"}
            </label>
            <input id={"file_" + inputID}  className='file-upload-input' accept='.jpg,.JPG,.png,.pdf,.PDF,.PNG'
                ref={i => {fileInputRef = i;}} type='file'
                onClick={() => { fileInputRef.value = null;}}
                onChange={handleOnChange}
            />
        </div>
    );
};

class FileUpload extends Component {
    constructor(props) {
        super(props);
        this.state = {file: '', imagePreviewUrl: '', isShow: false, isValidFile: true};
      }

    readFile(file) {
        let reader = new FileReader();
        reader.onloadend = (e) => {
        this.setState({
            file: file.files[0],
            imagePreviewUrl: e.target.result,
            isValidFile : true
          });
        }
        reader.readAsDataURL(file.files[0])
    }

    showContent() {
        const {isShow} = this.state;
        if(this.props.isDisplayDetail) {
            this.setState({isShow: !isShow});
        }
    }

    removeFile() {
        this.setState({file: '', imagePreviewUrl: '', isShow: false});
        this.props.handleUploadFile(this.props.inputID, "", 0, []);
        document.getElementById(`file_input_${this.props.inputID}`).value= null;
    }

    handleError() {
        this.setState({isValidFile: false});
    }
    
    render() {
        const {
            fileSize,
            inputValue,
            description,
            inputID,
            title,
            errorMsg,
            isValid,
            isDisabled
          } = this.props;
          const {imagePreviewUrl, isShow, file, isValidFile} = this.state;
          const showErrorLabel = (isValid && isValidFile)  ? "" : "file-upload--error";
          const fileSizeString = fileSize ? " - " + fileSize : "";
          const descriptionContent = inputValue ? inputValue.replace(/^.*[\\]/, "") + fileSizeString : description;
          const errorContainerStyle = (isValid && isValidFile) ? "" : "file-upload--container--error";
          const msg = !isValidFile ? errorMsg[1] : errorMsg[0];
        return (
            <div id={`file_input_${inputID}`} className="file-upload">
            <div className={`file-upload--container ${errorContainerStyle} ${isDisabled && "file-upload-disabled"}`}>
              <div className="file-upload--file">  
              <div className="file-upload--file--icon">
                {
                    FILE_TYPE.type(file.type) === "IMAGE" && imagePreviewUrl &&
                    <img className="image" onClick={this.showContent.bind(this)}  src={imagePreviewUrl}  alt="#"/>
                }
                {
                    FILE_TYPE.type(file.type) === "PDF" && imagePreviewUrl &&
                    <img className="pdf" onClick={this.showContent.bind(this)} src={pdfUrl}  alt="#" />
                }
                </div>
                <div className='file-upload--text-container'>
                <div className={"file-upload--title " + showErrorLabel}>
                    {`${title}${(isValid && isValidFile) ? "" : ` ${msg}`}`}
                </div>
                <div className='file-upload--description'>
                {
                    inputValue ? <a className='file-upload--name-title' onClick={this.showContent.bind(this)}> {descriptionContent} </a>
                            : <a > {descriptionContent} </a>
                }
                
                </div>
            </div>
            </div>
            <div className='file-upload--button-container'>
                <FileUploadContainer getFile={this.readFile.bind(this)} handleError={this.handleError.bind(this)} {...this.props} />
            </div>
            </div>
            <div>
                {   
                    isShow && imagePreviewUrl &&
                    <PreviewFile name={file.name} content={imagePreviewUrl} type={FILE_TYPE.type(file.type)} show={this.showContent.bind(this)} />
                }
                </div>    
            </div> 
        );
    }

}

FileUpload.propTypes = {
    inputID: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    dispatchUploadFile: PropTypes.func,
    dispatchShowErrorMsg: PropTypes.func,
    dispatchupdateUploadProgress: PropTypes.func
};


export default FileUpload;

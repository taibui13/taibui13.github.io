import React from 'react';
import PropTypes from 'prop-types';

import './GenderSelection.css';

import nonEditableImg from './../../assets/images/icon/non-editable-icon4.svg';
import iconMale from './../../assets/images/icon/icon-male.svg';
import iconFemale from './../../assets/images/icon/icon-female.svg';

const GenderSelection = props => {
  const { gender, isValid, errorMsg, isReadOnly, onClick, labelMale, labelFemale } = props;
    const readOnlyClass = isReadOnly ? "single-selection-input--readonly" : "";
    const errorContainerStyle =  isValid ? "" : "single-selection-input--error";
    const showErrorLabel = isValid ? "" : "GenderSelectionLabel--error";
    return (
        <div className={`single-selection-input--focused ${readOnlyClass} ${errorContainerStyle}`}>
            <div className='single-selection-input-title-container'>
                <div className={"single-selection-input-title " + showErrorLabel}>
                    {`Gender${isValid ? "" : ` ${errorMsg}`}`}
                </div>
                {isReadOnly &&
                    <img
                        className='read-only-single-selection-input--verified-icon'
                        src={nonEditableImg}
                        alt='verified-icon'
                    />}
            </div>

            <div className='single-selection-input-container'>
                <div
                    className={
                        gender === "M" ? "single-selection-input-button--selected" : "single-selection-input-button"
                    }
                    onClick={() => {
                        onClick("M");
                    }}
                >
                    <div className='single-selection-input-button-content'>
                        <img
                            src={iconMale}
                            className='single-selection-input-button-icon'
                            alt='gender-male'
                        />
                        {labelMale}
                    </div>
                </div>
                <div
                    className={
                        gender === "F" ? "single-selection-input-button--selected" : "single-selection-input-button"
                    }
                    onClick={() => {
                        onClick("F");
                    }}
                >
                    <img
                        src={iconFemale}
                        className='single-selection-input-button-icon'
                        alt='gender-female'
                    />
                    {labelFemale}
                </div>
            </div>
        </div>
    );
};

GenderSelection.propTypes = {
    onClick: PropTypes.func.isRequired
};

export default GenderSelection;

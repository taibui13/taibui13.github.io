import React from 'react';
import './PDFViewer.css';
//import pdfjsLib from 'pdfjs-dist';
let thePdf = null;
let scaleView = 1.5;

class PDFViewer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          pageNum: 1,
          pdfData: null
        }
        this.id = Math.floor(Math.random() * (9999999999 - 1000000000) + 1000000000);
        this.CANVAS_ID = this.id + '-pdf-page-canvas-';
        this.currentPage = 1;
        this.name = "";
        this.scrollHeight = 0;
    }

    componentWillMount() {
      const { content, scale, name } = this.props;
      this.name = name;
      this.readFile(content, scale);
    }

    componentWillReceiveProps(props) {
      const { content, scale, name } = props;
      if(this.name && this.name !== name) {
        this.readFile(content, scale);
      }
    }

    readFile(content, scale) {
      const arr = content.split(",");
      scaleView = scale || scaleView;
      const pdfData = window.atob(arr[1]);
      const _this = this;
      /*
      pdfjsLib.GlobalWorkerOptions.workerSrc = require('./lib/pdf.worker.js');
      const loadingTask = pdfjsLib.getDocument({data: pdfData});
      loadingTask.promise.then(function(pdf) {
        thePdf = pdf;
        let viewer = document.getElementById(_this.id + "-pdf-viewer");
        while(viewer.firstChild){
          viewer.removeChild(viewer.firstChild);
        }
        _this.setState({ pdfData: pdf });
        for(let page = 1; page <= pdf.numPages; page++) {
         let canvas = document.createElement("canvas");    
          canvas.id = _this.CANVAS_ID + page;        
          viewer.appendChild(canvas);           
          _this.renderPage(page, canvas);
        }
      }, function () {
      // PDF loading error
      });
      */
    }


    onPrevPage = () => {
      let {pageNum} = this.state;
      if (pageNum <= 1) {
        return;
      }
      pageNum --;
      this.scrollToPageNumber(pageNum)
      this.setState({ pageNum: pageNum });
    }

    onNextPage = () => {
      let {pageNum, pdfData} = this.state;
      if (pageNum >= pdfData.numPages) {
        return;
      }
      pageNum ++;
      this.scrollToPageNumber(pageNum)
      this.setState({ pageNum: pageNum });
    }

    scrollToPageNumber(count) {
      const canvas = document.getElementById(this.CANVAS_ID + count);
      canvas.scrollIntoView({block: "start", behavior: 'smooth'});
    }

    renderPage(pageNumber, canvas) {
      thePdf.getPage(pageNumber).then(function(page) {
      let  viewport = page.getViewport(scaleView);
        canvas.height = viewport.height;
        canvas.width = viewport.width;          
        page.render({canvasContext: canvas.getContext('2d'), viewport: viewport});
    });
  }

  scrollPage() {
    const { pdfData } = this.state;
    const wrapper = document.getElementById(this.id + "-wrapper-viewer");
    const viewer = document.getElementById(this.id + "-pdf-viewer");
    const scrollPercent = (wrapper.scrollTop / (viewer.offsetHeight - wrapper.offsetHeight)) * 100;
    const numberPage = parseInt((pdfData.numPages * scrollPercent) / 100, 10) + 1;
    let isIncrease = 0;
    if(wrapper.scrollTop < this.scrollHeight) {
        isIncrease = 1;
    } 
    if(numberPage === this.currentPage - isIncrease) {
      if(isIncrease === 0) {
        this.currentPage ++;
      } else {
        this.currentPage --;
      }
      this.setState({pageNum: this.currentPage});
    }
    this.scrollHeight = wrapper.scrollTop;
  }

    render() {
        const { pageNum, pdfData } = this.state;
        const { show } = this.props;
        return (
            <div>
              <div className="PDF-viewer" tabIndex="0">
              <div className="PDF-viewer--pagination">
                <button id="prev" onClick={this.onPrevPage}>Previous</button>
                <button id="next" onClick={this.onNextPage}>Next</button>
                <span>Page: <span>{pageNum}</span> / <span>{pdfData ? pdfData.numPages : 1}</span></span>
                <button className="PDF-viewer-close"  onClick={show}>Close</button>
              </div>
              <div id={this.id + "-wrapper-viewer"} className="PDF-viewer-wrapper" onScroll={this.scrollPage.bind(this)}>
              <div className="PDF-viewer-content" id={this.id + "-pdf-viewer"} ></div>
              </div>
            </div>
          </div>
        );
    }
}

export default PDFViewer;
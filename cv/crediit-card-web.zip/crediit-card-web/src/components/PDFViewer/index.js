import PDFViewer from './PDFViewer';

export default PDFViewer;

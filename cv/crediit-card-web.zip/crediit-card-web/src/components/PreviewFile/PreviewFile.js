import React, {Component} from 'react';
import PropTypes from 'prop-types';
import PDFViewer from '../PDFViewer';

import './PreviewFile.css';

class PreviewFile extends Component {
    render() {
        const {content, type, show, name } = this.props;
        return (
            <div className="preview-file">
                {
                content && type === "IMAGE" && 
                <div className="preview-file-image">
                    <img src={content} alt="#"/>
                </div>
                }
                {
                content && type === "PDF" && 
                <div className="preview-file-pdf">
                <PDFViewer content={content} show={show} name={name} />
                </div>
                }
            </div>
        );
    }

}

PreviewFile.propTypes = {
    type:PropTypes.string.isRequired,
};

export default PreviewFile;

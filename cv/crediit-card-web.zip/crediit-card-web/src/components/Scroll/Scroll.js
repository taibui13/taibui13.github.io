import React, { Component } from 'react';
import './Scroll.css';
import { animateScroll as scroll } from 'react-scroll'

export default class Scroll extends Component {
    constructor(props) {
        super(props);
    } 

    componentWillUpdate() {
        var node = this.getDOMNode();
        this.shouldScrollBottom = node.scrollTop + node.offsetHeight === node.scrollHeight;
    }

    componentDidUpdate() {
        if (this.shouldScrollBottom) {
          var node = this.getDOMNode();
          node.scrollTop = node.scrollHeight
        }
    }

    scrollToTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
    
  render() {
    return(
        <div  className="back-to-top" onClick={this.scrollToTop.bind(this)}>>
            <span>scroll to top</span> <i className="icon-right"></i>
        </div>
    );
  }
}

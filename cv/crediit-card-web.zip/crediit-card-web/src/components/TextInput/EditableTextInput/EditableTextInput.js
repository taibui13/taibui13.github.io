import React from 'react';
import PropTypes from 'prop-types';
import { validators, validateConditions } from './../../../common/validations';
import './EditableTextInput.css';

import tickImg from './../../../assets/images/icon/Tick.svg';
import crossImg from './../../../assets/images/icon/cross.svg';

const Icon = props => {
  const visibility = props.isValid ? "--visible" : "--invisible";
  const tick = <img className={`textInputTick${visibility}`} src={tickImg} alt='tick' />;
  const cross = <img className={"textInputTick--visible"} src={crossImg} alt='tick' />;

  return props.isValid ? tick : cross;
};

const EditableTextInput = props => {
  const { type, inputID, isFocus, isValid, errorMsg, label, value, onFocus, onBlur, onChange, validator, isUpperCase, isDateFormat, isDisabled, checkValidation, conditions } = props;
  const focus = isFocus || value.length > 0 || !isValid ? "--focused" : "";
  const showErrorLabel = isValid ? "" : "textInputLabel--error";
  const errorContainerStyle =  isValid ? "" : "textInputLabel-container--error";
  let keyCode;
  
  const handleOnChange = e => {
    const regex = /(^\d{2}$)|(^\d{2}\/\d{2}$)/;
    const dateFormatRegex = /(^\d{1,2}$)|(^\d{2}\/$)|(^\d{2}\/\d{1,2}$)|(^\d{2}\/\d{2}\/$)|(^\d{2}\/\d{2}\/\d{1,4}$)/;
    let val = (isDateFormat && regex.test(e.target.value) && keyCode !== 8 &&  keyCode !== 46)
      ? `${e.target.value}${"/"}`
      : e.target.value;

    if (isDateFormat && e.target.value && !dateFormatRegex.test(e.target.value) && keyCode !== 8 &&  keyCode !== 46) {
        val = value;
    }
    const inputValue = isUpperCase ? val.toUpperCase() : val;
    let isValid = true;
    let errorMsg = '';
    if (validator && validator.length > 0) {
      let result = validators(validator, inputValue);
      isValid = result.status;
      errorMsg = result.errorMsg;
    }

    if(isValid && checkValidation) {
      let result = checkValidation(inputValue);
      isValid = result.status;
      errorMsg = result.errorMsg;
    }
  
    if(conditions && conditions.length > 0) {
      let result = validateConditions(conditions, inputValue);
      isValid = result.status;
      errorMsg = result.errorMsg;
    }

    const data = {
      value: inputValue,
      name: inputID,
      isValid,
      errorMsg,
      isInitial: false
    };
    onChange(data);
  }

  return (
    <div
      id={inputID}
      className={`textInputContainer ${errorContainerStyle}`}
      onFocus={onFocus ? onFocus : null}
      onBlur={onBlur ? onBlur : null}
      onKeyDown={e => {
          keyCode = e.keyCode;
      }}
    >
      <div className='textInputContent'>
        <label className={`textInputLabel${focus} ${showErrorLabel}`}>
            {`${label}${isValid ? "" : ` ${errorMsg}`}`}
        </label>
        <input
          disabled={isDisabled}
          onWheel={(e) => e.preventDefault()}
          value={value}
          onKeyDown={e => {
              keyCode = e.keyCode;
          }}
          onChange={handleOnChange}
          type={type ? type : 'text'}
          className={`textInput${focus}`}
        />
        {value && <Icon isValid={isValid} />}
      </div>
    </div>
  );
};

EditableTextInput.propTypes = {
  isFocus: PropTypes.bool,
  isValid: PropTypes.bool,
  isDisabled: PropTypes.bool,
  errorMsg: PropTypes.string,
  label: PropTypes.string.isRequired,
  value: PropTypes.string,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  onChange: PropTypes.func.isRequired
};

EditableTextInput.defaultProps = {
  isFocus: false,
  isValid: true,
  errorMsg: '',
  label: 'Label',
  value: '',
  isUpperCase: false,
  isDateFormat: false,
  isDisabled: false
};

export default EditableTextInput;

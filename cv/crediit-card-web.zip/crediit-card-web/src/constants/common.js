export const applicantStep = {
    basic: "STEP_BASIC_DETAIL",
    verifySMS: "STEP_VERIFY_OTP_SMS",
    personalDetail: "STEP_PERSONAL_DETAIL",
    registeredAddress: "STEP_RESGISTER_ADDRESS",
    workDetails: "STEP_WORK_DETAIL",
    officeAddress: "STEP_OFFICE_ADDRESS",
    uploadDocument: "STEP_UPLOAD_DOCUMENT",
    summary: "STEP_SUMMARY",
}

export const sections = {
    basic: "basicDetails-section",
    verifySMS: "verifyOTP-section",
    personalDetail: "personalDetails-section",
    registeredAddress: "residentialDetails-sectionS",
    workDetails: "workDetails-section",
    officeAddress: "offficeAddress-section",
    uploadDocument: "uploadDocuments-section",
    summary: "summary-section",
    summary_auto_pay: "summary-section_auto_pay",
    summary_confirm: "summary-section_confirm",
}

export const PAGE = {COMPLETE: "complete"};

export const URL_PARAMS = {PRODUCT_ID: "productId", MS: "ms", MT: "mt", PROMOTION_CODE : "promotionCode", CHANNEL_CODE: "i_cid", CAMPAIGN_CODE: "s_cid", LANG: "lang"}

export const HIDDEN_JOB_TITTLE = ["PROFL", "SELFE1", "SELFE2", "STUDT", "NOINC", "SELFE"];
export const HIDDEN_INDUSTRY = ["STUDT", "NOINC"];
export const NATURE_EMPLOYEE_INDUSTRY = ["SELFE1", "SELFE2", "SELFE"];
export const HIDDEN_NUMBER_EMPLOYMENT = ["SELFE1", "SELFE2", "SELFE"];
export const HIDDEN_LENGTH_ENTITY = ["SELFE1", "SELFE2", "SELFE"];
export const HIDDEN_LENGTH_OF_EMPLOYEE = ["STUDT", "NOINC"];
export const HIDDEN_PREVIOUS_COMPANY = ["SELFE1", "SELFE2", "SELFE"];
export const MAX_LENTH_OF_EMPLOYMENT = 6;
export const TIER_1_CITY = 1;
export const TIER_2_CITY = 2;
export const IS_SHOW_PR = false;

export const DEFAULT_JOB_TITLE_MAPPING = {
    "PROFL": "00005",
    "SELFE": "00004",
    "SELFE1": "00004",
    "SELFE2": "00004",
    "STUDT": "00006"
};
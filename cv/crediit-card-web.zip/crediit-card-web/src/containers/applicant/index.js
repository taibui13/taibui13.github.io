import React, { Component } from 'react';
import { connect } from 'react-redux';
import { scrollToSection } from './../../actions/commonAction';
import BasicDetails from '../basicDetails';
import VerifyOPT from '../verifyOPT';
import PersonalDetails from '../personalDetails';
import ResidentialDetails from '../residentialDetails';
import WorkDetails from '../workDetails';
import OfficeAddress from '../officeAddress';
import UploadDocuments from '../uploadDocuments';
import { setErrorMessage } from '../../actions/commonAction';
import Summary from '../summary';
import {getIndexObject, sendDataToSparkline, getURLParameter} from '../../common/utils';
import {applicantStep, URL_PARAMS} from '../../constants/common';

class Applicant extends Component {

  handleSubmit(nextStep, section) {
    this.props.dispatch(scrollToSection(nextStep, section));
    const indexOfSteps = getIndexObject(applicantStep, this.props.commonReducer.currentStep) + 1;
    sendDataToSparkline(indexOfSteps, this.productID);
  }

  componentWillMount() {
    this.isIE = /*@cc_on!@*/false || !!document.documentMode;
    this.productID = getURLParameter(URL_PARAMS.PRODUCT_ID);
    sendDataToSparkline("", this.productID, "", true);
    const { dispatch, commonReducer } = this.props;
    if(this.isIE) {
      dispatch(setErrorMessage(commonReducer.msg && commonReducer.msg.IENotSupport));
    }
    if(commonReducer.appData.cardType.ids && commonReducer.appData.cardType.ids.indexOf(this.productID) < 0) {
      dispatch(setErrorMessage(commonReducer.msg && commonReducer.msg.invalidProductId));
    }
  }

  render() {
    const imgUrl = './images/logos/uobLogo.svg';
    const indexOfSteps = getIndexObject(applicantStep, this.props.commonReducer.currentStep) + 1;
    return(
      <div className={`uob-container${this.isIE ? " uob-container-disabled" : ""}`}>
        <div className="uob-content">
          <div>
              <img src={imgUrl} alt='Logo' />
          </div>
          {indexOfSteps >= 1 && <BasicDetails props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
          {indexOfSteps === 2 && <VerifyOPT props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
          {indexOfSteps >= 3 && <PersonalDetails props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
          {indexOfSteps >= 4 && <ResidentialDetails props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
          {indexOfSteps >= 5 && <WorkDetails props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
          {indexOfSteps >= 6 && <OfficeAddress props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
          {indexOfSteps >= 7 && <UploadDocuments props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> } 
          {indexOfSteps >= 8 && <Summary props={this.props} handleSubmit={this.handleSubmit.bind(this)} /> }
        </div>
      </div>
    );
  }
}


export default connect(state => state)(Applicant);
import store from '../../store/configureStore';
import {handleChangeData, setErrorMessage} from '../../actions/commonAction';
import { validateFields as validateBasic } from '../basicDetails/modules/validation';
import { Action as actionBasic } from '../basicDetails/modules/responseHandler';
import { validateFields as validatePersonal } from '../personalDetails/modules/validation';
import { Action as actionPersonal } from '../personalDetails/modules/responseHandler';
import { validateFields as validateResidence } from '../residentialDetails/modules/validation';
import { Action as actionResidence } from '../residentialDetails/modules/responseHandler';
import { validateFields as validateOfficeAddress } from '../officeAddress/modules/validation';
import { Action as actionOffice } from '../officeAddress/modules/responseHandler';
import { validateFields as validateWorkDetail } from '../workDetails/modules/validation';
import { Action as actionWork } from '../workDetails/modules/responseHandler';
import { validateFields as validateUploadFile } from '../uploadDocuments/modules/validation';
import { Action as actionUploadFile } from '../uploadDocuments/modules/responseHandler';
import { validateFields as validateSummary } from '../summary/modules/validation';
import { Action as actionSummary } from '../summary/modules/responseHandler';
import { checkRequiredFields, getIndexObject, getURLParameter} from '../../common/utils';
import { sections, applicantStep, URL_PARAMS } from '../../constants/common';

const validateForm = (currentStep) => {
  const props = store.getState();
  const productID = getURLParameter(URL_PARAMS.PRODUCT_ID);
  const { commonReducer } = props;
  if(commonReducer.appData.cardType.ids && commonReducer.appData.cardType.ids.indexOf(productID) < 0) {
    store.dispatch(setErrorMessage(commonReducer.msg && commonReducer.msg.invalidProductId));
    return {isRequire: true, section: sections.basic};
  }

  const numberStep = getIndexObject(applicantStep, currentStep) + 1;
  if(numberStep > 0) {
    const basicFields = validateBasic(props);
    if(basicFields.length > 0) {
      const {homeNumber, alias} = props.basicDetailReducer;
      const basicRequire = checkRequiredFields(basicFields, (obj) => store.dispatch(handleChangeData(actionBasic.REQUIRE_ERROR, obj)), "", [homeNumber, alias]);
      if(basicRequire) {
        return {isRequire: true, section: sections.basic};
      }
    }
  }

  if(numberStep > 2) {
    const personalFields = validatePersonal(props);
    if(personalFields.length > 0) {
      const personalRequire = checkRequiredFields(personalFields, (obj) => store.dispatch(handleChangeData(actionPersonal.REQUIRE_ERROR, obj)));
      if(personalRequire) {
        return {isRequire: true, section: sections.personalDetail};
      }
    }
  }

  if(numberStep > 3) {
    const rersidenceFields = validateResidence(props);
    if(rersidenceFields.length > 0) {
      const residenceRequire = checkRequiredFields(rersidenceFields, (obj) => store.dispatch(handleChangeData(actionResidence.REQUIRE_ERROR, obj)));
      if(residenceRequire) {
        return {isRequire: true, section: sections.registeredAddress};
      }
    }
  }

  if(numberStep > 4) {
    const workFields = validateWorkDetail(props);
    if(workFields.length > 0) {
      const workRequire = checkRequiredFields(workFields, (obj) => store.dispatch(handleChangeData(actionWork.REQUIRE_ERROR, obj)));
      if(workRequire) {
        return {isRequire: true, section: sections.workDetails};
      }
    }
  }

  if(numberStep > 5) {
    const officeFields = validateOfficeAddress(props);
    if(officeFields.length > 0) {
      const officeRequire = checkRequiredFields(officeFields, (obj) => store.dispatch(handleChangeData(actionOffice.REQUIRE_ERROR, obj)));
      if(officeRequire) {
        return {isRequire: true, section: sections.officeAddress};
      }
    }
  }

  if(numberStep > 6) {
    const uploadFields = validateUploadFile(props);
    if(uploadFields.length > 0) {
      const uploadRequire = checkRequiredFields(uploadFields, (obj) => store.dispatch(handleChangeData(actionUploadFile.REQUIRE_ERROR, obj)));
      if(uploadRequire) {
        return {isRequire: true, section: sections.uploadDocument};
      }
    }
  }

  if(numberStep > 7) {
    const summaryFields = validateSummary(props);
    if(summaryFields.length > 0) {
      const summaryRequire = checkRequiredFields(summaryFields, (obj) => store.dispatch(handleChangeData(actionSummary.REQUIRE_ERROR, obj)));
      if(summaryRequire) {
        return {isRequire: true, section: sections.summary_auto_pay};
      }
    }
  }
  return {isRequire: false, section: ""};

}
export default validateForm;
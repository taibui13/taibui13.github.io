import { connect } from 'react-redux';
import BasicDetails from './view/basicDetails';
import { handleChangeData, sendOTPAndSubmit } from './modules/dispatchHandler';
import {changeCurrentStep } from '../../actions/commonAction';
//import {wrapHOC} from '../../pages/WrappedComponent';


const mapDispatchToProps = {
  sendOTPAndSubmit,
  handleChangeData,
  changeCurrentStep
}

const mapStateToProps = (state) => ({
  isDisableForm: state.basicDetailReducer.isDisableForm,
  firstName: state.basicDetailReducer.firstName,
  lastName: state.basicDetailReducer.lastName,
  isPermanantResident: state.basicDetailReducer.isPermanantResident,
  isOtherName: state.basicDetailReducer.isOtherName,
  otherName: state.basicDetailReducer.otherName,
  idType: state.basicDetailReducer.idType,
  alias: state.basicDetailReducer.alias,
  nationID: state.basicDetailReducer.nationID,
  passportNumber: state.basicDetailReducer.passportNumber,
  emailAddress: state.basicDetailReducer.emailAddress,
  mobileNumber: state.basicDetailReducer.mobileNumber,
  homeNumber: state.basicDetailReducer.homeNumber,
  dateOfBirth: state.basicDetailReducer.dateOfBirth,
  city: state.basicDetailReducer.city,
  hasUOBAccount: state.basicDetailReducer.hasUOBAccount,
  passportExpireDate: state.basicDetailReducer.passportExpireDate,
  passpordIssueCountry: state.basicDetailReducer.passpordIssueCountry,
  otp: state.verifyOTPReducer.otp,
  commonReducer: state.commonReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(BasicDetails);
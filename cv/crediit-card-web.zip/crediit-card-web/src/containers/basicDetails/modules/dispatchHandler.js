import { Action } from './responseHandler';
import request from '../../../services/request';
import api from '../../../services/api';

export function getData(payload) {
  return (dispatch) => {
    dispatch({type: Action.WORK_INFO_GET_DATA, payload: payload});
  };
}

export const handleChangeData = (hander, payload) => {
  return (dispatch) => {
    dispatch({type: hander, payload: payload});
  };
}

export function getDataAPI(payload) {
  return (dispatch) => {
    request.get(api.getData, {}).then(res => {
      dispatch({type: Action.WORK_INFO_GET_DATA, payload: res.data});
    })
  };
}

export function sendOTPAndSubmit(payload, handler, obj, submitForm) {
  return (dispatch) => {
    request.post(api.sendotp, payload, false).then(res => {
      obj.data.prefix = res.data.prefix;
      obj.data.errorMsg = "";
      dispatch({type: handler, payload: obj});
      submitForm && submitForm();
    })
  };
}


export default {
    isDisableForm: false,
    firstName: {
        name: 'firstName',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    lastName: {
        name: 'lastName',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    isOtherName: false,
    isPermanantResident: false,
    otherName: {
        name: 'otherName',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    alias: {
        name: 'alias',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    nationID: {
        name: 'nationID',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    passportNumber: {
        name: 'passportNumber',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    emailAddress: {
        name: 'emailAddress',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    mobileNumber: {
        name: 'mobileNumber',
        type: 'Phone',
        isValid: true,
        value: '+62',
        errorMsg: '',
        isInitial: true
    }, 
    homeNumber: {
        name: 'homeNumber',
        type: 'Phone',
        isValid: true,
        value: '+62',
        errorMsg: '',
        isInitial: true
    }, 
    dateOfBirth: {
        name: 'dateOfBirth',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    city: {
        name: 'city',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    idType: {
        name: 'idType',
        isValid: true,
        isFocus: false,
        value: 'IC',
        errorMsg: '',
        isInitial: false,
    },
    hasUOBAccount: {
        name: 'hasUOBAccount',
        isValid: true,
        value: false,
        errorMsg: ''
    },
    passportExpireDate: {
        name: 'passportExpireDate',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    }, 
    passpordIssueCountry: {
        name: 'passpordIssueCountry',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
}
  
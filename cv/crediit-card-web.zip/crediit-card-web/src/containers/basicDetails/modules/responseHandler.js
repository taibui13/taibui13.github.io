import { BASIC_DETAIL } from '../../../actions/actionTypes';
const CODE_NBR_IN = "+62";
export const Action = {
    GET_DATA: `${BASIC_DETAIL}_GET_DATA`,
    GET_BASIC_DATA_INFO: `${BASIC_DETAIL}_GET_DATA_INFO`,
    REQUIRE_ERROR: `${BASIC_DETAIL}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.GET_BASIC_DATA_INFO]: handleGetBasicData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}

function handleGetBasicData(state, action) {
    let basic = { 
          ...state,
          firstName: { ...state.firstName, value: action.data.names && action.data.names.firstName, isInitial: false },
          lastName: { ...state.lastName, value: action.data.names && action.data.names.lastName, isInitial: false },
          otherName: { ...state.fullName, value: action.data.names && action.data.names.fullName, isInitial: false },
          alias: { ...state.alias, value: action.data.names && action.data.names.alias, isInitial: false },
          idType: { ...state.idType, value: action.data.legalIdType, isInitial: false },
          isPermanantResident: { ...state.isPermanantResident, value: action.data.prIndicator === "Y" ? true : false, isInitial: false },
          homeNumber: { ...state.homeNumber, value: CODE_NBR_IN + action.data.homeNumber, isInitial: false },
          mobileNumber: { ...state.mobileNumber, value: CODE_NBR_IN + action.data.mobileNumber, isInitial: false },
          emailAddress: { ...state.emailAddress, value: action.data.emailAddress, isInitial: false },
          dateOfBirth: { ...state.dateOfBirth, value: action.data.dateOfBirth, isInitial: false },
          city: { ...state.city, value: action.data.currentCity, isInitial: false },
          hasUOBAccount: { ...state.hasUOBAccount, value: action.data.savingAccIndicator === "Y" ? true : false, isInitial: false },
          isDisableForm: true
         };
    if(action.data.names && action.data.names.fullName && action.data.names && action.data.names.fullName.length > 0) {
        basic.isOtherName = true;
    }
    if(action.data.legalIdType === "IC") {
        basic.nationID = { ...state.nationID, value: action.data.legalId, isInitial: false };
    }
    if(action.data.legalIdType === "PP") {
        basic.passportNumber = { ...state.passportNumber, value: action.data.legalId, isInitial: false };
    }
    return basic;     
  }

function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





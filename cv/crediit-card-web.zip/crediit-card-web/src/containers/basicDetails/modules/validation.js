
import rules from '../../../common/rules';

const ID_TYPES = ["IC", "PP"];
export const validateFields = (props) => {
    const { basicDetailReducer: {isOtherName, otherName, firstName, lastName, idType, nationID, passportNumber, emailAddress, mobileNumber, homeNumber, 
      city, hasUOBAccount, passportExpireDate, dateOfBirth, passpordIssueCountry}, commonReducer } = props;
    let arr = [firstName, lastName, idType, emailAddress, mobileNumber, homeNumber, dateOfBirth, city];
    if(isOtherName) {
      arr.push(otherName);
    }
   
    if(idType.value === ID_TYPES[0]) {
      arr.push(nationID);
    }
    if(idType.value === ID_TYPES[1]) {
      arr.push(passportNumber, passpordIssueCountry, passportExpireDate);
    }
    if(commonReducer.appData.inputValues.tierCodeCities[city.value] === 2 && !hasUOBAccount.value) {
      hasUOBAccount.isValid = false;
      hasUOBAccount.errorMsg = commonReducer.appData.basicDetails.labels.hasUOBAccountRequire;
      arr.push(hasUOBAccount);
    }
    return arr;
}

export const birthdayValidations = rules.birthdayValidations;
export const passportValidations = rules.passportValidations;

  
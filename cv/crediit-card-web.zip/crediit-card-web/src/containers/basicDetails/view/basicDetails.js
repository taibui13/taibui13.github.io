import React from 'react';
import './basicDetails.scss';
import TextInput from '../../../components/TextInput/TextInput';
import ToggleInput from '../../../components/ToggleInput/ToggleInput';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import Dropdown from '../../../components/Dropdown/Dropdown';
import { Action } from '../modules/responseHandler';
//import { Action as AtionOTP } from '../../verifyOPT/modules/responseHandler';
import { birthdayValidations, passportValidations } from '../modules/validation';
import { applicantStep, sections, TIER_2_CITY, IS_SHOW_PR } from '../../../constants/common';
import validateForm from '../../applicant/validation';
import { resetRequiredFields, convertObjToArray, resetMessageError } from '../../../common/utils';

const ID_TYPES = ["IC", "PP"];
export default class BasicDetails extends React.Component {
    constructor(props) {
        super(props);
        this.idTypes = [];
        this.cities = [];
    }

    componentWillMount() {
      const { commonReducer } = this.props;
      this.idTypes = convertObjToArray(commonReducer.appData.inputValues.idTypes, "value",  "description");
      this.cities = convertObjToArray(commonReducer.appData.inputValues.tierCities, "value",  "description");
      this.nationalities = convertObjToArray(commonReducer.appData.countriesNamesMap, "value",  "description");
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
        Object.keys(obj).forEach(key => { data[key] = obj[key] });
     }
      handleChangeData(Action.GET_DATA, {field, data})
    }

    handleForcus(data, isFocus) {
      data.isFocus = isFocus;
      this.handleOnChange(data.name, data);
    }

    handleDropdownClick(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      this.handleOnChange(data.name, data);
    }

    handleOnSearchChange(e, data) {
      data.searchValue =  e.target.value;
      this.handleOnChange(data.name, data);
    }

    handleToggle(name, value, showedCompoments, selectedValue) {
      this.handleOnChange(name, value, selectedValue);
      if(value.value && showedCompoments && showedCompoments.length > 0) {
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleResetMessage(compoments) {
      resetMessageError(compoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
    }

    handleHomeNumber(field, data) {
      this.handleOnChange(field, data, "");
      if(data.value.length <= 3) {
        let {homeNumber} = this.props;
        homeNumber.value = data.value;
        this.handleResetMessage([homeNumber]);
      }
    }

    handleSubmit() {
      const { commonReducer, handleSubmit } = this.props;
      const result = validateForm(commonReducer.currentStep);
      if(!result.isRequire) {
        this.handleOnChange("isDisableForm", true);
          //sendOTPAndSubmit({ mobileNumber: mobileNumber.value.replace(/\s+/g, '')}, AtionOTP.GET_DATA, {field: 'otp', data: otp},handleSubmit.bind(this, applicantStep.verifySMS, sections.verifySMS));
          handleSubmit(applicantStep.verifySMS, sections.verifySMS)
      } else {
        handleSubmit.bind(this, applicantStep.basic, sections.basic)
      }
    }

    handleRequireFields(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      if(data.value === "OTHER") {
        data.isInitial = true;
        data.isValid = false;
        data.errorMsg = this.props.commonReducer.msg.notAllowProceed;
      }
      this.handleOnChange(data.name, data);
    }

   
    render() {
      const { isOtherName, commonReducer, otherName, idType, alias, nationID, passportNumber, emailAddress, passportExpireDate, passpordIssueCountry,
        mobileNumber, homeNumber, dateOfBirth, city, hasUOBAccount, firstName, lastName, isPermanantResident, isDisableForm } = this.props;
      const titles = commonReducer.appData.basicDetails;
      const labels = titles.labels;
      const readOnlyFields = commonReducer.appData.myInfoReadonlyFields;
      const isReadOnlyField = (field) => {
        const isReadField = readOnlyFields[field] ? readOnlyFields[field] : false;
        return isDisableForm && isReadField;
      }
      const isBasicStep = commonReducer.currentStep === applicantStep.basic;
      return(
        <div className="basic-detail" id={sections.basic}>
          <h1>{titles.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{titles.subtitle}</p>
          <div className='uob-input-separator'/>
          <div className='uob-input-separator-twocols'>
           <div className='uob-input-separator-half'>
            <TextInput
              inputID='firstName'
              isReadOnly={!isBasicStep}
              label={labels.firstName}
              value={firstName.value}
              errorMsg={firstName.errorMsg}
              onChange={this.handleOnChange.bind(this, 'firstName')}
              isValid={firstName.isValid}
              validator={["required", "isAlphanumeric", "maxSize|35"]}
              isDisabled={false}
            />
             </div>
             <div className="space"></div>
             <div className='uob-input-separator-half'>
              <TextInput
                inputID='lastName'
                isReadOnly={!isBasicStep}
                label={labels.lastName}
                value={lastName.value}
                errorMsg={lastName.errorMsg}
                onChange={this.handleOnChange.bind(this, 'lastName')}
                isValid={lastName.isValid}
                validator={["required", "isAlphanumeric", "maxSize|35"]}
                isDisabled={false}
              />
             </div>
          </div>
          <div className='uob-input-separator'>
              <ToggleInput
                description = {labels.isOtherName}
                onClick={this.handleToggle.bind(this, 'isOtherName', !isOtherName, [otherName, alias], {})}
                isToggled = {isOtherName}
                isDisabled={isReadOnlyField('isOtherName')}
              />
          </div>
          {
            isOtherName && 
            <div>
              <div className='uob-input-separator'>
                <TextInput
                  inputID='otherName'
                  isReadOnly={isReadOnlyField('otherName')}
                  label={labels.otherName}
                  value={otherName.value}
                  errorMsg={otherName.errorMsg}
                  isValid={otherName.isValid}
                  validator={["required", "isAlphanumeric", "maxSize|70"]}
                  onChange={this.handleOnChange.bind(this, 'otherName')}
                  unAmount={ resetRequiredFields.bind(this, [otherName], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                  isDisabled={false}
                />
              </div>
              <div className='uob-input-separator'>
                <TextInput
                  inputID='alias'
                  isReadOnly={isReadOnlyField('alias')}
                  label={labels.alias}
                  value={alias.value}
                  errorMsg={alias.errorMsg}
                  isValid={alias.isValid}
                  validator={["isAlphanumeric", "maxSize|70"]}
                  onChange={this.handleOnChange.bind(this, 'alias')}
                  unAmount={ resetRequiredFields.bind(this, [alias], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                  isDisabled={false}
                />
             </div>
           </div>
            }
          <div className='uob-input-separator hide-component'>
            <Dropdown
              inputID='idType'
              isReadOnly={!isBasicStep}
              isFocus={idType.isFocus}
              label={labels.idType}
              value={idType.value}
              isValid={idType.isValid}
              errorMsg={idType.errorMsg}
              dropdownItems={this.idTypes}
              searchValue={idType.searchValue}
              onBlur={this.handleForcus.bind(this, idType, false)}
              onFocus={this.handleForcus.bind(this, idType, true)}
              onClick={(data) => { this.handleDropdownClick(data, idType) } }
              onSearchChange={(event) => this.handleOnSearchChange(event, idType)}
            />
          </div> 
            {
              idType.value === ID_TYPES[0] &&
              <div className='uob-input-separator'>
                <TextInput
                  inputID='nationID'
                  isReadOnly={!isBasicStep}
                  label={labels.nationID}
                  value={nationID.value}
                  errorMsg={nationID.errorMsg}
                  isValid={nationID.isValid}
                  validator={["required", "isNumber", "maxSize|16"]}
                  onChange={this.handleOnChange.bind(this, 'nationID')}
                  unAmount={ resetRequiredFields.bind(this, [nationID], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                  isDisabled={false}
                />
              </div>
            } 
            {
               idType.value === ID_TYPES[1] &&
               <div>
                <div className='uob-input-separator'>
                  <TextInput
                    inputID='passportNumber'
                    isReadOnly={!isBasicStep}
                    label={labels.passportNumber}
                    value={passportNumber.value}
                    errorMsg={passportNumber.errorMsg}
                    isValid={passportNumber.isValid}
                    validator={["required", "isAlphanumeric", "maxSize|16"]}
                    onChange={this.handleOnChange.bind(this, 'passportNumber')}
                    unAmount={ resetRequiredFields.bind(this, [passportNumber], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                    isDisabled={false}
                  />
                </div>
                <div className='uob-input-separator'/>
                <Dropdown
                  inputID='passpordIssueCountry'
                  isReadOnly={isReadOnlyField('passpordIssueCountry')}
                  isFocus={passpordIssueCountry.isFocus}
                  focusOutItem={true}
                  label={labels.passpordIssueCountry}
                  value={passpordIssueCountry.value}
                  isValid={passpordIssueCountry.isValid}
                  errorMsg={passpordIssueCountry.errorMsg}
                  dropdownItems={this.nationalities}
                  searchValue={passpordIssueCountry.searchValue}
                  onBlur={this.handleForcus.bind(this, passpordIssueCountry, false)}
                  onFocus={this.handleForcus.bind(this, passpordIssueCountry, true)}
                  onClick={(data) => {  this.handleRequireFields(data, passpordIssueCountry)} }
                  onSearchChange={(event) => this.handleOnSearchChange(event, passpordIssueCountry)}
                /> 
                <div className='uob-input-separator'>
                  <TextInput
                    inputID='passportExpireDate'
                    isDateFormat={true}
                    isReadOnly={isReadOnlyField('passportExpireDate')}
                    label={labels.passportExpireDate}
                    value={passportExpireDate.value}
                    errorMsg={passportExpireDate.errorMsg}
                    isValid={passportExpireDate.isValid}
                    conditions={passportValidations}
                    onChange={this.handleOnChange.bind(this, 'passportExpireDate')}
                    unAmount={ resetRequiredFields.bind(this, [passportExpireDate], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                    isDisabled={false}
                  />
                </div>
              </div>
            }
            {
              IS_SHOW_PR &&
              <div className='uob-input-separator'>
               <ToggleInput
                 description = {labels.isPermanantResident}
                 onClick={this.handleToggle.bind(this, 'isPermanantResident', !isPermanantResident, [], {})}
                 isToggled = {isPermanantResident}
                 isDisabled={isReadOnlyField('isPermanantResident')}
               />
              </div> 
            }
            <div className='uob-input-separator'>
                <TextInput
                  inputID='emailAddress'
                  isReadOnly={!isBasicStep}
                  label={labels.emailAddress}
                  value={emailAddress.value}
                  errorMsg={emailAddress.errorMsg}
                  isValid={emailAddress.isValid}
                  validator={["required", "isEmail", "maxSize|30"]}
                  onChange={this.handleOnChange.bind(this, 'emailAddress')}
                  isDisabled={false}
                />
            </div>
            <div className='uob-input-separator'>
                <TextInput
                  inputID='mobileNumber'
                  type='Phone'
                  isReadOnly={!isBasicStep}
                  label={labels.mobileNumber}
                  value={mobileNumber.value}
                  errorMsg={mobileNumber.errorMsg}
                  isValid={mobileNumber.isValid}
                  validator={["required", "isPhoneNumber|15"]}
                  onChange={this.handleOnChange.bind(this, 'mobileNumber')}
                  isDisabled={false}
                />
            </div>
            <div className='uob-input-separator'>
                <TextInput
                  type='Phone'
                  inputID='homeNumber'
                  isReadOnly={isReadOnlyField('homeNumber')}
                  label={labels.homeNumber}
                  value={homeNumber.value}
                  errorMsg={homeNumber.errorMsg}
                  isValid={homeNumber.isValid}
                  validator={["required", "isPhoneNumber|15"]}
                  onChange={this.handleHomeNumber.bind(this, 'homeNumber')}
                  isDisabled={false}
                />
            </div>
            <div className='uob-input-separator'>
                <TextInput
                  inputID='dateOfBirth'
                  isDateFormat={true}
                  isReadOnly={isReadOnlyField('dateOfBirth')}
                  label={labels.dateOfBirth}
                  value={dateOfBirth.value}
                  errorMsg={dateOfBirth.errorMsg}
                  isValid={dateOfBirth.isValid}
                  conditions={birthdayValidations}
                  onChange={this.handleOnChange.bind(this, 'dateOfBirth')}
                  isDisabled={false}
                />
            </div>
            <div className='uob-input-separator'/>
            <Dropdown
              inputID='city'
              isReadOnly={isReadOnlyField('city')}
              isFocus={city.isFocus}
              focusOutItem={true}
              label={labels.city}
              value={city.value}
              isValid={city.isValid}
              errorMsg={city.errorMsg}
              dropdownItems={this.cities}
              searchValue={city.searchValue}
              onBlur={this.handleForcus.bind(this, city, false)}
              onFocus={this.handleForcus.bind(this, city, true)}
              onClick={(data) => {  this.handleRequireFields(data, city)} }
              onSearchChange={(event) => this.handleOnSearchChange(event, city)}
            /> 
            {
               commonReducer.appData.inputValues.tierCodeCities[city.value] === TIER_2_CITY &&
                <div className='uob-input-separator'>
                  <ToggleInput
                    description = {labels.hasUOBAccount}
                    onClick={() => {
                      this.handleToggle('hasUOBAccount', hasUOBAccount, [], {value: !hasUOBAccount.value});
                      this.handleResetMessage([hasUOBAccount])
                    }}
                    isToggled = {hasUOBAccount.value}
                    isValid={hasUOBAccount.isValid}
                    errorMsg={hasUOBAccount.errorMsg}
                    isDisabled={isReadOnlyField('hasUOBAccount')}
                  />
              </div>
            }
            <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
           {
              (isBasicStep) &&
                <div id="basic-detail-continue" className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.continueButton}
                    onClick={this.handleSubmit.bind(this)}
                    isLoading={commonReducer.isProcessing}
                  />
                </div>
            }  
        </div>
      );
    }
  }
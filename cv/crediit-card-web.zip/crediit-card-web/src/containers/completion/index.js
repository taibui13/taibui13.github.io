import { connect } from 'react-redux';
import Completion from './view/completion';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  changeCurrentStep
}

const mapStateToProps = (state) => ({
  commonReducer: state.commonReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(Completion);

export const validateFields = (props) => {
    const {   isAutoPay,
              payMinimum,
              debitingAccount,
              isCreditShield,
              isConfirm,
              isAgreeConfirm,
         } = props;
    let arr = [];
    if(isAutoPay) {
        arr.push(payMinimum, debitingAccount);
    }
    if(!isConfirm.value) {
      const labels = props.commonReducer.appData.confirmDetails.labels;
      isConfirm.isValid = false;
      isConfirm.errorMsg = labels.termAndCondition;
      arr.push(isConfirm)
    }
    if(!isAgreeConfirm.value) {
      const labels = props.commonReducer.appData.confirmDetails.labels;
      isAgreeConfirm.isValid = false;
      isAgreeConfirm.errorMsg = labels.termAndCondition;
      arr.push(isAgreeConfirm)
    }
    return arr;
}

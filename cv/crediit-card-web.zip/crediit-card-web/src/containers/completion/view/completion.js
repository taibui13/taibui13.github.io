import React from 'react';
import './completion.scss';
import {sendDataToSparkline} from '../../../common/utils';
export default class Completion extends React.Component {

  componentDidMount() {
    const { location } = this.props;
    sendDataToSparkline("", location.state.productId, location.state.id, false, true);
  }

  render() {
    const {
      commonReducer,
      location
    } = this.props;
    const labels = commonReducer.appData.completion.labels;
    const type = location.state.productId && location.state.productId.slice(-3);
    const cardTypes = commonReducer.appData.cardType;
    const name = cardTypes[type] && (cardTypes[type].name + " (Ref No. " + location.state.id + ")");
    return (
      <div className="complete">
        <div className="complete-left">
          <div className="complete-logo"></div>
          <div className="complete-title">
            {labels.submitted}
          </div>
          <div className="separator"></div>
          <div className="complete-content">
             {labels.submittedTitle}
          </div>
          <div className="complete-content-card">
           <li>
              {name}
          </li>
          </div>
        </div>
        <div className="complete-right">
        <div className="content-title"> {labels.title}</div>
          <div className="content">
        
            <div className="content-list"> 
              <div className="content-item"> 
                 <div className="icon-sign"> </div>
                 <div className="icon-title">
                     {labels.titleSignUp}
                   </div>
                   <div>
                   {labels.titleSignUpContent}
                   </div>
              </div>
              <div className="content-item"> 
                 <div className="icon-access"> </div>
                   <div className="icon-title">
                     {labels.titleAccess}
                   </div>
                   <div>
                      {labels.titleAccessContent}
                   </div>
              </div>
              <div className="content-item"> 
               <div className="icon-currency"> </div>
                  <div className="icon-title">
                      {labels.titleCurrency}
                   </div>
                   <div>
                     {labels.titleCurrencyContent}
                   </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    );
  }
}
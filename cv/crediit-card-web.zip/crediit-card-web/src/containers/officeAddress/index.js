import { connect } from 'react-redux';
import OfficeAddress from './view/officeAddress';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep, submitPartialApplication } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  submitPartialApplication,
  changeCurrentStep
}

const mapStateToProps = (state) => ({
  addressComplex: state.officeAddressReducer.addressComplex,
  addressComplexStreet: state.officeAddressReducer.addressComplexStreet,
  addressComplexKelurahan: state.officeAddressReducer.addressComplexKelurahan,
  city: state.officeAddressReducer.city,
  province: state.officeAddressReducer.province,
  postalCode: state.officeAddressReducer.postalCode,
  mailToLocation: state.officeAddressReducer.mailToLocation,
  isDisableForm: state.officeAddressReducer.isDisableForm,
  commonReducer: state.commonReducer,
  workDetailsReducer: state.workDetailsReducer,
  id: state.basicDetailReducer.id
})


export default connect(mapStateToProps, mapDispatchToProps)(OfficeAddress);
export const handleChangeData = (hander, payload) => {
  return (dispatch) => {
    dispatch({type: hander, payload: payload});
  };
}



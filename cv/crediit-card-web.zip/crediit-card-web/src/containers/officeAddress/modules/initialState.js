export default {
    addressComplex: {
        name: 'addressComplex',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    addressComplexStreet: {
        name: 'addressComplexStreet',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    addressComplexKelurahan: {
        name: 'addressComplexKelurahan',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    city: {
        name: 'city',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    province: {
        name: 'province',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    postalCode: {
        name: 'postalCode',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    mailToLocation: {
        name: 'mailToLocation',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false
    },
    isDisableForm: false,
    

}
  
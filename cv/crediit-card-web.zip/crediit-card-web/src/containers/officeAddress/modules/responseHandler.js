import { OFFICE_ADDRESS } from '../../../actions/actionTypes';

export const Action = {
    GET_DATA: `${OFFICE_ADDRESS}_GET_DATA`,
    GET_OFFICE_ADDRESS_DATA: `${OFFICE_ADDRESS}_GET_DATA_INFO`,
    REQUIRE_ERROR: `${OFFICE_ADDRESS}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.GET_OFFICE_ADDRESS_DATA]: handleGetOfficeAddressData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}

function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}

function handleGetOfficeAddressData(state, action) {
    const addresses = action.data.filter(item => item.type === "OFC");
    const address = addresses.length > 0 ? addresses[0] : {};
    let obj = { 
          ...state,
          addressComplex: { ...state.addressComplex, value: address.address1, isInitial: false },
          addressComplexStreet: { ...state.addressComplexStreet, value: address.address2, isInitial: false },
          addressComplexKelurahan: { ...state.addressComplexKelurahan, value: address.address3, isInitial: false },
          city: { ...state.city, value: address.city, isInitial: false },
          province: { ...state.province, value: address.province, isInitial: false },
          postalCode: { ...state.postalCode, value: address.postalCode, isInitial: false },
          residenceStatus: { ...state.residenceStatus, value: address.residentialStatus, isInitial: false },
          lengthOfResidence: { ...state.lengthOfResidence, value: address.lengthOfResidence, isInitial: false },
          mailToLocation: { ...state.mailToLocation, value: address.mailingIndicator, isInitial: false },
          isDisableForm: false
         };
    return obj;     
  }


function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





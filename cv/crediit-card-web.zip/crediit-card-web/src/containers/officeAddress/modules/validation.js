import { getMsgError } from '../../../common/message';
import { HIDDEN_LENGTH_OF_EMPLOYEE } from '../../../constants/common';

export const validateFields = (props) => {
    const { 
            officeAddressReducer: {
            addressComplex,
            addressComplexStreet,
            addressComplexKelurahan,
            city,
            province,
            postalCode,
            mailToLocation },
            workDetailsReducer
         } = props;
    let arr = [city, province, postalCode, mailToLocation];
    if(!(HIDDEN_LENGTH_OF_EMPLOYEE.indexOf(workDetailsReducer.natureOfEmployment.value) > -1)) {
        arr.push(addressComplex, addressComplexStreet, addressComplexKelurahan);
    }     
    return arr;
}

export const  checkSameAddress = (list, value) => {
    let status = true;
    let errorMsg = "";
    if(list.filter(item => item !== "").indexOf(value) > -1) {
        status = false;
        errorMsg = getMsgError().notSame;
    }
  
    return {status, errorMsg};
}

import React from 'react';
import './officeAddress.scss';
import TextInput from '../../../components/TextInput/TextInput';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import ButtonOption from '../../../components/ButtonOption/ButtonOption';
import Dropdown from '../../../components/Dropdown/Dropdown';
import { Action } from '../modules/responseHandler';
import { applicantStep, sections } from '../../../constants/common';
import { resetRequiredFields, convertObjToArray } from '../../../common/utils';
import { checkSameAddress } from '../modules/validation';
import validateForm from '../../applicant/validation';

export default class OfficeAddress extends React.Component {
    constructor(props) {
      super(props);
      this.cities = [];
      this.provinces = [];
      this.mailToLocations = [];
    }

    componentWillMount() {
      const { commonReducer } = this.props;
      this.cities = convertObjToArray(commonReducer.appData.inputValues.cities, "value",  "description");
      this.provinces = convertObjToArray(commonReducer.appData.inputValues.provinces, "value",  "description");
      this.mailToLocations =convertObjToArray(commonReducer.appData.inputValues.mailToLocations, "value",  "description");
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
        Object.keys(obj).forEach(key => { data[key] = obj[key] });
      }
      handleChangeData(Action.GET_DATA, {field, data})
    }

    handleDropdownClick(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      this.handleOnChange(data.name, data);
    }

    handleOnSearchChange(e, data) {
      data.searchValue =  e.target.value;
      this.handleOnChange(data.name, data);
    }

    handleToggle(name, value, showedCompoments) {
      this.handleOnChange(name, value);
      if(!value && showedCompoments && showedCompoments.length > 0) {
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleSubmit() {
      const { commonReducer, submitPartialApplication, handleSubmit, id } = this.props;
      const result = validateForm(commonReducer.currentStep);
      if(!result.isRequire) {
         this.handleOnChange("isDisableForm", true);
         submitPartialApplication({id: id}, handleSubmit.bind(this, applicantStep.uploadDocument, sections.uploadDocument));
      } else {
        handleSubmit(applicantStep.officeAddress, result.section);
      }
    }

    handleForcus(data, isFocus) {
      data.isFocus = isFocus;
      this.handleOnChange(data.name, data);
    }

    render() {
      const {  
            addressComplex,
            addressComplexStreet,
            addressComplexKelurahan,
            city,
            province,
            postalCode,
            mailToLocation,
            isDisableForm,
            commonReducer } = this.props;
      const labels = commonReducer.appData.officeAddress.labels;
      const readOnlyFields = commonReducer.appData.myInfoReadonlyFields;
      const isReadOnlyField = (field) => {
        const isReadField = readOnlyFields[field] ? readOnlyFields[field] : false;
        return isDisableForm && isReadField;
      }
      return(
        <div className="work-infor" id={sections.officeAddress}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          <div className='uob-input-separator'/>
          <TextInput
                inputID='officeAddressComplex'
                isReadOnly={isReadOnlyField('addressComplex')}
                label={labels.addressComplex}
                value={addressComplex.value}
                errorMsg={addressComplex.errorMsg}
                onChange={this.handleOnChange.bind(this, 'addressComplex')}
                isValid={addressComplex.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                checkValidation={checkSameAddress.bind(this, [addressComplexStreet.value, addressComplexKelurahan.value])}
                isDisabled={false}
              />  
            <div className='uob-input-separator'/>  
            <TextInput
                inputID='officeAddressComplexStreet'
                isReadOnly={isReadOnlyField('addressComplexStreet')}
                label={labels.addressComplexStreet}
                value={addressComplexStreet.value}
                errorMsg={addressComplexStreet.errorMsg}
                onChange={this.handleOnChange.bind(this, 'addressComplexStreet')}
                isValid={addressComplexStreet.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                checkValidation={checkSameAddress.bind(this, [addressComplex.value, addressComplexKelurahan.value])}
                isDisabled={false}
              />   
            <div className='uob-input-separator'/>  
              <TextInput
                inputID='officeAddressComplexKelurahan'
                isReadOnly={isReadOnlyField('addressComplexKelurahan')}
                label={labels.addressComplexKelurahan}
                value={addressComplexKelurahan.value}
                errorMsg={addressComplexKelurahan.errorMsg}
                onChange={this.handleOnChange.bind(this, 'addressComplexKelurahan')}
                isValid={addressComplexKelurahan.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                checkValidation={checkSameAddress.bind(this, [addressComplexStreet.value, addressComplex.value])}
                isDisabled={false}
              />  
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='officeCity'
                isReadOnly={isReadOnlyField('city')}
                isFocus={city.isFocus}
                label={labels.city}
                value={city.value}
                isValid={city.isValid}
                errorMsg={city.errorMsg}
                dropdownItems={this.cities}
                searchValue={city.searchValue}
                onBlur={this.handleForcus.bind(this, city, false)}
                onFocus={this.handleForcus.bind(this, city, true)}
                onClick={(data) => { this.handleDropdownClick(data, city); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, city)}
              />    
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='officeProvince'
                isReadOnly={isReadOnlyField('province')}
                isFocus={province.isFocus}
                label={labels.province}
                value={province.value}
                isValid={province.isValid}
                errorMsg={province.errorMsg}
                dropdownItems={this.provinces}
                searchValue={province.searchValue}
                onBlur={this.handleForcus.bind(this, province, false)}
                onFocus={this.handleForcus.bind(this, province, true)}
                onClick={(data) => { this.handleDropdownClick(data, province); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, province)}
              />   
             <div className='uob-input-separator'/>  
              <TextInput
                inputID='officePostalCode'
                isReadOnly={isReadOnlyField('postalCode')}
                label={labels.postalCode}
                value={postalCode.value}
                errorMsg={postalCode.errorMsg}
                onChange={this.handleOnChange.bind(this, 'postalCode')}
                isValid={postalCode.isValid}
                validator={["required", "isNumber", "exactSize|5"]}
                isDisabled={false}
              />  
              <div className='uob-input-separator'/>  
              <ButtonOption
                label={labels.mailToLocation}
                options={this.mailToLocations}
                value={mailToLocation.value}
                isValid={mailToLocation.isValid}
                errorMsg={mailToLocation.errorMsg}
                onClick={(data) => this.handleOnChange('mailToLocation', mailToLocation, {value: data.value, isValid: true, errorMsg: "", isInitial: false})}
              />   
            <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
            {
              (commonReducer.currentStep === applicantStep.officeAddress) &&
                <div className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.continueButton}
                    onClick={this.handleSubmit.bind(this)}
                    isLoading={commonReducer.isProcessing}
                  />
                </div>
            }  
        </div>
      );
    }
  }
import { connect } from 'react-redux';
import PersonalDetails from './view/personalDetails';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep, submitPartialApplication } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  submitPartialApplication,
  changeCurrentStep
}

const mapStateToProps = (state) => ({
  gender: state.personalDetailsReducer.gender,
  marital: state.personalDetailsReducer.marital,
  education: state.personalDetailsReducer.education,
  nationality: state.personalDetailsReducer.nationality,
  placeOfBirth: state.personalDetailsReducer.placeOfBirth,
  motherName: state.personalDetailsReducer.motherName,
  numberOfDependent: state.personalDetailsReducer.numberOfDependent,
  isDisableForm: state.personalDetailsReducer.isDisableForm,
  commonReducer: state.commonReducer,
  id: state.basicDetailReducer.id
})

export default connect(mapStateToProps, mapDispatchToProps)(PersonalDetails);
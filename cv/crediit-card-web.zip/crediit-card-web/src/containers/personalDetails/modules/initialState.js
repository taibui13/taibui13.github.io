export default {
    gender: {
        name: 'gender',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false
    },
    marital: {
        name: 'marital',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    education: {
        name: 'education',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    nationality: {
        name: 'nationality',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    placeOfBirth: {
        name: 'placeOfBirth',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    motherName: {
        name: 'motherName',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    numberOfDependent: {
        name: 'numberOfDependent',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    isDisableForm: false
}
  
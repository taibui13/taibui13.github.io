import { PERSONAL_DETAIL } from '../../../actions/actionTypes';

export const Action = {
    GET_DATA: `${PERSONAL_DETAIL}_GET_DATA`,
    GET_PERSONAL_DATA_INFO: `${PERSONAL_DETAIL}_GET_DATA_INFO`,
    REQUIRE_ERROR: `${PERSONAL_DETAIL}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.GET_PERSONAL_DATA_INFO]: handleGetPersonalData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}

function handleGetPersonalData(state, action) {
    let obj = { 
          ...state,
          gender: { ...state.gender, value: action.data.gender, isInitial: false },
          lastName: { ...state.lastName, value: action.data.names && action.data.names.lastName, isInitial: false },
          marital: { ...state.marital, value: action.data.maritalStatus, isInitial: false },
          education: { ...state.education, value: action.data.educationLevel, isInitial: false },
          nationality: { ...state.nationality, value: action.data.nationality, isInitial: false },
          placeOfBirth: { ...state.placeOfBirth, value: action.data.placeOfBirth, isInitial: false },
          motherName: { ...state.motherName, value: action.data.mothersMaidenName, isInitial: false },
          numberOfDependent: { ...state.numberOfDependent, value: action.data.noOfDependants, isInitial: false },
          isDisableForm: false
         };
  
    return obj;     
  }


function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





export const validateFields = (props) => {
    const { personalDetailsReducer: {gender, marital, education, nationality, placeOfBirth, motherName, numberOfDependent} } = props;
    let arr = [gender, marital, education, nationality, placeOfBirth, motherName, numberOfDependent];
    return arr;
}
import React from 'react';
import './personalDetails.scss';
import TextInput from '../../../components/TextInput/TextInput';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import GenderSelection from '../../../components/GenderSelection/GenderSelection';
import Dropdown from '../../../components/Dropdown/Dropdown';
import { Action } from '../modules/responseHandler';
import { applicantStep, sections } from '../../../constants/common';
import { convertObjToArray } from '../../../common/utils';
import { numberOfDependents } from '../../../constants/numberOfDependents';
import validationForm from '../../applicant/validation';

export default class PersonalDetails extends React.Component {
    constructor(props) {
        super(props);
      this.maritals = [];
      this.educationLevels = [];
      this.nationalities = [];
      this.numberOfDependents = [];
    }

    componentWillMount() {
      const { commonReducer } = this.props;
      this.maritals = convertObjToArray(commonReducer.appData.inputValues.maritalStatus, "value",  "description");
      this.educationLevels = convertObjToArray(commonReducer.appData.inputValues.educationLevel, "value",  "description");
      this.nationalities = convertObjToArray(commonReducer.appData.countriesNamesMap, "value",  "description");
      this.numberOfDependents = convertObjToArray(numberOfDependents, "value",  "description");
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
        Object.keys(obj).forEach(key => { data[key] = obj[key] });
      }
      handleChangeData(Action.GET_DATA, {field, data})
    }

    handleDropdownClick(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      this.handleOnChange(data.name, data);
    }

    handleOnSearchChange(e, data) {
      data.searchValue =  e.target.value;
      this.handleOnChange(data.name, data);
    }

    handleSubmit() {
      const { commonReducer, submitPartialApplication, handleSubmit, id } = this.props;
      const result= validationForm(commonReducer.currentStep);
      if(!result.isRequire) {
         this.handleOnChange("isDisableForm", true);
         submitPartialApplication({id: id}, handleSubmit.bind(this, applicantStep.registeredAddress, sections.registeredAddress));
      } else {
       handleSubmit(applicantStep.personalDetail, result.section);
      }
    }

    handleForcus(data, isFocus) {
      data.isFocus = isFocus;
      this.handleOnChange(data.name, data);
    }

    render() {
      const { gender, marital, education, nationality, placeOfBirth, motherName, numberOfDependent, isDisableForm,
         commonReducer } = this.props;
      const labels = commonReducer.appData.personalDetails.labels;
      const readOnlyFields = commonReducer.appData.myInfoReadonlyFields;
      const isReadOnlyField = (field) => {
        const isReadField = readOnlyFields[field] ? readOnlyFields[field] : false;
        return isDisableForm && isReadField;
      }
      return(
        <div className="work-infor" id={sections.personalDetail}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          <div className='uob-input-separator'/>
          <GenderSelection
              isReadOnly={isReadOnlyField('gender')}
              labelMale={labels.male}
              labelFemale={labels.female}
              isValid={gender.isValid}
              errorMsg={gender.errorMsg}
              gender={gender.value}
              onClick={value => { this.handleOnChange('gender', gender, {value: value, isInitial: false, isValid: true,errorMsg: ""});            }}
          />
          <div className='uob-input-separator'/>
            <Dropdown
              inputID='marital'
              isReadOnly={isReadOnlyField('marital')}
              isFocus={marital.isFocus}
              label={labels.maritalStatus}
              value={marital.value}
              isValid={marital.isValid}
              errorMsg={marital.errorMsg}
              dropdownItems={this.maritals}
              searchValue={marital.searchValue}
              onBlur={this.handleForcus.bind(this, marital, false)}
              onFocus={this.handleForcus.bind(this, marital, true)}
              onClick={(data) => { this.handleDropdownClick(data, marital); }}
              onSearchChange={(event) => this.handleOnSearchChange(event, marital)}
            /> 
          <div className='uob-input-separator'/>
          <Dropdown
              inputID='education'
              isReadOnly={isReadOnlyField('education')}
              isFocus={education.isFocus}
              label={labels.educationLevel}
              value={education.value}
              isValid={education.isValid}
              errorMsg={education.errorMsg}
              dropdownItems={this.educationLevels}
              searchValue={education.searchValue}
              onBlur={this.handleForcus.bind(this, education, false)}
              onFocus={this.handleForcus.bind(this, education, true)}
              onClick={(data) => { this.handleDropdownClick(data, education); }}
              onSearchChange={(event) => this.handleOnSearchChange(event, education)}
            /> 
            <div className='uob-input-separator'/>
              <Dropdown
                inputID='nationality'
                isReadOnly={isReadOnlyField('nationality')}
                isFocus={nationality.isFocus}
                label={labels.nationality}
                value={nationality.value}
                isValid={nationality.isValid}
                errorMsg={nationality.errorMsg}
                dropdownItems={this.nationalities}
                searchValue={nationality.searchValue}
                onBlur={this.handleForcus.bind(this, nationality, false)}
                onFocus={this.handleForcus.bind(this, nationality, true)}
                onClick={(data) => { this.handleDropdownClick(data, nationality); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, nationality)}
              /> 
             <div className='uob-input-separator'/>
              <TextInput
                inputID='placeOfBirth'
                isReadOnly={isReadOnlyField('placeOfBirth')}
                label={labels.placeOfBirth}
                value={placeOfBirth.value}
                errorMsg={placeOfBirth.errorMsg}
                onChange={this.handleOnChange.bind(this, 'placeOfBirth')}
                isValid={placeOfBirth.isValid}
                validator={["required", "isAlphanumeric", "maxSize|15"]}
                isDisabled={false}
              /> 
            <div className='uob-input-separator'/>
              <TextInput
                inputID='motherName'
                isReadOnly={isReadOnlyField('motherName')}
                label={labels.motherName}
                value={motherName.value}
                errorMsg={motherName.errorMsg}
                onChange={this.handleOnChange.bind(this, 'motherName')}
                isValid={motherName.isValid}
                validator={["required", "isAlphanumeric", "maxSize|35"]}
                isDisabled={false}
              />  
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='numberOfDependent'
                isReadOnly={isReadOnlyField('numberOfDependent')}
                isFocus={numberOfDependent.isFocus}
                label={labels.numberOfDependent}
                value={numberOfDependent.value}
                isValid={numberOfDependent.isValid}
                errorMsg={numberOfDependent.errorMsg}
                dropdownItems={this.numberOfDependents}
                searchValue={numberOfDependent.searchValue}
                onBlur={this.handleForcus.bind(this, numberOfDependent, false)}
                onFocus={this.handleForcus.bind(this, numberOfDependent, true)}
                onClick={(data) => { this.handleDropdownClick(data, numberOfDependent); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, numberOfDependent)}
              />      
            <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
            {
              (commonReducer.currentStep === applicantStep.personalDetail) &&
                <div className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.continueButton}
                    onClick={this.handleSubmit.bind(this)}
                    isLoading={commonReducer.isProcessing}
                  />
                </div>
            }  
        </div>
      );
    }
  }
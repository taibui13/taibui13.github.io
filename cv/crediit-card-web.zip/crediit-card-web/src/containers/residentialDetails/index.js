import { connect } from 'react-redux';
import ResidentialDetails from './view/residentialDetails';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep, submitPartialApplication } from '../../actions/commonAction';


const mapDispatchToProps = {
  handleChangeData,
  submitPartialApplication,
  changeCurrentStep
}

const mapStateToProps = (state) => ({
  addressComplex: state.residentialDetailsReducer.addressComplex,
  addressComplexStreet: state.residentialDetailsReducer.addressComplexStreet,
  addressComplexKelurahan: state.residentialDetailsReducer.addressComplexKelurahan,
  city: state.residentialDetailsReducer.city,
  province: state.residentialDetailsReducer.province,
  postalCode: state.residentialDetailsReducer.postalCode,
  residenceStatus: state.residentialDetailsReducer.residenceStatus,
  lengthOfResidence: state.residentialDetailsReducer.lengthOfResidence,
  otherAddress: state.residentialDetailsReducer.otherAddress,
  otherAddressComplex: state.residentialDetailsReducer.otherAddressComplex,
  otherAddressComplexStreet: state.residentialDetailsReducer.otherAddressComplexStreet,
  otherAddressComplexKelurahan: state.residentialDetailsReducer.otherAddressComplexKelurahan,
  otherCity: state.residentialDetailsReducer.otherCity,
  otherProvince: state.residentialDetailsReducer.otherProvince,
  otherPostalCode: state.residentialDetailsReducer.otherPostalCode,
  isDisableForm: state.residentialDetailsReducer.isDisableForm,
  commonReducer: state.commonReducer,
  id: state.basicDetailReducer.id,
  basicDetailReducer: state.basicDetailReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(ResidentialDetails);
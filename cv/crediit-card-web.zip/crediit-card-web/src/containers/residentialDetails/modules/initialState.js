export default {
    
    addressComplex: {
        name: 'addressComplex',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    addressComplexStreet: {
        name: 'addressComplexStreet',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    addressComplexKelurahan: {
        name: 'addressComplexKelurahan',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    city: {
        name: 'city',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    province: {
        name: 'province',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    postalCode: {
        name: 'postalCode',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    residenceStatus: {
        name: 'residenceStatus',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
    },
    lengthOfResidence: {
        name: 'lengthOfResidence',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    otherAddress: false,
    otherAddressComplex: {
        name: 'otherAddressComplex',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    otherAddressComplexStreet: {
        name: 'otherAddressComplexStreet',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    otherAddressComplexKelurahan: {
        name: 'otherAddressComplexKelurahan',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    otherCity: {
        name: 'otherCity',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
    },
    otherProvince: {
        name: 'otherProvince',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
    },
    otherPostalCode: {
        name: 'otherPostalCode',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    isDisableForm: false
}
  
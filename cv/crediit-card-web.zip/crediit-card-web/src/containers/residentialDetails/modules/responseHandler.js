import { RESGITERED_DETAIL } from '../../../actions/actionTypes';

export const Action = {
    GET_DATA: `${RESGITERED_DETAIL}_GET_DATA`,
    GET_ADDRESS_DATA_INFO: `${RESGITERED_DETAIL}_GET_DATA_INFO`,
    REQUIRE_ERROR: `${RESGITERED_DETAIL}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.GET_ADDRESS_DATA_INFO]: handleGetAddressData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}

function handleGetAddressData(state, action) {
    const addresses = action.data.filter(item => item.type !== "OFC");
    const address = addresses.length > 0 ? addresses[0] : {} ;
    const otherAddress = addresses.length > 1 ? addresses[1] : {} ;
    let obj = { 
          ...state,
          addressComplex: { ...state.addressComplex, value: address.address1, isInitial: false },
          addressComplexStreet: { ...state.addressComplexStreet, value: address.address2, isInitial: false },
          addressComplexKelurahan: { ...state.addressComplexKelurahan, value: address.address3, isInitial: false },
          city: { ...state.city, value: address.city, isInitial: false },
          province: { ...state.province, value: address.province, isInitial: false },
          postalCode: { ...state.postalCode, value: address.postalCode, isInitial: false },
          residenceStatus: { ...state.residenceStatus, value: address.residentialStatus, isInitial: false },
          lengthOfResidence: { ...state.lengthOfResidence, value: address.lengthOfResidence, isInitial: false },
          isDisableForm: false
         };
    if(otherAddress) {
        obj.otherAddress = true;
        obj.otherAddressComplex = { ...state.addressComplex, value: otherAddress.address1, isInitial: false };
        obj.otherAddressComplexStreet = { ...state.addressComplexStreet, value: otherAddress.address2, isInitial: false };
        obj.otherAddressComplexKelurahan = { ...state.addressComplexKelurahan, value: otherAddress.address3, isInitial: false };
        obj.otherCity = { ...state.city, value: otherAddress.city, isInitial: false };
        obj.otherProvince = { ...state.province, value: otherAddress.province, isInitial: false };
        obj.otherPostalCode = { ...state.postalCode, value: otherAddress.postalCode, isInitial: false };
        obj.otherResidenceStatus = { ...state.residenceStatus, value: otherAddress.residentialStatus, isInitial: false };
        obj.otherLengthOfResidence = { ...state.lengthOfResidence, value: otherAddress.lengthOfResidence, isInitial: false }
    }     
  
    return obj;     
  }


function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





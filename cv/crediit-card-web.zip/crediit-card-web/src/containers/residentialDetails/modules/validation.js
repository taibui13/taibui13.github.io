export const validateFields = (props) => {
    const { residentialDetailsReducer: { 
            addressComplex,
            addressComplexStreet,
            addressComplexKelurahan,
            city,
            province,
            postalCode,
            residenceStatus,
            lengthOfResidence,
            otherAddress,
            otherAddressComplex,
            otherAddressComplexStreet,
            otherAddressComplexKelurahan,
            otherCity,
            otherProvince,
            otherPostalCode }
         } = props;
    let arr = [addressComplex, addressComplexStreet, addressComplexKelurahan, city, province, postalCode, residenceStatus, lengthOfResidence];
    if(otherAddress) {
        arr.push( otherAddressComplex, otherAddressComplexStreet, otherAddressComplexKelurahan, otherCity, otherProvince, otherPostalCode);
    }
    return arr;
}
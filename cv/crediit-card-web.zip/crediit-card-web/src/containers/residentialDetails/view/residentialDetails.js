import React from 'react';
import './residentialDetails.scss';
import TextInput from '../../../components/TextInput/TextInput';
import ToggleInput from '../../../components/ToggleInput/ToggleInput';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import Dropdown from '../../../components/Dropdown/Dropdown';
import { Action } from '../modules/responseHandler';
import { applicantStep, sections } from '../../../constants/common';
import { resetRequiredFields, convertObjToArray } from '../../../common/utils';
import validateForm from '../../applicant/validation';

export default class ResidentialDetails extends React.Component {
    constructor(props) {
      super(props);
      this.cities = [];
      this.provinces = [];
      this.residentialStatuses = [];
      this.isDisabledCity = false;
    }

    componentWillMount() {
      const { commonReducer } = this.props;
      this.cities = convertObjToArray(commonReducer.appData.inputValues.cities, "value",  "description");
      this.provinces = convertObjToArray(commonReducer.appData.inputValues.provinces, "value",  "description");
      this.tierProvinces = convertObjToArray(commonReducer.appData.inputValues.tierProvinces, "value",  "description");
      this.residentialStatuses =convertObjToArray(commonReducer.appData.inputValues.residentialStatus, "value",  "description");
    }

    componentDidMount() { 
      let {otherCity, city, basicDetailReducer} = this.props;
      if(basicDetailReducer.city.value) {
        otherCity.value = basicDetailReducer.city.value;
        city.value = basicDetailReducer.city.value;
        city.isInitial = false;
        otherCity.isInitial = false;
        this.handleOnChange(otherCity.name, otherCity);
        this.handleOnChange(city.name, city);
        this.isDisabledCity = true;
      }
    }

    componentWillReceiveProps(props) {
      let {city, otherCity, basicDetailReducer, otherAddress} = props;
      if(city.value && basicDetailReducer.city.value !== city.value && !otherAddress) {
        city.value = basicDetailReducer.city.value;
        this.handleOnChange(city.name, city);
      }
      if(otherCity.value && basicDetailReducer.city.value !== otherCity.value && otherAddress) {
        otherCity.value = basicDetailReducer.city.value;
        this.handleOnChange(otherCity.name, otherCity);
      }
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
        Object.keys(obj).forEach(key => { data[key] = obj[key] });
      }
      handleChangeData(Action.GET_DATA, {field, data})
    }

    handleDropdownClick(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      this.handleOnChange(data.name, data);
    }

    handleOnSearchChange(e, data) {
      data.searchValue =  e.target.value;
      this.handleOnChange(data.name, data);
    }

    handleToggle(name, value, showedCompoments) {
      this.handleOnChange(name, value);
      if(!value && showedCompoments && showedCompoments.length > 0) {
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
      if(name === "otherAddress") {
        let {city, otherCity, basicDetailReducer} = this.props;
        if(value) {
          city.isInitial = true;
          city.isValid = true;
          city.value = "";
        }else {
          city.value = basicDetailReducer.city.value;
          city.isInitial = false;
        }
        this.isDisabledCity = value ? false : true;
        otherCity.value = basicDetailReducer.city.value;
        otherCity.isInitial = false;
        this.handleOnChange(otherCity.name, otherCity);
        this.handleOnChange(city.name, city);
      }
    }

    handleSubmit() {
      const { commonReducer, submitPartialApplication, handleSubmit, id } = this.props;
      const result = validateForm(commonReducer.currentStep);
      if(!result.isRequire) {
         this.handleOnChange("isDisableForm", true);
         submitPartialApplication({id: id}, handleSubmit.bind(this, applicantStep.workDetails, sections.workDetails));
      } else {
        handleSubmit(applicantStep.registeredAddress, result.section);
      }
    }

    handleForcus(data, isFocus) {
      data.isFocus = isFocus;
      this.handleOnChange(data.name, data);
    }

    render() {
      const {  
            addressComplex,
            addressComplexStreet,
            addressComplexKelurahan,
            city,
            province,
            postalCode,
            residenceStatus,
            lengthOfResidence,
            otherAddress,
            otherAddressComplex,
            otherAddressComplexStreet,
            otherAddressComplexKelurahan,
            otherCity,
            otherProvince,
            otherPostalCode,
            isDisableForm,
            commonReducer } = this.props;
      const labels = commonReducer.appData.residentialDetails.labels;
      const readOnlyFields = commonReducer.appData.myInfoReadonlyFields;
      const isReadOnlyField = (field) => {
        const isReadField = readOnlyFields[field] ? readOnlyFields[field] : false;
        return isDisableForm && isReadField;
      }
      return(
        <div className="work-infor" id={sections.registeredAddress}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          <div className='uob-input-separator'/>
          <TextInput
                inputID='addressComplex'
                isReadOnly={isReadOnlyField('addressComplex')}
                label={labels.addressComplex}
                value={addressComplex.value}
                errorMsg={addressComplex.errorMsg}
                onChange={this.handleOnChange.bind(this, 'addressComplex')}
                isValid={addressComplex.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                isDisabled={false}
              />  
            <div className='uob-input-separator'/>  
            <TextInput
                inputID='addressComplexStreet'
                isReadOnly={isReadOnlyField('addressComplexStreet')}
                label={labels.addressComplexStreet}
                value={addressComplexStreet.value}
                errorMsg={addressComplexStreet.errorMsg}
                onChange={this.handleOnChange.bind(this, 'addressComplexStreet')}
                isValid={addressComplexStreet.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                isDisabled={false}
              />   
            <div className='uob-input-separator'/>  
              <TextInput
                inputID='addressComplexKelurahan'
                isReadOnly={isReadOnlyField('addressComplexKelurahan')}
                label={labels.addressComplexKelurahan}
                value={addressComplexKelurahan.value}
                errorMsg={addressComplexKelurahan.errorMsg}
                onChange={this.handleOnChange.bind(this, 'addressComplexKelurahan')}
                isValid={addressComplexKelurahan.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                isDisabled={false}
              />  
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='residentCity'
                isReadOnly={this.isDisabledCity}
                isFocus={city.isFocus}
                label={labels.city}
                value={city.value}
                isValid={city.isValid}
                errorMsg={city.errorMsg}
                dropdownItems={this.cities}
                searchValue={city.searchValue}
                onBlur={this.handleForcus.bind(this, city, false)}
                onFocus={this.handleForcus.bind(this, city, true)}
                onClick={(data) => { this.handleDropdownClick(data, city); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, city)}
              />    
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='resdentProvince'
                isReadOnly={isReadOnlyField('province')}
                isFocus={province.isFocus}
                label={labels.province}
                value={province.value}
                isValid={province.isValid}
                errorMsg={province.errorMsg}
                dropdownItems={otherAddress ? this.provinces : this.tierProvinces}
                searchValue={province.searchValue}
                onBlur={this.handleForcus.bind(this, province, false)}
                onFocus={this.handleForcus.bind(this, province, true)}
                onClick={(data) => { this.handleDropdownClick(data, province); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, province)}
              />   
             <div className='uob-input-separator'/>  
              <TextInput
                inputID='postalCode'
                isReadOnly={isReadOnlyField('postalCode')}
                label={labels.postalCode}
                value={postalCode.value}
                errorMsg={postalCode.errorMsg}
                onChange={this.handleOnChange.bind(this, 'postalCode')}
                isValid={postalCode.isValid}
                validator={["required", "isNumber", "exactSize|5"]}
                isDisabled={false}
              />  
            <div className='uob-input-separator'/>
              <Dropdown
                inputID='residenceStatus'
                isReadOnly={isReadOnlyField('residenceStatus')}
                isFocus={residenceStatus.isFocus}
                label={labels.residenceStatus}
                value={residenceStatus.value}
                isValid={residenceStatus.isValid}
                errorMsg={residenceStatus.errorMsg}
                dropdownItems={this.residentialStatuses}
                searchValue={residenceStatus.searchValue}
                onBlur={this.handleForcus.bind(this, residenceStatus, false)}
                onFocus={this.handleForcus.bind(this, residenceStatus, true)}
                onClick={(data) => { this.handleDropdownClick(data, residenceStatus); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, residenceStatus)}
              />  
              <div className='uob-input-separator'/>
              <TextInput
                inputID='lengthOfResidence'
                isReadOnly={isReadOnlyField('lengthOfResidence')}
                label={labels.lengthOfResidence}
                value={lengthOfResidence.value}
                errorMsg={lengthOfResidence.errorMsg}
                onChange={this.handleOnChange.bind(this, 'lengthOfResidence')}
                isValid={lengthOfResidence.isValid}
                validator={["required", "isNumber", "maxSize|4"]}
                isDisabled={false}
              />  
               <div className='uob-input-separator' />
              <ToggleInput
                description = {labels.otherAddress}
                onClick={this.handleToggle.bind(this, 'otherAddress', !otherAddress, [otherAddressComplex,
                  otherAddressComplexStreet,
                  otherAddressComplexKelurahan,
                  otherCity,
                  otherProvince,
                  otherPostalCode])}
                isToggled = {otherAddress}
                //isDisabled={isDisableForm}
              /> 
             {
               otherAddress &&
               <div>
                <div className='uob-input-separator'/>
                <TextInput
                inputID='otherAddressComplex'
                isReadOnly={isReadOnlyField('otherAddressComplex')}
                label={labels.otherAddressComplex}
                value={otherAddressComplex.value}
                errorMsg={otherAddressComplex.errorMsg}
                onChange={this.handleOnChange.bind(this, 'otherAddressComplex')}
                isValid={otherAddressComplex.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                isDisabled={false}
              />  
            <div className='uob-input-separator'/>  
            <TextInput
                inputID='otherAddressComplexStreet'
                isReadOnly={isReadOnlyField('otherAddressComplexStreet')}
                label={labels.otherAddressComplexStreet}
                value={otherAddressComplexStreet.value}
                errorMsg={otherAddressComplexStreet.errorMsg}
                onChange={this.handleOnChange.bind(this, 'otherAddressComplexStreet')}
                isValid={otherAddressComplexStreet.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                isDisabled={false}
              />   
            <div className='uob-input-separator'/>  
              <TextInput
                inputID='otherAddressComplexKelurahan'
                isReadOnly={isReadOnlyField('otherAddressComplexKelurahan')}
                label={labels.otherAddressComplexKelurahan}
                value={otherAddressComplexKelurahan.value}
                errorMsg={otherAddressComplexKelurahan.errorMsg}
                onChange={this.handleOnChange.bind(this, 'otherAddressComplexKelurahan')}
                isValid={otherAddressComplexKelurahan.isValid}
                validator={["required", "isAlphanumeric", "maxSize|30"]}
                isDisabled={false}
              />  
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='otherCity'
                isReadOnly={false}
                isFocus={otherCity.isFocus}
                label={labels.city}
                value={otherCity.value}
                isValid={otherCity.isValid}
                errorMsg={otherCity.errorMsg}
                dropdownItems={this.cities}
                searchValue={otherCity.searchValue}
                onBlur={this.handleForcus.bind(this, otherCity, false)}
                onFocus={this.handleForcus.bind(this, otherCity, true)}
                onClick={(data) => { this.handleDropdownClick(data, otherCity); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, otherCity)}
              />    
             <div className='uob-input-separator'/>
              <Dropdown
                inputID='otherProvince'
                isReadOnly={isReadOnlyField('otherProvince')}
                isFocus={otherProvince.isFocus}
                label={labels.province}
                value={otherProvince.value}
                isValid={otherProvince.isValid}
                errorMsg={otherProvince.errorMsg}
                dropdownItems={this.tierProvinces}
                searchValue={otherProvince.searchValue}
                onBlur={this.handleForcus.bind(this, otherProvince, false)}
                onFocus={this.handleForcus.bind(this, otherProvince, true)}
                onClick={(data) => { this.handleDropdownClick(data, otherProvince); }}
                onSearchChange={(event) => this.handleOnSearchChange(event, otherProvince)}
              />   
             <div className='uob-input-separator'/>  
              <TextInput
                inputID='otherPostalCode'
                isReadOnly={isReadOnlyField('otherPostalCode')}
                label={labels.postalCode}
                value={otherPostalCode.value}
                errorMsg={otherPostalCode.errorMsg}
                onChange={this.handleOnChange.bind(this, 'otherPostalCode')}
                isValid={otherPostalCode.isValid}
                validator={["required", "isNumber", "exactSize|5"]}
                isDisabled={false}
              />  
               </div>
             }       
            <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
            {
              (commonReducer.currentStep === applicantStep.registeredAddress) &&
                <div className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.continueButton}
                    onClick={this.handleSubmit.bind(this)}
                    isLoading={commonReducer.isProcessing}
                  />
                </div>
            }  
        </div>
      );
    }
  }
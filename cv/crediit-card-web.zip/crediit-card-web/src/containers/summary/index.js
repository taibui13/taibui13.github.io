import { connect } from 'react-redux';
import Summary from './view/summary';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep, submitApplication, scrollBackToSection } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  submitApplication,
  changeCurrentStep,
  scrollBackToSection
}

const mapStateToProps = (state) => ({
  isAutoPay: state.summaryReducer.isAutoPay,
  payMinimum: state.summaryReducer.payMinimum,
  debitingAccount: state.summaryReducer.debitingAccount,
  isCreditShield: state.summaryReducer.isCreditShield,
  isConfirm: state.summaryReducer.isConfirm,
  isAgreeConfirm: state.summaryReducer.isAgreeConfirm,
  commonReducer: state.commonReducer,
  basicDetailReducer: state.basicDetailReducer,
  personalDetailsReducer: state.personalDetailsReducer,
  residentialDetailsReducer: state.residentialDetailsReducer,
  officeAddressReducer: state.officeAddressReducer,
  uploadDocumentsReducer: state.uploadDocumentsReducer,
  workDetailsReducer: state.workDetailsReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(Summary);
export default {
    isAutoPay: false,  
    payMinimum: {
      name: 'payMinimum',
      isValid: true,
      isFocus: false,
      value: '',
      errorMsg: '',
      isInitial: true,
      isMyInfo: false,
      description: ''
    },
    debitingAccount : {
      name: 'debitingAccount',
      isValid: true,
      value: '',
      errorMsg: '',
      isInitial: true
    },
    isCreditShield: true,
    isConfirm: {
      name: "isConfirm",
      value: false,
      isValid: true,
      errorMsg: ''
    },
    isAgreeConfirm: {
      name: "isAgreeConfirm",
      value: true,
      isValid: true,
      errorMsg: ''
    }
   
}
  
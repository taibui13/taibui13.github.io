import { TIER_2_CITY } from '../../../constants/common';

export const validateFields = (props) => {
    const {  summaryReducer: {
              isAutoPay,
              payMinimum,
              debitingAccount,
              isConfirm },
              commonReducer,
              basicDetailReducer
         } = props;
    let arr = [];
    if(isAutoPay || commonReducer.appData.inputValues.tierCodeCities[basicDetailReducer.city.value] === TIER_2_CITY) {
        arr.push(payMinimum, debitingAccount);
    }
    if(!isConfirm.value) {
      const labels = commonReducer.appData.confirmDetails.labels;
      isConfirm.isValid = false;
      isConfirm.errorMsg = labels.termAndCondition;
      arr.push(isConfirm)
    }
    return arr;
}

export const getBasicValue = (global, basicDetail) => {
    const labels = global.basicDetails.labels;
    return [
      { label: labels.firstName, value: basicDetail.firstName.value },
      { label: labels.lastName, value: basicDetail.lastName.value },
      { label: labels.otherName, value: basicDetail.otherName.value },
      { label: labels.alias, value: basicDetail.alias.value },
      { label: labels.idType, value: global.inputValues.idTypes[basicDetail.idType.value] },
      { label: labels.nationID, value: basicDetail.nationID.value },
      { label: labels.passportNumber, value: basicDetail.passportNumber.value },
      { label: labels.emailAddress, value: basicDetail.emailAddress.value },
      { label: labels.mobileNumber, value: basicDetail.mobileNumber.value },
      { label: labels.homeNumber, value: basicDetail.homeNumber.value },
      { label: labels.dateOfBirth, value: basicDetail.dateOfBirth.value },
      { label: labels.hasUOBAccountDes, value: basicDetail.hasUOBAccount.value ? labels.yes : labels.no, isInLine: true },
      //{ label: labels.isPermanantResidentDes, value: basicDetail.isPermanantResident ? labels.yes : labels.no, isInLine: true },
      { label: labels.city, value:  global.inputValues.cities[basicDetail.city.value] }
    ]
  };

  export const  getPersonalValue = (global, personalDetail) => {
    const labels = global.personalDetails.labels;
    return [
      { label: labels.gender, value: global.inputValues.gender[personalDetail.gender.value] },
      { label: labels.maritalStatus, value: global.inputValues.maritalStatus[personalDetail.marital.value] },
      { label: labels.educationLevel, value: global.inputValues.educationLevel[personalDetail.education.value] },
      { label: labels.nationality, value: global.countriesNamesMap[personalDetail.nationality.value] },
      { label: labels.placeOfBirth, value: personalDetail.placeOfBirth.value },
      { label: labels.motherName, value: personalDetail.motherName.value },
      { label: labels.numberOfDependent, value: personalDetail.numberOfDependent.value }
    ]
  };

  export const getAddressValue = (global, addressDetail) => {
    const labels = global.residentialDetails.labels;
    return [
      { label: labels.addressComplex, value: addressDetail.addressComplex.value },
      { label: labels.addressComplexStreet, value: addressDetail.addressComplexStreet.value },
      { label: labels.addressComplexKelurahan, value: addressDetail.addressComplexKelurahan.value },
      { label: labels.city, value: global.inputValues.cities[addressDetail.city.value] },
      { label: labels.province, value: global.inputValues.provinces[addressDetail.province.value] },
      { label: labels.postalCode, value: addressDetail.postalCode.value },
      { label: labels.residenceStatus, value:  global.inputValues.residentialStatus[addressDetail.residenceStatus.value] },
      { label: labels.lengthOfResidence, value: addressDetail.lengthOfResidence.value },
    ]
  };

  export const getOtherAddressValue = (global, addressDetail) => {
    const labels = global.residentialDetails.labels;
    return [
      { label: labels.otherAddressComplex, value: addressDetail.otherAddressComplex.value },
      { label: labels.otherAddressComplexStreet, value: addressDetail.otherAddressComplexStreet.value },
      { label: labels.otherAddressComplexKelurahan, value: addressDetail.otherAddressComplexKelurahan.value },
      { label: labels.city, value: global.inputValues.cities[addressDetail.otherCity.value] },
      { label: labels.province, value: global.inputValues.provinces[addressDetail.otherProvince.value] },
      { label: labels.postalCode, value: addressDetail.otherPostalCode.value },
    ]
  };

  export const getWorkDetailValue = (global, workDetail) => {
    const labels = global.workDetails.labels;
    return [
      { label: labels.natureOfEmployment, value: global.inputValues.natureOfEmployment[workDetail.natureOfEmployment.value] },
      { label: labels.jobTitle, value: global.inputValues.occupation[workDetail.jobTitle.value] },
      { label: labels.companyName, value: workDetail.companyName.value },
      { label: labels.industry, value: global.inputValues.industry[workDetail.industry.value] },
      { label: labels.lengthOfEmploymentAndBusiness, value: workDetail.lengthOfEmploymentAndBusiness.value },
      { label: labels.numberOfEmployee, value:  global.inputValues.numberOfEmployees[workDetail.numberOfEmployee.value] },
      { label: labels.entityType, value: global.inputValues.entityTypes[workDetail.entityType.value] },
      { label: labels.officeNumber, value: workDetail.officeNumber.value },
      { label: labels.officeExtension, value: workDetail.officeExtension.value },
      { label: labels.grossMonthlyIncome, value: workDetail.grossMonthlyIncome.value },
      { label: labels.previousCompany, value: workDetail.previousCompany.value },
      { label: labels.previousLengthOfEmployment, value: workDetail.previousLengthOfEmployment.value },
    ]
  };

  export const  getOfficeAddressValue = (global, officeAddress) => {
    const labels = global.officeAddress.labels;
    return [
      { label: labels.addressComplex, value: officeAddress.addressComplex.value },
      { label: labels.addressComplexStreet, value: officeAddress.addressComplexStreet.value },
      { label: labels.addressComplexKelurahan, value: officeAddress.addressComplexKelurahan.value },
      { label: labels.city, value: global.inputValues.cities[officeAddress.city.value] },
      { label: labels.province, value: global.inputValues.provinces[officeAddress.province.value] },
      { label: labels.postalCode, value: officeAddress.postalCode.value },
      { label: labels.mailToLocation, value: global.inputValues.mailToLocations[officeAddress.mailToLocation.value] },
    ]
  }

export const getUploadFileValue = (global, uploadDocs) => {
  const labels = global.uploadDocuments.labels;
    return [
      { label: labels.nationalID, value: uploadDocs.nationalID.inputValue },
      { label: labels.incomeDocument, value: uploadDocs.incomeDocument.inputValue },
      { label: labels.KITAS, value: uploadDocs.KITAS.inputValue },
      { label: labels.isCreditLimit, value: uploadDocs.isCreditLimit ? global.common.yes : global.common.no, isInLine: true },
      { label: labels.taxIDDocument, value: uploadDocs.taxIDDocument.inputValue },
    ]
  }


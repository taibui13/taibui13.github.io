import React from 'react';
import './summary.scss';
import { withRouter } from 'react-router-dom';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import Dropdown from '../../../components/Dropdown/Dropdown';
import ConfirmDetails from '../../../components/ConfirmDetails/ConfirmDetails';
import ToggleInput from '../../../components/ToggleInput/ToggleInput';
import TextInput from '../../../components/TextInput/TextInput';
import { Action } from '../modules/responseHandler';
import { applicantStep, sections, TIER_1_CITY, TIER_2_CITY } from '../../../constants/common';
import { Action as ACTION_BASIC } from '../../basicDetails/modules/responseHandler';
import { Action as ACTION_PERSONAL } from '../../personalDetails/modules/responseHandler';
import { Action as ACTION_RESIDENT } from '../../residentialDetails/modules/responseHandler';
import { Action as ACTION_OFFICE } from '../../officeAddress/modules/responseHandler';
import { Action as ACTION_WORK_DETAIL } from '../../workDetails/modules/responseHandler';
import { Action as ACTION_UPLOAD } from '../../uploadDocuments/modules/responseHandler';
import { resetRequiredFields, convertObjToArray } from '../../../common/utils';
import { getBasicValue, getPersonalValue, getAddressValue, getOtherAddressValue, getWorkDetailValue, getOfficeAddressValue, getUploadFileValue } from '../modules/validation';
import validateForm from '../../applicant/validation';

class Summary extends React.Component {
    constructor(props) {
      super(props);
      this.partialFull = [];
    }

    componentWillMount() {
      const { commonReducer } = this.props;
      this.partialFull = convertObjToArray(commonReducer.appData.inputValues.partialFull, "value",  "description");
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
         Object.keys(obj).forEach(key => { data[key] = obj[key] });
      }
      handleChangeData(Action.GET_DATA, {field, data})
    }


    handleToggle(name, value, showedCompoments, selectedValue) {
      this.handleOnChange(name, value, selectedValue);
      if(!value && showedCompoments && showedCompoments.length > 0) {
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleDropdownClick(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      this.handleOnChange(data.name, data);
    }

    handleOnSearchChange(e, data) {
      data.searchValue =  e.target.value;
      this.handleOnChange(data.name, data);
    }

    handleForcus(data, isFocus) {
      data.isFocus = isFocus;
      this.handleOnChange(data.name, data);
    }

    handleSubmit() {
      const { commonReducer, submitApplication, handleSubmit, basicDetailReducer } = this.props;
      const result = validateForm(commonReducer.currentStep);
      if(!result.isRequire) {
         submitApplication({id: basicDetailReducer.id}, this.props.history.push.bind(this));
      } else {
        handleSubmit(applicantStep.summary, result.section);
      }
    }

    handleScroll(section, reducer, obj) {
      this.props.scrollBackToSection("", section);
      this.props.handleChangeData(reducer, obj)
    }
  
    render() {
      const {  
          isAutoPay,
          payMinimum,
          debitingAccount,
          isCreditShield,
          isConfirm,
          isAgreeConfirm,
          basicDetailReducer,
          personalDetailsReducer,
          residentialDetailsReducer,
          officeAddressReducer,
          uploadDocumentsReducer,
          workDetailsReducer,
          commonReducer, handleSubmit } = this.props;
      const labels = commonReducer.appData.confirmDetails.labels;
    
      return(
        <div className="work-infor" id={sections.summary}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          <div className='uob-input-separator'/>
          <ConfirmDetails
            hasEdit={true}
            title={ commonReducer.appData.basicDetails.title}
            items={getBasicValue(commonReducer.appData, basicDetailReducer)}
            onClick={this.handleScroll.bind(this, sections.basic, ACTION_BASIC.GET_DATA, {field: 'isDisableForm', data: false})}
          />
           <div className='uob-input-separator'/>
           <ConfirmDetails 
            hasEdit={true}
            title={commonReducer.appData.personalDetails.labels.title}
            items={getPersonalValue(commonReducer.appData, personalDetailsReducer)}
            onClick={this.handleScroll.bind(this, sections.personalDetail, ACTION_PERSONAL.GET_DATA, {field: 'isDisableForm', data: false})}
          />
          <div className='uob-input-separator'/>
           <ConfirmDetails 
            hasEdit={true}
            title={commonReducer.appData.residentialDetails.labels.title}
            items={getAddressValue(commonReducer.appData, residentialDetailsReducer)}
            onClick={this.handleScroll.bind(this, sections.registeredAddress, ACTION_RESIDENT.GET_DATA, {field: 'isDisableForm', data: false})}
          />
          {
            residentialDetailsReducer.otherAddress && 
            <div className='uob-input-separator'>
              <ConfirmDetails 
                hasEdit={true}
                title={commonReducer.appData.residentialDetails.labels.otherTitle}
                items={getOtherAddressValue(commonReducer.appData, residentialDetailsReducer)}
                onClick={this.handleScroll.bind(this, sections.registeredAddress, ACTION_RESIDENT.GET_DATA, {field: 'isDisableForm', data: false})}
              />
            </div>
          }

           <div className='uob-input-separator'/>
           <ConfirmDetails 
            hasEdit={true}
            title={commonReducer.appData.workDetails.labels.title}
            items={getWorkDetailValue(commonReducer.appData, workDetailsReducer)}
            onClick={this.handleScroll.bind(this, sections.workDetails, ACTION_WORK_DETAIL.GET_DATA, {field: 'isDisableForm', data: false})}
          />
          <div className='uob-input-separator'/>
           <ConfirmDetails 
            hasEdit={true}
            title={commonReducer.appData.officeAddress.labels.title}
            items={getOfficeAddressValue(commonReducer.appData, officeAddressReducer)}
            onClick={this.handleScroll.bind(this, sections.officeAddress, ACTION_OFFICE.GET_DATA, {field: 'isDisableForm', data: false})}
          />
          <div className='uob-input-separator'/>
            <ConfirmDetails 
              hasEdit={true}
              title={commonReducer.appData.uploadDocuments.labels.title}
              items={getUploadFileValue(commonReducer.appData, uploadDocumentsReducer)}
              onClick={this.handleScroll.bind(this, sections.uploadDocument, ACTION_UPLOAD.GET_DATA, {field: 'isDisableForm', data: false})}
            />
            {
              (commonReducer.appData.inputValues.tierCodeCities[basicDetailReducer.city.value] === TIER_1_CITY) &&
               <div className='uob-input-separator' >
               <ToggleInput
                   description = {labels.isAutoPay}
                   onClick={this.handleToggle.bind(this, 'isAutoPay', !isAutoPay, [payMinimum], "")}
                   isToggled = {isAutoPay}
                 /> 
               </div>  
            }
            {
              (isAutoPay || commonReducer.appData.inputValues.tierCodeCities[basicDetailReducer.city.value] === TIER_2_CITY)  &&
              <div> 
                <div className='uob-input-separator'/>
                <Dropdown
                  inputID='payMinimum'
                  isReadOnly={false}
                  isFocus={payMinimum.isFocus}
                  label={labels.payMinimum}
                  value={payMinimum.value}
                  isValid={payMinimum.isValid}
                  errorMsg={payMinimum.errorMsg}
                  dropdownItems={this.partialFull}
                  searchValue={payMinimum.searchValue}
                  onBlur={this.handleForcus.bind(this, payMinimum, false)}
                  onFocus={this.handleForcus.bind(this, payMinimum, true)}
                  onClick={(data) => { this.handleDropdownClick(data, payMinimum); }}
                  onSearchChange={(event) => this.handleOnSearchChange(event, payMinimum, debitingAccount)}
                />   
                <div className='uob-input-separator'/>  
                  <TextInput
                    inputID='debitingAccount'
                    isReadOnly={false}
                    label={labels.debitingAccount}
                    value={debitingAccount.value}
                    errorMsg={debitingAccount.errorMsg}
                    onChange={this.handleOnChange.bind(this, 'debitingAccount')}
                    isValid={debitingAccount.isValid}
                    validator={["required", "isNumber","minSize|10", "maxSize|10"]}
                    isDisabled={false}
                  />   
              </div>
            }
             <div className='uob-input-separator' />
              <ToggleInput
                  isWithTitle={true}
                  title={labels.isCreditShield}
                  isValid={true}
                  errorMsg={""}
                  description ={labels.creditShieldDescription}
                  onClick={this.handleToggle.bind(this, 'isCreditShield', !isCreditShield, [], "")}
                  isToggled = {isCreditShield}
                /> 
            <div className='uob-input-separator' id={sections.summary_auto_pay} />
              <ToggleInput
                  isWithTitle={true}
                  title={labels.isConfirm}
                  description = {labels.confirmDescription}
                  isValid={isConfirm.isValid}
                  errorMsg={isConfirm.errorMsg}
                  onClick={() => {this.handleToggle('isConfirm', isConfirm, [], {value: !isConfirm.value, isValid: !isConfirm.value}); handleSubmit(applicantStep.summary, sections.summary_confirm)}}
                  isToggled = {isConfirm.value}
                />
            <div className='uob-input-separator' id={sections.summary_confirm} />
              <ToggleInput
                  isWithTitle={true}
                  title={labels.isAgreeConfirm}
                  description = {labels.agreeConfirmDescription}
                  isValid={isAgreeConfirm.isValid}
                  errorMsg={isAgreeConfirm.errorMsg}
                  onClick={() => { this.handleToggle('isAgreeConfirm', isAgreeConfirm, [], {value: !isAgreeConfirm.value})}}
                  isToggled = {isAgreeConfirm.value}
                />    
            {
              (commonReducer.currentStep === applicantStep.summary) &&
                <div className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.confirm}
                    onClick={this.handleSubmit.bind(this)}
                    isLoading={commonReducer.isProcessing}
                  />
                </div>
            }  
        </div>
      );
    }
  }
export default withRouter(Summary);
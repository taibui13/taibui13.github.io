import { connect } from 'react-redux';
import UploadDocuments from './view/uploadDocuments';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep, submitPartialApplication, uploadFile } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  changeCurrentStep,
  submitPartialApplication,
  uploadFile
}

const mapStateToProps = (state) => ({
  nationalID: state.uploadDocumentsReducer.nationalID,
  KITAS: state.uploadDocumentsReducer.KITAS,
  incomeDocument: state.uploadDocumentsReducer.incomeDocument,
  isCreditLimit: state.uploadDocumentsReducer.isCreditLimit,
  taxIDDocument: state.uploadDocumentsReducer.taxIDDocument,
  isDisableForm: state.uploadDocumentsReducer.isDisableForm,
  id: state.basicDetailReducer.id,
  basicDetailReducer: state.basicDetailReducer,
  commonReducer: state.commonReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(UploadDocuments);
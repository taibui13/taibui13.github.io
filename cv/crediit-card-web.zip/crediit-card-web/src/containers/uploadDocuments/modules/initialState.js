export default {
    nationalID: {
        name: 'nationalID',
        fileSize: '',
        inputValue: '',
        docType: 'NATIONAL_ID_FRONT',
        progress: 0,
        isValid: true,
        isInitial: true,
        errorMsg: ''
      },
    KITAS: {
        name: 'KITAS',
        fileSize: '',
        inputValue: '',
        docType: 'KITAS',
        progress: 0,
        isValid: true,
        isInitial: true,
        errorMsg: ''
      },  
    incomeDocument: {
        name: 'incomeDocument',
        fileSize: '',
        inputValue: '',
        docType: 'INCOME',
        progress: 0,
        isValid: true,
        isInitial: true,
        errorMsg: ''
      },  
    isCreditLimit: false,  
    taxIDDocument: {
        name: 'taxIDDocument',
        fileSize: '',
        inputValue: '',
        docType: 'TAX',
        progress: 0,
        isValid: true,
        isInitial: true,
        errorMsg: ''
      },  
      isDisableForm: false,
}
  
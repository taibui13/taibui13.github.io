import { UPLOAD_DOCUMENTS } from '../../../actions/actionTypes';

export const Action = {
    GET_DATA: `${UPLOAD_DOCUMENTS}_GET_DATA`,
    REQUIRE_ERROR: `${UPLOAD_DOCUMENTS}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}


function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





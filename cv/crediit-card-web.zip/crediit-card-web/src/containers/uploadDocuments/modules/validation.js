export const validateFields = (props) => {
    const {   uploadDocumentsReducer: {
              nationalID,
              KITAS,
              incomeDocument,
              isCreditLimit,
              taxIDDocument },
              basicDetailReducer
         } = props;
    let arr = [incomeDocument, nationalID];
    if(basicDetailReducer.passportNumber.value) {
       arr.push(KITAS);
    }
    if(isCreditLimit) {
        arr.push(taxIDDocument);
    }
    return arr;
}

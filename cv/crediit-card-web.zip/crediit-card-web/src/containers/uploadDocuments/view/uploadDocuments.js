import React from 'react';
import './uploadDocuments.scss';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import FileUpload from '../../../components/FileUpload/FileUpload';
import ToggleInput from '../../../components/ToggleInput/ToggleInput';
import { Action } from '../modules/responseHandler';
import { applicantStep, sections } from '../../../constants/common';
import { resetRequiredFields, resetInputFile } from '../../../common/utils';
import validateForm from '../../applicant/validation';

export default class UploadDocuments extends React.Component {
    constructor(props) {
      super(props);
       this.files =  {
          nationalID: {},
          KITAS: {},
          incomeDocument: {},
          taxIDDocument: {}
       }
    }


    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
         Object.keys(obj).forEach(key => { data[key] = obj[key] });
      }
      handleChangeData(Action.GET_DATA, {field, data})
    }


    handleToggle(name, value, showedCompoments) {
      this.handleOnChange(name, value);
      if(!value && showedCompoments && showedCompoments.length > 0) {
        this.files.taxIDDocument = {};
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleResetData(showedCompoments, isReset) {
      if(isReset) {
        resetInputFile(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleSubmit() {
      const { commonReducer, handleSubmit, uploadFile} = this.props;
      const result = validateForm(commonReducer.currentStep);
      if(!result.isRequire) {
         this.handleOnChange("isDisableForm", false);
         uploadFile(this.files, handleSubmit.bind(this, applicantStep.summary, sections.summary));
      } else {
        handleSubmit(applicantStep.uploadDocument, result.section);
      }
    }
    handleUploadFile(file, size, data) {
      const {uploadFile, commonReducer} = this.props;
      this.files[data.name] = {id: this.props.id, file: file, docType: data.docType } ;
      this.handleOnChange(data.name, data, { progress: 100, fileSize: size, inputValue: file.name, isInitial: false, isValid: true });
      if(commonReducer.currentStep !== applicantStep.uploadDocument) {
        this.files[data.name] = {id: this.props.id, file: file, docType: data.docType } ;
        uploadFile([{id: this.props.id, file: file, docType: data.docType }], "");
      }
    }

    render() {
      const {  
            nationalID,
            KITAS,
            incomeDocument,
            isCreditLimit,
            taxIDDocument,
            basicDetailReducer,
            isDisableForm,
            commonReducer } = this.props;
      const labels = commonReducer.appData.uploadDocuments.labels;
      return(
        <div className="work-infor" id={sections.uploadDocument}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          {     
             <div className='uob-input-separator'>
             <FileUpload
               inputID={'nationalID'}
               isValid={nationalID.isValid}
               errorMsg={[nationalID.errorMsg, commonReducer.msg.maxFileSize]}
               title={labels.nationalID}
               inputValue={nationalID.inputValue}
               fileSize={nationalID.fileSize}
               identifier={commonReducer.identifier}
               docType={'nationalID'}
               description={labels.nationalIDDescription}
               progressValue={nationalID.progress}
               labelName= {labels.upload}
               handleUploadFile={(file, size) => this.handleUploadFile(file, size, nationalID)}
               isDisabled={isDisableForm}
               isDisplayDetail={true}
             />
           </div>
          }
         
          {
              basicDetailReducer.passportNumber.value &&
              <div className='uob-input-separator'>
              <FileUpload
                  inputID={'KITAS'}
                  isValid={KITAS.isValid}
                  errorMsg={[KITAS.errorMsg, commonReducer.msg.maxFileSize]}
                  title={labels.KITAS}
                  inputValue={KITAS.inputValue}
                  fileSize={KITAS.fileSize}
                  identifier={commonReducer.identifier}
                  docType={'KITAS'}
                  description={labels.KITASDescription}
                  progressValue={KITAS.progress}
                  labelName= {labels.upload}
                  handleUploadFile={(file, size) => this.handleUploadFile(file, size, KITAS)}
                  isDisabled={isDisableForm}
                  isDisplayDetail={true}
                />
              </div>
            }
             <div className='uob-input-separator'>
              <FileUpload
                inputID={'incomeDocument'}
                isValid={incomeDocument.isValid}
                errorMsg={[incomeDocument.errorMsg, commonReducer.msg.maxFileSize]}
                title={labels.incomeDocument}
                inputValue={incomeDocument.inputValue}
                fileSize={incomeDocument.fileSize}
                identifier={commonReducer.identifier}
                docType={'incomeDocument'}
                description={labels.incomeDocumentDescription}
                progressValue={incomeDocument.progress}
                labelName= {labels.upload}
                handleUploadFile={(file, size) => this.handleUploadFile(file, size, incomeDocument)}
                isDisabled={isDisableForm}
                isDisplayDetail={true}
              />
            </div>
            <div className='uob-input-separator' />
            <ToggleInput
                description = {labels.isCreditLimit}
                //onClick={this.handleToggle.bind(this, 'isCreditLimit', !isCreditLimit, [taxIDDocument])}
                isToggled = {isCreditLimit}
                isDisabled={isDisableForm}
                onClick={() => {this.handleToggle('isCreditLimit', !isCreditLimit, [taxIDDocument]);
                this.handleResetData([taxIDDocument], isCreditLimit)
                }}
              /> 
              {
                isCreditLimit && 
                <FileUpload
                  inputID={'taxIDDocument'}
                  isValid={taxIDDocument.isValid}
                  errorMsg={[taxIDDocument.errorMsg, commonReducer.msg.maxFileSize]}
                  title={labels.taxIDDocument}
                  inputValue={taxIDDocument.inputValue}
                  fileSize={taxIDDocument.fileSize}
                  docType={'taxIDDocument'}
                  description={labels.taxIDDocumentDescription}
                  progressValue={taxIDDocument.progress}
                  labelName= {labels.upload}
                  handleUploadFile={(file, size) => this.handleUploadFile(file, size, taxIDDocument)}
                  isDisabled={isDisableForm}
                  isDisplayDetail={true}
              />  
              }
          
            <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
            {
              (commonReducer.currentStep === applicantStep.uploadDocument) &&
                <div className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.continueButton}
                    onClick={this.handleSubmit.bind(this)}
                    //isLoading={commonReducer.isLoading}
                  />
                </div>
            }  
        </div>
      );
    }
  }
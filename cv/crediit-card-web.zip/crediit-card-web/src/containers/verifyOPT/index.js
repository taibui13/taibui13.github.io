import { connect } from 'react-redux';
import VerifyOTP from './view/verifyOTP';
import { handleChangeData, verifyOTP, sendOTP } from './modules/dispatchHandler';
import {changeCurrentStep, firstSubmitPartialApplication } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  verifyOTP,
  sendOTP,
  firstSubmitPartialApplication,
  changeCurrentStep
}

const mapStateToProps = (state) => ({
  otp: state.verifyOTPReducer.otp,
  count: state.verifyOTPReducer.count,
  mobileNumber: state.basicDetailReducer.mobileNumber,
  commonReducer: state.commonReducer
})

export default connect(mapStateToProps, mapDispatchToProps)(VerifyOTP);
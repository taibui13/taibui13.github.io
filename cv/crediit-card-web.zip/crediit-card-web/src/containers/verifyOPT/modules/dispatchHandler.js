import { Action } from './responseHandler';
import request from '../../../services/request';
import api from '../../../services/api';

export const handleChangeData = (hander, payload) => {
  return (dispatch) => {
    dispatch({type: hander, payload: payload});
  };
}

export function sendOTP(payload, handler, obj) {
  return (dispatch) => {
    request.post(api.sendotp, payload, false).then(res => {
      obj.data.prefix = res.data.prefix;
      obj.data.errorMsg = "";
      dispatch({type: handler, payload: obj});
    })
  };
}

export function verifyOTP(payload, props, goNextStep) {
  return (dispatch, getState) => {
    request.post(api.verifyOTP, payload, false, showError.bind(this, props)).then(res => {
        goNextStep();      
    }) 
  };
}

function showError(props, store) {
    props.otp.isCountingDown = true;
    props.otp.code = "";
    props.otp.errorMsg =  store.getState().commonReducer.appData.globalErrors.invalidOTP;
    let count = props.count;
    count ++;
    store.dispatch({type: Action.GET_DATA, payload: {field: "count", data: count}});
    store.dispatch({type: Action.GET_DATA, payload: {field: "otp", data: props.otp}});
}



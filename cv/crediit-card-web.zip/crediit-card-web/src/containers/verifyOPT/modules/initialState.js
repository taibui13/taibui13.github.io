export default {
    otp: {
        code: '',
        prefix: '',
        isCountingDown: true,
        isLoading: false,
        errorMsg: '',
        isInitial: true
    },
    count: 1
    
}
  
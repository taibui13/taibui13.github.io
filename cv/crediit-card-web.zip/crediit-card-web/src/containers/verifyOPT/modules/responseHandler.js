import { VERIFY_OTP } from '../../../actions/actionTypes';

export const Action = {
    GET_DATA: `${VERIFY_OTP}_GET_DATA`,
    REQUIRE_ERROR: `${VERIFY_OTP}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}


function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





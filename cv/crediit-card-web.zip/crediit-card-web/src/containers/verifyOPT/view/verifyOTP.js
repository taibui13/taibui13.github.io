import React from 'react';
import './verifyOTP.scss';
import SmsToken from '../../../components/SmsToken/SmsToken';
import { Action } from '../modules/responseHandler';
import { applicantStep, sections } from '../../../constants/common';


export default class verifyOTP extends React.Component {
   
    componentDidMount() {
      this.props.firstSubmitPartialApplication({}, this.props.handleSubmit.bind(this, applicantStep.personalDetail, sections.personalDetail));
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      Object.keys(obj).forEach(key => { data[key] = obj[key] });
      handleChangeData(Action.GET_DATA, {field, data})
    }

    verifyOTP(value) {
      if(value.length === 6) {
        this.props.verifyOTP({mobileNumber: this.props.mobileNumber.value.replace(/\s+/g, ''), otp: value}, this.props, this.props.firstSubmitPartialApplication.bind(this, {}, this.props.handleSubmit.bind(this, applicantStep.personalDetail, sections.personalDetail)));
      }
    }

    handleOnChangeCode(field, data, obj) {
      const { handleChangeData } = this.props;
      Object.keys(obj).forEach(key => {
        data[key] = obj[key];
      })
      handleChangeData(Action.GET_DATA, {field, data})
    }
  
    handleSendToken() {
      //const { sendOTP, otp, mobileNumber } = this.props;
      //sendOTP({ mobileNumber: mobileNumber.value.replace(/\s+/g, '')}, Action.GET_DATA, {field: 'otp', data: otp});
    }

    render() {
      const { otp, commonReducer, count } = this.props;
      const labels = commonReducer.appData.otp;
      const interval = count > 3 ? 120 : (count === 3 ? 60 : count * 5);
      return(
        <div className="work-infor uob-invisible" id={sections.verifySMS}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          <SmsToken
              interval={interval}
              isMobileHide={true}
              value={otp.code}
              prefix={otp.prefix}
              isCountingDown={otp.isCountingDown}
              onGetToken={() => this.handleSendToken()}
              onEndCountDown={value => this.handleOnChange('otp', otp, {isCountingDown: false})}
              onChangeCode={value => {this.handleOnChange('otp', otp, {code: value, errorMsg: ''}); this.verifyOTP(value);}}
              resendLabel={labels.resendOtp}
              isLoading={otp.isLoading}
              inlineErrorMsg={otp.errorMsg}
            />
            <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
      
        </div>
      );
    }
  }
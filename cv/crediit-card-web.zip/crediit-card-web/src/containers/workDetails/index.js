import { connect } from 'react-redux';
import WorkDetails from './view/workDetails';
import { handleChangeData } from './modules/dispatchHandler';
import {changeCurrentStep, submitPartialApplication } from '../../actions/commonAction';

const mapDispatchToProps = {
  handleChangeData,
  changeCurrentStep,
  submitPartialApplication
}

const mapStateToProps = (state) => ({
  natureOfEmployment: state.workDetailsReducer.natureOfEmployment,
  jobTitle: state.workDetailsReducer.jobTitle,
  companyName: state.workDetailsReducer.companyName,
  industry: state.workDetailsReducer.industry,
  lengthOfEmploymentAndBusiness: state.workDetailsReducer.lengthOfEmploymentAndBusiness,
  numberOfEmployee: state.workDetailsReducer.numberOfEmployee,
  entityType: state.workDetailsReducer.entityType,
  officeNumber: state.workDetailsReducer.officeNumber,
  officeExtension: state.workDetailsReducer.officeExtension,
  grossMonthlyIncome: state.workDetailsReducer.grossMonthlyIncome,
  previousCompany: state.workDetailsReducer.previousCompany,
  previousLengthOfEmployment: state.workDetailsReducer.previousLengthOfEmployment,
  isDisableForm: state.workDetailsReducer.isDisableForm,
  mobileNumber: state.basicDetailReducer.mobileNumber,
  commonReducer: state.commonReducer,
  id: state.basicDetailReducer.id
})


export default connect(mapStateToProps, mapDispatchToProps)(WorkDetails);
export default {
    natureOfEmployment: {
        name: 'natureOfEmployment',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
    },
    jobTitle: {
        name: 'jobTitle',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
    },
    companyName: {
        name: 'companyName',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    industry: {
        name: 'industry',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
        description: ''
    },
    lengthOfEmploymentAndBusiness: {
        name: 'lengthOfEmploymentAndBusiness',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    numberOfEmployee: {
        name: 'numberOfEmployee',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
    },
    entityType: {
        name: 'entityType',
        isValid: true,
        isFocus: false,
        value: '',
        errorMsg: '',
        isInitial: true,
        isMyInfo: false,
    },
    officeNumber: {
        name: 'officeNumber',
        isValid: true,
        value: '+62',
        errorMsg: '',
        isInitial: true
    },
    officeExtension: {
        name: 'officeExtension',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    grossMonthlyIncome: {
        name: 'grossMonthlyIncome',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    previousCompany: {
        name: 'previousCompany',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    previousLengthOfEmployment: {
        name: 'previousLengthOfEmployment',
        isValid: true,
        value: '',
        errorMsg: '',
        isInitial: true
    },
    isDisableForm: false
}
  
import { WORK_DETAIL } from '../../../actions/actionTypes';

export const Action = {
    GET_DATA: `${WORK_DETAIL}_GET_DATA`,
    GET_WORK_DEATAIL_DATA: `${WORK_DETAIL}_GET_DATA_INFO`,
    REQUIRE_ERROR: `${WORK_DETAIL}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.GET_WORK_DEATAIL_DATA]: handleGetWorkDetailData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}

function handleGetWorkDetailData(state, action) {
    const employers = action.data.filter(item => item.type === "C");
    const employer = employers.length > 0 ? employers[0] : {};
    const previousEmployers = action.data.filter(item => item.type === "P");
    const previousEmployer = previousEmployers.length > 0 ? previousEmployers[0] : {};
    let obj = { 
          ...state,
          natureOfEmployment: { ...state.natureOfEmployment, value: employer.natureOfEmployment, isInitial: false },
          companyName: { ...state.companyName, value: employer.companyName, isInitial: false },
          jobTitle: { ...state.jobTitle, value: employer.jobTitle, isInitial: false },
          industry: { ...state.industry, value: employer.industry, isInitial: false },
          lengthOfEmploymentAndBusiness: { ...state.lengthOfEmploymentAndBusiness, value: employer.lengthOfEmployment, isInitial: false },
          numberOfEmployee: { ...state.numberOfEmployee, value: employer.noOfEmployees, isInitial: false },
          entityType: { ...state.entityType, value: employer.entityType, isInitial: false },
          officeNumber: { ...state.officeNumber, value: employer.officeNumber, isInitial: false },
          officeExtension: { ...state.officeExtension, value: employer.officeExt, isInitial: false },
          grossMonthlyIncome: { ...state.grossMonthlyIncome, value: employer.grossMonthlyIncome, isInitial: false },
          isDisableForm: false
         };
    if(previousEmployer) {
        obj.previousCompany = { ...state.previousCompany, value: previousEmployer.companyName, isInitial: false };
        obj.previousLengthOfEmployment = { ...state.previousLengthOfEmployment, value: previousEmployer.lengthOfEmployment, isInitial: false };
    }     
    return obj;     
  }


function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}





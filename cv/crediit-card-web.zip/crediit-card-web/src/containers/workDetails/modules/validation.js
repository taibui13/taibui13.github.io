import { HIDDEN_JOB_TITTLE, HIDDEN_INDUSTRY, MAX_LENTH_OF_EMPLOYMENT, HIDDEN_LENGTH_OF_EMPLOYEE,
     HIDDEN_LENGTH_ENTITY, HIDDEN_NUMBER_EMPLOYMENT, HIDDEN_PREVIOUS_COMPANY } from '../../../constants/common';
export const validateFields = (props) => {
    const { 
            workDetailsReducer: {
            natureOfEmployment,
            jobTitle,
            companyName,
            industry,
            lengthOfEmploymentAndBusiness,
            numberOfEmployee,
            entityType,
            officeNumber,
           // officeExtension,
            grossMonthlyIncome,
            previousLengthOfEmployment}
         } = props;
    let arr = [natureOfEmployment, companyName, officeNumber, grossMonthlyIncome];
    if(!(HIDDEN_JOB_TITTLE.indexOf(natureOfEmployment.value) > -1)) {
        arr.push(jobTitle);
    }
    if(!(HIDDEN_INDUSTRY.indexOf(natureOfEmployment.value) > -1)) {
        arr.push(industry);
    }
    if(!(HIDDEN_LENGTH_OF_EMPLOYEE.indexOf(natureOfEmployment.value) > -1)) {
        arr.push(lengthOfEmploymentAndBusiness);
    }
    if((HIDDEN_LENGTH_ENTITY.indexOf(natureOfEmployment.value) > -1)) {
        arr.push(entityType);
    }
    if((HIDDEN_NUMBER_EMPLOYMENT.indexOf(natureOfEmployment.value) > -1)) {
        arr.push(numberOfEmployee);
    }
    if(lengthOfEmploymentAndBusiness.value && (Number(lengthOfEmploymentAndBusiness.value) < MAX_LENTH_OF_EMPLOYMENT) && !(HIDDEN_PREVIOUS_COMPANY.indexOf(natureOfEmployment.value) > -1)) {
      arr.push(previousLengthOfEmployment);
    }
    return arr;
}
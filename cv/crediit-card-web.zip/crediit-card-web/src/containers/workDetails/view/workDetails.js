import React from 'react';
import './workDetails.scss';
import TextInput from '../../../components/TextInput/TextInput';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import Dropdown from '../../../components/Dropdown/Dropdown';
import { Action } from '../modules/responseHandler';
import { applicantStep, HIDDEN_JOB_TITTLE, HIDDEN_INDUSTRY, NATURE_EMPLOYEE_INDUSTRY, MAX_LENTH_OF_EMPLOYMENT,
   HIDDEN_LENGTH_OF_EMPLOYEE, HIDDEN_NUMBER_EMPLOYMENT, HIDDEN_LENGTH_ENTITY, HIDDEN_PREVIOUS_COMPANY,
    sections, DEFAULT_JOB_TITLE_MAPPING } from '../../../constants/common';
import { resetRequiredFields, convertObjToArray } from '../../../common/utils';
import validateForm from '../../applicant/validation';

export default class WorkDetails extends React.Component {
    constructor(props) {
      super(props);
      this.natureOfEmployments = [];
      this.occupations = [];
      this.industries = [];
      this.numberOfEmployees = [];
      this.entityTypes = [];
    }

    componentWillMount() {
      const { commonReducer } = this.props;
      this.natureOfEmployments = convertObjToArray(commonReducer.appData.inputValues.natureOfEmployment, "value",  "description");
      this.occupations = convertObjToArray(commonReducer.appData.inputValues.occupation, "value",  "description");
      this.industries =convertObjToArray(commonReducer.appData.inputValues.industry, "value",  "description");
      this.numberOfEmployees =convertObjToArray(commonReducer.appData.inputValues.numberOfEmployees, "value",  "description");
      this.entityTypes =convertObjToArray(commonReducer.appData.inputValues.entityTypes, "value",  "description");
    }

    handleOnChange(field, data, obj) {
      const { handleChangeData } = this.props;
      if(obj) {
        Object.keys(obj).forEach(key => { data[key] = obj[key] });
      }
      handleChangeData(Action.GET_DATA, {field, data})
    }

    handleDropdownClick(selectedItem, data) {
      Object.keys(selectedItem).forEach(key => { data[key] = selectedItem[key] });
      this.handleOnChange(data.name, data);
    }

    handleOnSearchChange(e, data) {
      data.searchValue =  e.target.value;
      this.handleOnChange(data.name, data);
    }

    handleToggle(name, value, showedCompoments) {
      this.handleOnChange(name, value);
      if(!value && showedCompoments && showedCompoments.length > 0) {
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleSubmit() {
      const { commonReducer, submitPartialApplication, handleSubmit, id } = this.props;
      const result = validateForm(commonReducer.currentStep);
      if(!result.isRequire) {
         this.handleOnChange("isDisableForm", true);
         submitPartialApplication({id: id}, handleSubmit.bind(this, applicantStep.officeAddress, sections.officeAddress));
      } else {
        handleSubmit(applicantStep.workDetails, result.section);
      }
    }

    handleForcus(data, isFocus) {
      data.isFocus = isFocus;
      this.handleOnChange(data.name, data);
    }
    
    handleResetData(showedCompoments, isReset) {
      if(isReset) {
        resetRequiredFields(showedCompoments, this.props.handleChangeData.bind(this, Action.GET_DATA));
      }
    }

    handleMappingJobTitle(employmentID) {
      const jobId = DEFAULT_JOB_TITLE_MAPPING[employmentID];
      if(jobId) {
          const data = { errorMsg: "", isFocus: true, isInitial: false, isMyInfo: false, isValid: true, name: "jobTitle", value: jobId };
          this.handleOnChange(data.name, data);
      }
    }

    render() {
      const {  
              natureOfEmployment,
              jobTitle,
              companyName,
              industry,
              lengthOfEmploymentAndBusiness,
              numberOfEmployee,
              entityType,
              officeNumber,
              officeExtension,
              grossMonthlyIncome,
              previousCompany,
              isDisableForm,
              previousLengthOfEmployment,
              commonReducer } = this.props;
      const labels = commonReducer.appData.workDetails.labels;
      const readOnlyFields = commonReducer.appData.myInfoReadonlyFields;
      const isReadOnlyField = (field) => {
        const isReadField = readOnlyFields[field] ? readOnlyFields[field] : false;
        return isDisableForm && isReadField;
      }
      return(
        <div className="work-infor" id={sections.workDetails}>
          <h1>{labels.title}</h1>
          <div className="uob-form-separator"></div>
          <p className='uob-headline'>{labels.subtitle}</p>
          <div className='uob-input-separator'/>
          <div className='uob-input-separator'/>
              <Dropdown
                inputID='natureOfEmployment'
                isReadOnly={isReadOnlyField('natureOfEmployment')}
                isFocus={natureOfEmployment.isFocus}
                label={labels.natureOfEmployment}
                value={natureOfEmployment.value}
                isValid={natureOfEmployment.isValid}
                errorMsg={natureOfEmployment.errorMsg}
                dropdownItems={this.natureOfEmployments}
                searchValue={natureOfEmployment.searchValue}
                onBlur={this.handleForcus.bind(this, natureOfEmployment, false)}
                onFocus={this.handleForcus.bind(this, natureOfEmployment, true)}
                onClick={(data) => { this.handleDropdownClick(data, natureOfEmployment);
                  if(HIDDEN_JOB_TITTLE.indexOf(data.value) > -1) {
                    this.handleMappingJobTitle(data.value);
                  } else {
                    this.handleResetData([jobTitle], HIDDEN_JOB_TITTLE.indexOf(data.value) > -1);
                  }
                  this.handleResetData([industry], HIDDEN_INDUSTRY.indexOf(data.value) > -1);
                  this.handleResetData([entityType], HIDDEN_LENGTH_ENTITY.indexOf(data.value) > -1);
                  this.handleResetData([lengthOfEmploymentAndBusiness], HIDDEN_LENGTH_OF_EMPLOYEE.indexOf(data.value) > -1);
                  this.handleResetData([previousLengthOfEmployment, previousCompany], HIDDEN_PREVIOUS_COMPANY.indexOf(data.value) > -1);
                  
                }}
                onSearchChange={(event) => this.handleOnSearchChange(event, natureOfEmployment)}
              /> 
          {
             !(HIDDEN_JOB_TITTLE.indexOf(natureOfEmployment.value) > -1) && natureOfEmployment.value !== "" &&
             <div className='uob-input-separator'>
              <Dropdown
                  inputID='jobTitle'
                  isReadOnly={isReadOnlyField('jobTitle')}
                  isFocus={jobTitle.isFocus}
                  label={labels.jobTitle}
                  value={jobTitle.value}
                  isValid={jobTitle.isValid}
                  errorMsg={jobTitle.errorMsg}
                  dropdownItems={this.occupations}
                  searchValue={jobTitle.searchValue}
                  onBlur={this.handleForcus.bind(this, jobTitle, false)}
                  onFocus={this.handleForcus.bind(this, jobTitle, true)}
                  onClick={(data) => { this.handleDropdownClick(data, jobTitle); }}
                  onSearchChange={(event) => this.handleOnSearchChange(event, jobTitle)}
                  unAmount={ resetRequiredFields.bind(this, [jobTitle], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                />    
              </div>       
          }
           <div className='uob-input-separator' />  
           <TextInput
                inputID='companyName'
                isReadOnly={isReadOnlyField('companyName')}
                label={labels.companyName}
                value={companyName.value}
                errorMsg={companyName.errorMsg}
                onChange={this.handleOnChange.bind(this, 'companyName')}
                isValid={companyName.isValid}
                validator={["required", "isAlphanumeric", "maxSize|35"]}
                isDisabled={false}
              />      
          {
           !(HIDDEN_INDUSTRY.indexOf(natureOfEmployment.value) > -1) && natureOfEmployment.value !== "" &&
             <div className='uob-input-separator'>
              <Dropdown
                  inputID='industry'
                  isReadOnly={isReadOnlyField('industry')}
                  isFocus={industry.isFocus}
                  label={labels.industry}
                  value={industry.value}
                  isValid={industry.isValid}
                  errorMsg={industry.errorMsg}
                  dropdownItems={this.industries}
                  searchValue={industry.searchValue}
                  onBlur={this.handleForcus.bind(this, industry, false)}
                  onFocus={this.handleForcus.bind(this, industry, true)}
                  onClick={(data) => { this.handleDropdownClick(data, industry); }}
                  onSearchChange={(event) => this.handleOnSearchChange(event, industry)}
                  unAmount={resetRequiredFields.bind(this, [industry], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                />    
              </div>       
          }
          {
             !(HIDDEN_LENGTH_OF_EMPLOYEE.indexOf(natureOfEmployment.value) > -1) && natureOfEmployment.value !== "" &&
            <div className='uob-input-separator'>  
             <TextInput
                  inputID='lengthOfEmploymentAndBusiness'
                  isReadOnly={isReadOnlyField('lengthOfEmploymentAndBusiness')}
                  label={ NATURE_EMPLOYEE_INDUSTRY.indexOf(natureOfEmployment.value) > -1 ? labels.lengthOfBusiness: labels.lengthOfEmployment}
                  value={lengthOfEmploymentAndBusiness.value}
                  errorMsg={lengthOfEmploymentAndBusiness.errorMsg}
                  onChange={data => {this.handleOnChange('lengthOfEmploymentAndBusiness', data);
                      this.handleResetData([previousLengthOfEmployment, previousCompany], Number(data.value) >= MAX_LENTH_OF_EMPLOYMENT)
                  }}
                  isValid={lengthOfEmploymentAndBusiness.isValid}
                  validator={["required", "isNumber", "maxSize|4"]}
                  isDisabled={false}
                  unAmount={resetRequiredFields.bind(this, [lengthOfEmploymentAndBusiness], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                />  
            </div>     
          }
          {   
            (HIDDEN_NUMBER_EMPLOYMENT.indexOf(natureOfEmployment.value) > -1) && natureOfEmployment.value !== "" &&
              <div className='uob-input-separator' >
              <Dropdown
                   inputID='numberOfEmployee'
                   isReadOnly={isReadOnlyField('numberOfEmployee')}
                   isFocus={numberOfEmployee.isFocus}
                   label={labels.numberOfEmployee}
                   value={numberOfEmployee.value}
                   isValid={numberOfEmployee.isValid}
                   errorMsg={numberOfEmployee.errorMsg}
                   dropdownItems={this.numberOfEmployees}
                   searchValue={numberOfEmployee.searchValue}
                   onBlur={this.handleForcus.bind(this, numberOfEmployee, false)}
                   onFocus={this.handleForcus.bind(this, numberOfEmployee, true)}
                   onClick={(data) => { this.handleDropdownClick(data, numberOfEmployee); }}
                   onSearchChange={(event) => this.handleOnSearchChange(event, numberOfEmployee)}
                   unAmount={resetRequiredFields.bind(this, [numberOfEmployee], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                 />   
              </div>  
            }
            {
              (HIDDEN_LENGTH_ENTITY.indexOf(natureOfEmployment.value) > -1) && natureOfEmployment.value !== "" &&
              <div className='uob-input-separator' >
               <Dropdown
                   inputID='entityType'
                   isReadOnly={isReadOnlyField('entityType')}
                   isFocus={entityType.isFocus}
                   label={labels.entityType}
                   value={entityType.value}
                   isValid={entityType.isValid}
                   errorMsg={entityType.errorMsg}
                   dropdownItems={this.entityTypes}
                   searchValue={entityType.searchValue}
                   onBlur={this.handleForcus.bind(this, entityType, false)}
                   onFocus={this.handleForcus.bind(this, entityType, true)}
                   onClick={(data) => { this.handleDropdownClick(data, entityType); }}
                   onSearchChange={(event) => this.handleOnSearchChange(event, entityType)}
                   unAmount={resetRequiredFields.bind(this, [entityType], this.props.handleChangeData.bind(this, Action.GET_DATA))}
                 /> 
                </div> 
            } 
               
            <div className='uob-input-separator' />    
            <TextInput
                  type='Phone'
                  inputID='officeNumber'
                  isReadOnly={isReadOnlyField('officeNumber')}
                  label={labels.officeNumber}
                  value={officeNumber.value}
                  errorMsg={officeNumber.errorMsg}
                  isValid={officeNumber.isValid}
                  validator={["required", "isPhoneNumber|16"]}
                  onChange={this.handleOnChange.bind(this, 'officeNumber')}
                  isDisabled={false}
                />    
           <div className='uob-input-separator' />    
              <TextInput
                  inputID='officeExtension'
                  isReadOnly={isReadOnlyField('officeExtension')}
                  label={labels.officeExtension}
                  value={officeExtension.value}
                  errorMsg={officeExtension.errorMsg}
                  isValid={officeExtension.isValid}
                  validator={["isNumber", "maxSize|8"]}
                  onChange={this.handleOnChange.bind(this, 'officeExtension')}
                  isDisabled={false}
                />     
             <div className='uob-input-separator' />    
              <TextInput
                  inputID='grossMonthlyIncome'
                  isReadOnly={isReadOnlyField('grossMonthlyIncome')}
                  label={labels.grossMonthlyIncome}
                  value={grossMonthlyIncome.value}
                  errorMsg={grossMonthlyIncome.errorMsg}
                  isValid={grossMonthlyIncome.isValid}
                  validator={["required", "isNumber", "minAmount|4000000", "maxSize|10"]}
                  onChange={this.handleOnChange.bind(this, 'grossMonthlyIncome')}
                  isDisabled={false}
                />  
               {
                 (lengthOfEmploymentAndBusiness.value && Number(lengthOfEmploymentAndBusiness.value) < MAX_LENTH_OF_EMPLOYMENT) &&
                 !(HIDDEN_PREVIOUS_COMPANY.indexOf(natureOfEmployment.value) > -1) &&
                 <div> 
                  <div className='uob-input-separator uob-invisible' >    
                    <TextInput
                      inputID='previousCompany'
                      isReadOnly={isReadOnlyField('previousCompany')}
                      label={labels.previousCompany}
                      value={previousCompany.value}
                      errorMsg={previousCompany.errorMsg}
                      isValid={previousCompany.isValid}
                      validator={["required", "isAlphanumeric",  "maxSize|35"]}
                      onChange={this.handleOnChange.bind(this, 'previousCompany')}
                      isDisabled={false}
                    />   
                  </div>  
                  <div className='uob-input-separator' />    
                  <TextInput
                      inputID='previousLengthOfEmployment'
                      isReadOnly={isReadOnlyField('previousLengthOfEmployment')}
                      label={labels.previousLengthOfEmployment}
                      value={previousLengthOfEmployment.value}
                      errorMsg={previousLengthOfEmployment.errorMsg}
                      isValid={previousLengthOfEmployment.isValid}
                      validator={["required", "isNumber",  "maxSize|4"]}
                      onChange={this.handleOnChange.bind(this, 'previousLengthOfEmployment')}
                      isDisabled={false}
                    />    
                 </div>
               }  
                           
          <div className='uob-input-separator'> 
               <div className= 'terms'> {labels.consent} </div>
            </div>
            {
              (commonReducer.currentStep === applicantStep.workDetails) &&
                <div className='uob-input-separator'>
                  <PrimaryButton
                    label={labels.continueButton}
                    onClick={this.handleSubmit.bind(this)}
                    isLoading={commonReducer.isProcessing}
                  />
                </div>
            }  
        </div>
      );
    }
  }
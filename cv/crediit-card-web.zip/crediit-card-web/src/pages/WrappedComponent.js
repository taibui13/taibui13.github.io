import React from "react";
import {connect} from 'react-redux';
import Loader from './../components/Loader/Loader';
import './../assets/css/uob-form-loan.scss';
import { getInitialData, setErrorMessage } from '../actions/commonAction';
import GenericErrorMessage from './../components/GenericErrorMessage/GenericErrorMessage';
import {getURLParameter} from '../common/utils';

export const wrapHOC = (WrappedComponent) => {
  
  class Wrapper extends React.Component {
   
    componentWillMount() {
      const { dispatch, commonReducer } = this.props;
      const lang = getURLParameter("lang") || "id";
      if (!commonReducer.appData) {
        dispatch(getInitialData(lang));
      }
    }

    handleOnClearMessage() {
      const { dispatch } = this.props;
      dispatch(setErrorMessage(''));
    }

    render() {
      const { commonReducer } = this.props;
      return (
        <div className='uob-form-loan'>
          <div className='uob-form-loan-container'>
            <div className='uob-header-wrap'>
              <div className='uob-header'>
              </div>
              {
               commonReducer.isLoading && <Loader />
              }
            </div>
            <div className='uob-body'>
              {
                (commonReducer.appData && commonReducer.msg) && <WrappedComponent {...this.props}/>
              }
            
            </div>
          </div>
          {
          (commonReducer.messageContent !== '') &&
            <GenericErrorMessage {...this.props} interval={45} messageContent={commonReducer.messageContent} onClearMessage={this.handleOnClearMessage.bind(this)} />
          }
        </div>
      );
    }
  }

  return connect(state => state)(Wrapper);
}
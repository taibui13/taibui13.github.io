import * as types from './../actions/actionTypes';
import { applicantStep } from '../constants/common';
const initialState = {
  isLoading: false,
  currentStep: applicantStep.basic,
  appData: null,
  messageContent: '',
  inlineMessage: '',
  backgroundUrl: '',
  logoUrl: null,
  errorType: '',
  msg: null
};

const commonReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.INITIAL_APP_DATA:
      return { ...state, appData: action.appData };

    case types.INITIAL_APP_MSG:
      return { ...state, msg: action.msg };  

    case types.SET_APP_LOADING_STATUS:
      return { ...state, isLoading: action.isLoading };

    case types.SET_ERROR_CONTENT_MESSAGE:
      return { ...state, messageContent: action.messageContent, errorType: action.errorType };

    case types.SET_INLINE_ERROR_MESSAGE:
      return { ...state, inlineMessage: action.inlineMessage };

    case types.CHANGE_CURRENT_STEP:
      return { ...state, currentStep: action.step };

    case types.SET_JWT_TOKEN:
      return { ...state, accessToken: action.accessToken };

    case types.RESET_TO_INITIAL:
      return initialState;

    default:
      return state;
  }
}

export default commonReducer;

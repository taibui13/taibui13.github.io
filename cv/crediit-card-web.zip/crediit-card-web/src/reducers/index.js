import { combineReducers } from 'redux';
import commonReducer from './commonReducer';
import basicDetailReducer from '../containers/basicDetails/modules/basicDetailReducer';
import verifyOTPReducer from '../containers/verifyOPT/modules/verifyOTPReducer';
import personalDetailsReducer from '../containers/personalDetails/modules/personalDetailsReducer';
import residentialDetailsReducer from '../containers/residentialDetails/modules/residentialDetailsReducer';
import workDetailsReducer from '../containers/workDetails/modules/workDetailsReducer';
import officeAddressReducer from '../containers/officeAddress/modules/officeAddressReducer';
import uploadDocumentsReducer from '../containers/uploadDocuments/modules/uploadDocumentsReducer';
import summaryReducer from '../containers/summary/modules/summaryReducer';
import completionReducer from '../containers/completion/modules/completionReducer';

export default combineReducers({
    commonReducer,
    basicDetailReducer,
    verifyOTPReducer,
    personalDetailsReducer,
    residentialDetailsReducer,
    workDetailsReducer,
    officeAddressReducer,
    uploadDocumentsReducer,
    summaryReducer,
    completionReducer
});

import React from 'react';
import { Switch, Route } from 'react-router-dom';
import { detectPathName } from './../common/utils';
import  Applicant from './../containers/applicant';
import  Completion from './../containers/completion';
import { wrapHOC } from '../pages/WrappedComponent';

const configureRoutes = () => (
  <main>
    <Switch>
      <Route exact path={detectPathName()} component={wrapHOC(Applicant)} />
      <Route path={`${detectPathName()}complete`} component={wrapHOC(Completion)} />
    </Switch>
  </main>
);

export default configureRoutes;

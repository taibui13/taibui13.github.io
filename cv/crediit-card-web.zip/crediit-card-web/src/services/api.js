/* global GLOBAL_CONFIG */
export default {
    getFormData: getForm,
    getMessage: getMsg,
    verifyOTP: "/api/v1/credit/verifyOtp",
    firstSubmitPartialApplication: "/api/v1/applications/application",
    submitPartialApplication: "/api/v1/applications/{id}/save",
    submitApplication: "/api/v1/applications/{id}/submit",
    sendotp: "/api/v1/credit/sendOtp",
    getAppication: "api/application/index.json",
    uploadFile: "/api/v1/applications/{id}/document", 
   
}

function getForm(lang) {
  return lang && lang.toLowerCase() === "en" ? GLOBAL_CONFIG.formConfig : GLOBAL_CONFIG.formConfigID;
}

function getMsg(lang) {
  return lang && lang.toLowerCase() === "en" ? GLOBAL_CONFIG.message : GLOBAL_CONFIG.messageID;
}
/* global GLOBAL_CONFIG */
export default {
    base: GLOBAL_CONFIG.API_PATH,
    base_dev: "http://localhost:9090"
}
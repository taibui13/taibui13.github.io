import endPoint from './endPoint';
import axios from 'axios';
import store from '../store/configureStore';
import { setLoadingStatus, setErrorMessage } from '../actions/commonAction';
const url_enviroment = (process.env.NODE_ENV === 'development') ? endPoint.base_dev : endPoint.base;
const request = (method) => {
    return (url, data, hideLoading, callbackError) => {
       if(!hideLoading) {
            store.dispatch(setLoadingStatus(true));
       }
        return new Promise((resolve, reject) => {
            axios[method](url_enviroment + url, data).then((response) => {
            resolve(response);
            store.dispatch(setLoadingStatus(false));
          }).catch((e) => {
              reject(e);
              store.dispatch(setLoadingStatus(false));
              if(callbackError) {
                callbackError(store)
              } else {
                const globalErrors = store.getState().commonReducer.appData.globalErrors;
                store.dispatch(setErrorMessage(globalErrors.apiException));
              }
             
            });
        });
    }   
    
}

const requestInternal = (method) => {
    return (url, data) => {
        return new Promise((resolve, reject) => {
            axios[method](url, data).then((response) => {
            resolve(response);
          }).catch((e) => reject(e));
        });
    }   
}

export const fileUploadHelper = (uploadUrl, file, obj, {progressDispatch}) => {
    return new Promise((resolve, reject) => {
        const xhr = new window.XMLHttpRequest();
        const formData = new window.FormData();
        formData.append("file", file);
        formData.append("documentType", obj.docType);
        xhr.upload.addEventListener(
            "progress",
            e => {  progressDispatch && progressDispatch(Math.round(e.loaded / e.total * 100)); },
            false
        );
        xhr.onloadend = e => { 
             if (e.target.status === 200) {
                resolve({upload: true})
             } else { 
                 showErrMessage();
                 reject({upload: false});
            }}
        xhr.open("POST", `${url_enviroment + uploadUrl.replace("{id}", obj.id)}`);
        xhr.onerror = () =>  showErrMessage();
        xhr.send(formData);
    }).catch(err => {
        console.log(err);
        showErrMessage();
        }
    )
};

const showErrMessage = () => {
    const globalErrors = store.getState().commonReducer.appData.globalErrors;
    store.dispatch(setLoadingStatus(false));
    store.dispatch(setErrorMessage(globalErrors.apiException));
}

export default {
    get : request("get"),
    getInternal : requestInternal("get"),
    post: request("post"),
    uploadFile: fileUploadHelper
}
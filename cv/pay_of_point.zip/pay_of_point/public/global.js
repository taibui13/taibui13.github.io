const GLOBAL_CONFIG = {
    API_PATH: "./..",
    root: "./",
    formConfig: "./form.json",
    message: "./msg.json"
};

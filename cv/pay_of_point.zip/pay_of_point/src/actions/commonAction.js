import * as types from './actionTypes';
import request from '../services/request';
import scrollIntoView from 'scroll-into-view';
import api from '../services/api';

export const getInitialData = (lang) => {
  return (dispatch) => {
    request.getInternal(api.getFormData(lang), {}).then(res => {
      dispatch({type: types.INITIAL_APP_DATA, appData: res.data});
    });
    request.getInternal(api.getMessage(lang), {}).then(res => {
      dispatch({type: types.INITIAL_APP_MSG, msg: res.data});
    })
  };
}

export function getMyInfo() {
  return (dispatch, getState) => {
    request.get(api.getAppication, {}, false).then(res => {
    })
  };
}


export const setErrorMessage = (messageContent, errorType='error') => {
  return (dispatch) => {
    dispatch({
      type: types.SET_ERROR_CONTENT_MESSAGE,
      messageContent,
      errorType
    })
  };
}

export const setInlineErrorMessage = (inlineMessage) => {
  return {
    type: types.SET_INLINE_ERROR_MESSAGE,
    inlineMessage
  }
}

//set loading status
export const setLoadingStatus = (isLoading) => {
  return (dispatch) => {
    dispatch({
      type: types.SET_APP_LOADING_STATUS,
      isLoading
    });
  };
}


export const setJWTToken = (accessToken) => {
  return {
    type: types.SET_JWT_TOKEN,
    accessToken
  }
}

export const changeCurrentStep = (step) => {
  return (dispatch) => {
    dispatch({
      type: types.CHANGE_CURRENT_STEP,
      step
    });
  };
};

export const scrollBackToSection = (nextStep, section) => {
  return (dispatch) => {
    Promise.resolve().then(() => {
      const element = document.querySelector(`[id='${section}']`);
      scrollIntoView(element, {time: 500, align: {top: 0}});
    });
  }
}

export const scrollToSection = (nextStep, section) => {
  return (dispatch) => {
    Promise.resolve().then(() => {
      dispatch(changeCurrentStep(nextStep));
    }).then(() => {
      const element = document.querySelector(`[id='${section}']`);
      scrollIntoView(element, {time: 500, align: {top: 0}});
    });
  }
}

import {} from './utils';
const convertAmountToUNI = (store, objInput) => {
    const balance =  Number(store.dataRes.value.poolBalance);
    const uni = (Number(objInput.value) * balance).toLocaleString();
    return [objInput.value.toLocaleString(), uni];
}
const convertUNItoAmount = (store) => {
    const balance =  Number(store.dataRes.value.poolBalance);
    const redeemValue = store.redeemValue;
    return [(balance * redeemValue).toLocaleString(), redeemValue.toLocaleString()];
}
export const STEP_ANWSER = {
    2 : {
        inputContentKey: {
            1: {setText: convertAmountToUNI}
        }
    },
    4 : {
        inputContentKey: {
            1: {setText: convertAmountToUNI}
        }
    },
    5 : {
        inputContentKey: {
            0: {setText: convertUNItoAmount}
        }
    },
}
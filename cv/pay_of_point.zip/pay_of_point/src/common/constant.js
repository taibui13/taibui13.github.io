import {} from './utils';
export const STEP_HAVE_SLIDER = [1];
export const DEFAULT_TIME_OUT = 1000 * 120;
export const PAGES = {
    REDEEM: "redeem",
    COMPLETE: "complete",
    ERROR: "error"
};

export const PARAMS = {
    REF_NO: "offerReferenceNo",
    TYPE_REDEEM : "fullRedeem"
}

export const REDEEM = {
    MIN_BLOCK: 1
}

export const STEP_RULE = {
    STEP_1 : {
        FULL_REDEEM_CONTENT: "fullRedeemContent",
        PARTIAL_REDEEM_CONTENT: "partialRedeemContent"
    }
}

export const REDEEM_TYPE = {
    FULL_REDEEM: 1,
    PARTIAL_REDEEM: 2,
    FULL_PARTIAL_REDEEM: 3
}
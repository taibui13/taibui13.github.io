import {} from './utils';
const initialMsg = (store) => {
    return [Number(store.dataRes.value.poolBalance).toLocaleString(), Number(store.dataRes.value.transactionAmount).toFixed(2).toLocaleString(), store.dataRes.value.cardNumber && store.dataRes.value.cardNumber.substr(-4)];
}

const countUNI = (store, obj) => {
    return [(Number(obj.value) * Number(store.dataRes.value.poolBalance)).toLocaleString()];
}

const remainUNI = (store) => {
    const remainPoint = Number(store.dataRes.value.fullRedeemPoints) - (Number(store.dataRes.value.poolBalance) * Number(store.redeemValue));
    return [store.redeemValue.toLocaleString(), remainPoint.toLocaleString()];
}

export const STEP_QUESTION = {
    1 : initialMsg,
    5 : countUNI,
    6 : remainUNI
}
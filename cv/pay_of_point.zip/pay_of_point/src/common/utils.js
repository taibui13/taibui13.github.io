
import {PAGES} from './constant';

export const mapValueToLabel = (arrayOfItems, value) => {
  const item = arrayOfItems.find(x => x.value === value);
  return item ? item.description : value;
};

export const imageExists = (url, callback) => {
  var img = new Image();
  img.onload = function() { callback(true); };
  img.onerror = function() { callback(false); };
  img.src = url;
}

export const bytesToSize = bytes => {
    var sizes = ["Bytes", "KB", "MB", "GB", "TB"];
    if (bytes === 0) {
        return "0 Byte";
    }
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
    return Math.round(bytes / Math.pow(1024, i), 2) + " " + sizes[i];
};

export const detectPathName = () => {
    const router = [PAGES.REDEEM, PAGES.COMPLETE, PAGES.ERROR];
    let pn = window.location.pathname;
    return pn.replace(router.filter(a => pn.indexOf(a) !== -1)[0], "");
};

export const getURLParameter = (name) => {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=([^&;]+?)(&|#|;|$)').exec(window.location.search) || [null, ''])[1].replace(/\+/g, '%20')) || '';
}

export const convertObjToArray = (obj, objKey, objValue) => {
    const arr = [];
    Object.keys(obj).map(key => arr.push({ [objKey]: key, [objValue]: obj[key]}));
    return arr;
  };

export const getIndexObject = (obj, key) => {
    return  Object.values(obj).indexOf(key);
}

export const smoothScroll = (elementId) => {
    const MIN_PIXELS_PER_STEP = 16;
    const MAX_SCROLL_STEPS = 30;
    let target = document.getElementById(elementId);
    let scrollContainer = target;
    do {
        scrollContainer = scrollContainer.parentNode;
        if (!scrollContainer) return;
        scrollContainer.scrollTop += 1;
    } while (scrollContainer.scrollTop === 0);

    let targetY = 0;
    do {
        if (target === scrollContainer) break;
        targetY += target.offsetTop;
    } while (target === target.offsetParent);

    const pixelsPerStep = Math.max(MIN_PIXELS_PER_STEP,
                                 (targetY - scrollContainer.scrollTop) / MAX_SCROLL_STEPS);

    const stepFunc = () => {
        scrollContainer.scrollTop =
            Math.min(targetY, pixelsPerStep + scrollContainer.scrollTop);

        if (scrollContainer.scrollTop >= targetY) {
            return;
        }

        window.requestAnimationFrame(stepFunc);
    };

    window.requestAnimationFrame(stepFunc);
}

export const scrollToSmoothly = (target, option) => {
    let element = document.getElementById(target)
    if(element) {
        if(option === "top") {
            element.scrollTop = 0;
        }
        if(option === "bottom") {
            element.scrollTop = element.scrollHeight - element.offsetTop;
        }
    }
}

export const stringInject = (str, data) => {
    if (typeof str === 'string' && (data instanceof Array)) {
        return str.replace(/({\d})/g, (i) => {
            return data[parseInt(i.replace(/{/, '').replace(/}/, ''), 10) - 1];
        });
    } else if (typeof str === 'string' && (data instanceof Object)) {
        for (let key in data) {
            return str.replace(/({([^}]+)})/g, (i) => {
                let key = i.replace(/{/, '').replace(/}/, '');
                if (!data[key]) {
                    return i;
                }
                return data[key];
            });
        }
    } else {
        return false;
    }
}

export const convertObjectToMessages = (objStep, props, config, step, currentObj) => {
    let msgText = objStep[props.objName];
    let msgValue = objStep[props.objValue];
    for (let i = 0; i < msgText.length; i++ ) {
        if(msgValue && msgValue[i] && config[step]) {
            //let value = [...props.messages.value];
            let value = config[step](props, currentObj) || [];
            if(value.length > 0) {
               const replaceArr = value.slice(0, msgValue[i]);
               value.splice(0, msgValue[i]);
               msgText[i] = stringInject(msgText[i], replaceArr);
            }
        }
    }
    return msgText || [];
}

export const addValuesToText = (dataInput, obj, step, dataRes) => {
    if(obj[step] && obj[step].inputContentKey && obj[step].inputContentKey[dataInput.key] 
        && obj[step].inputContentKey[dataInput.key].setText instanceof Object) {
        const listOfValueText = obj[step].inputContentKey[dataInput.key].setText(dataRes, dataInput) || [];
        return listOfValueText && stringInject(dataInput.textDisplay, listOfValueText);
    }
    return dataInput.textDisplay;
}


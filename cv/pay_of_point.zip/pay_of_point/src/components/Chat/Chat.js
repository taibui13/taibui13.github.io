import React, {Component} from 'react';
import './Chat.scss';

import ChatMessage from '../ChatMessage/ChatMessage';
import ChatInput from '../ChatInput/ChatInput';
import logo from '../../assets/images/icon/UobLogo.png';
import Spinner from '../Spinner/Spinner';
import {STEP_ANWSER} from '../../common/anwserMessage';
import {addValuesToText, stringInject} from '../../common/utils';
import {REDEEM, REDEEM_TYPE} from '../../common/constant';
export default class Chat extends Component {
    constructor(props) {
        super(props);
        this.state = {
            messages: [], footer: {}
        };
        this.containerId = "messages-content";
        this.enableScroll = false;
    }

    componentDidMount() {
        this.setState({footer: this.props.footer, messages: this.props.data});
    }
  
    componentWillReceiveProps(newProps) {
        const {data} = newProps;
        let {messages} = this.state;
        if(data.text.length > 0) {
           messages.push({text: data.text, isOwner: false});
           this.setState({messages: messages});
        }
        this.renderFooter(newProps)
    }

    sendText(obj) {
        let {messages} = this.state;
        if(obj.textDisplay) {
            messages.push({text: [addValuesToText(obj, STEP_ANWSER, this.props.step, this.props.responseData)], isOwner: true});
            this.setState({messages: messages});
        }
        this.props.sendData(obj);
    }

    sendInput(obj) {
        let footer = this.props.footer;
        this.props.sendData(obj);
        footer.defaultDisplay = obj.displayFooter;
        this.setState({footer: footer});
    }

    renderFooter(props) {
        let footer = {...props.footer};
        const {inputContent, responseData} = props;
        let redeemValue = Number(responseData.redeemValue);
        const redeemBlockSize = Number(responseData.dataRes.value.redeemBlockSize) / (Number(responseData.dataRes.value.redeemBlockValue) || REDEEM.MIN_BLOCK);
        let UNI = (inputContent[0].max === redeemValue) ? (redeemBlockSize * redeemValue) : redeemBlockSize * redeemValue;
        if(props.fullRedeem) {
            redeemValue = responseData.dataRes.value && Number(responseData.dataRes.value.fullRedeemValue);
            UNI = responseData.dataRes.value && Number(responseData.dataRes.value.fullRedeemPoints);
        }
        if(inputContent && inputContent[0] && inputContent[0].max === Number(responseData.redeemValue) && REDEEM_TYPE.FULL_PARTIAL_REDEEM === responseData.redeemType) {
            UNI = responseData.dataRes.value && Number(responseData.dataRes.value.fullRedeemPoints);
        }
        footer.redeem = stringInject(footer.redeem, [redeemValue.toFixed(2).toLocaleString(), Math.round(UNI).toLocaleString()]);
        this.setState({footer: footer});
    }

    componentDidUpdate() {
        //this.props.handleScroll && this.props.handleScroll(this.containerId, "bottom");
        const target = document.getElementById(this.containerId);
        if(target.scrollHeight > target.offsetHeight) {
            this.enableScroll = true;
        }
    }

    render() {
        const {messages, footer} = this.state;
        const {inputContent, isLoading, handleScroll, input, disabledForm, label, responseData} = this.props;
        return (
                <div className="chat">
                   {disabledForm &&  <div className="chat-disabled" onClick={() => { this.refs.chatInputChild.hide(); this.sendInput(input[0])}} />} 
                   <div className="chat-header">
                    <div className="chat-title">
                            <figure className="avatar"><img alt="#" src={logo}/></figure>
                        <label> {label.redeem.titleHeader} </label> 
                    </div>
                    </div>
                        <div className="messages">
                            <div id={this.containerId} className="messages-content">
                                <div className=" mCSB_inside" tabIndex="0">
                                    <div className="mCSB_container">
                                        {
                                            (messages || []).map((e, index) => {
                                            return <ChatMessage
                                                key={index}
                                                isOwner={e.isOwner}
                                                fullRedeem={true}
                                                text={e.text}
                                                isFooter={e.isFooter}
                                                inputContent={inputContent}
                                                responseData={responseData}
                                                sendText={this.sendText.bind(this)}
                                                isShowInputContent={messages.length - 1 === index}
                                                />
                                        })
                                        }
                                        {
                                            isLoading &&
                                            <div className="message new"> 
                                                <figure className="avatar">
                                                </figure>
                                                 <Spinner />
                                            </div>
                                        }
                                    </div>
                                </div>
                                 
                            </div>
                        </div>    
                    <div className="footer"> </div>   
                    { 
                      input && !isLoading &&
                      <ChatInput 
                      ref="chatInputChild"
                      inputData={input} 
                      sendText={this.sendInput.bind(this)} 
                      scrollTo={handleScroll.bind(this, this.containerId, "top")}
                      content={footer} 
                      enableScroll={this.enableScroll}/>
                    }   
                   
                </div>
        );
    }
}

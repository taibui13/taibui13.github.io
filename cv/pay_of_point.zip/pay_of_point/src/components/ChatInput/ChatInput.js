import React, {Component} from 'react';
import './ChatInput.scss';
import Chip from '../Chip/Chip';
export default class ChatInput extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: "",
            isLoading: false,
            animation: "message-box-animation-fast"
        };
        this.TIME_OUT = 250;
    }

    handleSend(obj, inputValue) {
       if(inputValue) {
         obj.value = inputValue;
       }
       this.props.sendText(obj);
       if(obj.isRequestServer) {
            this.setState({isLoading: true});
       }
    }

    setTimeHandle(obj, inputValue) {
        const _this = this;
        if(obj.delay) {
            _this.setState({animation: "message-box-animation-down"});
            setTimeout(() => {
                _this.setState({animation: "message-box-animation-fast"});
                return _this.handleSend(obj, inputValue);
            }, obj.delay);
        } else {
            this.handleSend(obj, inputValue);
            if(obj.delay === 0) {
                return;
            }
            this.setState({animation: "message-box-animation-down-fast"});
            setTimeout(() => {
                this.setState({animation: "message-box-animation"});
            }, this.TIME_OUT);
           
        }
    }

    hide() {
        this.setState({animation: "message-box-animation-down"});
        setTimeout(() => {
            this.setState({animation: "message-box-animation-fast"});
        }, this.TIME_OUT);
    }

    render() {
        const {inputData, content} = this.props;
        const {isLoading, animation} = this.state;
        const percent = {width: ((100 / inputData.length) - 2) + "%"};
        const clssModify = content.defaultDisplay ? "message-box-input-modify" : "";
        return (
            <div className={`message-box-input ${clssModify} ${animation} ${isLoading ? " message-box-disable" : ""}`}>
                {isLoading && <div className="message-box-loading" />}
               
                <div className="message-box--wrapp-left">
                {
                    content.defaultDisplay &&
                    <div className="message-title">
                        <h2>{content.title} </h2>
                        <p className="amount"> {content.redeem}  </p>
                        <p dangerouslySetInnerHTML={{__html: content.termCondition}}></p>
                    </div>
                }
              
                <div className="list chip"> 
                            {
                                (inputData || []).map((e, index) => {
                                    return  <Chip key={index} {...e} 
                                                sendText={this.setTimeHandle.bind(this, e)}
                                                width={percent}
                                            />
                                })
                            }
                    </div>
                </div>
            </div>
        );
    }
}

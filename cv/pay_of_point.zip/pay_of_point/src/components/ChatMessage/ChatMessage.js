import React, {Component} from 'react';
import './ChatMessage.scss';
import SliderInput from '../SliderInput/SliderInput';

export default class ChatMessage extends Component {
    
    sendText(obj, value) {
        obj.value = value;
        this.props.sendText(obj);
    }

    render() {
        const {isOwner, text, inputContent, isShowInputContent, fullRedeem, isFooter, responseData} = this.props;
        return (
            <div>
                { text.map((e, index) => {
                 return <div key={index}> 
                        <div className={`message ${isOwner ? " message-personal" : " new"}`}>
                        <div dangerouslySetInnerHTML={{__html: e}} />
                        </div>
                        { isFooter && <hr/>}
                        {
                            text.length - 1 === index && !isOwner && inputContent && isShowInputContent && 
                            (inputContent || []).map((e, index) => (
                            <div key={index}>  
                                {   
                                e.type === "chip/slider" && e.isLoaded && 
                                <div className="new message slider-message">
                                    <SliderInput responseData={responseData} defaultValue={fullRedeem ? 100 : 0} inputData={e} sendText={this.sendText.bind(this, e)}/>
                                </div>
                                }
                            </div>
                            ))
                        }
                        </div>
                })
            } 
            </div>
        );
    }
}

import React, {Component} from 'react';
import './Chip.scss';
export default class Chip extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: ""
        };
    }

    handleChange(event) {
        this.setState({value: event.target.value});
    }

    handleSend(data) {
       this.props.sendText(data && this.state.value)
    }


    render() {
        const {text, isConfirm, isConfirmText, width} = this.props;
        return (
            <button  
                className={`md-button chip-enable ${isConfirm && "md-button-confirm"}`}
                style={width}
                onClick={this.handleSend.bind(this, isConfirmText)}>
                {text}
          </button>
        );
    }
}

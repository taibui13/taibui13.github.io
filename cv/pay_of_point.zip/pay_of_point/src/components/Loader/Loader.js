import React from "react";
import "./Loader.css";
const Loader = () => {
    return (
        <div className="fader">
            <div className="message-box-loading" />
        </div>
    );
};
export default Loader;

import React, {Component} from 'react';
import './Slider.scss';
export default class Slider extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentValue: 0,
            position: {left : "0px"},
            filledPosition: {width : "0px"}
        };
        this.sliderRanger = null;
        this.isStopRanger = true;
        this.defaultPositionX = 0;
    }

    componentDidMount() {
      if(this.props.defaultValue > 0) {
        this.getValueFromPostion(this.sliderRanger.offsetWidth);
      }
    }

    handleDrag(e) {
        this.handleMove(e, Math.round(e.touches[0].clientX));
    }

    handleMouseMove(e) {
        this.handleMove(e, e.clientX);
    }

    handleListner(value) {
        if(this) {
            this.isStopRanger = value;
        }
    }

    handleMove(position, current) {
        if(this.isStopRanger) {
            return;
        }
        if(this.defaultPositionX === 0) {
            this.defaultPositionX = current;
        }
        position.stopPropagation();
        let posX = (current - this.defaultPositionX);
        if(this.props.defaultValue > 0) {
            posX = this.defaultPositionX - current;

            if(Math.round(posX) < 0 ) {
                this.getValueFromPostion(this.sliderRanger.offsetWidth);
            } 

            if(Math.round(posX) <= this.sliderRanger.offsetWidth && Math.round(posX) >= 0) {
                this.getValueFromPostion(this.sliderRanger.offsetWidth - posX);
            } 
            return;
          }
    }

    getValueFromPostion(current) {
        const {min, max, onChange} = this.props;
        const percentage  = Number(parseFloat(current / this.sliderRanger.offsetWidth).toFixed(4));
        const value = Number((Number(parseFloat((max - min) * percentage).toFixed(2))).toFixed(2));

        if(current >= this.sliderRanger.offsetWidth) {
            this.setState({position: {left : this.sliderRanger.offsetWidth + "px"}, filledPosition: {width : this.sliderRanger.offsetWidth + "px"}, currentValue: max});
            onChange(max);
        } else {
            this.setState({position: {left : current + "px"}, filledPosition: {width : current + "px"}, currentValue: value});
            onChange(value);
        }
    }

    handleEnd() {
        this.handleListner(true);
        this.props.onChangeCompleted(true);
    }

    render() {
        const {min, max, formatSym} = this.props;
        const {position, filledPosition, currentValue} = this.state;
        const clssHandleTouch = !this.isStopRanger ? " slider-handle-touch" : "";
        return (
            <div className="slider">
                <div className="slider-boxes">
                <div className="slider-box header" />
                <div className="slider-box"
                   aria-valuemin={min}
                   aria-valuemax={max}
                   aria-valuenow={currentValue}
                   ref={e => {this.sliderRanger = e}}
                   onMouseMove={this.handleMouseMove.bind(this)}
                   onMouseUp={this.handleEnd.bind(this, currentValue)}
                >
                    <div className="slider-position-1" />
                    <div className="slider-position-2" />
                    <div className="slider-position-3" />
                    <div className={"slider-handle" + clssHandleTouch}
                         style={position}
                         onMouseDown={this.handleListner.bind(this, false)}
                         onTouchMove={this.handleDrag.bind(this)}
                         onTouchStart={this.handleListner.bind(this, false)}
                         onTouchEnd={this.handleEnd.bind(this, currentValue)}
                      
                    />
                    <div className="slider-ranger"  >
                        <div className="slider-filled"  style={filledPosition} />
                    </div>
                </div>
                <div className="slider-box header" />
                </div>
                <div  className="slider-values" > 
                    <div className="from" >{formatSym + min.toFixed(2)}</div>
                    <div className="to" >{formatSym + max.toFixed(2)}</div>
                </div>
              
            </div>
        );
    }
}

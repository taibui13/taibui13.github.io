import React, {Component} from 'react';
import './SliderInput.scss';
import Slider from '../Slider/Slider';
import {REDEEM_TYPE} from '../../common/constant';
export default class SliderInput extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentValue: 0
        };
    }

    componentDidMount() {
        const {inputData : {max}} = this.props;
        if((this.props.defaultValue > 0)) {
            this.setState({currentValue: max});
            this.props.sendText(max);
        }
    }

    setMinBlockValue(currentPoint) {
        const {currentValue} = this.state;
        const {inputData : {minBlocK, min, max}} = this.props;
        if((currentPoint + min - minBlocK >= currentValue) || (currentPoint >= max)) {
            return true;
        } 
        if(currentValue - (currentPoint + min) > 0) {
            const block =  (currentValue - currentPoint)/minBlocK > 1 ? Number((currentValue - currentPoint)/minBlocK).toFixed() : 1;
            let value = currentPoint < min ? min : Number((currentValue - minBlocK * block).toFixed(2));
            const maxValueBaseBlock =  (max/min).toFixed() * min;
            if(currentValue === max && currentValue !== maxValueBaseBlock) {
                value = maxValueBaseBlock;
            }
            this.setState({currentValue: value});
        } 
        return false;
    }

    setCurrentValue(currentPoint) {
        const {inputData : {minBlocK, min, max}} = this.props;
        const {currentValue} = this.state;
        if(currentPoint + min >= currentValue ) {
            const block =  (currentPoint - currentValue)/minBlocK > 1 ? Number((currentPoint - currentValue)/minBlocK).toFixed() : 1;
            this.setState({currentValue: Number((currentValue + minBlocK * block).toFixed(2))});
        }
 
        if(this.props.defaultValue > 0 && currentPoint >= max) {
            this.setState({currentValue: max});
            this.onChangeCompleted(true);
        }
    }

    onChange(currentPoint) {
        const {inputData : { max, isFullRedeem}} = this.props;
        
        if(this.setMinBlockValue(currentPoint) || currentPoint >= max || isFullRedeem) {
            this.setCurrentValue(currentPoint);
        }
    }

    onChangeCompleted(isFullRedeem) {
        const {currentValue} = this.state;
        if(isFullRedeem && this.props.responseData.redeemType !== REDEEM_TYPE.FULL_REDEEM) {
           this.props.sendText(currentValue);
        }
    }

    getcurrentPoint() {
      const {inputData : {redeemBlockSize, isFullRedeem, max}, responseData: {dataRes}} = this.props;
      const {currentValue} = this.state;
      const fullRedemPoint = dataRes && dataRes.value && dataRes.value.fullRedeemPoints;
      let currentPoint = isFullRedeem ? fullRedemPoint : Math.round(redeemBlockSize * currentValue);
      if(currentValue === max && this.props.responseData.redeemType === REDEEM_TYPE.FULL_PARTIAL_REDEEM) {
        currentPoint = fullRedemPoint;
      }
      return Number(currentPoint);
    }

    render() {
        const {inputData : {sliderText, min, max, poolbalance, isFullRedeem}, defaultValue} = this.props;
        const {currentValue} = this.state;
        const currentPoint = this.getcurrentPoint();
        const isShowformula = false;
        return (
            <div className="slider-input">
                <div className="slider-input--title">
                    {sliderText.redeemptionQuestion}
                </div>
                <div className="slider-input--formula">
                {
                     isShowformula &&
                     <div className="boxes">
                        <div className="row">
                        <div className="box box-width">{sliderText.available}</div>
                        <div className="box"></div>
                        <div className="box box-width">{sliderText.redeem}</div>
                        <div className="box"></div>
                        <div className="box box-width">{sliderText.remaining}</div>
                        </div>
                        <div className="row">
                        <div className="box">UNI${poolbalance.toLocaleString()}</div>
                        <div className="box">-</div>
                        <div className="box">UNI${currentPoint.toLocaleString()}</div>
                        <div className="box">=</div>
                        <div className="box">UNI${(poolbalance - currentPoint).toLocaleString()}</div>
                        </div>
                    </div>
                }
               
                </div>
                <div className="slider-input--redeem">
                    {/* <div className="amount-text"> {sliderText.amountRedeem}</div> */}
                    <div className="amount"> ${currentValue.toFixed(2).toLocaleString()} </div>
                </div>
                <div className={`slider-input--slider ${isFullRedeem ? "slider-input--disabled" : ""}`}>
                    <Slider 
                        min={min} 
                        max={max}
                        formatSym={"$"} 
                        onChange={this.onChange.bind(this)} 
                        defaultValue={defaultValue}
                        onChangeCompleted={this.onChangeCompleted.bind(this)} />
                </div>
                <div className="slider-input--redeem-uni">
                    UNI${currentPoint.toLocaleString()}
                </div>
            </div>
        );
    }
}

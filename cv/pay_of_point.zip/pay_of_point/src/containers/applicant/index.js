import React, { Component } from 'react';
import { connect } from 'react-redux';
import ChatBot from '../chatBot';

class Applicant extends Component {

  render() {
    return(
      <div className="uob-container">
        <div className="uob-content">
         <ChatBot props={this.props} /> 
        </div>
      </div>
    );
  }
}

export default connect(state => state)(Applicant);
import { connect } from 'react-redux';
import chatBot from './view/chatBot';
import { handleChangeData, offer, redeem } from './modules/dispatchHandler';
import {changeCurrentStep, scrollBackToSection } from '../../actions/commonAction';


const mapDispatchToProps = {
  offer,
  redeem,
  handleChangeData,
  changeCurrentStep,
  scrollBackToSection
}

const mapStateToProps = (state) => ({
  responseData : state.chatBotReducer,
  commonReducer: state.commonReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(chatBot);
import { Action } from './responseHandler';
import { INITIAL_APP_INPUT_DATA } from '../../../actions/actionTypes';
import request from '../../../services/request';
import api from '../../../services/api';
import {STEP_HAVE_SLIDER, PAGES} from '../../../common/constant';

export function getData(payload) {
  return (dispatch) => {
    dispatch({type: Action.WORK_INFO_GET_DATA, payload: payload});
  };
}

export const handleChangeData = (hander, payload) => {
  return (dispatch) => {
    dispatch({type: hander, payload: payload});
  };
}

export function offer(payload, handler, goPage) {
  return (dispatch) => {
    request.get(api.offer.replace("{id}", payload.id), payload, true, redirectPage.bind(this, goPage)).then(res => {
      dispatch({type: INITIAL_APP_INPUT_DATA, payload: {res:res.data, steps: STEP_HAVE_SLIDER}});
      dispatch({type: handler, payload: res.data});
    })
  };
}

export function redeem(payload, goPage) {
  return () => {
    request.post(api.redeem.replace("{id}", payload.id), payload, true, redirectPage.bind(this, goPage)).then(res => {
      goPage && goPage({pathname: PAGES.COMPLETE, state: payload});
    })
  };
}

const redirectPage = (go, error) => {
  const errorCode = error && error.response && error.response.data && error.response.data.errorCode;
  const status = error && error.response && error.response.status;
  go && go({pathname: PAGES.ERROR, state: {errorID: errorCode ? errorCode: status}});
}


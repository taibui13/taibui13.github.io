export default {
    isRecieveData: false,
    objName: "content",
    objValue: "value",
    inputName: "inputContent",
    input: "input",
    footer: "footer",
    step: 1
}
  
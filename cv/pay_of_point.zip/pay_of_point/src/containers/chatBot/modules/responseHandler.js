import {REDEEM_TYPE, REDEEM} from '../../../common/constant';
const CHAT= "CHAT";
export const Action = {
    GET_DATA: `${CHAT}_GET_DATA`,
    GET_CHAT_DATA: `${CHAT}_GET_DATA_INFO`,
    REQUIRE_ERROR: `${CHAT}_REQUIRE_ERROR`
}
  
export default {
    [Action.GET_DATA]: handleGetData,
    [Action.GET_CHAT_DATA]: handleGetBasicData,
    [Action.REQUIRE_ERROR]: handleRequireError,
}


function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}

function handleGetBasicData(state, action) {
    let redeemType = REDEEM_TYPE.FULL_PARTIAL_REDEEM;
    let redeemValue = Number(action.payload.redeemBlockValue) * (Number(action.payload.minRedeemBlock) || REDEEM.MIN_BLOCK);
    if(Number(action.payload.maxRedeemPoints) === 0 && Number(action.payload.maxNbrRedeemBlocks) === 0 && Number(action.payload.maxRedeemValue) === 0 ) {
        redeemType = REDEEM_TYPE.FULL_REDEEM;
        redeemValue = Number(action.payload.fullRedeemValue);
    }
    if(Number(action.payload.fullRedeemPoints) === 0 && Number(action.payload.fullRedeemValue) === 0) {
        redeemType = REDEEM_TYPE.PARTIAL_REDEEM;
    }
   
    let chattingData = { 
          ...state,
          dataRes: { value: action.payload || {} },
          redeemValue: redeemValue,
          redeemType: redeemType,
          isRecieveData: true
         };
  
    return chattingData;     
  }

function handleRequireError(state, action) {
    return { ...state, [action.payload.field]: { ...state[action.payload.field], errorMsg: action.payload.errorMsg, isValid: false }};
}




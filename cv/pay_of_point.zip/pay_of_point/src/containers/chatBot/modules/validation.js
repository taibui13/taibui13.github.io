

export const validateFields = (props, data, step) => {
    const obj = (props.inputContent || []).filter(e => e.key === data.key);
    if(obj && obj[0]) {
      if(obj[0].nextStep && props.nextStep) {
        return {valid: true, step: props.nextStep[obj[0].nextStep], isRequestServer: data.isRequestServer, isSave: data.isSave, name: data.saveName};
      }
    }
    step ++;
    return {valid: true, step: step, isRequestServer: data.isRequestServer, isSave: data.isSave, name: data.saveName};
  }


  
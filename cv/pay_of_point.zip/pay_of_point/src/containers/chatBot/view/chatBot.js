import React from 'react';
import './ChatBot.scss';

import Chat from '../../../components/Chat/Chat';
import { Action } from '../modules/responseHandler';
import {convertObjectToMessages} from '../../../common/utils';
//import logo from  '../../../assets/images/icon/favicon.ico';
import {validateFields} from '../modules/validation';
import {scrollToSmoothly} from '../../../common/utils';
import {STEP_QUESTION} from '../../../common/questionMessage';
import {REDEEM, STEP_RULE, REDEEM_TYPE} from '../../../common/constant'

export default class ChatBot extends React.Component {
    constructor(props) {
        super(props);
        this.isRender = false;
        this.isLoading = false;
        this.state = {message: [], inputData: {}};
        this.step = 1;
        this.id = "";
        this.dataMgs = {};
        this.fullRedeem = false;
    }

    componentWillMount() {
      const {offer, commonReducer: {msg}, props} = this.props;
      this.id = props.location.state && props.location.state.offerReferenceNo;
      offer({id: this.id}, Action.GET_CHAT_DATA, this.props.props.history.push);
      this.setState({message: [{text: [msg.redeem.greeting]}]});
      this.isLoading = true;
    }

    componentWillReceiveProps(newProps) {
      const {responseData, commonReducer} = newProps;
      if(responseData.isRecieveData && responseData.dataRes && responseData.dataRes.value) {
        const stepObj = commonReducer.appData[this.step];
        if(responseData.redeemType === REDEEM_TYPE.FULL_REDEEM) {
          this.fullRedeem = true;
          responseData.objName = STEP_RULE.STEP_1.FULL_REDEEM_CONTENT;
        }
        if(responseData.redeemType === REDEEM_TYPE.PARTIAL_REDEEM) {
          responseData.objName = STEP_RULE.STEP_1.PARTIAL_REDEEM_CONTENT;
        }
        this.setState({message: {text: convertObjectToMessages(stepObj, responseData, STEP_QUESTION, this.step, this.dataMgs)}});
        this.setRender(true);
        this.isLoading = false;
        this.props.handleChangeData(Action.GET_DATA, {field : "isRecieveData", data: false});
      }
   }


   shouldComponentUpdate() {
      return this.isRender;
   }

    setRender(status) {
      this.isRender = status;
      //this.props.handleChangeData(Action.GET_DATA, {field : "isRecieveData", data: false});
    }

    sendData(data) {
      const { commonReducer: {appData}, responseData } = this.props;
      const result = validateFields(appData[this.step], data, this.step);
      if(result.isSave) {
        this.props.handleChangeData(Action.GET_DATA, {field : data.saveName, data: data.value});
      }
      this.props.handleChangeData(Action.GET_DATA, {field : "disabledForm", data: data.isConfirm ? true: false});
      if(result.isRequestServer) {
        let redeemPoints = responseData.redeemValue * (Number(responseData.dataRes.value.redeemBlockSize)/ (Number(responseData.dataRes.value.redeemBlockValue) || REDEEM.MIN_BLOCK));
        if( this.fullRedeem) {
          redeemPoints = responseData.dataRes.value && Number(responseData.dataRes.value.fullRedeemPoints);
        }
        if(responseData.redeemType === REDEEM_TYPE.FULL_PARTIAL_REDEEM && Number(responseData.dataRes.value.fullRedeemValue) === responseData.redeemValue) {
          redeemPoints = responseData.dataRes.value && Number(responseData.dataRes.value.fullRedeemPoints);
        }
        this.props.redeem({id: this.id, 
                          redeemValue: responseData.redeemValue,
                          redeemPoints: Math.round(redeemPoints),
                          poolBalance: Number(responseData.dataRes.value.poolBalance)},
                          this.props.props.history.push.bind(this));
        //this.isLoading = true;                  
      }
      this.setRender(true);
      this.setState({message: {text: []}});
    }

    handleScroll(id, position) {
      scrollToSmoothly(id, position);
    }

    render() {
     const { commonReducer, responseData } = this.props;
     this.setRender(false);
      return(
        <div className="chat-container">
          <div className="chat-container_left">
            <div>
            {/* <img alt="#" src={logo} /> */}
             {/* UOB */}
             </div>
          </div>
          <Chat isLoading={this.isLoading}
           inputContent={commonReducer.appData[this.step][responseData.inputName]} 
           input={commonReducer.appData[this.step][responseData.input]}
           footer={commonReducer.appData[this.step][responseData.footer]}
           label={commonReducer.msg}
           data={this.state.message}
           step={this.step} 
           responseData={responseData}
           disabledForm={responseData.disabledForm}
           fullRedeem={this.fullRedeem}
           sendData={this.sendData.bind(this)} handleScroll={this.handleScroll.bind(this)} />
        </div>
      );
    }
  }
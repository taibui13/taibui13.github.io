/* global GLOBAL_CONFIG */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import './index.scss';
import { stringInject } from '../../common/utils';

// import moment from 'moment';
class Complete extends Component {

  handleProcess = () => {
    this.props.history.push({ pathname: "redeem", search: '' })
  }

  redirect = (link) => {
    window.location.href = link;
  }

  render() {
    const { commonReducer: { msg }, location } = this.props;
    const labels = msg.complete || {};
    const transMsgLine1 = stringInject(labels.transactionLine1, [location.state.redeemValue.toFixed(2).toLocaleString()]);
    const transMsgLine2 = stringInject(labels.transactionLine2, [(location.state.poolBalance - location.state.redeemPoints).toLocaleString()]);
    return (
      <div className="complete">
        <div className="header" onClick={this.redirect.bind(this, labels.linkCard)}
          style={{ background: `linear-gradient(rgba(131, 182, 240, 0.226), rgba(105, 119, 136, 0.45)),url(${GLOBAL_CONFIG.root}${labels.banner})` }}
        >
          <div className="complete-remain">{labels.redeemed}</div>
          <div className="complete-uni">{labels.uni}
            {location.state.redeemPoints.toLocaleString()}
          </div>
        </div>
        <div className="bodyAndFooter">
          <div className="body">
            <div className="complete-image">
              <div>
                <img alt="#" />
              </div>

            </div>
            {/* <div className="complete-date"> {labels.dateProcessed} {moment().format("DD-MM-YYYY")} </div> */}
            <div className="complete-transaction"> {transMsgLine1} </div>
            <div className="complete-transaction transaction-line-2"> {transMsgLine2} </div>
            {/* <div className="complete-thank"> {labels.thankYou} </div> */}

          </div>
          <div className="footer">

            <div className="complete-reward"> {labels.reward}  </div>
            <div className="complete-term"> {labels.termAndCondition} </div>
            <div className="complete-link">  <button onClick={this.redirect.bind(this, labels.linkReward)}> {labels.rewardBtn} </button></div>

          </div>
        </div>
      </div>
    );
  }
}

export default connect(state => state)(Complete);
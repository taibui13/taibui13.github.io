import { connect } from 'react-redux';
import security from './view/security';
import { offer } from './modules/dispatchHandler';

const mapDispatchToProps = {
  offer
}

const mapStateToProps = (state) => ({
  responseData : state.securityReducer,
  commonReducer: state.commonReducer
})


export default connect(mapStateToProps, mapDispatchToProps)(security);
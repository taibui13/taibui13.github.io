import request from '../../../services/request';
import api from '../../../services/api';
import {PAGES} from '../../../common/constant';
import {Action} from './responseHandler';

export function offer(payload, goPage) {
  return (dispatch) => request.get(api.offer.replace("{id}", payload.id), payload, true, redirectPage.bind(this, goPage)).then(res => {
    dispatch({type: Action.GET_DATA, payload: {field: "isLoading", data: false}});
  })
}

const redirectPage = (go, error) => {
  const errorCode = error && error.response && error.response.data && error.response.data.errorCode;
  const status = error && error.response && error.response.status;
  go && go({pathname: PAGES.ERROR, state: {errorID: errorCode ? errorCode: status}});
}


const CHAT= "SECURITY";
export const Action = {
    GET_DATA: `${CHAT}_GET_DATA`
}
  
export default {
    [Action.GET_DATA]: handleGetData
}

function handleGetData(state, action) {
  return { ...state, [action.payload.field]: action.payload.data };
}


import React, { Component } from 'react';
import './index.scss';
import PrimaryButton from '../../../components/PrimaryButton/PrimaryButton';
import Loader from '../../../components/Loader/Loader';
import logo from '../../../assets/images/icon/UobLogo.png';
import logoRight from '../../../assets/images/icon/rightByYouLogo.jpg';
import iconInfo from '../../../assets/images/icon/info.png';
import {PAGES} from '../../../common/constant';
import {getURLParameter} from '../../../common/utils';

export default class Security extends Component {

  componentWillMount() {
    this.offerReferenceNo = getURLParameter("t");
    this.props.offer({id: this.offerReferenceNo}, this.props.history.push);
  }

  handleProcess = () => {
    this.props.history.push({pathname : PAGES.REDEEM, state:{offerReferenceNo: this.offerReferenceNo}})
  }

  createMarkup(text) {
    return {__html: text};
  }

  render() {
    const {commonReducer: {msg}, securityReducer: {isLoading}} = this.props;
    const labels = msg.security || {};
    return(
      <div className="security">
       {
         isLoading && <Loader />
       }
      
       <div className="security-header"> 
          <div className="security-title">
            <div className="logo">  
            <img alt="#" src={logo}/>
            </div>
            <div className="text">
            <label> {labels.title} </label> </div>
            </div>
            <div className="logo-right">  
              <img alt="#" src={logoRight}/>
            </div>
        </div>
        <div className="security-content">
        <div className="security-body"> 
          <div className="tip"> {labels.tip}</div>
          <div className="info">
            <div><img alt="#" src={iconInfo}/> </div>
            <div className="info-tip"> <span>{labels.info}</span></div>
          </div>
          <div className="items">
          <div className="item" dangerouslySetInnerHTML={this.createMarkup(labels.line_one)} />
          <div className="item" dangerouslySetInnerHTML={this.createMarkup(labels.line_two)} />
          <div className="item" dangerouslySetInnerHTML={this.createMarkup(labels.line_three)} />
          </div>
          <div className="security-footer"> 
            <PrimaryButton 
              label={labels.agree} 
              onClick={this.handleProcess.bind(this)}
            />
          </div>
        </div>
        </div>
      </div>
    );
  }
}

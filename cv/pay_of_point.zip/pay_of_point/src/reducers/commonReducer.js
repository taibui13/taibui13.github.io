import * as types from './../actions/actionTypes';
import {REDEEM} from '../common/constant'
const initialState = {
  isLoading: false,
  appData: null,
  messageContent: '',
  inlineMessage: '',
  errorType: '',
  msg: null
};

const commonReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.INITIAL_APP_DATA:
      return { ...state, appData: action.appData };

    case types.INITIAL_APP_MSG:
      return { ...state, msg: action.msg };  

    case types.SET_APP_LOADING_STATUS:
      return { ...state, isLoading: action.isLoading };

    case types.SET_ERROR_CONTENT_MESSAGE:
      return { ...state, messageContent: action.messageContent, errorType: action.errorType };

    case types.SET_INLINE_ERROR_MESSAGE:
      return { ...state, inlineMessage: action.inlineMessage };

    case types.SET_JWT_TOKEN:
      return { ...state, accessToken: action.accessToken };
    
    case types.INITIAL_APP_INPUT_DATA:
      let appData = state.appData;
      const res = action.payload.res;
      (action.payload.steps || []).forEach(e => {
        if(appData[e] && appData[e].inputContent && appData[e].inputContent[0]) {
          appData[e].inputContent[0].min = Number(res.redeemBlockValue) * (Number(res.minRedeemBlock) || REDEEM.MIN_BLOCK);
          appData[e].inputContent[0].minBlocK = Number(res.redeemBlockValue) || REDEEM.MIN_BLOCK;
          if(Number(res.maxRedeemPoints) === 0 && Number(res.maxNbrRedeemBlocks) === 0 && Number(res.maxRedeemValue) === 0) {
            appData[e].inputContent[0].isFullRedeem = true;
          } else {
            appData[e].inputContent[0].isFullRedeem = false;
          }
          appData[e].inputContent[0].max = Number(res.fullRedeemValue) === 0 ? Number(res.maxRedeemValue) : Number(res.fullRedeemValue);
          appData[e].inputContent[0].fullpoint = Number(res.fullRedeemPoints);
          appData[e].inputContent[0].redeemBlockSize = Number(res.redeemBlockSize) / (Number(res.redeemBlockValue) || REDEEM.MIN_BLOCK);
          appData[e].inputContent[0].poolbalance = Number(res.poolBalance);
          appData[e].inputContent[0].isLoaded = true;
        }
      });
      return { ...state, appData: appData };  

    default:
      return state;
  }
}

export default commonReducer;

import { combineReducers } from 'redux';
import commonReducer from './commonReducer';
import chatBotReducer from '../containers/chatBot/modules/chatBotReducer';
import securityReducer from '../containers/secutity/modules/securityReducer';

export default combineReducers({
    commonReducer,
    chatBotReducer,
    securityReducer
});

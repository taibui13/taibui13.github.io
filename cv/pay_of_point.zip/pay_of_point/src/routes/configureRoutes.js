import React from 'react';
import { Switch, Route } from 'react-router-dom';
import { detectPathName } from './../common/utils';
import  Applicant from './../containers/applicant';
import  Secutity from './../containers/secutity';
import  Complete from './../containers/complete';
import  Error from './../containers/error';
import { wrapHOC } from '../pages/WrappedComponent';

const configureRoutes = () => (
  <main>
    <Switch>
    <Route exact path={detectPathName()} component={wrapHOC(Secutity)} />  
    <Route path={`${detectPathName()}redeem`} component={wrapHOC(Applicant)} />
    <Route path={`${detectPathName()}complete`} component={wrapHOC(Complete)} />
    <Route path={`${detectPathName()}error`} component={wrapHOC(Error)} />
    </Switch>
  </main>
);

export default configureRoutes;

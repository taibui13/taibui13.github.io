<template>
  <div class='uob-form-loan'>
          <div class='uob-form-loan-container'>
            <div class='uob-header-wrap'>
              <div class='uob-header'>
              </div>
              <!-- {
               commonReducer.isLoading && <Loader />
              } -->
            </div>
            <div class='uob-body'>
              <router-view/>
            </div>
          </div>
          <!-- {
          (commonReducer.messageContent !== '') &&
            <GenericErrorMessage {...this.props} interval={45} messageContent={commonReducer.messageContent} onClearMessage={this.handleOnClearMessage.bind(this)} />
          } -->
    </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style src="./styles/core.scss"></style>
<style src="./assets/css/container.scss"></style>
<style lang="scss">
@import '../node_modules/bootstrap/dist/css/bootstrap.css';
@import '../node_modules/bootstrap/scss/bootstrap.scss';
</style>

<template>
  <div class="uob-container">
    <div class="uob-content">
       <basicDetail> </basicDetail>
    </div>  
  </div>
</template>

<style ></style>
<script>
 import BasicDetail from '../basicDetail'
 export default {
        data () {
            return {
                message: 'Hello World'
            }
        },
         components: {
          BasicDetail
        }
  }
</script>
export {default} from './applicant.vue'


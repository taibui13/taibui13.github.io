import Vue from 'vue'

export {default} from './view/basic.vue'

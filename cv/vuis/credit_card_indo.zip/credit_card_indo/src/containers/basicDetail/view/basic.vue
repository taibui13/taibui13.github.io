<script>
export default {
    data: () => {
      return {
        firstName : {name: "", type: "", message: ""}, 
        lastName : {name: "", type: "", message: ""}, 
        fullName : {name: "", type: "", message: ""}, 
        isOherName: false,
        countries: ["australia", "brazil", "japan", "united-states"],
      }
    },
};
</script>

<template>
    <section>
    <div class="basic-detail">
      <h1 class="title"> Basic Detail </h1>
      <div class="row">
        <div class="col">
          <b-field label="First Name">
            <b-input v-model="firstName.name" ></b-input>
          </b-field>
        </div>
        <div class="col">
            <b-field label="Last Name">
            <b-input v-model="lastName.name"></b-input>
          </b-field>
        </div>
        </div>
        <div class="row">
            <div class="col-10"> Do you have other name?
            </div>
            <div class="col-2">
                 <b-switch v-model="isOherName">
              
                </b-switch>
            </div>
        </div>
         <div class="row" v-if="isOherName">
             <div class="col">
                <b-field label="Last Name">
                  <b-input v-model="lastName.name"></b-input>
                </b-field>
        </div>
        </div>
         <div class="row">
             <div class="col">
                <div class="md-layout-item">
                    <md-field>
                        <label for="country">Disabled Options</label>
                        <md-select v-model="country" name="country" id="country">
                            <md-option value="country"  v-for="country in countries">
                                {{country}}
                            </md-option>
                       
                        </md-select>
                    </md-field>
                </div>
            </div>
        </div>
     </div>
    </section>
</template>

<style  src="./basic.scss" rel='stylesheet/scss'></style>
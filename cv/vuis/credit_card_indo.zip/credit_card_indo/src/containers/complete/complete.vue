<template>
  <div class="rating">
      complete
  </div>
</template>

<style ></style>
<script></script>
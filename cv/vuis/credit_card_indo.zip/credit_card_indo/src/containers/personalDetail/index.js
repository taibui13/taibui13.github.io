export {default} from './view/personal.vue'

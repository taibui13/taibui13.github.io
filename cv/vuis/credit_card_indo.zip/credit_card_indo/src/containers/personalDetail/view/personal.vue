<template>
    <div>
       <h1> personal detail </h1>
    </div>
</template>

<style src="./personal.scss"></style>
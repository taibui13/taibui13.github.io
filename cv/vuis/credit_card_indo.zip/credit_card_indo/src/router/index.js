import Vue from 'vue'
import Router from 'vue-router'
import Complete from '@/containers/complete'
import Applicant from '@/containers/applicant'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'Applicant',
      component: Applicant
    },
    {
      path: '/apply',
      name: 'Applicant',
      component: Applicant
    },
    {
      path: '/complete',
      name: 'Complete',
      component: Complete
    }
  ]
})

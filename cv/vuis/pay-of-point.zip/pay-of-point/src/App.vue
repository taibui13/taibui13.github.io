<template>
  <div id="app">
    {{msg}}
    <Loader v-if="$store.state.common.isLoading" />
    <router-view/>
  </div>
</template>

<script>
import Loader from './components/Loader';
export default {
  name: 'App',
    data() {
      return {
        isShow: false,
        msg: "1234557"
      }
    },
  components: {Loader}
}
</script>

<style lang="scss" src="./styles/core.scss"></style>



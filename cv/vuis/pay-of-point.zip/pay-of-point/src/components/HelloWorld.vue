<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    {{$store.state.common.msg.security}}
    <h2>Essential Links</h2>
     <button v-on:click="add(1, 2 ,3, 4)">Add 1</button>
     <button @click="goDetail">Next</button>
     <h3 @click="goDetail('123456')" >Click</h3>
     <p>The button above has been clicked {{ counter }} times.</p>
  </div>
</template>

<script>
export default {
    name: 'HelloWorld',
    data() {
      return {
        msg: 'Pay of point',
        counter: 0
      }
    },
    methods: {
      add: (counter, a, b, c) => {
        alert("sas: " + counter);
      },
      goDetail(prodId) {
        let proId=prodId
        this.$router.push({name:'details', params:{Pid:proId}})
      }
    
    },
    created() {
      console.log("12345");
    },
    mounted() {
      this.$store.dispatch('common/getInitialData', 123456789);
    },
    destroyed() {
      console.log("456789");
    }
}
</script>

<style scoped>
  h1, h2 {
    font-weight: normal;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    display: inline-block;
    margin: 0 10px;
  }
  a {
    color: #42b983;
  }
</style>

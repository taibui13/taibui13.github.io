<script>
export default {
    data: () => {
      return {
        isOherName: false,
        
      }
    },
};
</script>

<template>
    <section>
     <div class="loader">
        <div id='fader' class='fade in' v-bind:style="{display: 'block'}" />
        <div class='loader fade in' v-bind:style="{display: 'block'}" ><div /><div /><div /><div /></div>
        <div class='loader-backdrop-sm fade in' v-bind:style="{display: 'block'}" />
        <div class='loader-backdrop fade in' v-bind:style="{display: 'block'}" />
        <div class='loader-text fade in' v-bind:style="{display: 'block'}" />
        </div>
    </section>
</template>

<style  src="./Loader.scss" rel='stylesheet/scss'></style>
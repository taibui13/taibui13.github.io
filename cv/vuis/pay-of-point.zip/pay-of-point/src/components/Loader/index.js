import Vue from 'vue'

export {default} from './Loader.vue'
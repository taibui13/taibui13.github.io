/* global GLOBAL_CONFIG */
export default {
    getFormData: getForm,
    getMessage: getMsg,
    redeem: "/rewards/api/v1/offers/{id}/accept", 
    offer: "/rewards/api/v1/offers/{id}"
}

function getForm() {
  return GLOBAL_CONFIG.formConfig;
}

function getMsg() {
  return  GLOBAL_CONFIG.message;
}
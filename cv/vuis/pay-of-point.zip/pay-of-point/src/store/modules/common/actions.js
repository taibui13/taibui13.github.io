import api from '../../../services/api'
import request from '../../../services/request';

const getInitialData = ({commit}, id) => {
    commit('getData', {type: "isLoading", data: true});
    request.get(api.offer.replace("{id}", id), "payload", "", "").then(res => {
      commit('count', res.data.maxRedeemBlock);
      commit('getData', {type: "data", data: res.data});
      commit('getData', {type: "isLoading", data: false});
    });
    request.getInternal(api.getFormData()).then(res => {
      commit('getData', {type: "chatRule", data: res.data});
    });
    request.getInternal(api.getMessage()).then(res => {
      commit('getData', {type: "msg", data: res.data});
    });
}

export default {
  getInitialData
}  
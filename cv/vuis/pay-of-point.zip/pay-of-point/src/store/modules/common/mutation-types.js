export const FIND = 'FIND';

export default {
  FIND,
};
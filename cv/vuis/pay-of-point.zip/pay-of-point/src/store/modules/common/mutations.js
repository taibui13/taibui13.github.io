
import { FIND } from './mutation-types';

const count = (state, account) => {
  state.app += account;
}

const getData = (state, obj) => {
  state[obj.type] = obj.data;
}

const find = (state, account) => {
  state.email = account.email;
  state.firstName = account.firstName;
  state.lastName = account.lastName;
}

export default {
  count,
  getData,
  [FIND]: find
};

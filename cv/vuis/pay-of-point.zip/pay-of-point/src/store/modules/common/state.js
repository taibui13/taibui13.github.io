export default {
    app: 1000,
    data: {},
    msg: {},
    chatRule: {},
    isLoading: false
  };
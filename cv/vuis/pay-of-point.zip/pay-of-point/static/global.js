const GLOBAL_CONFIG = {
    API_PATH: "./..",
    formConfig: "./static/form.json",
    message: "./static/msg.json"
};

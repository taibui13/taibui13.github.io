<style src="./rating.scss"></style>
<script>
  import 'vue-awesome/icons/star'
  import 'vue-awesome/icons/star-half'
  import Icon from 'vue-awesome/components/Icon'

  export default {
    components: { Icon },
    //props: ['grade', 'maxStars', 'hasCounter'],
    props: {
        grade: {
        type: Number,
        required: true
        },
        maxStars: {
        type: Number,
        default: 5
        },
        hasCounter: {
        type: Boolean,
        default: true
        }
    },
    computed: { // LAZY UPDATE
        counter(grade) {return `${this.stars} of ${this.maxStars} plus ${grade}`}
    },

     data() {
      return {
        stars: this.grade,
        maxStars: this.maxStars,
        hasCounter: this.hasCounter
      }
    },

    methods: {
        rate(star) {
            console.log("start: " + star);
            this.stars = star;
            this.$emit = ("passValueToParent", this.stars);
        }
    }
  }
</script>

<template>
  <div class="rating">
    <ul class="list">
      <li @click="rate(star)" v-for="star in maxStars" :class="{ 'active': star <= stars }" class="star">
        <icon :name="star <= stars ? 'star' : 'star-half'"/>
      </li>
    </ul>
      
   <!-- <span>{{ stars }} of {{ maxStars }}</span> -->
   <!-- <span v-if="hasCounter">{{ stars }} of {{ maxStars }}</span> -->
   <!-- <span>{{ counter }}</span> -->
    <span  v-if="hasCounter">{{ counter }}</span>
  </div>
</template>

<style scoped>
 .rating {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    font-size: 14px;
    color: #a7a8a8;
  }
</style>

<script>
  export default {
    watch: {
  	searchQuery: function(query) {
      this.isSearching = true;
      let vm = this;
      setTimeout(function() {
      	vm.results = ['JavaScript', 'PHP', 'MySQL'];
		vm.isSearching = false;
      }, 500);
    }},
     data() {
      return {
          searchQuery: '',
          results: [],
          isSearching: false
      }
    }
  }
</script>

<template>
    <div>
    <input type="text" v-model="searchQuery">
        <p v-if="isSearching">Searching...</p>
        <div v-else>
            <ol>
            <li v-for="result in results">{{ result }}</li>
            </ol>
        </div>
    </div>
</template>


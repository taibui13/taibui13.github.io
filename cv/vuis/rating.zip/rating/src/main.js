import Vue from 'vue'
import App from './App.vue'
import Rating from './components/rating'
import Search from './components/search'

new Vue({
  el: '#app',
  render: h => h(Search),
  // template: '<Rating :grade="2" :maxStars="5" :hasCounter="true" @passValueToParent="showValue" />',
  // components: { Rating },
  methods: {
    showValue: (data) => {
      console.log("show value: " + data)
    }
  }
})

/* ============
 * Dutch Language File
 * ============
 *
 * An example language file.
 */

import * as auth from './auth.json';

export default {
  auth,
};

/* ============
 * Font Awesome
 * ============
 *
 * Font Awesome gives you scalable vector icons that can instantly
 * be customized — size, color, drop shadow, and anything that can
 * be done with the power of CSS.
 *
 * http://fontawesome.io/
 */

import 'font-awesome/css/font-awesome.css';

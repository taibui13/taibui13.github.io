
export default {
  email: null,
  firstName: null,
  lastName: null,
};
